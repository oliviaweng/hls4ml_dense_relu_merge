#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_int.h"
#include "ap_fixed.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

//hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 28
#define N_INPUT_2_1 28
#define N_SIZE_1_2 784
#define N_LAYER_5 128
#define N_LAYER_6 10

//hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<12,7> flatten_input_default_t;
typedef nnet::array<ap_fixed<12,7>, 28*1> input_t;
typedef ap_fixed<12,7> model_default_t;
typedef ap_fixed<12,7> dense_default_t;
typedef nnet::array<ap_fixed<12,7>, 128*1> layer3_t;
typedef ap_fixed<8,3> dense_weight_t;
typedef ap_fixed<8,3> dense_bias_t;
typedef nnet::array<ap_fixed<9,3,AP_RND,AP_SAT>, 128*1> layer5_t;
typedef ap_fixed<12,7> dense_1_default_t;
typedef nnet::array<ap_fixed<12,7>, 10*1> layer6_t;

#endif
