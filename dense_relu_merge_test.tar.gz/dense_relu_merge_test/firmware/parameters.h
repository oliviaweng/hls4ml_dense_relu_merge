#ifndef PARAMETERS_H_
#define PARAMETERS_H_

#include "ap_int.h"
#include "ap_fixed.h"

#include "nnet_utils/nnet_helpers.h"
//hls-fpga-machine-learning insert includes
#include "nnet_utils/nnet_dense.h"
#include "nnet_utils/nnet_dense_compressed.h"
#include "nnet_utils/nnet_dense_stream.h"
 
//hls-fpga-machine-learning insert weights
#include "weights/w3.h"
#include "weights/b3.h"
#include "weights/w6.h"
#include "weights/b6.h"

//hls-fpga-machine-learning insert layer-config
// dense
struct config5 : nnet::dense_config {
    static const unsigned n_in = N_SIZE_1_2;
    static const unsigned n_out = N_LAYER_5;
    static const unsigned io_type = nnet::io_stream;
    static const unsigned strategy = nnet::resource;
    static const unsigned reuse_factor = 12544;
    static const unsigned n_zeros = 0;
    static const unsigned n_nonzeros = 100352;
    static const bool merged_relu = true;
    static const bool store_weights_in_bram = false;
    typedef ap_fixed<12,7> accum_t;
    typedef dense_bias_t bias_t;
    typedef dense_weight_t weight_t;
    typedef ap_uint<1> index_t;
    typedef layer5_t:: value_type out_t;
    template<class x_T, class y_T, class res_T>
    using product = nnet::product::mult<x_T, y_T, res_T>;
};

// dense_1
struct config6 : nnet::dense_config {
    static const unsigned n_in = N_LAYER_5;
    static const unsigned n_out = N_LAYER_6;
    static const unsigned io_type = nnet::io_stream;
    static const unsigned strategy = nnet::resource;
    static const unsigned reuse_factor = 1280;
    static const unsigned n_zeros = 0;
    static const unsigned n_nonzeros = 1280;
    static const bool merged_relu = false;
    static const bool store_weights_in_bram = false;
    typedef ap_fixed<12,7> accum_t;
    typedef dense_1_default_t bias_t;
    typedef dense_1_default_t weight_t;
    typedef ap_uint<1> index_t;
    typedef layer6_t:: value_type out_t;
    template<class x_T, class y_T, class res_T>
    using product = nnet::product::mult<x_T, y_T, res_T>;
};


#endif
