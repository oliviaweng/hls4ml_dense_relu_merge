//Numpy array shape [10]
//Min -0.102602109313
//Max 0.099779352546
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
dense_1_default_t b6[10];
#else
dense_1_default_t b6[10] = {-0.06447, 0.03094, -0.00272, -0.10260, 0.03854, 0.09978, 0.03150, 0.02410, -0.00140, -0.06884};
#endif

#endif
