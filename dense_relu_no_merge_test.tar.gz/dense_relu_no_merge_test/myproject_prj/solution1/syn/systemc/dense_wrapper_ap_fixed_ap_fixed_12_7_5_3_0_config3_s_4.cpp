#include "dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_481_V_read756_phi_phi_fu_23270_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_481_V_read756_phi_phi_fu_23270_p4 = ap_phi_mux_data_481_V_read756_rewind_phi_fu_13242_p6.read();
    } else {
        ap_phi_mux_data_481_V_read756_phi_phi_fu_23270_p4 = ap_phi_reg_pp0_iter1_data_481_V_read756_phi_reg_23266.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_481_V_read756_rewind_phi_fu_13242_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_481_V_read756_rewind_phi_fu_13242_p6 = data_481_V_read756_phi_reg_23266.read();
    } else {
        ap_phi_mux_data_481_V_read756_rewind_phi_fu_13242_p6 = data_481_V_read756_rewind_reg_13238.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_482_V_read757_phi_phi_fu_23282_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_482_V_read757_phi_phi_fu_23282_p4 = ap_phi_mux_data_482_V_read757_rewind_phi_fu_13256_p6.read();
    } else {
        ap_phi_mux_data_482_V_read757_phi_phi_fu_23282_p4 = ap_phi_reg_pp0_iter1_data_482_V_read757_phi_reg_23278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_482_V_read757_rewind_phi_fu_13256_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_482_V_read757_rewind_phi_fu_13256_p6 = data_482_V_read757_phi_reg_23278.read();
    } else {
        ap_phi_mux_data_482_V_read757_rewind_phi_fu_13256_p6 = data_482_V_read757_rewind_reg_13252.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_483_V_read758_phi_phi_fu_23294_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_483_V_read758_phi_phi_fu_23294_p4 = ap_phi_mux_data_483_V_read758_rewind_phi_fu_13270_p6.read();
    } else {
        ap_phi_mux_data_483_V_read758_phi_phi_fu_23294_p4 = ap_phi_reg_pp0_iter1_data_483_V_read758_phi_reg_23290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_483_V_read758_rewind_phi_fu_13270_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_483_V_read758_rewind_phi_fu_13270_p6 = data_483_V_read758_phi_reg_23290.read();
    } else {
        ap_phi_mux_data_483_V_read758_rewind_phi_fu_13270_p6 = data_483_V_read758_rewind_reg_13266.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_484_V_read759_phi_phi_fu_23306_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_484_V_read759_phi_phi_fu_23306_p4 = ap_phi_mux_data_484_V_read759_rewind_phi_fu_13284_p6.read();
    } else {
        ap_phi_mux_data_484_V_read759_phi_phi_fu_23306_p4 = ap_phi_reg_pp0_iter1_data_484_V_read759_phi_reg_23302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_484_V_read759_rewind_phi_fu_13284_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_484_V_read759_rewind_phi_fu_13284_p6 = data_484_V_read759_phi_reg_23302.read();
    } else {
        ap_phi_mux_data_484_V_read759_rewind_phi_fu_13284_p6 = data_484_V_read759_rewind_reg_13280.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_485_V_read760_phi_phi_fu_23318_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_485_V_read760_phi_phi_fu_23318_p4 = ap_phi_mux_data_485_V_read760_rewind_phi_fu_13298_p6.read();
    } else {
        ap_phi_mux_data_485_V_read760_phi_phi_fu_23318_p4 = ap_phi_reg_pp0_iter1_data_485_V_read760_phi_reg_23314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_485_V_read760_rewind_phi_fu_13298_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_485_V_read760_rewind_phi_fu_13298_p6 = data_485_V_read760_phi_reg_23314.read();
    } else {
        ap_phi_mux_data_485_V_read760_rewind_phi_fu_13298_p6 = data_485_V_read760_rewind_reg_13294.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_486_V_read761_phi_phi_fu_23330_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_486_V_read761_phi_phi_fu_23330_p4 = ap_phi_mux_data_486_V_read761_rewind_phi_fu_13312_p6.read();
    } else {
        ap_phi_mux_data_486_V_read761_phi_phi_fu_23330_p4 = ap_phi_reg_pp0_iter1_data_486_V_read761_phi_reg_23326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_486_V_read761_rewind_phi_fu_13312_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_486_V_read761_rewind_phi_fu_13312_p6 = data_486_V_read761_phi_reg_23326.read();
    } else {
        ap_phi_mux_data_486_V_read761_rewind_phi_fu_13312_p6 = data_486_V_read761_rewind_reg_13308.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_487_V_read762_phi_phi_fu_23342_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_487_V_read762_phi_phi_fu_23342_p4 = ap_phi_mux_data_487_V_read762_rewind_phi_fu_13326_p6.read();
    } else {
        ap_phi_mux_data_487_V_read762_phi_phi_fu_23342_p4 = ap_phi_reg_pp0_iter1_data_487_V_read762_phi_reg_23338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_487_V_read762_rewind_phi_fu_13326_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_487_V_read762_rewind_phi_fu_13326_p6 = data_487_V_read762_phi_reg_23338.read();
    } else {
        ap_phi_mux_data_487_V_read762_rewind_phi_fu_13326_p6 = data_487_V_read762_rewind_reg_13322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_488_V_read763_phi_phi_fu_23354_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_488_V_read763_phi_phi_fu_23354_p4 = ap_phi_mux_data_488_V_read763_rewind_phi_fu_13340_p6.read();
    } else {
        ap_phi_mux_data_488_V_read763_phi_phi_fu_23354_p4 = ap_phi_reg_pp0_iter1_data_488_V_read763_phi_reg_23350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_488_V_read763_rewind_phi_fu_13340_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_488_V_read763_rewind_phi_fu_13340_p6 = data_488_V_read763_phi_reg_23350.read();
    } else {
        ap_phi_mux_data_488_V_read763_rewind_phi_fu_13340_p6 = data_488_V_read763_rewind_reg_13336.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_489_V_read764_phi_phi_fu_23366_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_489_V_read764_phi_phi_fu_23366_p4 = ap_phi_mux_data_489_V_read764_rewind_phi_fu_13354_p6.read();
    } else {
        ap_phi_mux_data_489_V_read764_phi_phi_fu_23366_p4 = ap_phi_reg_pp0_iter1_data_489_V_read764_phi_reg_23362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_489_V_read764_rewind_phi_fu_13354_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_489_V_read764_rewind_phi_fu_13354_p6 = data_489_V_read764_phi_reg_23362.read();
    } else {
        ap_phi_mux_data_489_V_read764_rewind_phi_fu_13354_p6 = data_489_V_read764_rewind_reg_13350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_48_V_read323_phi_phi_fu_18074_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_48_V_read323_phi_phi_fu_18074_p4 = ap_phi_mux_data_48_V_read323_rewind_phi_fu_7180_p6.read();
    } else {
        ap_phi_mux_data_48_V_read323_phi_phi_fu_18074_p4 = ap_phi_reg_pp0_iter1_data_48_V_read323_phi_reg_18070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_48_V_read323_rewind_phi_fu_7180_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_48_V_read323_rewind_phi_fu_7180_p6 = data_48_V_read323_phi_reg_18070.read();
    } else {
        ap_phi_mux_data_48_V_read323_rewind_phi_fu_7180_p6 = data_48_V_read323_rewind_reg_7176.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_490_V_read765_phi_phi_fu_23378_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_490_V_read765_phi_phi_fu_23378_p4 = ap_phi_mux_data_490_V_read765_rewind_phi_fu_13368_p6.read();
    } else {
        ap_phi_mux_data_490_V_read765_phi_phi_fu_23378_p4 = ap_phi_reg_pp0_iter1_data_490_V_read765_phi_reg_23374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_490_V_read765_rewind_phi_fu_13368_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_490_V_read765_rewind_phi_fu_13368_p6 = data_490_V_read765_phi_reg_23374.read();
    } else {
        ap_phi_mux_data_490_V_read765_rewind_phi_fu_13368_p6 = data_490_V_read765_rewind_reg_13364.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_491_V_read766_phi_phi_fu_23390_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_491_V_read766_phi_phi_fu_23390_p4 = ap_phi_mux_data_491_V_read766_rewind_phi_fu_13382_p6.read();
    } else {
        ap_phi_mux_data_491_V_read766_phi_phi_fu_23390_p4 = ap_phi_reg_pp0_iter1_data_491_V_read766_phi_reg_23386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_491_V_read766_rewind_phi_fu_13382_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_491_V_read766_rewind_phi_fu_13382_p6 = data_491_V_read766_phi_reg_23386.read();
    } else {
        ap_phi_mux_data_491_V_read766_rewind_phi_fu_13382_p6 = data_491_V_read766_rewind_reg_13378.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_492_V_read767_phi_phi_fu_23402_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_492_V_read767_phi_phi_fu_23402_p4 = ap_phi_mux_data_492_V_read767_rewind_phi_fu_13396_p6.read();
    } else {
        ap_phi_mux_data_492_V_read767_phi_phi_fu_23402_p4 = ap_phi_reg_pp0_iter1_data_492_V_read767_phi_reg_23398.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_492_V_read767_rewind_phi_fu_13396_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_492_V_read767_rewind_phi_fu_13396_p6 = data_492_V_read767_phi_reg_23398.read();
    } else {
        ap_phi_mux_data_492_V_read767_rewind_phi_fu_13396_p6 = data_492_V_read767_rewind_reg_13392.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_493_V_read768_phi_phi_fu_23414_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_493_V_read768_phi_phi_fu_23414_p4 = ap_phi_mux_data_493_V_read768_rewind_phi_fu_13410_p6.read();
    } else {
        ap_phi_mux_data_493_V_read768_phi_phi_fu_23414_p4 = ap_phi_reg_pp0_iter1_data_493_V_read768_phi_reg_23410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_493_V_read768_rewind_phi_fu_13410_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_493_V_read768_rewind_phi_fu_13410_p6 = data_493_V_read768_phi_reg_23410.read();
    } else {
        ap_phi_mux_data_493_V_read768_rewind_phi_fu_13410_p6 = data_493_V_read768_rewind_reg_13406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_494_V_read769_phi_phi_fu_23426_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_494_V_read769_phi_phi_fu_23426_p4 = ap_phi_mux_data_494_V_read769_rewind_phi_fu_13424_p6.read();
    } else {
        ap_phi_mux_data_494_V_read769_phi_phi_fu_23426_p4 = ap_phi_reg_pp0_iter1_data_494_V_read769_phi_reg_23422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_494_V_read769_rewind_phi_fu_13424_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_494_V_read769_rewind_phi_fu_13424_p6 = data_494_V_read769_phi_reg_23422.read();
    } else {
        ap_phi_mux_data_494_V_read769_rewind_phi_fu_13424_p6 = data_494_V_read769_rewind_reg_13420.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_495_V_read770_phi_phi_fu_23438_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_495_V_read770_phi_phi_fu_23438_p4 = ap_phi_mux_data_495_V_read770_rewind_phi_fu_13438_p6.read();
    } else {
        ap_phi_mux_data_495_V_read770_phi_phi_fu_23438_p4 = ap_phi_reg_pp0_iter1_data_495_V_read770_phi_reg_23434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_495_V_read770_rewind_phi_fu_13438_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_495_V_read770_rewind_phi_fu_13438_p6 = data_495_V_read770_phi_reg_23434.read();
    } else {
        ap_phi_mux_data_495_V_read770_rewind_phi_fu_13438_p6 = data_495_V_read770_rewind_reg_13434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_496_V_read771_phi_phi_fu_23450_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_496_V_read771_phi_phi_fu_23450_p4 = ap_phi_mux_data_496_V_read771_rewind_phi_fu_13452_p6.read();
    } else {
        ap_phi_mux_data_496_V_read771_phi_phi_fu_23450_p4 = ap_phi_reg_pp0_iter1_data_496_V_read771_phi_reg_23446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_496_V_read771_rewind_phi_fu_13452_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_496_V_read771_rewind_phi_fu_13452_p6 = data_496_V_read771_phi_reg_23446.read();
    } else {
        ap_phi_mux_data_496_V_read771_rewind_phi_fu_13452_p6 = data_496_V_read771_rewind_reg_13448.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_497_V_read772_phi_phi_fu_23462_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_497_V_read772_phi_phi_fu_23462_p4 = ap_phi_mux_data_497_V_read772_rewind_phi_fu_13466_p6.read();
    } else {
        ap_phi_mux_data_497_V_read772_phi_phi_fu_23462_p4 = ap_phi_reg_pp0_iter1_data_497_V_read772_phi_reg_23458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_497_V_read772_rewind_phi_fu_13466_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_497_V_read772_rewind_phi_fu_13466_p6 = data_497_V_read772_phi_reg_23458.read();
    } else {
        ap_phi_mux_data_497_V_read772_rewind_phi_fu_13466_p6 = data_497_V_read772_rewind_reg_13462.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_498_V_read773_phi_phi_fu_23474_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_498_V_read773_phi_phi_fu_23474_p4 = ap_phi_mux_data_498_V_read773_rewind_phi_fu_13480_p6.read();
    } else {
        ap_phi_mux_data_498_V_read773_phi_phi_fu_23474_p4 = ap_phi_reg_pp0_iter1_data_498_V_read773_phi_reg_23470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_498_V_read773_rewind_phi_fu_13480_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_498_V_read773_rewind_phi_fu_13480_p6 = data_498_V_read773_phi_reg_23470.read();
    } else {
        ap_phi_mux_data_498_V_read773_rewind_phi_fu_13480_p6 = data_498_V_read773_rewind_reg_13476.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_499_V_read774_phi_phi_fu_23486_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_499_V_read774_phi_phi_fu_23486_p4 = ap_phi_mux_data_499_V_read774_rewind_phi_fu_13494_p6.read();
    } else {
        ap_phi_mux_data_499_V_read774_phi_phi_fu_23486_p4 = ap_phi_reg_pp0_iter1_data_499_V_read774_phi_reg_23482.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_499_V_read774_rewind_phi_fu_13494_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_499_V_read774_rewind_phi_fu_13494_p6 = data_499_V_read774_phi_reg_23482.read();
    } else {
        ap_phi_mux_data_499_V_read774_rewind_phi_fu_13494_p6 = data_499_V_read774_rewind_reg_13490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_49_V_read324_phi_phi_fu_18086_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_49_V_read324_phi_phi_fu_18086_p4 = ap_phi_mux_data_49_V_read324_rewind_phi_fu_7194_p6.read();
    } else {
        ap_phi_mux_data_49_V_read324_phi_phi_fu_18086_p4 = ap_phi_reg_pp0_iter1_data_49_V_read324_phi_reg_18082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_49_V_read324_rewind_phi_fu_7194_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_49_V_read324_rewind_phi_fu_7194_p6 = data_49_V_read324_phi_reg_18082.read();
    } else {
        ap_phi_mux_data_49_V_read324_rewind_phi_fu_7194_p6 = data_49_V_read324_rewind_reg_7190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_4_V_read279_phi_phi_fu_17546_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_4_V_read279_phi_phi_fu_17546_p4 = ap_phi_mux_data_4_V_read279_rewind_phi_fu_6564_p6.read();
    } else {
        ap_phi_mux_data_4_V_read279_phi_phi_fu_17546_p4 = ap_phi_reg_pp0_iter1_data_4_V_read279_phi_reg_17542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_4_V_read279_rewind_phi_fu_6564_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_4_V_read279_rewind_phi_fu_6564_p6 = data_4_V_read279_phi_reg_17542.read();
    } else {
        ap_phi_mux_data_4_V_read279_rewind_phi_fu_6564_p6 = data_4_V_read279_rewind_reg_6560.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_500_V_read775_phi_phi_fu_23498_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_500_V_read775_phi_phi_fu_23498_p4 = ap_phi_mux_data_500_V_read775_rewind_phi_fu_13508_p6.read();
    } else {
        ap_phi_mux_data_500_V_read775_phi_phi_fu_23498_p4 = ap_phi_reg_pp0_iter1_data_500_V_read775_phi_reg_23494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_500_V_read775_rewind_phi_fu_13508_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_500_V_read775_rewind_phi_fu_13508_p6 = data_500_V_read775_phi_reg_23494.read();
    } else {
        ap_phi_mux_data_500_V_read775_rewind_phi_fu_13508_p6 = data_500_V_read775_rewind_reg_13504.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_501_V_read776_phi_phi_fu_23510_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_501_V_read776_phi_phi_fu_23510_p4 = ap_phi_mux_data_501_V_read776_rewind_phi_fu_13522_p6.read();
    } else {
        ap_phi_mux_data_501_V_read776_phi_phi_fu_23510_p4 = ap_phi_reg_pp0_iter1_data_501_V_read776_phi_reg_23506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_501_V_read776_rewind_phi_fu_13522_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_501_V_read776_rewind_phi_fu_13522_p6 = data_501_V_read776_phi_reg_23506.read();
    } else {
        ap_phi_mux_data_501_V_read776_rewind_phi_fu_13522_p6 = data_501_V_read776_rewind_reg_13518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_502_V_read777_phi_phi_fu_23522_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_502_V_read777_phi_phi_fu_23522_p4 = ap_phi_mux_data_502_V_read777_rewind_phi_fu_13536_p6.read();
    } else {
        ap_phi_mux_data_502_V_read777_phi_phi_fu_23522_p4 = ap_phi_reg_pp0_iter1_data_502_V_read777_phi_reg_23518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_502_V_read777_rewind_phi_fu_13536_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_502_V_read777_rewind_phi_fu_13536_p6 = data_502_V_read777_phi_reg_23518.read();
    } else {
        ap_phi_mux_data_502_V_read777_rewind_phi_fu_13536_p6 = data_502_V_read777_rewind_reg_13532.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_503_V_read778_phi_phi_fu_23534_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_503_V_read778_phi_phi_fu_23534_p4 = ap_phi_mux_data_503_V_read778_rewind_phi_fu_13550_p6.read();
    } else {
        ap_phi_mux_data_503_V_read778_phi_phi_fu_23534_p4 = ap_phi_reg_pp0_iter1_data_503_V_read778_phi_reg_23530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_503_V_read778_rewind_phi_fu_13550_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_503_V_read778_rewind_phi_fu_13550_p6 = data_503_V_read778_phi_reg_23530.read();
    } else {
        ap_phi_mux_data_503_V_read778_rewind_phi_fu_13550_p6 = data_503_V_read778_rewind_reg_13546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_504_V_read779_phi_phi_fu_23546_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_504_V_read779_phi_phi_fu_23546_p4 = ap_phi_mux_data_504_V_read779_rewind_phi_fu_13564_p6.read();
    } else {
        ap_phi_mux_data_504_V_read779_phi_phi_fu_23546_p4 = ap_phi_reg_pp0_iter1_data_504_V_read779_phi_reg_23542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_504_V_read779_rewind_phi_fu_13564_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_504_V_read779_rewind_phi_fu_13564_p6 = data_504_V_read779_phi_reg_23542.read();
    } else {
        ap_phi_mux_data_504_V_read779_rewind_phi_fu_13564_p6 = data_504_V_read779_rewind_reg_13560.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_505_V_read780_phi_phi_fu_23558_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_505_V_read780_phi_phi_fu_23558_p4 = ap_phi_mux_data_505_V_read780_rewind_phi_fu_13578_p6.read();
    } else {
        ap_phi_mux_data_505_V_read780_phi_phi_fu_23558_p4 = ap_phi_reg_pp0_iter1_data_505_V_read780_phi_reg_23554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_505_V_read780_rewind_phi_fu_13578_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_505_V_read780_rewind_phi_fu_13578_p6 = data_505_V_read780_phi_reg_23554.read();
    } else {
        ap_phi_mux_data_505_V_read780_rewind_phi_fu_13578_p6 = data_505_V_read780_rewind_reg_13574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_506_V_read781_phi_phi_fu_23570_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_506_V_read781_phi_phi_fu_23570_p4 = ap_phi_mux_data_506_V_read781_rewind_phi_fu_13592_p6.read();
    } else {
        ap_phi_mux_data_506_V_read781_phi_phi_fu_23570_p4 = ap_phi_reg_pp0_iter1_data_506_V_read781_phi_reg_23566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_506_V_read781_rewind_phi_fu_13592_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_506_V_read781_rewind_phi_fu_13592_p6 = data_506_V_read781_phi_reg_23566.read();
    } else {
        ap_phi_mux_data_506_V_read781_rewind_phi_fu_13592_p6 = data_506_V_read781_rewind_reg_13588.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_507_V_read782_phi_phi_fu_23582_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_507_V_read782_phi_phi_fu_23582_p4 = ap_phi_mux_data_507_V_read782_rewind_phi_fu_13606_p6.read();
    } else {
        ap_phi_mux_data_507_V_read782_phi_phi_fu_23582_p4 = ap_phi_reg_pp0_iter1_data_507_V_read782_phi_reg_23578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_507_V_read782_rewind_phi_fu_13606_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_507_V_read782_rewind_phi_fu_13606_p6 = data_507_V_read782_phi_reg_23578.read();
    } else {
        ap_phi_mux_data_507_V_read782_rewind_phi_fu_13606_p6 = data_507_V_read782_rewind_reg_13602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_508_V_read783_phi_phi_fu_23594_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_508_V_read783_phi_phi_fu_23594_p4 = ap_phi_mux_data_508_V_read783_rewind_phi_fu_13620_p6.read();
    } else {
        ap_phi_mux_data_508_V_read783_phi_phi_fu_23594_p4 = ap_phi_reg_pp0_iter1_data_508_V_read783_phi_reg_23590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_508_V_read783_rewind_phi_fu_13620_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_508_V_read783_rewind_phi_fu_13620_p6 = data_508_V_read783_phi_reg_23590.read();
    } else {
        ap_phi_mux_data_508_V_read783_rewind_phi_fu_13620_p6 = data_508_V_read783_rewind_reg_13616.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_509_V_read784_phi_phi_fu_23606_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_509_V_read784_phi_phi_fu_23606_p4 = ap_phi_mux_data_509_V_read784_rewind_phi_fu_13634_p6.read();
    } else {
        ap_phi_mux_data_509_V_read784_phi_phi_fu_23606_p4 = ap_phi_reg_pp0_iter1_data_509_V_read784_phi_reg_23602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_509_V_read784_rewind_phi_fu_13634_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_509_V_read784_rewind_phi_fu_13634_p6 = data_509_V_read784_phi_reg_23602.read();
    } else {
        ap_phi_mux_data_509_V_read784_rewind_phi_fu_13634_p6 = data_509_V_read784_rewind_reg_13630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_50_V_read325_phi_phi_fu_18098_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_50_V_read325_phi_phi_fu_18098_p4 = ap_phi_mux_data_50_V_read325_rewind_phi_fu_7208_p6.read();
    } else {
        ap_phi_mux_data_50_V_read325_phi_phi_fu_18098_p4 = ap_phi_reg_pp0_iter1_data_50_V_read325_phi_reg_18094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_50_V_read325_rewind_phi_fu_7208_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_50_V_read325_rewind_phi_fu_7208_p6 = data_50_V_read325_phi_reg_18094.read();
    } else {
        ap_phi_mux_data_50_V_read325_rewind_phi_fu_7208_p6 = data_50_V_read325_rewind_reg_7204.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_510_V_read785_phi_phi_fu_23618_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_510_V_read785_phi_phi_fu_23618_p4 = ap_phi_mux_data_510_V_read785_rewind_phi_fu_13648_p6.read();
    } else {
        ap_phi_mux_data_510_V_read785_phi_phi_fu_23618_p4 = ap_phi_reg_pp0_iter1_data_510_V_read785_phi_reg_23614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_510_V_read785_rewind_phi_fu_13648_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_510_V_read785_rewind_phi_fu_13648_p6 = data_510_V_read785_phi_reg_23614.read();
    } else {
        ap_phi_mux_data_510_V_read785_rewind_phi_fu_13648_p6 = data_510_V_read785_rewind_reg_13644.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_511_V_read786_phi_phi_fu_23630_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_511_V_read786_phi_phi_fu_23630_p4 = ap_phi_mux_data_511_V_read786_rewind_phi_fu_13662_p6.read();
    } else {
        ap_phi_mux_data_511_V_read786_phi_phi_fu_23630_p4 = ap_phi_reg_pp0_iter1_data_511_V_read786_phi_reg_23626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_511_V_read786_rewind_phi_fu_13662_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_511_V_read786_rewind_phi_fu_13662_p6 = data_511_V_read786_phi_reg_23626.read();
    } else {
        ap_phi_mux_data_511_V_read786_rewind_phi_fu_13662_p6 = data_511_V_read786_rewind_reg_13658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_512_V_read787_phi_phi_fu_23642_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_512_V_read787_phi_phi_fu_23642_p4 = ap_phi_mux_data_512_V_read787_rewind_phi_fu_13676_p6.read();
    } else {
        ap_phi_mux_data_512_V_read787_phi_phi_fu_23642_p4 = ap_phi_reg_pp0_iter1_data_512_V_read787_phi_reg_23638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_512_V_read787_rewind_phi_fu_13676_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_512_V_read787_rewind_phi_fu_13676_p6 = data_512_V_read787_phi_reg_23638.read();
    } else {
        ap_phi_mux_data_512_V_read787_rewind_phi_fu_13676_p6 = data_512_V_read787_rewind_reg_13672.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_513_V_read788_phi_phi_fu_23654_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_513_V_read788_phi_phi_fu_23654_p4 = ap_phi_mux_data_513_V_read788_rewind_phi_fu_13690_p6.read();
    } else {
        ap_phi_mux_data_513_V_read788_phi_phi_fu_23654_p4 = ap_phi_reg_pp0_iter1_data_513_V_read788_phi_reg_23650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_513_V_read788_rewind_phi_fu_13690_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_513_V_read788_rewind_phi_fu_13690_p6 = data_513_V_read788_phi_reg_23650.read();
    } else {
        ap_phi_mux_data_513_V_read788_rewind_phi_fu_13690_p6 = data_513_V_read788_rewind_reg_13686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_514_V_read789_phi_phi_fu_23666_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_514_V_read789_phi_phi_fu_23666_p4 = ap_phi_mux_data_514_V_read789_rewind_phi_fu_13704_p6.read();
    } else {
        ap_phi_mux_data_514_V_read789_phi_phi_fu_23666_p4 = ap_phi_reg_pp0_iter1_data_514_V_read789_phi_reg_23662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_514_V_read789_rewind_phi_fu_13704_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_514_V_read789_rewind_phi_fu_13704_p6 = data_514_V_read789_phi_reg_23662.read();
    } else {
        ap_phi_mux_data_514_V_read789_rewind_phi_fu_13704_p6 = data_514_V_read789_rewind_reg_13700.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_515_V_read790_phi_phi_fu_23678_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_515_V_read790_phi_phi_fu_23678_p4 = ap_phi_mux_data_515_V_read790_rewind_phi_fu_13718_p6.read();
    } else {
        ap_phi_mux_data_515_V_read790_phi_phi_fu_23678_p4 = ap_phi_reg_pp0_iter1_data_515_V_read790_phi_reg_23674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_515_V_read790_rewind_phi_fu_13718_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_515_V_read790_rewind_phi_fu_13718_p6 = data_515_V_read790_phi_reg_23674.read();
    } else {
        ap_phi_mux_data_515_V_read790_rewind_phi_fu_13718_p6 = data_515_V_read790_rewind_reg_13714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_516_V_read791_phi_phi_fu_23690_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_516_V_read791_phi_phi_fu_23690_p4 = ap_phi_mux_data_516_V_read791_rewind_phi_fu_13732_p6.read();
    } else {
        ap_phi_mux_data_516_V_read791_phi_phi_fu_23690_p4 = ap_phi_reg_pp0_iter1_data_516_V_read791_phi_reg_23686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_516_V_read791_rewind_phi_fu_13732_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_516_V_read791_rewind_phi_fu_13732_p6 = data_516_V_read791_phi_reg_23686.read();
    } else {
        ap_phi_mux_data_516_V_read791_rewind_phi_fu_13732_p6 = data_516_V_read791_rewind_reg_13728.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_517_V_read792_phi_phi_fu_23702_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_517_V_read792_phi_phi_fu_23702_p4 = ap_phi_mux_data_517_V_read792_rewind_phi_fu_13746_p6.read();
    } else {
        ap_phi_mux_data_517_V_read792_phi_phi_fu_23702_p4 = ap_phi_reg_pp0_iter1_data_517_V_read792_phi_reg_23698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_517_V_read792_rewind_phi_fu_13746_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_517_V_read792_rewind_phi_fu_13746_p6 = data_517_V_read792_phi_reg_23698.read();
    } else {
        ap_phi_mux_data_517_V_read792_rewind_phi_fu_13746_p6 = data_517_V_read792_rewind_reg_13742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_518_V_read793_phi_phi_fu_23714_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_518_V_read793_phi_phi_fu_23714_p4 = ap_phi_mux_data_518_V_read793_rewind_phi_fu_13760_p6.read();
    } else {
        ap_phi_mux_data_518_V_read793_phi_phi_fu_23714_p4 = ap_phi_reg_pp0_iter1_data_518_V_read793_phi_reg_23710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_518_V_read793_rewind_phi_fu_13760_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_518_V_read793_rewind_phi_fu_13760_p6 = data_518_V_read793_phi_reg_23710.read();
    } else {
        ap_phi_mux_data_518_V_read793_rewind_phi_fu_13760_p6 = data_518_V_read793_rewind_reg_13756.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_519_V_read794_phi_phi_fu_23726_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_519_V_read794_phi_phi_fu_23726_p4 = ap_phi_mux_data_519_V_read794_rewind_phi_fu_13774_p6.read();
    } else {
        ap_phi_mux_data_519_V_read794_phi_phi_fu_23726_p4 = ap_phi_reg_pp0_iter1_data_519_V_read794_phi_reg_23722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_519_V_read794_rewind_phi_fu_13774_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_519_V_read794_rewind_phi_fu_13774_p6 = data_519_V_read794_phi_reg_23722.read();
    } else {
        ap_phi_mux_data_519_V_read794_rewind_phi_fu_13774_p6 = data_519_V_read794_rewind_reg_13770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_51_V_read326_phi_phi_fu_18110_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_51_V_read326_phi_phi_fu_18110_p4 = ap_phi_mux_data_51_V_read326_rewind_phi_fu_7222_p6.read();
    } else {
        ap_phi_mux_data_51_V_read326_phi_phi_fu_18110_p4 = ap_phi_reg_pp0_iter1_data_51_V_read326_phi_reg_18106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_51_V_read326_rewind_phi_fu_7222_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_51_V_read326_rewind_phi_fu_7222_p6 = data_51_V_read326_phi_reg_18106.read();
    } else {
        ap_phi_mux_data_51_V_read326_rewind_phi_fu_7222_p6 = data_51_V_read326_rewind_reg_7218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_520_V_read795_phi_phi_fu_23738_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_520_V_read795_phi_phi_fu_23738_p4 = ap_phi_mux_data_520_V_read795_rewind_phi_fu_13788_p6.read();
    } else {
        ap_phi_mux_data_520_V_read795_phi_phi_fu_23738_p4 = ap_phi_reg_pp0_iter1_data_520_V_read795_phi_reg_23734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_520_V_read795_rewind_phi_fu_13788_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_520_V_read795_rewind_phi_fu_13788_p6 = data_520_V_read795_phi_reg_23734.read();
    } else {
        ap_phi_mux_data_520_V_read795_rewind_phi_fu_13788_p6 = data_520_V_read795_rewind_reg_13784.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_521_V_read796_phi_phi_fu_23750_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_521_V_read796_phi_phi_fu_23750_p4 = ap_phi_mux_data_521_V_read796_rewind_phi_fu_13802_p6.read();
    } else {
        ap_phi_mux_data_521_V_read796_phi_phi_fu_23750_p4 = ap_phi_reg_pp0_iter1_data_521_V_read796_phi_reg_23746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_521_V_read796_rewind_phi_fu_13802_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_521_V_read796_rewind_phi_fu_13802_p6 = data_521_V_read796_phi_reg_23746.read();
    } else {
        ap_phi_mux_data_521_V_read796_rewind_phi_fu_13802_p6 = data_521_V_read796_rewind_reg_13798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_522_V_read797_phi_phi_fu_23762_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_522_V_read797_phi_phi_fu_23762_p4 = ap_phi_mux_data_522_V_read797_rewind_phi_fu_13816_p6.read();
    } else {
        ap_phi_mux_data_522_V_read797_phi_phi_fu_23762_p4 = ap_phi_reg_pp0_iter1_data_522_V_read797_phi_reg_23758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_522_V_read797_rewind_phi_fu_13816_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_522_V_read797_rewind_phi_fu_13816_p6 = data_522_V_read797_phi_reg_23758.read();
    } else {
        ap_phi_mux_data_522_V_read797_rewind_phi_fu_13816_p6 = data_522_V_read797_rewind_reg_13812.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_523_V_read798_phi_phi_fu_23774_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_523_V_read798_phi_phi_fu_23774_p4 = ap_phi_mux_data_523_V_read798_rewind_phi_fu_13830_p6.read();
    } else {
        ap_phi_mux_data_523_V_read798_phi_phi_fu_23774_p4 = ap_phi_reg_pp0_iter1_data_523_V_read798_phi_reg_23770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_523_V_read798_rewind_phi_fu_13830_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_523_V_read798_rewind_phi_fu_13830_p6 = data_523_V_read798_phi_reg_23770.read();
    } else {
        ap_phi_mux_data_523_V_read798_rewind_phi_fu_13830_p6 = data_523_V_read798_rewind_reg_13826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_524_V_read799_phi_phi_fu_23786_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_524_V_read799_phi_phi_fu_23786_p4 = ap_phi_mux_data_524_V_read799_rewind_phi_fu_13844_p6.read();
    } else {
        ap_phi_mux_data_524_V_read799_phi_phi_fu_23786_p4 = ap_phi_reg_pp0_iter1_data_524_V_read799_phi_reg_23782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_524_V_read799_rewind_phi_fu_13844_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_524_V_read799_rewind_phi_fu_13844_p6 = data_524_V_read799_phi_reg_23782.read();
    } else {
        ap_phi_mux_data_524_V_read799_rewind_phi_fu_13844_p6 = data_524_V_read799_rewind_reg_13840.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_525_V_read800_phi_phi_fu_23798_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_525_V_read800_phi_phi_fu_23798_p4 = ap_phi_mux_data_525_V_read800_rewind_phi_fu_13858_p6.read();
    } else {
        ap_phi_mux_data_525_V_read800_phi_phi_fu_23798_p4 = ap_phi_reg_pp0_iter1_data_525_V_read800_phi_reg_23794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_525_V_read800_rewind_phi_fu_13858_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_525_V_read800_rewind_phi_fu_13858_p6 = data_525_V_read800_phi_reg_23794.read();
    } else {
        ap_phi_mux_data_525_V_read800_rewind_phi_fu_13858_p6 = data_525_V_read800_rewind_reg_13854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_526_V_read801_phi_phi_fu_23810_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_526_V_read801_phi_phi_fu_23810_p4 = ap_phi_mux_data_526_V_read801_rewind_phi_fu_13872_p6.read();
    } else {
        ap_phi_mux_data_526_V_read801_phi_phi_fu_23810_p4 = ap_phi_reg_pp0_iter1_data_526_V_read801_phi_reg_23806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_526_V_read801_rewind_phi_fu_13872_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_526_V_read801_rewind_phi_fu_13872_p6 = data_526_V_read801_phi_reg_23806.read();
    } else {
        ap_phi_mux_data_526_V_read801_rewind_phi_fu_13872_p6 = data_526_V_read801_rewind_reg_13868.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_527_V_read802_phi_phi_fu_23822_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_527_V_read802_phi_phi_fu_23822_p4 = ap_phi_mux_data_527_V_read802_rewind_phi_fu_13886_p6.read();
    } else {
        ap_phi_mux_data_527_V_read802_phi_phi_fu_23822_p4 = ap_phi_reg_pp0_iter1_data_527_V_read802_phi_reg_23818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_527_V_read802_rewind_phi_fu_13886_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_527_V_read802_rewind_phi_fu_13886_p6 = data_527_V_read802_phi_reg_23818.read();
    } else {
        ap_phi_mux_data_527_V_read802_rewind_phi_fu_13886_p6 = data_527_V_read802_rewind_reg_13882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_528_V_read803_phi_phi_fu_23834_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_528_V_read803_phi_phi_fu_23834_p4 = ap_phi_mux_data_528_V_read803_rewind_phi_fu_13900_p6.read();
    } else {
        ap_phi_mux_data_528_V_read803_phi_phi_fu_23834_p4 = ap_phi_reg_pp0_iter1_data_528_V_read803_phi_reg_23830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_528_V_read803_rewind_phi_fu_13900_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_528_V_read803_rewind_phi_fu_13900_p6 = data_528_V_read803_phi_reg_23830.read();
    } else {
        ap_phi_mux_data_528_V_read803_rewind_phi_fu_13900_p6 = data_528_V_read803_rewind_reg_13896.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_529_V_read804_phi_phi_fu_23846_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_529_V_read804_phi_phi_fu_23846_p4 = ap_phi_mux_data_529_V_read804_rewind_phi_fu_13914_p6.read();
    } else {
        ap_phi_mux_data_529_V_read804_phi_phi_fu_23846_p4 = ap_phi_reg_pp0_iter1_data_529_V_read804_phi_reg_23842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_529_V_read804_rewind_phi_fu_13914_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_529_V_read804_rewind_phi_fu_13914_p6 = data_529_V_read804_phi_reg_23842.read();
    } else {
        ap_phi_mux_data_529_V_read804_rewind_phi_fu_13914_p6 = data_529_V_read804_rewind_reg_13910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_52_V_read327_phi_phi_fu_18122_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_52_V_read327_phi_phi_fu_18122_p4 = ap_phi_mux_data_52_V_read327_rewind_phi_fu_7236_p6.read();
    } else {
        ap_phi_mux_data_52_V_read327_phi_phi_fu_18122_p4 = ap_phi_reg_pp0_iter1_data_52_V_read327_phi_reg_18118.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_52_V_read327_rewind_phi_fu_7236_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_52_V_read327_rewind_phi_fu_7236_p6 = data_52_V_read327_phi_reg_18118.read();
    } else {
        ap_phi_mux_data_52_V_read327_rewind_phi_fu_7236_p6 = data_52_V_read327_rewind_reg_7232.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_530_V_read805_phi_phi_fu_23858_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_530_V_read805_phi_phi_fu_23858_p4 = ap_phi_mux_data_530_V_read805_rewind_phi_fu_13928_p6.read();
    } else {
        ap_phi_mux_data_530_V_read805_phi_phi_fu_23858_p4 = ap_phi_reg_pp0_iter1_data_530_V_read805_phi_reg_23854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_530_V_read805_rewind_phi_fu_13928_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_530_V_read805_rewind_phi_fu_13928_p6 = data_530_V_read805_phi_reg_23854.read();
    } else {
        ap_phi_mux_data_530_V_read805_rewind_phi_fu_13928_p6 = data_530_V_read805_rewind_reg_13924.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_531_V_read806_phi_phi_fu_23870_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_531_V_read806_phi_phi_fu_23870_p4 = ap_phi_mux_data_531_V_read806_rewind_phi_fu_13942_p6.read();
    } else {
        ap_phi_mux_data_531_V_read806_phi_phi_fu_23870_p4 = ap_phi_reg_pp0_iter1_data_531_V_read806_phi_reg_23866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_531_V_read806_rewind_phi_fu_13942_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_531_V_read806_rewind_phi_fu_13942_p6 = data_531_V_read806_phi_reg_23866.read();
    } else {
        ap_phi_mux_data_531_V_read806_rewind_phi_fu_13942_p6 = data_531_V_read806_rewind_reg_13938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_532_V_read807_phi_phi_fu_23882_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_532_V_read807_phi_phi_fu_23882_p4 = ap_phi_mux_data_532_V_read807_rewind_phi_fu_13956_p6.read();
    } else {
        ap_phi_mux_data_532_V_read807_phi_phi_fu_23882_p4 = ap_phi_reg_pp0_iter1_data_532_V_read807_phi_reg_23878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_532_V_read807_rewind_phi_fu_13956_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_532_V_read807_rewind_phi_fu_13956_p6 = data_532_V_read807_phi_reg_23878.read();
    } else {
        ap_phi_mux_data_532_V_read807_rewind_phi_fu_13956_p6 = data_532_V_read807_rewind_reg_13952.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_533_V_read808_phi_phi_fu_23894_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_533_V_read808_phi_phi_fu_23894_p4 = ap_phi_mux_data_533_V_read808_rewind_phi_fu_13970_p6.read();
    } else {
        ap_phi_mux_data_533_V_read808_phi_phi_fu_23894_p4 = ap_phi_reg_pp0_iter1_data_533_V_read808_phi_reg_23890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_533_V_read808_rewind_phi_fu_13970_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_533_V_read808_rewind_phi_fu_13970_p6 = data_533_V_read808_phi_reg_23890.read();
    } else {
        ap_phi_mux_data_533_V_read808_rewind_phi_fu_13970_p6 = data_533_V_read808_rewind_reg_13966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_534_V_read809_phi_phi_fu_23906_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_534_V_read809_phi_phi_fu_23906_p4 = ap_phi_mux_data_534_V_read809_rewind_phi_fu_13984_p6.read();
    } else {
        ap_phi_mux_data_534_V_read809_phi_phi_fu_23906_p4 = ap_phi_reg_pp0_iter1_data_534_V_read809_phi_reg_23902.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_534_V_read809_rewind_phi_fu_13984_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_534_V_read809_rewind_phi_fu_13984_p6 = data_534_V_read809_phi_reg_23902.read();
    } else {
        ap_phi_mux_data_534_V_read809_rewind_phi_fu_13984_p6 = data_534_V_read809_rewind_reg_13980.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_535_V_read810_phi_phi_fu_23918_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_535_V_read810_phi_phi_fu_23918_p4 = ap_phi_mux_data_535_V_read810_rewind_phi_fu_13998_p6.read();
    } else {
        ap_phi_mux_data_535_V_read810_phi_phi_fu_23918_p4 = ap_phi_reg_pp0_iter1_data_535_V_read810_phi_reg_23914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_535_V_read810_rewind_phi_fu_13998_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_535_V_read810_rewind_phi_fu_13998_p6 = data_535_V_read810_phi_reg_23914.read();
    } else {
        ap_phi_mux_data_535_V_read810_rewind_phi_fu_13998_p6 = data_535_V_read810_rewind_reg_13994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_536_V_read811_phi_phi_fu_23930_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_536_V_read811_phi_phi_fu_23930_p4 = ap_phi_mux_data_536_V_read811_rewind_phi_fu_14012_p6.read();
    } else {
        ap_phi_mux_data_536_V_read811_phi_phi_fu_23930_p4 = ap_phi_reg_pp0_iter1_data_536_V_read811_phi_reg_23926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_536_V_read811_rewind_phi_fu_14012_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_536_V_read811_rewind_phi_fu_14012_p6 = data_536_V_read811_phi_reg_23926.read();
    } else {
        ap_phi_mux_data_536_V_read811_rewind_phi_fu_14012_p6 = data_536_V_read811_rewind_reg_14008.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_537_V_read812_phi_phi_fu_23942_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_537_V_read812_phi_phi_fu_23942_p4 = ap_phi_mux_data_537_V_read812_rewind_phi_fu_14026_p6.read();
    } else {
        ap_phi_mux_data_537_V_read812_phi_phi_fu_23942_p4 = ap_phi_reg_pp0_iter1_data_537_V_read812_phi_reg_23938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_537_V_read812_rewind_phi_fu_14026_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_537_V_read812_rewind_phi_fu_14026_p6 = data_537_V_read812_phi_reg_23938.read();
    } else {
        ap_phi_mux_data_537_V_read812_rewind_phi_fu_14026_p6 = data_537_V_read812_rewind_reg_14022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_538_V_read813_phi_phi_fu_23954_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_538_V_read813_phi_phi_fu_23954_p4 = ap_phi_mux_data_538_V_read813_rewind_phi_fu_14040_p6.read();
    } else {
        ap_phi_mux_data_538_V_read813_phi_phi_fu_23954_p4 = ap_phi_reg_pp0_iter1_data_538_V_read813_phi_reg_23950.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_538_V_read813_rewind_phi_fu_14040_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_538_V_read813_rewind_phi_fu_14040_p6 = data_538_V_read813_phi_reg_23950.read();
    } else {
        ap_phi_mux_data_538_V_read813_rewind_phi_fu_14040_p6 = data_538_V_read813_rewind_reg_14036.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_539_V_read814_phi_phi_fu_23966_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_539_V_read814_phi_phi_fu_23966_p4 = ap_phi_mux_data_539_V_read814_rewind_phi_fu_14054_p6.read();
    } else {
        ap_phi_mux_data_539_V_read814_phi_phi_fu_23966_p4 = ap_phi_reg_pp0_iter1_data_539_V_read814_phi_reg_23962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_539_V_read814_rewind_phi_fu_14054_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_539_V_read814_rewind_phi_fu_14054_p6 = data_539_V_read814_phi_reg_23962.read();
    } else {
        ap_phi_mux_data_539_V_read814_rewind_phi_fu_14054_p6 = data_539_V_read814_rewind_reg_14050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_53_V_read328_phi_phi_fu_18134_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_53_V_read328_phi_phi_fu_18134_p4 = ap_phi_mux_data_53_V_read328_rewind_phi_fu_7250_p6.read();
    } else {
        ap_phi_mux_data_53_V_read328_phi_phi_fu_18134_p4 = ap_phi_reg_pp0_iter1_data_53_V_read328_phi_reg_18130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_53_V_read328_rewind_phi_fu_7250_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_53_V_read328_rewind_phi_fu_7250_p6 = data_53_V_read328_phi_reg_18130.read();
    } else {
        ap_phi_mux_data_53_V_read328_rewind_phi_fu_7250_p6 = data_53_V_read328_rewind_reg_7246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_540_V_read815_phi_phi_fu_23978_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_540_V_read815_phi_phi_fu_23978_p4 = ap_phi_mux_data_540_V_read815_rewind_phi_fu_14068_p6.read();
    } else {
        ap_phi_mux_data_540_V_read815_phi_phi_fu_23978_p4 = ap_phi_reg_pp0_iter1_data_540_V_read815_phi_reg_23974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_540_V_read815_rewind_phi_fu_14068_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_540_V_read815_rewind_phi_fu_14068_p6 = data_540_V_read815_phi_reg_23974.read();
    } else {
        ap_phi_mux_data_540_V_read815_rewind_phi_fu_14068_p6 = data_540_V_read815_rewind_reg_14064.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_541_V_read816_phi_phi_fu_23990_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_541_V_read816_phi_phi_fu_23990_p4 = ap_phi_mux_data_541_V_read816_rewind_phi_fu_14082_p6.read();
    } else {
        ap_phi_mux_data_541_V_read816_phi_phi_fu_23990_p4 = ap_phi_reg_pp0_iter1_data_541_V_read816_phi_reg_23986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_541_V_read816_rewind_phi_fu_14082_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_541_V_read816_rewind_phi_fu_14082_p6 = data_541_V_read816_phi_reg_23986.read();
    } else {
        ap_phi_mux_data_541_V_read816_rewind_phi_fu_14082_p6 = data_541_V_read816_rewind_reg_14078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_542_V_read817_phi_phi_fu_24002_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_542_V_read817_phi_phi_fu_24002_p4 = ap_phi_mux_data_542_V_read817_rewind_phi_fu_14096_p6.read();
    } else {
        ap_phi_mux_data_542_V_read817_phi_phi_fu_24002_p4 = ap_phi_reg_pp0_iter1_data_542_V_read817_phi_reg_23998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_542_V_read817_rewind_phi_fu_14096_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_542_V_read817_rewind_phi_fu_14096_p6 = data_542_V_read817_phi_reg_23998.read();
    } else {
        ap_phi_mux_data_542_V_read817_rewind_phi_fu_14096_p6 = data_542_V_read817_rewind_reg_14092.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_543_V_read818_phi_phi_fu_24014_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_543_V_read818_phi_phi_fu_24014_p4 = ap_phi_mux_data_543_V_read818_rewind_phi_fu_14110_p6.read();
    } else {
        ap_phi_mux_data_543_V_read818_phi_phi_fu_24014_p4 = ap_phi_reg_pp0_iter1_data_543_V_read818_phi_reg_24010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_543_V_read818_rewind_phi_fu_14110_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_543_V_read818_rewind_phi_fu_14110_p6 = data_543_V_read818_phi_reg_24010.read();
    } else {
        ap_phi_mux_data_543_V_read818_rewind_phi_fu_14110_p6 = data_543_V_read818_rewind_reg_14106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_544_V_read819_phi_phi_fu_24026_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_544_V_read819_phi_phi_fu_24026_p4 = ap_phi_mux_data_544_V_read819_rewind_phi_fu_14124_p6.read();
    } else {
        ap_phi_mux_data_544_V_read819_phi_phi_fu_24026_p4 = ap_phi_reg_pp0_iter1_data_544_V_read819_phi_reg_24022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_544_V_read819_rewind_phi_fu_14124_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_544_V_read819_rewind_phi_fu_14124_p6 = data_544_V_read819_phi_reg_24022.read();
    } else {
        ap_phi_mux_data_544_V_read819_rewind_phi_fu_14124_p6 = data_544_V_read819_rewind_reg_14120.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_545_V_read820_phi_phi_fu_24038_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_545_V_read820_phi_phi_fu_24038_p4 = ap_phi_mux_data_545_V_read820_rewind_phi_fu_14138_p6.read();
    } else {
        ap_phi_mux_data_545_V_read820_phi_phi_fu_24038_p4 = ap_phi_reg_pp0_iter1_data_545_V_read820_phi_reg_24034.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_545_V_read820_rewind_phi_fu_14138_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_545_V_read820_rewind_phi_fu_14138_p6 = data_545_V_read820_phi_reg_24034.read();
    } else {
        ap_phi_mux_data_545_V_read820_rewind_phi_fu_14138_p6 = data_545_V_read820_rewind_reg_14134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_546_V_read821_phi_phi_fu_24050_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_546_V_read821_phi_phi_fu_24050_p4 = ap_phi_mux_data_546_V_read821_rewind_phi_fu_14152_p6.read();
    } else {
        ap_phi_mux_data_546_V_read821_phi_phi_fu_24050_p4 = ap_phi_reg_pp0_iter1_data_546_V_read821_phi_reg_24046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_546_V_read821_rewind_phi_fu_14152_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_546_V_read821_rewind_phi_fu_14152_p6 = data_546_V_read821_phi_reg_24046.read();
    } else {
        ap_phi_mux_data_546_V_read821_rewind_phi_fu_14152_p6 = data_546_V_read821_rewind_reg_14148.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_547_V_read822_phi_phi_fu_24062_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_547_V_read822_phi_phi_fu_24062_p4 = ap_phi_mux_data_547_V_read822_rewind_phi_fu_14166_p6.read();
    } else {
        ap_phi_mux_data_547_V_read822_phi_phi_fu_24062_p4 = ap_phi_reg_pp0_iter1_data_547_V_read822_phi_reg_24058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_547_V_read822_rewind_phi_fu_14166_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_547_V_read822_rewind_phi_fu_14166_p6 = data_547_V_read822_phi_reg_24058.read();
    } else {
        ap_phi_mux_data_547_V_read822_rewind_phi_fu_14166_p6 = data_547_V_read822_rewind_reg_14162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_548_V_read823_phi_phi_fu_24074_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_548_V_read823_phi_phi_fu_24074_p4 = ap_phi_mux_data_548_V_read823_rewind_phi_fu_14180_p6.read();
    } else {
        ap_phi_mux_data_548_V_read823_phi_phi_fu_24074_p4 = ap_phi_reg_pp0_iter1_data_548_V_read823_phi_reg_24070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_548_V_read823_rewind_phi_fu_14180_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_548_V_read823_rewind_phi_fu_14180_p6 = data_548_V_read823_phi_reg_24070.read();
    } else {
        ap_phi_mux_data_548_V_read823_rewind_phi_fu_14180_p6 = data_548_V_read823_rewind_reg_14176.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_549_V_read824_phi_phi_fu_24086_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_549_V_read824_phi_phi_fu_24086_p4 = ap_phi_mux_data_549_V_read824_rewind_phi_fu_14194_p6.read();
    } else {
        ap_phi_mux_data_549_V_read824_phi_phi_fu_24086_p4 = ap_phi_reg_pp0_iter1_data_549_V_read824_phi_reg_24082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_549_V_read824_rewind_phi_fu_14194_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_549_V_read824_rewind_phi_fu_14194_p6 = data_549_V_read824_phi_reg_24082.read();
    } else {
        ap_phi_mux_data_549_V_read824_rewind_phi_fu_14194_p6 = data_549_V_read824_rewind_reg_14190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_54_V_read329_phi_phi_fu_18146_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_54_V_read329_phi_phi_fu_18146_p4 = ap_phi_mux_data_54_V_read329_rewind_phi_fu_7264_p6.read();
    } else {
        ap_phi_mux_data_54_V_read329_phi_phi_fu_18146_p4 = ap_phi_reg_pp0_iter1_data_54_V_read329_phi_reg_18142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_54_V_read329_rewind_phi_fu_7264_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_54_V_read329_rewind_phi_fu_7264_p6 = data_54_V_read329_phi_reg_18142.read();
    } else {
        ap_phi_mux_data_54_V_read329_rewind_phi_fu_7264_p6 = data_54_V_read329_rewind_reg_7260.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_550_V_read825_phi_phi_fu_24098_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_550_V_read825_phi_phi_fu_24098_p4 = ap_phi_mux_data_550_V_read825_rewind_phi_fu_14208_p6.read();
    } else {
        ap_phi_mux_data_550_V_read825_phi_phi_fu_24098_p4 = ap_phi_reg_pp0_iter1_data_550_V_read825_phi_reg_24094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_550_V_read825_rewind_phi_fu_14208_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_550_V_read825_rewind_phi_fu_14208_p6 = data_550_V_read825_phi_reg_24094.read();
    } else {
        ap_phi_mux_data_550_V_read825_rewind_phi_fu_14208_p6 = data_550_V_read825_rewind_reg_14204.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_551_V_read826_phi_phi_fu_24110_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_551_V_read826_phi_phi_fu_24110_p4 = ap_phi_mux_data_551_V_read826_rewind_phi_fu_14222_p6.read();
    } else {
        ap_phi_mux_data_551_V_read826_phi_phi_fu_24110_p4 = ap_phi_reg_pp0_iter1_data_551_V_read826_phi_reg_24106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_551_V_read826_rewind_phi_fu_14222_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_551_V_read826_rewind_phi_fu_14222_p6 = data_551_V_read826_phi_reg_24106.read();
    } else {
        ap_phi_mux_data_551_V_read826_rewind_phi_fu_14222_p6 = data_551_V_read826_rewind_reg_14218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_552_V_read827_phi_phi_fu_24122_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_552_V_read827_phi_phi_fu_24122_p4 = ap_phi_mux_data_552_V_read827_rewind_phi_fu_14236_p6.read();
    } else {
        ap_phi_mux_data_552_V_read827_phi_phi_fu_24122_p4 = ap_phi_reg_pp0_iter1_data_552_V_read827_phi_reg_24118.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_552_V_read827_rewind_phi_fu_14236_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_552_V_read827_rewind_phi_fu_14236_p6 = data_552_V_read827_phi_reg_24118.read();
    } else {
        ap_phi_mux_data_552_V_read827_rewind_phi_fu_14236_p6 = data_552_V_read827_rewind_reg_14232.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_553_V_read828_phi_phi_fu_24134_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_553_V_read828_phi_phi_fu_24134_p4 = ap_phi_mux_data_553_V_read828_rewind_phi_fu_14250_p6.read();
    } else {
        ap_phi_mux_data_553_V_read828_phi_phi_fu_24134_p4 = ap_phi_reg_pp0_iter1_data_553_V_read828_phi_reg_24130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_553_V_read828_rewind_phi_fu_14250_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_553_V_read828_rewind_phi_fu_14250_p6 = data_553_V_read828_phi_reg_24130.read();
    } else {
        ap_phi_mux_data_553_V_read828_rewind_phi_fu_14250_p6 = data_553_V_read828_rewind_reg_14246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_554_V_read829_phi_phi_fu_24146_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_554_V_read829_phi_phi_fu_24146_p4 = ap_phi_mux_data_554_V_read829_rewind_phi_fu_14264_p6.read();
    } else {
        ap_phi_mux_data_554_V_read829_phi_phi_fu_24146_p4 = ap_phi_reg_pp0_iter1_data_554_V_read829_phi_reg_24142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_554_V_read829_rewind_phi_fu_14264_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_554_V_read829_rewind_phi_fu_14264_p6 = data_554_V_read829_phi_reg_24142.read();
    } else {
        ap_phi_mux_data_554_V_read829_rewind_phi_fu_14264_p6 = data_554_V_read829_rewind_reg_14260.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_555_V_read830_phi_phi_fu_24158_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_555_V_read830_phi_phi_fu_24158_p4 = ap_phi_mux_data_555_V_read830_rewind_phi_fu_14278_p6.read();
    } else {
        ap_phi_mux_data_555_V_read830_phi_phi_fu_24158_p4 = ap_phi_reg_pp0_iter1_data_555_V_read830_phi_reg_24154.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_555_V_read830_rewind_phi_fu_14278_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_555_V_read830_rewind_phi_fu_14278_p6 = data_555_V_read830_phi_reg_24154.read();
    } else {
        ap_phi_mux_data_555_V_read830_rewind_phi_fu_14278_p6 = data_555_V_read830_rewind_reg_14274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_556_V_read831_phi_phi_fu_24170_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_556_V_read831_phi_phi_fu_24170_p4 = ap_phi_mux_data_556_V_read831_rewind_phi_fu_14292_p6.read();
    } else {
        ap_phi_mux_data_556_V_read831_phi_phi_fu_24170_p4 = ap_phi_reg_pp0_iter1_data_556_V_read831_phi_reg_24166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_556_V_read831_rewind_phi_fu_14292_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_556_V_read831_rewind_phi_fu_14292_p6 = data_556_V_read831_phi_reg_24166.read();
    } else {
        ap_phi_mux_data_556_V_read831_rewind_phi_fu_14292_p6 = data_556_V_read831_rewind_reg_14288.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_557_V_read832_phi_phi_fu_24182_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_557_V_read832_phi_phi_fu_24182_p4 = ap_phi_mux_data_557_V_read832_rewind_phi_fu_14306_p6.read();
    } else {
        ap_phi_mux_data_557_V_read832_phi_phi_fu_24182_p4 = ap_phi_reg_pp0_iter1_data_557_V_read832_phi_reg_24178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_557_V_read832_rewind_phi_fu_14306_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_557_V_read832_rewind_phi_fu_14306_p6 = data_557_V_read832_phi_reg_24178.read();
    } else {
        ap_phi_mux_data_557_V_read832_rewind_phi_fu_14306_p6 = data_557_V_read832_rewind_reg_14302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_558_V_read833_phi_phi_fu_24194_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_558_V_read833_phi_phi_fu_24194_p4 = ap_phi_mux_data_558_V_read833_rewind_phi_fu_14320_p6.read();
    } else {
        ap_phi_mux_data_558_V_read833_phi_phi_fu_24194_p4 = ap_phi_reg_pp0_iter1_data_558_V_read833_phi_reg_24190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_558_V_read833_rewind_phi_fu_14320_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_558_V_read833_rewind_phi_fu_14320_p6 = data_558_V_read833_phi_reg_24190.read();
    } else {
        ap_phi_mux_data_558_V_read833_rewind_phi_fu_14320_p6 = data_558_V_read833_rewind_reg_14316.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_559_V_read834_phi_phi_fu_24206_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_559_V_read834_phi_phi_fu_24206_p4 = ap_phi_mux_data_559_V_read834_rewind_phi_fu_14334_p6.read();
    } else {
        ap_phi_mux_data_559_V_read834_phi_phi_fu_24206_p4 = ap_phi_reg_pp0_iter1_data_559_V_read834_phi_reg_24202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_559_V_read834_rewind_phi_fu_14334_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_559_V_read834_rewind_phi_fu_14334_p6 = data_559_V_read834_phi_reg_24202.read();
    } else {
        ap_phi_mux_data_559_V_read834_rewind_phi_fu_14334_p6 = data_559_V_read834_rewind_reg_14330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_55_V_read330_phi_phi_fu_18158_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_55_V_read330_phi_phi_fu_18158_p4 = ap_phi_mux_data_55_V_read330_rewind_phi_fu_7278_p6.read();
    } else {
        ap_phi_mux_data_55_V_read330_phi_phi_fu_18158_p4 = ap_phi_reg_pp0_iter1_data_55_V_read330_phi_reg_18154.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_55_V_read330_rewind_phi_fu_7278_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_55_V_read330_rewind_phi_fu_7278_p6 = data_55_V_read330_phi_reg_18154.read();
    } else {
        ap_phi_mux_data_55_V_read330_rewind_phi_fu_7278_p6 = data_55_V_read330_rewind_reg_7274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_560_V_read835_phi_phi_fu_24218_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_560_V_read835_phi_phi_fu_24218_p4 = ap_phi_mux_data_560_V_read835_rewind_phi_fu_14348_p6.read();
    } else {
        ap_phi_mux_data_560_V_read835_phi_phi_fu_24218_p4 = ap_phi_reg_pp0_iter1_data_560_V_read835_phi_reg_24214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_560_V_read835_rewind_phi_fu_14348_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_560_V_read835_rewind_phi_fu_14348_p6 = data_560_V_read835_phi_reg_24214.read();
    } else {
        ap_phi_mux_data_560_V_read835_rewind_phi_fu_14348_p6 = data_560_V_read835_rewind_reg_14344.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_561_V_read836_phi_phi_fu_24230_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_561_V_read836_phi_phi_fu_24230_p4 = ap_phi_mux_data_561_V_read836_rewind_phi_fu_14362_p6.read();
    } else {
        ap_phi_mux_data_561_V_read836_phi_phi_fu_24230_p4 = ap_phi_reg_pp0_iter1_data_561_V_read836_phi_reg_24226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_561_V_read836_rewind_phi_fu_14362_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_561_V_read836_rewind_phi_fu_14362_p6 = data_561_V_read836_phi_reg_24226.read();
    } else {
        ap_phi_mux_data_561_V_read836_rewind_phi_fu_14362_p6 = data_561_V_read836_rewind_reg_14358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_562_V_read837_phi_phi_fu_24242_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_562_V_read837_phi_phi_fu_24242_p4 = ap_phi_mux_data_562_V_read837_rewind_phi_fu_14376_p6.read();
    } else {
        ap_phi_mux_data_562_V_read837_phi_phi_fu_24242_p4 = ap_phi_reg_pp0_iter1_data_562_V_read837_phi_reg_24238.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_562_V_read837_rewind_phi_fu_14376_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_562_V_read837_rewind_phi_fu_14376_p6 = data_562_V_read837_phi_reg_24238.read();
    } else {
        ap_phi_mux_data_562_V_read837_rewind_phi_fu_14376_p6 = data_562_V_read837_rewind_reg_14372.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_563_V_read838_phi_phi_fu_24254_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_563_V_read838_phi_phi_fu_24254_p4 = ap_phi_mux_data_563_V_read838_rewind_phi_fu_14390_p6.read();
    } else {
        ap_phi_mux_data_563_V_read838_phi_phi_fu_24254_p4 = ap_phi_reg_pp0_iter1_data_563_V_read838_phi_reg_24250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_563_V_read838_rewind_phi_fu_14390_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_563_V_read838_rewind_phi_fu_14390_p6 = data_563_V_read838_phi_reg_24250.read();
    } else {
        ap_phi_mux_data_563_V_read838_rewind_phi_fu_14390_p6 = data_563_V_read838_rewind_reg_14386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_564_V_read839_phi_phi_fu_24266_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_564_V_read839_phi_phi_fu_24266_p4 = ap_phi_mux_data_564_V_read839_rewind_phi_fu_14404_p6.read();
    } else {
        ap_phi_mux_data_564_V_read839_phi_phi_fu_24266_p4 = ap_phi_reg_pp0_iter1_data_564_V_read839_phi_reg_24262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_564_V_read839_rewind_phi_fu_14404_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_564_V_read839_rewind_phi_fu_14404_p6 = data_564_V_read839_phi_reg_24262.read();
    } else {
        ap_phi_mux_data_564_V_read839_rewind_phi_fu_14404_p6 = data_564_V_read839_rewind_reg_14400.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_565_V_read840_phi_phi_fu_24278_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_565_V_read840_phi_phi_fu_24278_p4 = ap_phi_mux_data_565_V_read840_rewind_phi_fu_14418_p6.read();
    } else {
        ap_phi_mux_data_565_V_read840_phi_phi_fu_24278_p4 = ap_phi_reg_pp0_iter1_data_565_V_read840_phi_reg_24274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_565_V_read840_rewind_phi_fu_14418_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_565_V_read840_rewind_phi_fu_14418_p6 = data_565_V_read840_phi_reg_24274.read();
    } else {
        ap_phi_mux_data_565_V_read840_rewind_phi_fu_14418_p6 = data_565_V_read840_rewind_reg_14414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_566_V_read841_phi_phi_fu_24290_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_566_V_read841_phi_phi_fu_24290_p4 = ap_phi_mux_data_566_V_read841_rewind_phi_fu_14432_p6.read();
    } else {
        ap_phi_mux_data_566_V_read841_phi_phi_fu_24290_p4 = ap_phi_reg_pp0_iter1_data_566_V_read841_phi_reg_24286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_566_V_read841_rewind_phi_fu_14432_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_566_V_read841_rewind_phi_fu_14432_p6 = data_566_V_read841_phi_reg_24286.read();
    } else {
        ap_phi_mux_data_566_V_read841_rewind_phi_fu_14432_p6 = data_566_V_read841_rewind_reg_14428.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_567_V_read842_phi_phi_fu_24302_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_567_V_read842_phi_phi_fu_24302_p4 = ap_phi_mux_data_567_V_read842_rewind_phi_fu_14446_p6.read();
    } else {
        ap_phi_mux_data_567_V_read842_phi_phi_fu_24302_p4 = ap_phi_reg_pp0_iter1_data_567_V_read842_phi_reg_24298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_567_V_read842_rewind_phi_fu_14446_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_567_V_read842_rewind_phi_fu_14446_p6 = data_567_V_read842_phi_reg_24298.read();
    } else {
        ap_phi_mux_data_567_V_read842_rewind_phi_fu_14446_p6 = data_567_V_read842_rewind_reg_14442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_568_V_read843_phi_phi_fu_24314_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_568_V_read843_phi_phi_fu_24314_p4 = ap_phi_mux_data_568_V_read843_rewind_phi_fu_14460_p6.read();
    } else {
        ap_phi_mux_data_568_V_read843_phi_phi_fu_24314_p4 = ap_phi_reg_pp0_iter1_data_568_V_read843_phi_reg_24310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_568_V_read843_rewind_phi_fu_14460_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_568_V_read843_rewind_phi_fu_14460_p6 = data_568_V_read843_phi_reg_24310.read();
    } else {
        ap_phi_mux_data_568_V_read843_rewind_phi_fu_14460_p6 = data_568_V_read843_rewind_reg_14456.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_569_V_read844_phi_phi_fu_24326_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_569_V_read844_phi_phi_fu_24326_p4 = ap_phi_mux_data_569_V_read844_rewind_phi_fu_14474_p6.read();
    } else {
        ap_phi_mux_data_569_V_read844_phi_phi_fu_24326_p4 = ap_phi_reg_pp0_iter1_data_569_V_read844_phi_reg_24322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_569_V_read844_rewind_phi_fu_14474_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_569_V_read844_rewind_phi_fu_14474_p6 = data_569_V_read844_phi_reg_24322.read();
    } else {
        ap_phi_mux_data_569_V_read844_rewind_phi_fu_14474_p6 = data_569_V_read844_rewind_reg_14470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_56_V_read331_phi_phi_fu_18170_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_56_V_read331_phi_phi_fu_18170_p4 = ap_phi_mux_data_56_V_read331_rewind_phi_fu_7292_p6.read();
    } else {
        ap_phi_mux_data_56_V_read331_phi_phi_fu_18170_p4 = ap_phi_reg_pp0_iter1_data_56_V_read331_phi_reg_18166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_56_V_read331_rewind_phi_fu_7292_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_56_V_read331_rewind_phi_fu_7292_p6 = data_56_V_read331_phi_reg_18166.read();
    } else {
        ap_phi_mux_data_56_V_read331_rewind_phi_fu_7292_p6 = data_56_V_read331_rewind_reg_7288.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_570_V_read845_phi_phi_fu_24338_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_570_V_read845_phi_phi_fu_24338_p4 = ap_phi_mux_data_570_V_read845_rewind_phi_fu_14488_p6.read();
    } else {
        ap_phi_mux_data_570_V_read845_phi_phi_fu_24338_p4 = ap_phi_reg_pp0_iter1_data_570_V_read845_phi_reg_24334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_570_V_read845_rewind_phi_fu_14488_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_570_V_read845_rewind_phi_fu_14488_p6 = data_570_V_read845_phi_reg_24334.read();
    } else {
        ap_phi_mux_data_570_V_read845_rewind_phi_fu_14488_p6 = data_570_V_read845_rewind_reg_14484.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_571_V_read846_phi_phi_fu_24350_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_571_V_read846_phi_phi_fu_24350_p4 = ap_phi_mux_data_571_V_read846_rewind_phi_fu_14502_p6.read();
    } else {
        ap_phi_mux_data_571_V_read846_phi_phi_fu_24350_p4 = ap_phi_reg_pp0_iter1_data_571_V_read846_phi_reg_24346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_571_V_read846_rewind_phi_fu_14502_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_571_V_read846_rewind_phi_fu_14502_p6 = data_571_V_read846_phi_reg_24346.read();
    } else {
        ap_phi_mux_data_571_V_read846_rewind_phi_fu_14502_p6 = data_571_V_read846_rewind_reg_14498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_572_V_read847_phi_phi_fu_24362_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_572_V_read847_phi_phi_fu_24362_p4 = ap_phi_mux_data_572_V_read847_rewind_phi_fu_14516_p6.read();
    } else {
        ap_phi_mux_data_572_V_read847_phi_phi_fu_24362_p4 = ap_phi_reg_pp0_iter1_data_572_V_read847_phi_reg_24358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_572_V_read847_rewind_phi_fu_14516_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_572_V_read847_rewind_phi_fu_14516_p6 = data_572_V_read847_phi_reg_24358.read();
    } else {
        ap_phi_mux_data_572_V_read847_rewind_phi_fu_14516_p6 = data_572_V_read847_rewind_reg_14512.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_573_V_read848_phi_phi_fu_24374_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_573_V_read848_phi_phi_fu_24374_p4 = ap_phi_mux_data_573_V_read848_rewind_phi_fu_14530_p6.read();
    } else {
        ap_phi_mux_data_573_V_read848_phi_phi_fu_24374_p4 = ap_phi_reg_pp0_iter1_data_573_V_read848_phi_reg_24370.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_573_V_read848_rewind_phi_fu_14530_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_573_V_read848_rewind_phi_fu_14530_p6 = data_573_V_read848_phi_reg_24370.read();
    } else {
        ap_phi_mux_data_573_V_read848_rewind_phi_fu_14530_p6 = data_573_V_read848_rewind_reg_14526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_574_V_read849_phi_phi_fu_24386_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_574_V_read849_phi_phi_fu_24386_p4 = ap_phi_mux_data_574_V_read849_rewind_phi_fu_14544_p6.read();
    } else {
        ap_phi_mux_data_574_V_read849_phi_phi_fu_24386_p4 = ap_phi_reg_pp0_iter1_data_574_V_read849_phi_reg_24382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_574_V_read849_rewind_phi_fu_14544_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_574_V_read849_rewind_phi_fu_14544_p6 = data_574_V_read849_phi_reg_24382.read();
    } else {
        ap_phi_mux_data_574_V_read849_rewind_phi_fu_14544_p6 = data_574_V_read849_rewind_reg_14540.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_575_V_read850_phi_phi_fu_24398_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_575_V_read850_phi_phi_fu_24398_p4 = ap_phi_mux_data_575_V_read850_rewind_phi_fu_14558_p6.read();
    } else {
        ap_phi_mux_data_575_V_read850_phi_phi_fu_24398_p4 = ap_phi_reg_pp0_iter1_data_575_V_read850_phi_reg_24394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_575_V_read850_rewind_phi_fu_14558_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_575_V_read850_rewind_phi_fu_14558_p6 = data_575_V_read850_phi_reg_24394.read();
    } else {
        ap_phi_mux_data_575_V_read850_rewind_phi_fu_14558_p6 = data_575_V_read850_rewind_reg_14554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_576_V_read851_phi_phi_fu_24410_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_576_V_read851_phi_phi_fu_24410_p4 = ap_phi_mux_data_576_V_read851_rewind_phi_fu_14572_p6.read();
    } else {
        ap_phi_mux_data_576_V_read851_phi_phi_fu_24410_p4 = ap_phi_reg_pp0_iter1_data_576_V_read851_phi_reg_24406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_576_V_read851_rewind_phi_fu_14572_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_576_V_read851_rewind_phi_fu_14572_p6 = data_576_V_read851_phi_reg_24406.read();
    } else {
        ap_phi_mux_data_576_V_read851_rewind_phi_fu_14572_p6 = data_576_V_read851_rewind_reg_14568.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_577_V_read852_phi_phi_fu_24422_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_577_V_read852_phi_phi_fu_24422_p4 = ap_phi_mux_data_577_V_read852_rewind_phi_fu_14586_p6.read();
    } else {
        ap_phi_mux_data_577_V_read852_phi_phi_fu_24422_p4 = ap_phi_reg_pp0_iter1_data_577_V_read852_phi_reg_24418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_577_V_read852_rewind_phi_fu_14586_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_577_V_read852_rewind_phi_fu_14586_p6 = data_577_V_read852_phi_reg_24418.read();
    } else {
        ap_phi_mux_data_577_V_read852_rewind_phi_fu_14586_p6 = data_577_V_read852_rewind_reg_14582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_578_V_read853_phi_phi_fu_24434_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_578_V_read853_phi_phi_fu_24434_p4 = ap_phi_mux_data_578_V_read853_rewind_phi_fu_14600_p6.read();
    } else {
        ap_phi_mux_data_578_V_read853_phi_phi_fu_24434_p4 = ap_phi_reg_pp0_iter1_data_578_V_read853_phi_reg_24430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_578_V_read853_rewind_phi_fu_14600_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_578_V_read853_rewind_phi_fu_14600_p6 = data_578_V_read853_phi_reg_24430.read();
    } else {
        ap_phi_mux_data_578_V_read853_rewind_phi_fu_14600_p6 = data_578_V_read853_rewind_reg_14596.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_579_V_read854_phi_phi_fu_24446_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_579_V_read854_phi_phi_fu_24446_p4 = ap_phi_mux_data_579_V_read854_rewind_phi_fu_14614_p6.read();
    } else {
        ap_phi_mux_data_579_V_read854_phi_phi_fu_24446_p4 = ap_phi_reg_pp0_iter1_data_579_V_read854_phi_reg_24442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_579_V_read854_rewind_phi_fu_14614_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_579_V_read854_rewind_phi_fu_14614_p6 = data_579_V_read854_phi_reg_24442.read();
    } else {
        ap_phi_mux_data_579_V_read854_rewind_phi_fu_14614_p6 = data_579_V_read854_rewind_reg_14610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_57_V_read332_phi_phi_fu_18182_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_57_V_read332_phi_phi_fu_18182_p4 = ap_phi_mux_data_57_V_read332_rewind_phi_fu_7306_p6.read();
    } else {
        ap_phi_mux_data_57_V_read332_phi_phi_fu_18182_p4 = ap_phi_reg_pp0_iter1_data_57_V_read332_phi_reg_18178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_57_V_read332_rewind_phi_fu_7306_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_57_V_read332_rewind_phi_fu_7306_p6 = data_57_V_read332_phi_reg_18178.read();
    } else {
        ap_phi_mux_data_57_V_read332_rewind_phi_fu_7306_p6 = data_57_V_read332_rewind_reg_7302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_580_V_read855_phi_phi_fu_24458_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_580_V_read855_phi_phi_fu_24458_p4 = ap_phi_mux_data_580_V_read855_rewind_phi_fu_14628_p6.read();
    } else {
        ap_phi_mux_data_580_V_read855_phi_phi_fu_24458_p4 = ap_phi_reg_pp0_iter1_data_580_V_read855_phi_reg_24454.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_580_V_read855_rewind_phi_fu_14628_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_580_V_read855_rewind_phi_fu_14628_p6 = data_580_V_read855_phi_reg_24454.read();
    } else {
        ap_phi_mux_data_580_V_read855_rewind_phi_fu_14628_p6 = data_580_V_read855_rewind_reg_14624.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_581_V_read856_phi_phi_fu_24470_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_581_V_read856_phi_phi_fu_24470_p4 = ap_phi_mux_data_581_V_read856_rewind_phi_fu_14642_p6.read();
    } else {
        ap_phi_mux_data_581_V_read856_phi_phi_fu_24470_p4 = ap_phi_reg_pp0_iter1_data_581_V_read856_phi_reg_24466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_581_V_read856_rewind_phi_fu_14642_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_581_V_read856_rewind_phi_fu_14642_p6 = data_581_V_read856_phi_reg_24466.read();
    } else {
        ap_phi_mux_data_581_V_read856_rewind_phi_fu_14642_p6 = data_581_V_read856_rewind_reg_14638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_582_V_read857_phi_phi_fu_24482_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_582_V_read857_phi_phi_fu_24482_p4 = ap_phi_mux_data_582_V_read857_rewind_phi_fu_14656_p6.read();
    } else {
        ap_phi_mux_data_582_V_read857_phi_phi_fu_24482_p4 = ap_phi_reg_pp0_iter1_data_582_V_read857_phi_reg_24478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_582_V_read857_rewind_phi_fu_14656_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_582_V_read857_rewind_phi_fu_14656_p6 = data_582_V_read857_phi_reg_24478.read();
    } else {
        ap_phi_mux_data_582_V_read857_rewind_phi_fu_14656_p6 = data_582_V_read857_rewind_reg_14652.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_583_V_read858_phi_phi_fu_24494_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_583_V_read858_phi_phi_fu_24494_p4 = ap_phi_mux_data_583_V_read858_rewind_phi_fu_14670_p6.read();
    } else {
        ap_phi_mux_data_583_V_read858_phi_phi_fu_24494_p4 = ap_phi_reg_pp0_iter1_data_583_V_read858_phi_reg_24490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_583_V_read858_rewind_phi_fu_14670_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_583_V_read858_rewind_phi_fu_14670_p6 = data_583_V_read858_phi_reg_24490.read();
    } else {
        ap_phi_mux_data_583_V_read858_rewind_phi_fu_14670_p6 = data_583_V_read858_rewind_reg_14666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_584_V_read859_phi_phi_fu_24506_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_584_V_read859_phi_phi_fu_24506_p4 = ap_phi_mux_data_584_V_read859_rewind_phi_fu_14684_p6.read();
    } else {
        ap_phi_mux_data_584_V_read859_phi_phi_fu_24506_p4 = ap_phi_reg_pp0_iter1_data_584_V_read859_phi_reg_24502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_584_V_read859_rewind_phi_fu_14684_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_584_V_read859_rewind_phi_fu_14684_p6 = data_584_V_read859_phi_reg_24502.read();
    } else {
        ap_phi_mux_data_584_V_read859_rewind_phi_fu_14684_p6 = data_584_V_read859_rewind_reg_14680.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_585_V_read860_phi_phi_fu_24518_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_585_V_read860_phi_phi_fu_24518_p4 = ap_phi_mux_data_585_V_read860_rewind_phi_fu_14698_p6.read();
    } else {
        ap_phi_mux_data_585_V_read860_phi_phi_fu_24518_p4 = ap_phi_reg_pp0_iter1_data_585_V_read860_phi_reg_24514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_585_V_read860_rewind_phi_fu_14698_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_585_V_read860_rewind_phi_fu_14698_p6 = data_585_V_read860_phi_reg_24514.read();
    } else {
        ap_phi_mux_data_585_V_read860_rewind_phi_fu_14698_p6 = data_585_V_read860_rewind_reg_14694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_586_V_read861_phi_phi_fu_24530_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_586_V_read861_phi_phi_fu_24530_p4 = ap_phi_mux_data_586_V_read861_rewind_phi_fu_14712_p6.read();
    } else {
        ap_phi_mux_data_586_V_read861_phi_phi_fu_24530_p4 = ap_phi_reg_pp0_iter1_data_586_V_read861_phi_reg_24526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_586_V_read861_rewind_phi_fu_14712_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_586_V_read861_rewind_phi_fu_14712_p6 = data_586_V_read861_phi_reg_24526.read();
    } else {
        ap_phi_mux_data_586_V_read861_rewind_phi_fu_14712_p6 = data_586_V_read861_rewind_reg_14708.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_587_V_read862_phi_phi_fu_24542_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_587_V_read862_phi_phi_fu_24542_p4 = ap_phi_mux_data_587_V_read862_rewind_phi_fu_14726_p6.read();
    } else {
        ap_phi_mux_data_587_V_read862_phi_phi_fu_24542_p4 = ap_phi_reg_pp0_iter1_data_587_V_read862_phi_reg_24538.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_587_V_read862_rewind_phi_fu_14726_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_587_V_read862_rewind_phi_fu_14726_p6 = data_587_V_read862_phi_reg_24538.read();
    } else {
        ap_phi_mux_data_587_V_read862_rewind_phi_fu_14726_p6 = data_587_V_read862_rewind_reg_14722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_588_V_read863_phi_phi_fu_24554_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_588_V_read863_phi_phi_fu_24554_p4 = ap_phi_mux_data_588_V_read863_rewind_phi_fu_14740_p6.read();
    } else {
        ap_phi_mux_data_588_V_read863_phi_phi_fu_24554_p4 = ap_phi_reg_pp0_iter1_data_588_V_read863_phi_reg_24550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_588_V_read863_rewind_phi_fu_14740_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_588_V_read863_rewind_phi_fu_14740_p6 = data_588_V_read863_phi_reg_24550.read();
    } else {
        ap_phi_mux_data_588_V_read863_rewind_phi_fu_14740_p6 = data_588_V_read863_rewind_reg_14736.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_589_V_read864_phi_phi_fu_24566_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_589_V_read864_phi_phi_fu_24566_p4 = ap_phi_mux_data_589_V_read864_rewind_phi_fu_14754_p6.read();
    } else {
        ap_phi_mux_data_589_V_read864_phi_phi_fu_24566_p4 = ap_phi_reg_pp0_iter1_data_589_V_read864_phi_reg_24562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_589_V_read864_rewind_phi_fu_14754_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_589_V_read864_rewind_phi_fu_14754_p6 = data_589_V_read864_phi_reg_24562.read();
    } else {
        ap_phi_mux_data_589_V_read864_rewind_phi_fu_14754_p6 = data_589_V_read864_rewind_reg_14750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_58_V_read333_phi_phi_fu_18194_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_58_V_read333_phi_phi_fu_18194_p4 = ap_phi_mux_data_58_V_read333_rewind_phi_fu_7320_p6.read();
    } else {
        ap_phi_mux_data_58_V_read333_phi_phi_fu_18194_p4 = ap_phi_reg_pp0_iter1_data_58_V_read333_phi_reg_18190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_58_V_read333_rewind_phi_fu_7320_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_58_V_read333_rewind_phi_fu_7320_p6 = data_58_V_read333_phi_reg_18190.read();
    } else {
        ap_phi_mux_data_58_V_read333_rewind_phi_fu_7320_p6 = data_58_V_read333_rewind_reg_7316.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_590_V_read865_phi_phi_fu_24578_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_590_V_read865_phi_phi_fu_24578_p4 = ap_phi_mux_data_590_V_read865_rewind_phi_fu_14768_p6.read();
    } else {
        ap_phi_mux_data_590_V_read865_phi_phi_fu_24578_p4 = ap_phi_reg_pp0_iter1_data_590_V_read865_phi_reg_24574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_590_V_read865_rewind_phi_fu_14768_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_590_V_read865_rewind_phi_fu_14768_p6 = data_590_V_read865_phi_reg_24574.read();
    } else {
        ap_phi_mux_data_590_V_read865_rewind_phi_fu_14768_p6 = data_590_V_read865_rewind_reg_14764.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_591_V_read866_phi_phi_fu_24590_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_591_V_read866_phi_phi_fu_24590_p4 = ap_phi_mux_data_591_V_read866_rewind_phi_fu_14782_p6.read();
    } else {
        ap_phi_mux_data_591_V_read866_phi_phi_fu_24590_p4 = ap_phi_reg_pp0_iter1_data_591_V_read866_phi_reg_24586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_591_V_read866_rewind_phi_fu_14782_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_591_V_read866_rewind_phi_fu_14782_p6 = data_591_V_read866_phi_reg_24586.read();
    } else {
        ap_phi_mux_data_591_V_read866_rewind_phi_fu_14782_p6 = data_591_V_read866_rewind_reg_14778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_592_V_read867_phi_phi_fu_24602_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_592_V_read867_phi_phi_fu_24602_p4 = ap_phi_mux_data_592_V_read867_rewind_phi_fu_14796_p6.read();
    } else {
        ap_phi_mux_data_592_V_read867_phi_phi_fu_24602_p4 = ap_phi_reg_pp0_iter1_data_592_V_read867_phi_reg_24598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_592_V_read867_rewind_phi_fu_14796_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_592_V_read867_rewind_phi_fu_14796_p6 = data_592_V_read867_phi_reg_24598.read();
    } else {
        ap_phi_mux_data_592_V_read867_rewind_phi_fu_14796_p6 = data_592_V_read867_rewind_reg_14792.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_593_V_read868_phi_phi_fu_24614_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_593_V_read868_phi_phi_fu_24614_p4 = ap_phi_mux_data_593_V_read868_rewind_phi_fu_14810_p6.read();
    } else {
        ap_phi_mux_data_593_V_read868_phi_phi_fu_24614_p4 = ap_phi_reg_pp0_iter1_data_593_V_read868_phi_reg_24610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_593_V_read868_rewind_phi_fu_14810_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_593_V_read868_rewind_phi_fu_14810_p6 = data_593_V_read868_phi_reg_24610.read();
    } else {
        ap_phi_mux_data_593_V_read868_rewind_phi_fu_14810_p6 = data_593_V_read868_rewind_reg_14806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_594_V_read869_phi_phi_fu_24626_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_594_V_read869_phi_phi_fu_24626_p4 = ap_phi_mux_data_594_V_read869_rewind_phi_fu_14824_p6.read();
    } else {
        ap_phi_mux_data_594_V_read869_phi_phi_fu_24626_p4 = ap_phi_reg_pp0_iter1_data_594_V_read869_phi_reg_24622.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_594_V_read869_rewind_phi_fu_14824_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_594_V_read869_rewind_phi_fu_14824_p6 = data_594_V_read869_phi_reg_24622.read();
    } else {
        ap_phi_mux_data_594_V_read869_rewind_phi_fu_14824_p6 = data_594_V_read869_rewind_reg_14820.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_595_V_read870_phi_phi_fu_24638_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_595_V_read870_phi_phi_fu_24638_p4 = ap_phi_mux_data_595_V_read870_rewind_phi_fu_14838_p6.read();
    } else {
        ap_phi_mux_data_595_V_read870_phi_phi_fu_24638_p4 = ap_phi_reg_pp0_iter1_data_595_V_read870_phi_reg_24634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_595_V_read870_rewind_phi_fu_14838_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_595_V_read870_rewind_phi_fu_14838_p6 = data_595_V_read870_phi_reg_24634.read();
    } else {
        ap_phi_mux_data_595_V_read870_rewind_phi_fu_14838_p6 = data_595_V_read870_rewind_reg_14834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_596_V_read871_phi_phi_fu_24650_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_596_V_read871_phi_phi_fu_24650_p4 = ap_phi_mux_data_596_V_read871_rewind_phi_fu_14852_p6.read();
    } else {
        ap_phi_mux_data_596_V_read871_phi_phi_fu_24650_p4 = ap_phi_reg_pp0_iter1_data_596_V_read871_phi_reg_24646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_596_V_read871_rewind_phi_fu_14852_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_596_V_read871_rewind_phi_fu_14852_p6 = data_596_V_read871_phi_reg_24646.read();
    } else {
        ap_phi_mux_data_596_V_read871_rewind_phi_fu_14852_p6 = data_596_V_read871_rewind_reg_14848.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_597_V_read872_phi_phi_fu_24662_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_597_V_read872_phi_phi_fu_24662_p4 = ap_phi_mux_data_597_V_read872_rewind_phi_fu_14866_p6.read();
    } else {
        ap_phi_mux_data_597_V_read872_phi_phi_fu_24662_p4 = ap_phi_reg_pp0_iter1_data_597_V_read872_phi_reg_24658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_597_V_read872_rewind_phi_fu_14866_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_597_V_read872_rewind_phi_fu_14866_p6 = data_597_V_read872_phi_reg_24658.read();
    } else {
        ap_phi_mux_data_597_V_read872_rewind_phi_fu_14866_p6 = data_597_V_read872_rewind_reg_14862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_598_V_read873_phi_phi_fu_24674_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_598_V_read873_phi_phi_fu_24674_p4 = ap_phi_mux_data_598_V_read873_rewind_phi_fu_14880_p6.read();
    } else {
        ap_phi_mux_data_598_V_read873_phi_phi_fu_24674_p4 = ap_phi_reg_pp0_iter1_data_598_V_read873_phi_reg_24670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_598_V_read873_rewind_phi_fu_14880_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_598_V_read873_rewind_phi_fu_14880_p6 = data_598_V_read873_phi_reg_24670.read();
    } else {
        ap_phi_mux_data_598_V_read873_rewind_phi_fu_14880_p6 = data_598_V_read873_rewind_reg_14876.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_599_V_read874_phi_phi_fu_24686_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_599_V_read874_phi_phi_fu_24686_p4 = ap_phi_mux_data_599_V_read874_rewind_phi_fu_14894_p6.read();
    } else {
        ap_phi_mux_data_599_V_read874_phi_phi_fu_24686_p4 = ap_phi_reg_pp0_iter1_data_599_V_read874_phi_reg_24682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_599_V_read874_rewind_phi_fu_14894_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_599_V_read874_rewind_phi_fu_14894_p6 = data_599_V_read874_phi_reg_24682.read();
    } else {
        ap_phi_mux_data_599_V_read874_rewind_phi_fu_14894_p6 = data_599_V_read874_rewind_reg_14890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_59_V_read334_phi_phi_fu_18206_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_59_V_read334_phi_phi_fu_18206_p4 = ap_phi_mux_data_59_V_read334_rewind_phi_fu_7334_p6.read();
    } else {
        ap_phi_mux_data_59_V_read334_phi_phi_fu_18206_p4 = ap_phi_reg_pp0_iter1_data_59_V_read334_phi_reg_18202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_59_V_read334_rewind_phi_fu_7334_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_59_V_read334_rewind_phi_fu_7334_p6 = data_59_V_read334_phi_reg_18202.read();
    } else {
        ap_phi_mux_data_59_V_read334_rewind_phi_fu_7334_p6 = data_59_V_read334_rewind_reg_7330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_5_V_read280_phi_phi_fu_17558_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_5_V_read280_phi_phi_fu_17558_p4 = ap_phi_mux_data_5_V_read280_rewind_phi_fu_6578_p6.read();
    } else {
        ap_phi_mux_data_5_V_read280_phi_phi_fu_17558_p4 = ap_phi_reg_pp0_iter1_data_5_V_read280_phi_reg_17554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_5_V_read280_rewind_phi_fu_6578_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_5_V_read280_rewind_phi_fu_6578_p6 = data_5_V_read280_phi_reg_17554.read();
    } else {
        ap_phi_mux_data_5_V_read280_rewind_phi_fu_6578_p6 = data_5_V_read280_rewind_reg_6574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_600_V_read875_phi_phi_fu_24698_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_600_V_read875_phi_phi_fu_24698_p4 = ap_phi_mux_data_600_V_read875_rewind_phi_fu_14908_p6.read();
    } else {
        ap_phi_mux_data_600_V_read875_phi_phi_fu_24698_p4 = ap_phi_reg_pp0_iter1_data_600_V_read875_phi_reg_24694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_600_V_read875_rewind_phi_fu_14908_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_600_V_read875_rewind_phi_fu_14908_p6 = data_600_V_read875_phi_reg_24694.read();
    } else {
        ap_phi_mux_data_600_V_read875_rewind_phi_fu_14908_p6 = data_600_V_read875_rewind_reg_14904.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_601_V_read876_phi_phi_fu_24710_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_601_V_read876_phi_phi_fu_24710_p4 = ap_phi_mux_data_601_V_read876_rewind_phi_fu_14922_p6.read();
    } else {
        ap_phi_mux_data_601_V_read876_phi_phi_fu_24710_p4 = ap_phi_reg_pp0_iter1_data_601_V_read876_phi_reg_24706.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_601_V_read876_rewind_phi_fu_14922_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_601_V_read876_rewind_phi_fu_14922_p6 = data_601_V_read876_phi_reg_24706.read();
    } else {
        ap_phi_mux_data_601_V_read876_rewind_phi_fu_14922_p6 = data_601_V_read876_rewind_reg_14918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_602_V_read877_phi_phi_fu_24722_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_602_V_read877_phi_phi_fu_24722_p4 = ap_phi_mux_data_602_V_read877_rewind_phi_fu_14936_p6.read();
    } else {
        ap_phi_mux_data_602_V_read877_phi_phi_fu_24722_p4 = ap_phi_reg_pp0_iter1_data_602_V_read877_phi_reg_24718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_602_V_read877_rewind_phi_fu_14936_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_602_V_read877_rewind_phi_fu_14936_p6 = data_602_V_read877_phi_reg_24718.read();
    } else {
        ap_phi_mux_data_602_V_read877_rewind_phi_fu_14936_p6 = data_602_V_read877_rewind_reg_14932.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_603_V_read878_phi_phi_fu_24734_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_603_V_read878_phi_phi_fu_24734_p4 = ap_phi_mux_data_603_V_read878_rewind_phi_fu_14950_p6.read();
    } else {
        ap_phi_mux_data_603_V_read878_phi_phi_fu_24734_p4 = ap_phi_reg_pp0_iter1_data_603_V_read878_phi_reg_24730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_603_V_read878_rewind_phi_fu_14950_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_603_V_read878_rewind_phi_fu_14950_p6 = data_603_V_read878_phi_reg_24730.read();
    } else {
        ap_phi_mux_data_603_V_read878_rewind_phi_fu_14950_p6 = data_603_V_read878_rewind_reg_14946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_604_V_read879_phi_phi_fu_24746_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_604_V_read879_phi_phi_fu_24746_p4 = ap_phi_mux_data_604_V_read879_rewind_phi_fu_14964_p6.read();
    } else {
        ap_phi_mux_data_604_V_read879_phi_phi_fu_24746_p4 = ap_phi_reg_pp0_iter1_data_604_V_read879_phi_reg_24742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_604_V_read879_rewind_phi_fu_14964_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_604_V_read879_rewind_phi_fu_14964_p6 = data_604_V_read879_phi_reg_24742.read();
    } else {
        ap_phi_mux_data_604_V_read879_rewind_phi_fu_14964_p6 = data_604_V_read879_rewind_reg_14960.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_605_V_read880_phi_phi_fu_24758_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_605_V_read880_phi_phi_fu_24758_p4 = ap_phi_mux_data_605_V_read880_rewind_phi_fu_14978_p6.read();
    } else {
        ap_phi_mux_data_605_V_read880_phi_phi_fu_24758_p4 = ap_phi_reg_pp0_iter1_data_605_V_read880_phi_reg_24754.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_605_V_read880_rewind_phi_fu_14978_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_605_V_read880_rewind_phi_fu_14978_p6 = data_605_V_read880_phi_reg_24754.read();
    } else {
        ap_phi_mux_data_605_V_read880_rewind_phi_fu_14978_p6 = data_605_V_read880_rewind_reg_14974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_606_V_read881_phi_phi_fu_24770_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_606_V_read881_phi_phi_fu_24770_p4 = ap_phi_mux_data_606_V_read881_rewind_phi_fu_14992_p6.read();
    } else {
        ap_phi_mux_data_606_V_read881_phi_phi_fu_24770_p4 = ap_phi_reg_pp0_iter1_data_606_V_read881_phi_reg_24766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_606_V_read881_rewind_phi_fu_14992_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_606_V_read881_rewind_phi_fu_14992_p6 = data_606_V_read881_phi_reg_24766.read();
    } else {
        ap_phi_mux_data_606_V_read881_rewind_phi_fu_14992_p6 = data_606_V_read881_rewind_reg_14988.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_607_V_read882_phi_phi_fu_24782_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_607_V_read882_phi_phi_fu_24782_p4 = ap_phi_mux_data_607_V_read882_rewind_phi_fu_15006_p6.read();
    } else {
        ap_phi_mux_data_607_V_read882_phi_phi_fu_24782_p4 = ap_phi_reg_pp0_iter1_data_607_V_read882_phi_reg_24778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_607_V_read882_rewind_phi_fu_15006_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_607_V_read882_rewind_phi_fu_15006_p6 = data_607_V_read882_phi_reg_24778.read();
    } else {
        ap_phi_mux_data_607_V_read882_rewind_phi_fu_15006_p6 = data_607_V_read882_rewind_reg_15002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_608_V_read883_phi_phi_fu_24794_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_608_V_read883_phi_phi_fu_24794_p4 = ap_phi_mux_data_608_V_read883_rewind_phi_fu_15020_p6.read();
    } else {
        ap_phi_mux_data_608_V_read883_phi_phi_fu_24794_p4 = ap_phi_reg_pp0_iter1_data_608_V_read883_phi_reg_24790.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_608_V_read883_rewind_phi_fu_15020_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_608_V_read883_rewind_phi_fu_15020_p6 = data_608_V_read883_phi_reg_24790.read();
    } else {
        ap_phi_mux_data_608_V_read883_rewind_phi_fu_15020_p6 = data_608_V_read883_rewind_reg_15016.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_609_V_read884_phi_phi_fu_24806_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_609_V_read884_phi_phi_fu_24806_p4 = ap_phi_mux_data_609_V_read884_rewind_phi_fu_15034_p6.read();
    } else {
        ap_phi_mux_data_609_V_read884_phi_phi_fu_24806_p4 = ap_phi_reg_pp0_iter1_data_609_V_read884_phi_reg_24802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_609_V_read884_rewind_phi_fu_15034_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_609_V_read884_rewind_phi_fu_15034_p6 = data_609_V_read884_phi_reg_24802.read();
    } else {
        ap_phi_mux_data_609_V_read884_rewind_phi_fu_15034_p6 = data_609_V_read884_rewind_reg_15030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_60_V_read335_phi_phi_fu_18218_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_60_V_read335_phi_phi_fu_18218_p4 = ap_phi_mux_data_60_V_read335_rewind_phi_fu_7348_p6.read();
    } else {
        ap_phi_mux_data_60_V_read335_phi_phi_fu_18218_p4 = ap_phi_reg_pp0_iter1_data_60_V_read335_phi_reg_18214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_60_V_read335_rewind_phi_fu_7348_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_60_V_read335_rewind_phi_fu_7348_p6 = data_60_V_read335_phi_reg_18214.read();
    } else {
        ap_phi_mux_data_60_V_read335_rewind_phi_fu_7348_p6 = data_60_V_read335_rewind_reg_7344.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_610_V_read885_phi_phi_fu_24818_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_610_V_read885_phi_phi_fu_24818_p4 = ap_phi_mux_data_610_V_read885_rewind_phi_fu_15048_p6.read();
    } else {
        ap_phi_mux_data_610_V_read885_phi_phi_fu_24818_p4 = ap_phi_reg_pp0_iter1_data_610_V_read885_phi_reg_24814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_610_V_read885_rewind_phi_fu_15048_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_610_V_read885_rewind_phi_fu_15048_p6 = data_610_V_read885_phi_reg_24814.read();
    } else {
        ap_phi_mux_data_610_V_read885_rewind_phi_fu_15048_p6 = data_610_V_read885_rewind_reg_15044.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_611_V_read886_phi_phi_fu_24830_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_611_V_read886_phi_phi_fu_24830_p4 = ap_phi_mux_data_611_V_read886_rewind_phi_fu_15062_p6.read();
    } else {
        ap_phi_mux_data_611_V_read886_phi_phi_fu_24830_p4 = ap_phi_reg_pp0_iter1_data_611_V_read886_phi_reg_24826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_611_V_read886_rewind_phi_fu_15062_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_611_V_read886_rewind_phi_fu_15062_p6 = data_611_V_read886_phi_reg_24826.read();
    } else {
        ap_phi_mux_data_611_V_read886_rewind_phi_fu_15062_p6 = data_611_V_read886_rewind_reg_15058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_612_V_read887_phi_phi_fu_24842_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_612_V_read887_phi_phi_fu_24842_p4 = ap_phi_mux_data_612_V_read887_rewind_phi_fu_15076_p6.read();
    } else {
        ap_phi_mux_data_612_V_read887_phi_phi_fu_24842_p4 = ap_phi_reg_pp0_iter1_data_612_V_read887_phi_reg_24838.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_612_V_read887_rewind_phi_fu_15076_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_612_V_read887_rewind_phi_fu_15076_p6 = data_612_V_read887_phi_reg_24838.read();
    } else {
        ap_phi_mux_data_612_V_read887_rewind_phi_fu_15076_p6 = data_612_V_read887_rewind_reg_15072.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_613_V_read888_phi_phi_fu_24854_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_613_V_read888_phi_phi_fu_24854_p4 = ap_phi_mux_data_613_V_read888_rewind_phi_fu_15090_p6.read();
    } else {
        ap_phi_mux_data_613_V_read888_phi_phi_fu_24854_p4 = ap_phi_reg_pp0_iter1_data_613_V_read888_phi_reg_24850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_613_V_read888_rewind_phi_fu_15090_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_613_V_read888_rewind_phi_fu_15090_p6 = data_613_V_read888_phi_reg_24850.read();
    } else {
        ap_phi_mux_data_613_V_read888_rewind_phi_fu_15090_p6 = data_613_V_read888_rewind_reg_15086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_614_V_read889_phi_phi_fu_24866_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_614_V_read889_phi_phi_fu_24866_p4 = ap_phi_mux_data_614_V_read889_rewind_phi_fu_15104_p6.read();
    } else {
        ap_phi_mux_data_614_V_read889_phi_phi_fu_24866_p4 = ap_phi_reg_pp0_iter1_data_614_V_read889_phi_reg_24862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_614_V_read889_rewind_phi_fu_15104_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_614_V_read889_rewind_phi_fu_15104_p6 = data_614_V_read889_phi_reg_24862.read();
    } else {
        ap_phi_mux_data_614_V_read889_rewind_phi_fu_15104_p6 = data_614_V_read889_rewind_reg_15100.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_615_V_read890_phi_phi_fu_24878_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_615_V_read890_phi_phi_fu_24878_p4 = ap_phi_mux_data_615_V_read890_rewind_phi_fu_15118_p6.read();
    } else {
        ap_phi_mux_data_615_V_read890_phi_phi_fu_24878_p4 = ap_phi_reg_pp0_iter1_data_615_V_read890_phi_reg_24874.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_615_V_read890_rewind_phi_fu_15118_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_615_V_read890_rewind_phi_fu_15118_p6 = data_615_V_read890_phi_reg_24874.read();
    } else {
        ap_phi_mux_data_615_V_read890_rewind_phi_fu_15118_p6 = data_615_V_read890_rewind_reg_15114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_616_V_read891_phi_phi_fu_24890_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_616_V_read891_phi_phi_fu_24890_p4 = ap_phi_mux_data_616_V_read891_rewind_phi_fu_15132_p6.read();
    } else {
        ap_phi_mux_data_616_V_read891_phi_phi_fu_24890_p4 = ap_phi_reg_pp0_iter1_data_616_V_read891_phi_reg_24886.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_616_V_read891_rewind_phi_fu_15132_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_616_V_read891_rewind_phi_fu_15132_p6 = data_616_V_read891_phi_reg_24886.read();
    } else {
        ap_phi_mux_data_616_V_read891_rewind_phi_fu_15132_p6 = data_616_V_read891_rewind_reg_15128.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_617_V_read892_phi_phi_fu_24902_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_617_V_read892_phi_phi_fu_24902_p4 = ap_phi_mux_data_617_V_read892_rewind_phi_fu_15146_p6.read();
    } else {
        ap_phi_mux_data_617_V_read892_phi_phi_fu_24902_p4 = ap_phi_reg_pp0_iter1_data_617_V_read892_phi_reg_24898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_617_V_read892_rewind_phi_fu_15146_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_617_V_read892_rewind_phi_fu_15146_p6 = data_617_V_read892_phi_reg_24898.read();
    } else {
        ap_phi_mux_data_617_V_read892_rewind_phi_fu_15146_p6 = data_617_V_read892_rewind_reg_15142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_618_V_read893_phi_phi_fu_24914_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_618_V_read893_phi_phi_fu_24914_p4 = ap_phi_mux_data_618_V_read893_rewind_phi_fu_15160_p6.read();
    } else {
        ap_phi_mux_data_618_V_read893_phi_phi_fu_24914_p4 = ap_phi_reg_pp0_iter1_data_618_V_read893_phi_reg_24910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_618_V_read893_rewind_phi_fu_15160_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_618_V_read893_rewind_phi_fu_15160_p6 = data_618_V_read893_phi_reg_24910.read();
    } else {
        ap_phi_mux_data_618_V_read893_rewind_phi_fu_15160_p6 = data_618_V_read893_rewind_reg_15156.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_619_V_read894_phi_phi_fu_24926_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_619_V_read894_phi_phi_fu_24926_p4 = ap_phi_mux_data_619_V_read894_rewind_phi_fu_15174_p6.read();
    } else {
        ap_phi_mux_data_619_V_read894_phi_phi_fu_24926_p4 = ap_phi_reg_pp0_iter1_data_619_V_read894_phi_reg_24922.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_619_V_read894_rewind_phi_fu_15174_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_619_V_read894_rewind_phi_fu_15174_p6 = data_619_V_read894_phi_reg_24922.read();
    } else {
        ap_phi_mux_data_619_V_read894_rewind_phi_fu_15174_p6 = data_619_V_read894_rewind_reg_15170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_61_V_read336_phi_phi_fu_18230_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_61_V_read336_phi_phi_fu_18230_p4 = ap_phi_mux_data_61_V_read336_rewind_phi_fu_7362_p6.read();
    } else {
        ap_phi_mux_data_61_V_read336_phi_phi_fu_18230_p4 = ap_phi_reg_pp0_iter1_data_61_V_read336_phi_reg_18226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_61_V_read336_rewind_phi_fu_7362_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_61_V_read336_rewind_phi_fu_7362_p6 = data_61_V_read336_phi_reg_18226.read();
    } else {
        ap_phi_mux_data_61_V_read336_rewind_phi_fu_7362_p6 = data_61_V_read336_rewind_reg_7358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_620_V_read895_phi_phi_fu_24938_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_620_V_read895_phi_phi_fu_24938_p4 = ap_phi_mux_data_620_V_read895_rewind_phi_fu_15188_p6.read();
    } else {
        ap_phi_mux_data_620_V_read895_phi_phi_fu_24938_p4 = ap_phi_reg_pp0_iter1_data_620_V_read895_phi_reg_24934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_620_V_read895_rewind_phi_fu_15188_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_620_V_read895_rewind_phi_fu_15188_p6 = data_620_V_read895_phi_reg_24934.read();
    } else {
        ap_phi_mux_data_620_V_read895_rewind_phi_fu_15188_p6 = data_620_V_read895_rewind_reg_15184.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_621_V_read896_phi_phi_fu_24950_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_621_V_read896_phi_phi_fu_24950_p4 = ap_phi_mux_data_621_V_read896_rewind_phi_fu_15202_p6.read();
    } else {
        ap_phi_mux_data_621_V_read896_phi_phi_fu_24950_p4 = ap_phi_reg_pp0_iter1_data_621_V_read896_phi_reg_24946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_621_V_read896_rewind_phi_fu_15202_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_621_V_read896_rewind_phi_fu_15202_p6 = data_621_V_read896_phi_reg_24946.read();
    } else {
        ap_phi_mux_data_621_V_read896_rewind_phi_fu_15202_p6 = data_621_V_read896_rewind_reg_15198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_622_V_read897_phi_phi_fu_24962_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_622_V_read897_phi_phi_fu_24962_p4 = ap_phi_mux_data_622_V_read897_rewind_phi_fu_15216_p6.read();
    } else {
        ap_phi_mux_data_622_V_read897_phi_phi_fu_24962_p4 = ap_phi_reg_pp0_iter1_data_622_V_read897_phi_reg_24958.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_622_V_read897_rewind_phi_fu_15216_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_622_V_read897_rewind_phi_fu_15216_p6 = data_622_V_read897_phi_reg_24958.read();
    } else {
        ap_phi_mux_data_622_V_read897_rewind_phi_fu_15216_p6 = data_622_V_read897_rewind_reg_15212.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_623_V_read898_phi_phi_fu_24974_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_623_V_read898_phi_phi_fu_24974_p4 = ap_phi_mux_data_623_V_read898_rewind_phi_fu_15230_p6.read();
    } else {
        ap_phi_mux_data_623_V_read898_phi_phi_fu_24974_p4 = ap_phi_reg_pp0_iter1_data_623_V_read898_phi_reg_24970.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_623_V_read898_rewind_phi_fu_15230_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_623_V_read898_rewind_phi_fu_15230_p6 = data_623_V_read898_phi_reg_24970.read();
    } else {
        ap_phi_mux_data_623_V_read898_rewind_phi_fu_15230_p6 = data_623_V_read898_rewind_reg_15226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_624_V_read899_phi_phi_fu_24986_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_624_V_read899_phi_phi_fu_24986_p4 = ap_phi_mux_data_624_V_read899_rewind_phi_fu_15244_p6.read();
    } else {
        ap_phi_mux_data_624_V_read899_phi_phi_fu_24986_p4 = ap_phi_reg_pp0_iter1_data_624_V_read899_phi_reg_24982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_624_V_read899_rewind_phi_fu_15244_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_624_V_read899_rewind_phi_fu_15244_p6 = data_624_V_read899_phi_reg_24982.read();
    } else {
        ap_phi_mux_data_624_V_read899_rewind_phi_fu_15244_p6 = data_624_V_read899_rewind_reg_15240.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_625_V_read900_phi_phi_fu_24998_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_625_V_read900_phi_phi_fu_24998_p4 = ap_phi_mux_data_625_V_read900_rewind_phi_fu_15258_p6.read();
    } else {
        ap_phi_mux_data_625_V_read900_phi_phi_fu_24998_p4 = ap_phi_reg_pp0_iter1_data_625_V_read900_phi_reg_24994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_625_V_read900_rewind_phi_fu_15258_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_625_V_read900_rewind_phi_fu_15258_p6 = data_625_V_read900_phi_reg_24994.read();
    } else {
        ap_phi_mux_data_625_V_read900_rewind_phi_fu_15258_p6 = data_625_V_read900_rewind_reg_15254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_626_V_read901_phi_phi_fu_25010_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_626_V_read901_phi_phi_fu_25010_p4 = ap_phi_mux_data_626_V_read901_rewind_phi_fu_15272_p6.read();
    } else {
        ap_phi_mux_data_626_V_read901_phi_phi_fu_25010_p4 = ap_phi_reg_pp0_iter1_data_626_V_read901_phi_reg_25006.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_626_V_read901_rewind_phi_fu_15272_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_626_V_read901_rewind_phi_fu_15272_p6 = data_626_V_read901_phi_reg_25006.read();
    } else {
        ap_phi_mux_data_626_V_read901_rewind_phi_fu_15272_p6 = data_626_V_read901_rewind_reg_15268.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_627_V_read902_phi_phi_fu_25022_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_627_V_read902_phi_phi_fu_25022_p4 = ap_phi_mux_data_627_V_read902_rewind_phi_fu_15286_p6.read();
    } else {
        ap_phi_mux_data_627_V_read902_phi_phi_fu_25022_p4 = ap_phi_reg_pp0_iter1_data_627_V_read902_phi_reg_25018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_627_V_read902_rewind_phi_fu_15286_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_627_V_read902_rewind_phi_fu_15286_p6 = data_627_V_read902_phi_reg_25018.read();
    } else {
        ap_phi_mux_data_627_V_read902_rewind_phi_fu_15286_p6 = data_627_V_read902_rewind_reg_15282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_628_V_read903_phi_phi_fu_25034_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_628_V_read903_phi_phi_fu_25034_p4 = ap_phi_mux_data_628_V_read903_rewind_phi_fu_15300_p6.read();
    } else {
        ap_phi_mux_data_628_V_read903_phi_phi_fu_25034_p4 = ap_phi_reg_pp0_iter1_data_628_V_read903_phi_reg_25030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_628_V_read903_rewind_phi_fu_15300_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_628_V_read903_rewind_phi_fu_15300_p6 = data_628_V_read903_phi_reg_25030.read();
    } else {
        ap_phi_mux_data_628_V_read903_rewind_phi_fu_15300_p6 = data_628_V_read903_rewind_reg_15296.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_629_V_read904_phi_phi_fu_25046_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_629_V_read904_phi_phi_fu_25046_p4 = ap_phi_mux_data_629_V_read904_rewind_phi_fu_15314_p6.read();
    } else {
        ap_phi_mux_data_629_V_read904_phi_phi_fu_25046_p4 = ap_phi_reg_pp0_iter1_data_629_V_read904_phi_reg_25042.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_629_V_read904_rewind_phi_fu_15314_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_629_V_read904_rewind_phi_fu_15314_p6 = data_629_V_read904_phi_reg_25042.read();
    } else {
        ap_phi_mux_data_629_V_read904_rewind_phi_fu_15314_p6 = data_629_V_read904_rewind_reg_15310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_62_V_read337_phi_phi_fu_18242_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_62_V_read337_phi_phi_fu_18242_p4 = ap_phi_mux_data_62_V_read337_rewind_phi_fu_7376_p6.read();
    } else {
        ap_phi_mux_data_62_V_read337_phi_phi_fu_18242_p4 = ap_phi_reg_pp0_iter1_data_62_V_read337_phi_reg_18238.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_62_V_read337_rewind_phi_fu_7376_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_62_V_read337_rewind_phi_fu_7376_p6 = data_62_V_read337_phi_reg_18238.read();
    } else {
        ap_phi_mux_data_62_V_read337_rewind_phi_fu_7376_p6 = data_62_V_read337_rewind_reg_7372.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_630_V_read905_phi_phi_fu_25058_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_630_V_read905_phi_phi_fu_25058_p4 = ap_phi_mux_data_630_V_read905_rewind_phi_fu_15328_p6.read();
    } else {
        ap_phi_mux_data_630_V_read905_phi_phi_fu_25058_p4 = ap_phi_reg_pp0_iter1_data_630_V_read905_phi_reg_25054.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_630_V_read905_rewind_phi_fu_15328_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_630_V_read905_rewind_phi_fu_15328_p6 = data_630_V_read905_phi_reg_25054.read();
    } else {
        ap_phi_mux_data_630_V_read905_rewind_phi_fu_15328_p6 = data_630_V_read905_rewind_reg_15324.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_631_V_read906_phi_phi_fu_25070_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_631_V_read906_phi_phi_fu_25070_p4 = ap_phi_mux_data_631_V_read906_rewind_phi_fu_15342_p6.read();
    } else {
        ap_phi_mux_data_631_V_read906_phi_phi_fu_25070_p4 = ap_phi_reg_pp0_iter1_data_631_V_read906_phi_reg_25066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_631_V_read906_rewind_phi_fu_15342_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_631_V_read906_rewind_phi_fu_15342_p6 = data_631_V_read906_phi_reg_25066.read();
    } else {
        ap_phi_mux_data_631_V_read906_rewind_phi_fu_15342_p6 = data_631_V_read906_rewind_reg_15338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_632_V_read907_phi_phi_fu_25082_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_632_V_read907_phi_phi_fu_25082_p4 = ap_phi_mux_data_632_V_read907_rewind_phi_fu_15356_p6.read();
    } else {
        ap_phi_mux_data_632_V_read907_phi_phi_fu_25082_p4 = ap_phi_reg_pp0_iter1_data_632_V_read907_phi_reg_25078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_632_V_read907_rewind_phi_fu_15356_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_632_V_read907_rewind_phi_fu_15356_p6 = data_632_V_read907_phi_reg_25078.read();
    } else {
        ap_phi_mux_data_632_V_read907_rewind_phi_fu_15356_p6 = data_632_V_read907_rewind_reg_15352.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_633_V_read908_phi_phi_fu_25094_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_633_V_read908_phi_phi_fu_25094_p4 = ap_phi_mux_data_633_V_read908_rewind_phi_fu_15370_p6.read();
    } else {
        ap_phi_mux_data_633_V_read908_phi_phi_fu_25094_p4 = ap_phi_reg_pp0_iter1_data_633_V_read908_phi_reg_25090.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_633_V_read908_rewind_phi_fu_15370_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_633_V_read908_rewind_phi_fu_15370_p6 = data_633_V_read908_phi_reg_25090.read();
    } else {
        ap_phi_mux_data_633_V_read908_rewind_phi_fu_15370_p6 = data_633_V_read908_rewind_reg_15366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_634_V_read909_phi_phi_fu_25106_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_634_V_read909_phi_phi_fu_25106_p4 = ap_phi_mux_data_634_V_read909_rewind_phi_fu_15384_p6.read();
    } else {
        ap_phi_mux_data_634_V_read909_phi_phi_fu_25106_p4 = ap_phi_reg_pp0_iter1_data_634_V_read909_phi_reg_25102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_634_V_read909_rewind_phi_fu_15384_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_634_V_read909_rewind_phi_fu_15384_p6 = data_634_V_read909_phi_reg_25102.read();
    } else {
        ap_phi_mux_data_634_V_read909_rewind_phi_fu_15384_p6 = data_634_V_read909_rewind_reg_15380.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_635_V_read910_phi_phi_fu_25118_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_635_V_read910_phi_phi_fu_25118_p4 = ap_phi_mux_data_635_V_read910_rewind_phi_fu_15398_p6.read();
    } else {
        ap_phi_mux_data_635_V_read910_phi_phi_fu_25118_p4 = ap_phi_reg_pp0_iter1_data_635_V_read910_phi_reg_25114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_635_V_read910_rewind_phi_fu_15398_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_635_V_read910_rewind_phi_fu_15398_p6 = data_635_V_read910_phi_reg_25114.read();
    } else {
        ap_phi_mux_data_635_V_read910_rewind_phi_fu_15398_p6 = data_635_V_read910_rewind_reg_15394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_636_V_read911_phi_phi_fu_25130_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_636_V_read911_phi_phi_fu_25130_p4 = ap_phi_mux_data_636_V_read911_rewind_phi_fu_15412_p6.read();
    } else {
        ap_phi_mux_data_636_V_read911_phi_phi_fu_25130_p4 = ap_phi_reg_pp0_iter1_data_636_V_read911_phi_reg_25126.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_636_V_read911_rewind_phi_fu_15412_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_636_V_read911_rewind_phi_fu_15412_p6 = data_636_V_read911_phi_reg_25126.read();
    } else {
        ap_phi_mux_data_636_V_read911_rewind_phi_fu_15412_p6 = data_636_V_read911_rewind_reg_15408.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_637_V_read912_phi_phi_fu_25142_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_637_V_read912_phi_phi_fu_25142_p4 = ap_phi_mux_data_637_V_read912_rewind_phi_fu_15426_p6.read();
    } else {
        ap_phi_mux_data_637_V_read912_phi_phi_fu_25142_p4 = ap_phi_reg_pp0_iter1_data_637_V_read912_phi_reg_25138.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_637_V_read912_rewind_phi_fu_15426_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_637_V_read912_rewind_phi_fu_15426_p6 = data_637_V_read912_phi_reg_25138.read();
    } else {
        ap_phi_mux_data_637_V_read912_rewind_phi_fu_15426_p6 = data_637_V_read912_rewind_reg_15422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_638_V_read913_phi_phi_fu_25154_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_638_V_read913_phi_phi_fu_25154_p4 = ap_phi_mux_data_638_V_read913_rewind_phi_fu_15440_p6.read();
    } else {
        ap_phi_mux_data_638_V_read913_phi_phi_fu_25154_p4 = ap_phi_reg_pp0_iter1_data_638_V_read913_phi_reg_25150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_638_V_read913_rewind_phi_fu_15440_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_638_V_read913_rewind_phi_fu_15440_p6 = data_638_V_read913_phi_reg_25150.read();
    } else {
        ap_phi_mux_data_638_V_read913_rewind_phi_fu_15440_p6 = data_638_V_read913_rewind_reg_15436.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_639_V_read914_phi_phi_fu_25166_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_639_V_read914_phi_phi_fu_25166_p4 = ap_phi_mux_data_639_V_read914_rewind_phi_fu_15454_p6.read();
    } else {
        ap_phi_mux_data_639_V_read914_phi_phi_fu_25166_p4 = ap_phi_reg_pp0_iter1_data_639_V_read914_phi_reg_25162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_639_V_read914_rewind_phi_fu_15454_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_639_V_read914_rewind_phi_fu_15454_p6 = data_639_V_read914_phi_reg_25162.read();
    } else {
        ap_phi_mux_data_639_V_read914_rewind_phi_fu_15454_p6 = data_639_V_read914_rewind_reg_15450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_63_V_read338_phi_phi_fu_18254_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_63_V_read338_phi_phi_fu_18254_p4 = ap_phi_mux_data_63_V_read338_rewind_phi_fu_7390_p6.read();
    } else {
        ap_phi_mux_data_63_V_read338_phi_phi_fu_18254_p4 = ap_phi_reg_pp0_iter1_data_63_V_read338_phi_reg_18250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_63_V_read338_rewind_phi_fu_7390_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_63_V_read338_rewind_phi_fu_7390_p6 = data_63_V_read338_phi_reg_18250.read();
    } else {
        ap_phi_mux_data_63_V_read338_rewind_phi_fu_7390_p6 = data_63_V_read338_rewind_reg_7386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_640_V_read915_phi_phi_fu_25178_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_640_V_read915_phi_phi_fu_25178_p4 = ap_phi_mux_data_640_V_read915_rewind_phi_fu_15468_p6.read();
    } else {
        ap_phi_mux_data_640_V_read915_phi_phi_fu_25178_p4 = ap_phi_reg_pp0_iter1_data_640_V_read915_phi_reg_25174.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_640_V_read915_rewind_phi_fu_15468_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_640_V_read915_rewind_phi_fu_15468_p6 = data_640_V_read915_phi_reg_25174.read();
    } else {
        ap_phi_mux_data_640_V_read915_rewind_phi_fu_15468_p6 = data_640_V_read915_rewind_reg_15464.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_641_V_read916_phi_phi_fu_25190_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_641_V_read916_phi_phi_fu_25190_p4 = ap_phi_mux_data_641_V_read916_rewind_phi_fu_15482_p6.read();
    } else {
        ap_phi_mux_data_641_V_read916_phi_phi_fu_25190_p4 = ap_phi_reg_pp0_iter1_data_641_V_read916_phi_reg_25186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_641_V_read916_rewind_phi_fu_15482_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_641_V_read916_rewind_phi_fu_15482_p6 = data_641_V_read916_phi_reg_25186.read();
    } else {
        ap_phi_mux_data_641_V_read916_rewind_phi_fu_15482_p6 = data_641_V_read916_rewind_reg_15478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_642_V_read917_phi_phi_fu_25202_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_642_V_read917_phi_phi_fu_25202_p4 = ap_phi_mux_data_642_V_read917_rewind_phi_fu_15496_p6.read();
    } else {
        ap_phi_mux_data_642_V_read917_phi_phi_fu_25202_p4 = ap_phi_reg_pp0_iter1_data_642_V_read917_phi_reg_25198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_642_V_read917_rewind_phi_fu_15496_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_642_V_read917_rewind_phi_fu_15496_p6 = data_642_V_read917_phi_reg_25198.read();
    } else {
        ap_phi_mux_data_642_V_read917_rewind_phi_fu_15496_p6 = data_642_V_read917_rewind_reg_15492.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_643_V_read918_phi_phi_fu_25214_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_643_V_read918_phi_phi_fu_25214_p4 = ap_phi_mux_data_643_V_read918_rewind_phi_fu_15510_p6.read();
    } else {
        ap_phi_mux_data_643_V_read918_phi_phi_fu_25214_p4 = ap_phi_reg_pp0_iter1_data_643_V_read918_phi_reg_25210.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_643_V_read918_rewind_phi_fu_15510_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_643_V_read918_rewind_phi_fu_15510_p6 = data_643_V_read918_phi_reg_25210.read();
    } else {
        ap_phi_mux_data_643_V_read918_rewind_phi_fu_15510_p6 = data_643_V_read918_rewind_reg_15506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_644_V_read919_phi_phi_fu_25226_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_644_V_read919_phi_phi_fu_25226_p4 = ap_phi_mux_data_644_V_read919_rewind_phi_fu_15524_p6.read();
    } else {
        ap_phi_mux_data_644_V_read919_phi_phi_fu_25226_p4 = ap_phi_reg_pp0_iter1_data_644_V_read919_phi_reg_25222.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_644_V_read919_rewind_phi_fu_15524_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_644_V_read919_rewind_phi_fu_15524_p6 = data_644_V_read919_phi_reg_25222.read();
    } else {
        ap_phi_mux_data_644_V_read919_rewind_phi_fu_15524_p6 = data_644_V_read919_rewind_reg_15520.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_645_V_read920_phi_phi_fu_25238_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_645_V_read920_phi_phi_fu_25238_p4 = ap_phi_mux_data_645_V_read920_rewind_phi_fu_15538_p6.read();
    } else {
        ap_phi_mux_data_645_V_read920_phi_phi_fu_25238_p4 = ap_phi_reg_pp0_iter1_data_645_V_read920_phi_reg_25234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_645_V_read920_rewind_phi_fu_15538_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_645_V_read920_rewind_phi_fu_15538_p6 = data_645_V_read920_phi_reg_25234.read();
    } else {
        ap_phi_mux_data_645_V_read920_rewind_phi_fu_15538_p6 = data_645_V_read920_rewind_reg_15534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_646_V_read921_phi_phi_fu_25250_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_646_V_read921_phi_phi_fu_25250_p4 = ap_phi_mux_data_646_V_read921_rewind_phi_fu_15552_p6.read();
    } else {
        ap_phi_mux_data_646_V_read921_phi_phi_fu_25250_p4 = ap_phi_reg_pp0_iter1_data_646_V_read921_phi_reg_25246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_646_V_read921_rewind_phi_fu_15552_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_646_V_read921_rewind_phi_fu_15552_p6 = data_646_V_read921_phi_reg_25246.read();
    } else {
        ap_phi_mux_data_646_V_read921_rewind_phi_fu_15552_p6 = data_646_V_read921_rewind_reg_15548.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_647_V_read922_phi_phi_fu_25262_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_647_V_read922_phi_phi_fu_25262_p4 = ap_phi_mux_data_647_V_read922_rewind_phi_fu_15566_p6.read();
    } else {
        ap_phi_mux_data_647_V_read922_phi_phi_fu_25262_p4 = ap_phi_reg_pp0_iter1_data_647_V_read922_phi_reg_25258.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_647_V_read922_rewind_phi_fu_15566_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_647_V_read922_rewind_phi_fu_15566_p6 = data_647_V_read922_phi_reg_25258.read();
    } else {
        ap_phi_mux_data_647_V_read922_rewind_phi_fu_15566_p6 = data_647_V_read922_rewind_reg_15562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_648_V_read923_phi_phi_fu_25274_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_648_V_read923_phi_phi_fu_25274_p4 = ap_phi_mux_data_648_V_read923_rewind_phi_fu_15580_p6.read();
    } else {
        ap_phi_mux_data_648_V_read923_phi_phi_fu_25274_p4 = ap_phi_reg_pp0_iter1_data_648_V_read923_phi_reg_25270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_648_V_read923_rewind_phi_fu_15580_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_648_V_read923_rewind_phi_fu_15580_p6 = data_648_V_read923_phi_reg_25270.read();
    } else {
        ap_phi_mux_data_648_V_read923_rewind_phi_fu_15580_p6 = data_648_V_read923_rewind_reg_15576.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_649_V_read924_phi_phi_fu_25286_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_649_V_read924_phi_phi_fu_25286_p4 = ap_phi_mux_data_649_V_read924_rewind_phi_fu_15594_p6.read();
    } else {
        ap_phi_mux_data_649_V_read924_phi_phi_fu_25286_p4 = ap_phi_reg_pp0_iter1_data_649_V_read924_phi_reg_25282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_649_V_read924_rewind_phi_fu_15594_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_649_V_read924_rewind_phi_fu_15594_p6 = data_649_V_read924_phi_reg_25282.read();
    } else {
        ap_phi_mux_data_649_V_read924_rewind_phi_fu_15594_p6 = data_649_V_read924_rewind_reg_15590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_64_V_read339_phi_phi_fu_18266_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_64_V_read339_phi_phi_fu_18266_p4 = ap_phi_mux_data_64_V_read339_rewind_phi_fu_7404_p6.read();
    } else {
        ap_phi_mux_data_64_V_read339_phi_phi_fu_18266_p4 = ap_phi_reg_pp0_iter1_data_64_V_read339_phi_reg_18262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_64_V_read339_rewind_phi_fu_7404_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_64_V_read339_rewind_phi_fu_7404_p6 = data_64_V_read339_phi_reg_18262.read();
    } else {
        ap_phi_mux_data_64_V_read339_rewind_phi_fu_7404_p6 = data_64_V_read339_rewind_reg_7400.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_650_V_read925_phi_phi_fu_25298_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_650_V_read925_phi_phi_fu_25298_p4 = ap_phi_mux_data_650_V_read925_rewind_phi_fu_15608_p6.read();
    } else {
        ap_phi_mux_data_650_V_read925_phi_phi_fu_25298_p4 = ap_phi_reg_pp0_iter1_data_650_V_read925_phi_reg_25294.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_650_V_read925_rewind_phi_fu_15608_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_650_V_read925_rewind_phi_fu_15608_p6 = data_650_V_read925_phi_reg_25294.read();
    } else {
        ap_phi_mux_data_650_V_read925_rewind_phi_fu_15608_p6 = data_650_V_read925_rewind_reg_15604.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_651_V_read926_phi_phi_fu_25310_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_651_V_read926_phi_phi_fu_25310_p4 = ap_phi_mux_data_651_V_read926_rewind_phi_fu_15622_p6.read();
    } else {
        ap_phi_mux_data_651_V_read926_phi_phi_fu_25310_p4 = ap_phi_reg_pp0_iter1_data_651_V_read926_phi_reg_25306.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_651_V_read926_rewind_phi_fu_15622_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_651_V_read926_rewind_phi_fu_15622_p6 = data_651_V_read926_phi_reg_25306.read();
    } else {
        ap_phi_mux_data_651_V_read926_rewind_phi_fu_15622_p6 = data_651_V_read926_rewind_reg_15618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_652_V_read927_phi_phi_fu_25322_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_652_V_read927_phi_phi_fu_25322_p4 = ap_phi_mux_data_652_V_read927_rewind_phi_fu_15636_p6.read();
    } else {
        ap_phi_mux_data_652_V_read927_phi_phi_fu_25322_p4 = ap_phi_reg_pp0_iter1_data_652_V_read927_phi_reg_25318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_652_V_read927_rewind_phi_fu_15636_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_652_V_read927_rewind_phi_fu_15636_p6 = data_652_V_read927_phi_reg_25318.read();
    } else {
        ap_phi_mux_data_652_V_read927_rewind_phi_fu_15636_p6 = data_652_V_read927_rewind_reg_15632.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_653_V_read928_phi_phi_fu_25334_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_653_V_read928_phi_phi_fu_25334_p4 = ap_phi_mux_data_653_V_read928_rewind_phi_fu_15650_p6.read();
    } else {
        ap_phi_mux_data_653_V_read928_phi_phi_fu_25334_p4 = ap_phi_reg_pp0_iter1_data_653_V_read928_phi_reg_25330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_653_V_read928_rewind_phi_fu_15650_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_653_V_read928_rewind_phi_fu_15650_p6 = data_653_V_read928_phi_reg_25330.read();
    } else {
        ap_phi_mux_data_653_V_read928_rewind_phi_fu_15650_p6 = data_653_V_read928_rewind_reg_15646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_654_V_read929_phi_phi_fu_25346_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_654_V_read929_phi_phi_fu_25346_p4 = ap_phi_mux_data_654_V_read929_rewind_phi_fu_15664_p6.read();
    } else {
        ap_phi_mux_data_654_V_read929_phi_phi_fu_25346_p4 = ap_phi_reg_pp0_iter1_data_654_V_read929_phi_reg_25342.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_654_V_read929_rewind_phi_fu_15664_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_654_V_read929_rewind_phi_fu_15664_p6 = data_654_V_read929_phi_reg_25342.read();
    } else {
        ap_phi_mux_data_654_V_read929_rewind_phi_fu_15664_p6 = data_654_V_read929_rewind_reg_15660.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_655_V_read930_phi_phi_fu_25358_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_655_V_read930_phi_phi_fu_25358_p4 = ap_phi_mux_data_655_V_read930_rewind_phi_fu_15678_p6.read();
    } else {
        ap_phi_mux_data_655_V_read930_phi_phi_fu_25358_p4 = ap_phi_reg_pp0_iter1_data_655_V_read930_phi_reg_25354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_655_V_read930_rewind_phi_fu_15678_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_655_V_read930_rewind_phi_fu_15678_p6 = data_655_V_read930_phi_reg_25354.read();
    } else {
        ap_phi_mux_data_655_V_read930_rewind_phi_fu_15678_p6 = data_655_V_read930_rewind_reg_15674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_656_V_read931_phi_phi_fu_25370_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_656_V_read931_phi_phi_fu_25370_p4 = ap_phi_mux_data_656_V_read931_rewind_phi_fu_15692_p6.read();
    } else {
        ap_phi_mux_data_656_V_read931_phi_phi_fu_25370_p4 = ap_phi_reg_pp0_iter1_data_656_V_read931_phi_reg_25366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_656_V_read931_rewind_phi_fu_15692_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_656_V_read931_rewind_phi_fu_15692_p6 = data_656_V_read931_phi_reg_25366.read();
    } else {
        ap_phi_mux_data_656_V_read931_rewind_phi_fu_15692_p6 = data_656_V_read931_rewind_reg_15688.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_657_V_read932_phi_phi_fu_25382_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_657_V_read932_phi_phi_fu_25382_p4 = ap_phi_mux_data_657_V_read932_rewind_phi_fu_15706_p6.read();
    } else {
        ap_phi_mux_data_657_V_read932_phi_phi_fu_25382_p4 = ap_phi_reg_pp0_iter1_data_657_V_read932_phi_reg_25378.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_657_V_read932_rewind_phi_fu_15706_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_657_V_read932_rewind_phi_fu_15706_p6 = data_657_V_read932_phi_reg_25378.read();
    } else {
        ap_phi_mux_data_657_V_read932_rewind_phi_fu_15706_p6 = data_657_V_read932_rewind_reg_15702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_658_V_read933_phi_phi_fu_25394_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_658_V_read933_phi_phi_fu_25394_p4 = ap_phi_mux_data_658_V_read933_rewind_phi_fu_15720_p6.read();
    } else {
        ap_phi_mux_data_658_V_read933_phi_phi_fu_25394_p4 = ap_phi_reg_pp0_iter1_data_658_V_read933_phi_reg_25390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_658_V_read933_rewind_phi_fu_15720_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_658_V_read933_rewind_phi_fu_15720_p6 = data_658_V_read933_phi_reg_25390.read();
    } else {
        ap_phi_mux_data_658_V_read933_rewind_phi_fu_15720_p6 = data_658_V_read933_rewind_reg_15716.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_659_V_read934_phi_phi_fu_25406_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_659_V_read934_phi_phi_fu_25406_p4 = ap_phi_mux_data_659_V_read934_rewind_phi_fu_15734_p6.read();
    } else {
        ap_phi_mux_data_659_V_read934_phi_phi_fu_25406_p4 = ap_phi_reg_pp0_iter1_data_659_V_read934_phi_reg_25402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_659_V_read934_rewind_phi_fu_15734_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_659_V_read934_rewind_phi_fu_15734_p6 = data_659_V_read934_phi_reg_25402.read();
    } else {
        ap_phi_mux_data_659_V_read934_rewind_phi_fu_15734_p6 = data_659_V_read934_rewind_reg_15730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_65_V_read340_phi_phi_fu_18278_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_65_V_read340_phi_phi_fu_18278_p4 = ap_phi_mux_data_65_V_read340_rewind_phi_fu_7418_p6.read();
    } else {
        ap_phi_mux_data_65_V_read340_phi_phi_fu_18278_p4 = ap_phi_reg_pp0_iter1_data_65_V_read340_phi_reg_18274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_65_V_read340_rewind_phi_fu_7418_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_65_V_read340_rewind_phi_fu_7418_p6 = data_65_V_read340_phi_reg_18274.read();
    } else {
        ap_phi_mux_data_65_V_read340_rewind_phi_fu_7418_p6 = data_65_V_read340_rewind_reg_7414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_660_V_read935_phi_phi_fu_25418_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_660_V_read935_phi_phi_fu_25418_p4 = ap_phi_mux_data_660_V_read935_rewind_phi_fu_15748_p6.read();
    } else {
        ap_phi_mux_data_660_V_read935_phi_phi_fu_25418_p4 = ap_phi_reg_pp0_iter1_data_660_V_read935_phi_reg_25414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_660_V_read935_rewind_phi_fu_15748_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_660_V_read935_rewind_phi_fu_15748_p6 = data_660_V_read935_phi_reg_25414.read();
    } else {
        ap_phi_mux_data_660_V_read935_rewind_phi_fu_15748_p6 = data_660_V_read935_rewind_reg_15744.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_661_V_read936_phi_phi_fu_25430_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_661_V_read936_phi_phi_fu_25430_p4 = ap_phi_mux_data_661_V_read936_rewind_phi_fu_15762_p6.read();
    } else {
        ap_phi_mux_data_661_V_read936_phi_phi_fu_25430_p4 = ap_phi_reg_pp0_iter1_data_661_V_read936_phi_reg_25426.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_661_V_read936_rewind_phi_fu_15762_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_661_V_read936_rewind_phi_fu_15762_p6 = data_661_V_read936_phi_reg_25426.read();
    } else {
        ap_phi_mux_data_661_V_read936_rewind_phi_fu_15762_p6 = data_661_V_read936_rewind_reg_15758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_662_V_read937_phi_phi_fu_25442_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_662_V_read937_phi_phi_fu_25442_p4 = ap_phi_mux_data_662_V_read937_rewind_phi_fu_15776_p6.read();
    } else {
        ap_phi_mux_data_662_V_read937_phi_phi_fu_25442_p4 = ap_phi_reg_pp0_iter1_data_662_V_read937_phi_reg_25438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_662_V_read937_rewind_phi_fu_15776_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_662_V_read937_rewind_phi_fu_15776_p6 = data_662_V_read937_phi_reg_25438.read();
    } else {
        ap_phi_mux_data_662_V_read937_rewind_phi_fu_15776_p6 = data_662_V_read937_rewind_reg_15772.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_663_V_read938_phi_phi_fu_25454_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_663_V_read938_phi_phi_fu_25454_p4 = ap_phi_mux_data_663_V_read938_rewind_phi_fu_15790_p6.read();
    } else {
        ap_phi_mux_data_663_V_read938_phi_phi_fu_25454_p4 = ap_phi_reg_pp0_iter1_data_663_V_read938_phi_reg_25450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_663_V_read938_rewind_phi_fu_15790_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_663_V_read938_rewind_phi_fu_15790_p6 = data_663_V_read938_phi_reg_25450.read();
    } else {
        ap_phi_mux_data_663_V_read938_rewind_phi_fu_15790_p6 = data_663_V_read938_rewind_reg_15786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_664_V_read939_phi_phi_fu_25466_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_664_V_read939_phi_phi_fu_25466_p4 = ap_phi_mux_data_664_V_read939_rewind_phi_fu_15804_p6.read();
    } else {
        ap_phi_mux_data_664_V_read939_phi_phi_fu_25466_p4 = ap_phi_reg_pp0_iter1_data_664_V_read939_phi_reg_25462.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_664_V_read939_rewind_phi_fu_15804_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_664_V_read939_rewind_phi_fu_15804_p6 = data_664_V_read939_phi_reg_25462.read();
    } else {
        ap_phi_mux_data_664_V_read939_rewind_phi_fu_15804_p6 = data_664_V_read939_rewind_reg_15800.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_665_V_read940_phi_phi_fu_25478_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_665_V_read940_phi_phi_fu_25478_p4 = ap_phi_mux_data_665_V_read940_rewind_phi_fu_15818_p6.read();
    } else {
        ap_phi_mux_data_665_V_read940_phi_phi_fu_25478_p4 = ap_phi_reg_pp0_iter1_data_665_V_read940_phi_reg_25474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_665_V_read940_rewind_phi_fu_15818_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_665_V_read940_rewind_phi_fu_15818_p6 = data_665_V_read940_phi_reg_25474.read();
    } else {
        ap_phi_mux_data_665_V_read940_rewind_phi_fu_15818_p6 = data_665_V_read940_rewind_reg_15814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_666_V_read941_phi_phi_fu_25490_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_666_V_read941_phi_phi_fu_25490_p4 = ap_phi_mux_data_666_V_read941_rewind_phi_fu_15832_p6.read();
    } else {
        ap_phi_mux_data_666_V_read941_phi_phi_fu_25490_p4 = ap_phi_reg_pp0_iter1_data_666_V_read941_phi_reg_25486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_666_V_read941_rewind_phi_fu_15832_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_666_V_read941_rewind_phi_fu_15832_p6 = data_666_V_read941_phi_reg_25486.read();
    } else {
        ap_phi_mux_data_666_V_read941_rewind_phi_fu_15832_p6 = data_666_V_read941_rewind_reg_15828.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_667_V_read942_phi_phi_fu_25502_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_667_V_read942_phi_phi_fu_25502_p4 = ap_phi_mux_data_667_V_read942_rewind_phi_fu_15846_p6.read();
    } else {
        ap_phi_mux_data_667_V_read942_phi_phi_fu_25502_p4 = ap_phi_reg_pp0_iter1_data_667_V_read942_phi_reg_25498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_667_V_read942_rewind_phi_fu_15846_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_667_V_read942_rewind_phi_fu_15846_p6 = data_667_V_read942_phi_reg_25498.read();
    } else {
        ap_phi_mux_data_667_V_read942_rewind_phi_fu_15846_p6 = data_667_V_read942_rewind_reg_15842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_668_V_read943_phi_phi_fu_25514_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_668_V_read943_phi_phi_fu_25514_p4 = ap_phi_mux_data_668_V_read943_rewind_phi_fu_15860_p6.read();
    } else {
        ap_phi_mux_data_668_V_read943_phi_phi_fu_25514_p4 = ap_phi_reg_pp0_iter1_data_668_V_read943_phi_reg_25510.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_668_V_read943_rewind_phi_fu_15860_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_668_V_read943_rewind_phi_fu_15860_p6 = data_668_V_read943_phi_reg_25510.read();
    } else {
        ap_phi_mux_data_668_V_read943_rewind_phi_fu_15860_p6 = data_668_V_read943_rewind_reg_15856.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_669_V_read944_phi_phi_fu_25526_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_669_V_read944_phi_phi_fu_25526_p4 = ap_phi_mux_data_669_V_read944_rewind_phi_fu_15874_p6.read();
    } else {
        ap_phi_mux_data_669_V_read944_phi_phi_fu_25526_p4 = ap_phi_reg_pp0_iter1_data_669_V_read944_phi_reg_25522.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_669_V_read944_rewind_phi_fu_15874_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_669_V_read944_rewind_phi_fu_15874_p6 = data_669_V_read944_phi_reg_25522.read();
    } else {
        ap_phi_mux_data_669_V_read944_rewind_phi_fu_15874_p6 = data_669_V_read944_rewind_reg_15870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_66_V_read341_phi_phi_fu_18290_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_66_V_read341_phi_phi_fu_18290_p4 = ap_phi_mux_data_66_V_read341_rewind_phi_fu_7432_p6.read();
    } else {
        ap_phi_mux_data_66_V_read341_phi_phi_fu_18290_p4 = ap_phi_reg_pp0_iter1_data_66_V_read341_phi_reg_18286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_66_V_read341_rewind_phi_fu_7432_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_66_V_read341_rewind_phi_fu_7432_p6 = data_66_V_read341_phi_reg_18286.read();
    } else {
        ap_phi_mux_data_66_V_read341_rewind_phi_fu_7432_p6 = data_66_V_read341_rewind_reg_7428.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_670_V_read945_phi_phi_fu_25538_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_670_V_read945_phi_phi_fu_25538_p4 = ap_phi_mux_data_670_V_read945_rewind_phi_fu_15888_p6.read();
    } else {
        ap_phi_mux_data_670_V_read945_phi_phi_fu_25538_p4 = ap_phi_reg_pp0_iter1_data_670_V_read945_phi_reg_25534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_670_V_read945_rewind_phi_fu_15888_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_670_V_read945_rewind_phi_fu_15888_p6 = data_670_V_read945_phi_reg_25534.read();
    } else {
        ap_phi_mux_data_670_V_read945_rewind_phi_fu_15888_p6 = data_670_V_read945_rewind_reg_15884.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_671_V_read946_phi_phi_fu_25550_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_671_V_read946_phi_phi_fu_25550_p4 = ap_phi_mux_data_671_V_read946_rewind_phi_fu_15902_p6.read();
    } else {
        ap_phi_mux_data_671_V_read946_phi_phi_fu_25550_p4 = ap_phi_reg_pp0_iter1_data_671_V_read946_phi_reg_25546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_671_V_read946_rewind_phi_fu_15902_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_671_V_read946_rewind_phi_fu_15902_p6 = data_671_V_read946_phi_reg_25546.read();
    } else {
        ap_phi_mux_data_671_V_read946_rewind_phi_fu_15902_p6 = data_671_V_read946_rewind_reg_15898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_672_V_read947_phi_phi_fu_25562_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_672_V_read947_phi_phi_fu_25562_p4 = ap_phi_mux_data_672_V_read947_rewind_phi_fu_15916_p6.read();
    } else {
        ap_phi_mux_data_672_V_read947_phi_phi_fu_25562_p4 = ap_phi_reg_pp0_iter1_data_672_V_read947_phi_reg_25558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_672_V_read947_rewind_phi_fu_15916_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_672_V_read947_rewind_phi_fu_15916_p6 = data_672_V_read947_phi_reg_25558.read();
    } else {
        ap_phi_mux_data_672_V_read947_rewind_phi_fu_15916_p6 = data_672_V_read947_rewind_reg_15912.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_673_V_read948_phi_phi_fu_25574_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_673_V_read948_phi_phi_fu_25574_p4 = ap_phi_mux_data_673_V_read948_rewind_phi_fu_15930_p6.read();
    } else {
        ap_phi_mux_data_673_V_read948_phi_phi_fu_25574_p4 = ap_phi_reg_pp0_iter1_data_673_V_read948_phi_reg_25570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_673_V_read948_rewind_phi_fu_15930_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_673_V_read948_rewind_phi_fu_15930_p6 = data_673_V_read948_phi_reg_25570.read();
    } else {
        ap_phi_mux_data_673_V_read948_rewind_phi_fu_15930_p6 = data_673_V_read948_rewind_reg_15926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_674_V_read949_phi_phi_fu_25586_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_674_V_read949_phi_phi_fu_25586_p4 = ap_phi_mux_data_674_V_read949_rewind_phi_fu_15944_p6.read();
    } else {
        ap_phi_mux_data_674_V_read949_phi_phi_fu_25586_p4 = ap_phi_reg_pp0_iter1_data_674_V_read949_phi_reg_25582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_674_V_read949_rewind_phi_fu_15944_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_674_V_read949_rewind_phi_fu_15944_p6 = data_674_V_read949_phi_reg_25582.read();
    } else {
        ap_phi_mux_data_674_V_read949_rewind_phi_fu_15944_p6 = data_674_V_read949_rewind_reg_15940.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_675_V_read950_phi_phi_fu_25598_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_675_V_read950_phi_phi_fu_25598_p4 = ap_phi_mux_data_675_V_read950_rewind_phi_fu_15958_p6.read();
    } else {
        ap_phi_mux_data_675_V_read950_phi_phi_fu_25598_p4 = ap_phi_reg_pp0_iter1_data_675_V_read950_phi_reg_25594.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_675_V_read950_rewind_phi_fu_15958_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_675_V_read950_rewind_phi_fu_15958_p6 = data_675_V_read950_phi_reg_25594.read();
    } else {
        ap_phi_mux_data_675_V_read950_rewind_phi_fu_15958_p6 = data_675_V_read950_rewind_reg_15954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_676_V_read951_phi_phi_fu_25610_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_676_V_read951_phi_phi_fu_25610_p4 = ap_phi_mux_data_676_V_read951_rewind_phi_fu_15972_p6.read();
    } else {
        ap_phi_mux_data_676_V_read951_phi_phi_fu_25610_p4 = ap_phi_reg_pp0_iter1_data_676_V_read951_phi_reg_25606.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_676_V_read951_rewind_phi_fu_15972_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_676_V_read951_rewind_phi_fu_15972_p6 = data_676_V_read951_phi_reg_25606.read();
    } else {
        ap_phi_mux_data_676_V_read951_rewind_phi_fu_15972_p6 = data_676_V_read951_rewind_reg_15968.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_677_V_read952_phi_phi_fu_25622_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_677_V_read952_phi_phi_fu_25622_p4 = ap_phi_mux_data_677_V_read952_rewind_phi_fu_15986_p6.read();
    } else {
        ap_phi_mux_data_677_V_read952_phi_phi_fu_25622_p4 = ap_phi_reg_pp0_iter1_data_677_V_read952_phi_reg_25618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_677_V_read952_rewind_phi_fu_15986_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_677_V_read952_rewind_phi_fu_15986_p6 = data_677_V_read952_phi_reg_25618.read();
    } else {
        ap_phi_mux_data_677_V_read952_rewind_phi_fu_15986_p6 = data_677_V_read952_rewind_reg_15982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_678_V_read953_phi_phi_fu_25634_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_678_V_read953_phi_phi_fu_25634_p4 = ap_phi_mux_data_678_V_read953_rewind_phi_fu_16000_p6.read();
    } else {
        ap_phi_mux_data_678_V_read953_phi_phi_fu_25634_p4 = ap_phi_reg_pp0_iter1_data_678_V_read953_phi_reg_25630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_678_V_read953_rewind_phi_fu_16000_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_678_V_read953_rewind_phi_fu_16000_p6 = data_678_V_read953_phi_reg_25630.read();
    } else {
        ap_phi_mux_data_678_V_read953_rewind_phi_fu_16000_p6 = data_678_V_read953_rewind_reg_15996.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_679_V_read954_phi_phi_fu_25646_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_679_V_read954_phi_phi_fu_25646_p4 = ap_phi_mux_data_679_V_read954_rewind_phi_fu_16014_p6.read();
    } else {
        ap_phi_mux_data_679_V_read954_phi_phi_fu_25646_p4 = ap_phi_reg_pp0_iter1_data_679_V_read954_phi_reg_25642.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_679_V_read954_rewind_phi_fu_16014_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_679_V_read954_rewind_phi_fu_16014_p6 = data_679_V_read954_phi_reg_25642.read();
    } else {
        ap_phi_mux_data_679_V_read954_rewind_phi_fu_16014_p6 = data_679_V_read954_rewind_reg_16010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_67_V_read342_phi_phi_fu_18302_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_67_V_read342_phi_phi_fu_18302_p4 = ap_phi_mux_data_67_V_read342_rewind_phi_fu_7446_p6.read();
    } else {
        ap_phi_mux_data_67_V_read342_phi_phi_fu_18302_p4 = ap_phi_reg_pp0_iter1_data_67_V_read342_phi_reg_18298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_67_V_read342_rewind_phi_fu_7446_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_67_V_read342_rewind_phi_fu_7446_p6 = data_67_V_read342_phi_reg_18298.read();
    } else {
        ap_phi_mux_data_67_V_read342_rewind_phi_fu_7446_p6 = data_67_V_read342_rewind_reg_7442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_680_V_read955_phi_phi_fu_25658_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_680_V_read955_phi_phi_fu_25658_p4 = ap_phi_mux_data_680_V_read955_rewind_phi_fu_16028_p6.read();
    } else {
        ap_phi_mux_data_680_V_read955_phi_phi_fu_25658_p4 = ap_phi_reg_pp0_iter1_data_680_V_read955_phi_reg_25654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_680_V_read955_rewind_phi_fu_16028_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_680_V_read955_rewind_phi_fu_16028_p6 = data_680_V_read955_phi_reg_25654.read();
    } else {
        ap_phi_mux_data_680_V_read955_rewind_phi_fu_16028_p6 = data_680_V_read955_rewind_reg_16024.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_681_V_read956_phi_phi_fu_25670_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_681_V_read956_phi_phi_fu_25670_p4 = ap_phi_mux_data_681_V_read956_rewind_phi_fu_16042_p6.read();
    } else {
        ap_phi_mux_data_681_V_read956_phi_phi_fu_25670_p4 = ap_phi_reg_pp0_iter1_data_681_V_read956_phi_reg_25666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_681_V_read956_rewind_phi_fu_16042_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_681_V_read956_rewind_phi_fu_16042_p6 = data_681_V_read956_phi_reg_25666.read();
    } else {
        ap_phi_mux_data_681_V_read956_rewind_phi_fu_16042_p6 = data_681_V_read956_rewind_reg_16038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_682_V_read957_phi_phi_fu_25682_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_682_V_read957_phi_phi_fu_25682_p4 = ap_phi_mux_data_682_V_read957_rewind_phi_fu_16056_p6.read();
    } else {
        ap_phi_mux_data_682_V_read957_phi_phi_fu_25682_p4 = ap_phi_reg_pp0_iter1_data_682_V_read957_phi_reg_25678.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_682_V_read957_rewind_phi_fu_16056_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_682_V_read957_rewind_phi_fu_16056_p6 = data_682_V_read957_phi_reg_25678.read();
    } else {
        ap_phi_mux_data_682_V_read957_rewind_phi_fu_16056_p6 = data_682_V_read957_rewind_reg_16052.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_683_V_read958_phi_phi_fu_25694_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_683_V_read958_phi_phi_fu_25694_p4 = ap_phi_mux_data_683_V_read958_rewind_phi_fu_16070_p6.read();
    } else {
        ap_phi_mux_data_683_V_read958_phi_phi_fu_25694_p4 = ap_phi_reg_pp0_iter1_data_683_V_read958_phi_reg_25690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_683_V_read958_rewind_phi_fu_16070_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_683_V_read958_rewind_phi_fu_16070_p6 = data_683_V_read958_phi_reg_25690.read();
    } else {
        ap_phi_mux_data_683_V_read958_rewind_phi_fu_16070_p6 = data_683_V_read958_rewind_reg_16066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_684_V_read959_phi_phi_fu_25706_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_684_V_read959_phi_phi_fu_25706_p4 = ap_phi_mux_data_684_V_read959_rewind_phi_fu_16084_p6.read();
    } else {
        ap_phi_mux_data_684_V_read959_phi_phi_fu_25706_p4 = ap_phi_reg_pp0_iter1_data_684_V_read959_phi_reg_25702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_684_V_read959_rewind_phi_fu_16084_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_684_V_read959_rewind_phi_fu_16084_p6 = data_684_V_read959_phi_reg_25702.read();
    } else {
        ap_phi_mux_data_684_V_read959_rewind_phi_fu_16084_p6 = data_684_V_read959_rewind_reg_16080.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_685_V_read960_phi_phi_fu_25718_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_685_V_read960_phi_phi_fu_25718_p4 = ap_phi_mux_data_685_V_read960_rewind_phi_fu_16098_p6.read();
    } else {
        ap_phi_mux_data_685_V_read960_phi_phi_fu_25718_p4 = ap_phi_reg_pp0_iter1_data_685_V_read960_phi_reg_25714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_685_V_read960_rewind_phi_fu_16098_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_685_V_read960_rewind_phi_fu_16098_p6 = data_685_V_read960_phi_reg_25714.read();
    } else {
        ap_phi_mux_data_685_V_read960_rewind_phi_fu_16098_p6 = data_685_V_read960_rewind_reg_16094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_686_V_read961_phi_phi_fu_25730_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_686_V_read961_phi_phi_fu_25730_p4 = ap_phi_mux_data_686_V_read961_rewind_phi_fu_16112_p6.read();
    } else {
        ap_phi_mux_data_686_V_read961_phi_phi_fu_25730_p4 = ap_phi_reg_pp0_iter1_data_686_V_read961_phi_reg_25726.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_686_V_read961_rewind_phi_fu_16112_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_686_V_read961_rewind_phi_fu_16112_p6 = data_686_V_read961_phi_reg_25726.read();
    } else {
        ap_phi_mux_data_686_V_read961_rewind_phi_fu_16112_p6 = data_686_V_read961_rewind_reg_16108.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_687_V_read962_phi_phi_fu_25742_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_687_V_read962_phi_phi_fu_25742_p4 = ap_phi_mux_data_687_V_read962_rewind_phi_fu_16126_p6.read();
    } else {
        ap_phi_mux_data_687_V_read962_phi_phi_fu_25742_p4 = ap_phi_reg_pp0_iter1_data_687_V_read962_phi_reg_25738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_687_V_read962_rewind_phi_fu_16126_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_687_V_read962_rewind_phi_fu_16126_p6 = data_687_V_read962_phi_reg_25738.read();
    } else {
        ap_phi_mux_data_687_V_read962_rewind_phi_fu_16126_p6 = data_687_V_read962_rewind_reg_16122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_688_V_read963_phi_phi_fu_25754_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_688_V_read963_phi_phi_fu_25754_p4 = ap_phi_mux_data_688_V_read963_rewind_phi_fu_16140_p6.read();
    } else {
        ap_phi_mux_data_688_V_read963_phi_phi_fu_25754_p4 = ap_phi_reg_pp0_iter1_data_688_V_read963_phi_reg_25750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_688_V_read963_rewind_phi_fu_16140_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_688_V_read963_rewind_phi_fu_16140_p6 = data_688_V_read963_phi_reg_25750.read();
    } else {
        ap_phi_mux_data_688_V_read963_rewind_phi_fu_16140_p6 = data_688_V_read963_rewind_reg_16136.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_689_V_read964_phi_phi_fu_25766_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_689_V_read964_phi_phi_fu_25766_p4 = ap_phi_mux_data_689_V_read964_rewind_phi_fu_16154_p6.read();
    } else {
        ap_phi_mux_data_689_V_read964_phi_phi_fu_25766_p4 = ap_phi_reg_pp0_iter1_data_689_V_read964_phi_reg_25762.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_689_V_read964_rewind_phi_fu_16154_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_689_V_read964_rewind_phi_fu_16154_p6 = data_689_V_read964_phi_reg_25762.read();
    } else {
        ap_phi_mux_data_689_V_read964_rewind_phi_fu_16154_p6 = data_689_V_read964_rewind_reg_16150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_68_V_read343_phi_phi_fu_18314_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_68_V_read343_phi_phi_fu_18314_p4 = ap_phi_mux_data_68_V_read343_rewind_phi_fu_7460_p6.read();
    } else {
        ap_phi_mux_data_68_V_read343_phi_phi_fu_18314_p4 = ap_phi_reg_pp0_iter1_data_68_V_read343_phi_reg_18310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_68_V_read343_rewind_phi_fu_7460_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_68_V_read343_rewind_phi_fu_7460_p6 = data_68_V_read343_phi_reg_18310.read();
    } else {
        ap_phi_mux_data_68_V_read343_rewind_phi_fu_7460_p6 = data_68_V_read343_rewind_reg_7456.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_690_V_read965_phi_phi_fu_25778_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_690_V_read965_phi_phi_fu_25778_p4 = ap_phi_mux_data_690_V_read965_rewind_phi_fu_16168_p6.read();
    } else {
        ap_phi_mux_data_690_V_read965_phi_phi_fu_25778_p4 = ap_phi_reg_pp0_iter1_data_690_V_read965_phi_reg_25774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_690_V_read965_rewind_phi_fu_16168_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_690_V_read965_rewind_phi_fu_16168_p6 = data_690_V_read965_phi_reg_25774.read();
    } else {
        ap_phi_mux_data_690_V_read965_rewind_phi_fu_16168_p6 = data_690_V_read965_rewind_reg_16164.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_691_V_read966_phi_phi_fu_25790_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_691_V_read966_phi_phi_fu_25790_p4 = ap_phi_mux_data_691_V_read966_rewind_phi_fu_16182_p6.read();
    } else {
        ap_phi_mux_data_691_V_read966_phi_phi_fu_25790_p4 = ap_phi_reg_pp0_iter1_data_691_V_read966_phi_reg_25786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_691_V_read966_rewind_phi_fu_16182_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_691_V_read966_rewind_phi_fu_16182_p6 = data_691_V_read966_phi_reg_25786.read();
    } else {
        ap_phi_mux_data_691_V_read966_rewind_phi_fu_16182_p6 = data_691_V_read966_rewind_reg_16178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_692_V_read967_phi_phi_fu_25802_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_692_V_read967_phi_phi_fu_25802_p4 = ap_phi_mux_data_692_V_read967_rewind_phi_fu_16196_p6.read();
    } else {
        ap_phi_mux_data_692_V_read967_phi_phi_fu_25802_p4 = ap_phi_reg_pp0_iter1_data_692_V_read967_phi_reg_25798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_692_V_read967_rewind_phi_fu_16196_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_692_V_read967_rewind_phi_fu_16196_p6 = data_692_V_read967_phi_reg_25798.read();
    } else {
        ap_phi_mux_data_692_V_read967_rewind_phi_fu_16196_p6 = data_692_V_read967_rewind_reg_16192.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_693_V_read968_phi_phi_fu_25814_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_693_V_read968_phi_phi_fu_25814_p4 = ap_phi_mux_data_693_V_read968_rewind_phi_fu_16210_p6.read();
    } else {
        ap_phi_mux_data_693_V_read968_phi_phi_fu_25814_p4 = ap_phi_reg_pp0_iter1_data_693_V_read968_phi_reg_25810.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_693_V_read968_rewind_phi_fu_16210_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_693_V_read968_rewind_phi_fu_16210_p6 = data_693_V_read968_phi_reg_25810.read();
    } else {
        ap_phi_mux_data_693_V_read968_rewind_phi_fu_16210_p6 = data_693_V_read968_rewind_reg_16206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_694_V_read969_phi_phi_fu_25826_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_694_V_read969_phi_phi_fu_25826_p4 = ap_phi_mux_data_694_V_read969_rewind_phi_fu_16224_p6.read();
    } else {
        ap_phi_mux_data_694_V_read969_phi_phi_fu_25826_p4 = ap_phi_reg_pp0_iter1_data_694_V_read969_phi_reg_25822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_694_V_read969_rewind_phi_fu_16224_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_694_V_read969_rewind_phi_fu_16224_p6 = data_694_V_read969_phi_reg_25822.read();
    } else {
        ap_phi_mux_data_694_V_read969_rewind_phi_fu_16224_p6 = data_694_V_read969_rewind_reg_16220.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_695_V_read970_phi_phi_fu_25838_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_695_V_read970_phi_phi_fu_25838_p4 = ap_phi_mux_data_695_V_read970_rewind_phi_fu_16238_p6.read();
    } else {
        ap_phi_mux_data_695_V_read970_phi_phi_fu_25838_p4 = ap_phi_reg_pp0_iter1_data_695_V_read970_phi_reg_25834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_695_V_read970_rewind_phi_fu_16238_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_695_V_read970_rewind_phi_fu_16238_p6 = data_695_V_read970_phi_reg_25834.read();
    } else {
        ap_phi_mux_data_695_V_read970_rewind_phi_fu_16238_p6 = data_695_V_read970_rewind_reg_16234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_696_V_read971_phi_phi_fu_25850_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_696_V_read971_phi_phi_fu_25850_p4 = ap_phi_mux_data_696_V_read971_rewind_phi_fu_16252_p6.read();
    } else {
        ap_phi_mux_data_696_V_read971_phi_phi_fu_25850_p4 = ap_phi_reg_pp0_iter1_data_696_V_read971_phi_reg_25846.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_696_V_read971_rewind_phi_fu_16252_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_696_V_read971_rewind_phi_fu_16252_p6 = data_696_V_read971_phi_reg_25846.read();
    } else {
        ap_phi_mux_data_696_V_read971_rewind_phi_fu_16252_p6 = data_696_V_read971_rewind_reg_16248.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_697_V_read972_phi_phi_fu_25862_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_697_V_read972_phi_phi_fu_25862_p4 = ap_phi_mux_data_697_V_read972_rewind_phi_fu_16266_p6.read();
    } else {
        ap_phi_mux_data_697_V_read972_phi_phi_fu_25862_p4 = ap_phi_reg_pp0_iter1_data_697_V_read972_phi_reg_25858.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_697_V_read972_rewind_phi_fu_16266_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_697_V_read972_rewind_phi_fu_16266_p6 = data_697_V_read972_phi_reg_25858.read();
    } else {
        ap_phi_mux_data_697_V_read972_rewind_phi_fu_16266_p6 = data_697_V_read972_rewind_reg_16262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_698_V_read973_phi_phi_fu_25874_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_698_V_read973_phi_phi_fu_25874_p4 = ap_phi_mux_data_698_V_read973_rewind_phi_fu_16280_p6.read();
    } else {
        ap_phi_mux_data_698_V_read973_phi_phi_fu_25874_p4 = ap_phi_reg_pp0_iter1_data_698_V_read973_phi_reg_25870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_698_V_read973_rewind_phi_fu_16280_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_698_V_read973_rewind_phi_fu_16280_p6 = data_698_V_read973_phi_reg_25870.read();
    } else {
        ap_phi_mux_data_698_V_read973_rewind_phi_fu_16280_p6 = data_698_V_read973_rewind_reg_16276.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_699_V_read974_phi_phi_fu_25886_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_699_V_read974_phi_phi_fu_25886_p4 = ap_phi_mux_data_699_V_read974_rewind_phi_fu_16294_p6.read();
    } else {
        ap_phi_mux_data_699_V_read974_phi_phi_fu_25886_p4 = ap_phi_reg_pp0_iter1_data_699_V_read974_phi_reg_25882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_699_V_read974_rewind_phi_fu_16294_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_699_V_read974_rewind_phi_fu_16294_p6 = data_699_V_read974_phi_reg_25882.read();
    } else {
        ap_phi_mux_data_699_V_read974_rewind_phi_fu_16294_p6 = data_699_V_read974_rewind_reg_16290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_69_V_read344_phi_phi_fu_18326_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_69_V_read344_phi_phi_fu_18326_p4 = ap_phi_mux_data_69_V_read344_rewind_phi_fu_7474_p6.read();
    } else {
        ap_phi_mux_data_69_V_read344_phi_phi_fu_18326_p4 = ap_phi_reg_pp0_iter1_data_69_V_read344_phi_reg_18322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_69_V_read344_rewind_phi_fu_7474_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_69_V_read344_rewind_phi_fu_7474_p6 = data_69_V_read344_phi_reg_18322.read();
    } else {
        ap_phi_mux_data_69_V_read344_rewind_phi_fu_7474_p6 = data_69_V_read344_rewind_reg_7470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_6_V_read281_phi_phi_fu_17570_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_6_V_read281_phi_phi_fu_17570_p4 = ap_phi_mux_data_6_V_read281_rewind_phi_fu_6592_p6.read();
    } else {
        ap_phi_mux_data_6_V_read281_phi_phi_fu_17570_p4 = ap_phi_reg_pp0_iter1_data_6_V_read281_phi_reg_17566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_6_V_read281_rewind_phi_fu_6592_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_6_V_read281_rewind_phi_fu_6592_p6 = data_6_V_read281_phi_reg_17566.read();
    } else {
        ap_phi_mux_data_6_V_read281_rewind_phi_fu_6592_p6 = data_6_V_read281_rewind_reg_6588.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_700_V_read975_phi_phi_fu_25898_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_700_V_read975_phi_phi_fu_25898_p4 = ap_phi_mux_data_700_V_read975_rewind_phi_fu_16308_p6.read();
    } else {
        ap_phi_mux_data_700_V_read975_phi_phi_fu_25898_p4 = ap_phi_reg_pp0_iter1_data_700_V_read975_phi_reg_25894.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_700_V_read975_rewind_phi_fu_16308_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_700_V_read975_rewind_phi_fu_16308_p6 = data_700_V_read975_phi_reg_25894.read();
    } else {
        ap_phi_mux_data_700_V_read975_rewind_phi_fu_16308_p6 = data_700_V_read975_rewind_reg_16304.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_701_V_read976_phi_phi_fu_25910_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_701_V_read976_phi_phi_fu_25910_p4 = ap_phi_mux_data_701_V_read976_rewind_phi_fu_16322_p6.read();
    } else {
        ap_phi_mux_data_701_V_read976_phi_phi_fu_25910_p4 = ap_phi_reg_pp0_iter1_data_701_V_read976_phi_reg_25906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_701_V_read976_rewind_phi_fu_16322_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_701_V_read976_rewind_phi_fu_16322_p6 = data_701_V_read976_phi_reg_25906.read();
    } else {
        ap_phi_mux_data_701_V_read976_rewind_phi_fu_16322_p6 = data_701_V_read976_rewind_reg_16318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_702_V_read977_phi_phi_fu_25922_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_702_V_read977_phi_phi_fu_25922_p4 = ap_phi_mux_data_702_V_read977_rewind_phi_fu_16336_p6.read();
    } else {
        ap_phi_mux_data_702_V_read977_phi_phi_fu_25922_p4 = ap_phi_reg_pp0_iter1_data_702_V_read977_phi_reg_25918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_702_V_read977_rewind_phi_fu_16336_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_702_V_read977_rewind_phi_fu_16336_p6 = data_702_V_read977_phi_reg_25918.read();
    } else {
        ap_phi_mux_data_702_V_read977_rewind_phi_fu_16336_p6 = data_702_V_read977_rewind_reg_16332.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_703_V_read978_phi_phi_fu_25934_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_703_V_read978_phi_phi_fu_25934_p4 = ap_phi_mux_data_703_V_read978_rewind_phi_fu_16350_p6.read();
    } else {
        ap_phi_mux_data_703_V_read978_phi_phi_fu_25934_p4 = ap_phi_reg_pp0_iter1_data_703_V_read978_phi_reg_25930.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_703_V_read978_rewind_phi_fu_16350_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_703_V_read978_rewind_phi_fu_16350_p6 = data_703_V_read978_phi_reg_25930.read();
    } else {
        ap_phi_mux_data_703_V_read978_rewind_phi_fu_16350_p6 = data_703_V_read978_rewind_reg_16346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_704_V_read979_phi_phi_fu_25946_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_704_V_read979_phi_phi_fu_25946_p4 = ap_phi_mux_data_704_V_read979_rewind_phi_fu_16364_p6.read();
    } else {
        ap_phi_mux_data_704_V_read979_phi_phi_fu_25946_p4 = ap_phi_reg_pp0_iter1_data_704_V_read979_phi_reg_25942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_704_V_read979_rewind_phi_fu_16364_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_704_V_read979_rewind_phi_fu_16364_p6 = data_704_V_read979_phi_reg_25942.read();
    } else {
        ap_phi_mux_data_704_V_read979_rewind_phi_fu_16364_p6 = data_704_V_read979_rewind_reg_16360.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_705_V_read980_phi_phi_fu_25958_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_705_V_read980_phi_phi_fu_25958_p4 = ap_phi_mux_data_705_V_read980_rewind_phi_fu_16378_p6.read();
    } else {
        ap_phi_mux_data_705_V_read980_phi_phi_fu_25958_p4 = ap_phi_reg_pp0_iter1_data_705_V_read980_phi_reg_25954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_705_V_read980_rewind_phi_fu_16378_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_705_V_read980_rewind_phi_fu_16378_p6 = data_705_V_read980_phi_reg_25954.read();
    } else {
        ap_phi_mux_data_705_V_read980_rewind_phi_fu_16378_p6 = data_705_V_read980_rewind_reg_16374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_706_V_read981_phi_phi_fu_25970_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_706_V_read981_phi_phi_fu_25970_p4 = ap_phi_mux_data_706_V_read981_rewind_phi_fu_16392_p6.read();
    } else {
        ap_phi_mux_data_706_V_read981_phi_phi_fu_25970_p4 = ap_phi_reg_pp0_iter1_data_706_V_read981_phi_reg_25966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_706_V_read981_rewind_phi_fu_16392_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_706_V_read981_rewind_phi_fu_16392_p6 = data_706_V_read981_phi_reg_25966.read();
    } else {
        ap_phi_mux_data_706_V_read981_rewind_phi_fu_16392_p6 = data_706_V_read981_rewind_reg_16388.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_707_V_read982_phi_phi_fu_25982_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_707_V_read982_phi_phi_fu_25982_p4 = ap_phi_mux_data_707_V_read982_rewind_phi_fu_16406_p6.read();
    } else {
        ap_phi_mux_data_707_V_read982_phi_phi_fu_25982_p4 = ap_phi_reg_pp0_iter1_data_707_V_read982_phi_reg_25978.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_707_V_read982_rewind_phi_fu_16406_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_707_V_read982_rewind_phi_fu_16406_p6 = data_707_V_read982_phi_reg_25978.read();
    } else {
        ap_phi_mux_data_707_V_read982_rewind_phi_fu_16406_p6 = data_707_V_read982_rewind_reg_16402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_708_V_read983_phi_phi_fu_25994_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_708_V_read983_phi_phi_fu_25994_p4 = ap_phi_mux_data_708_V_read983_rewind_phi_fu_16420_p6.read();
    } else {
        ap_phi_mux_data_708_V_read983_phi_phi_fu_25994_p4 = ap_phi_reg_pp0_iter1_data_708_V_read983_phi_reg_25990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_708_V_read983_rewind_phi_fu_16420_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_708_V_read983_rewind_phi_fu_16420_p6 = data_708_V_read983_phi_reg_25990.read();
    } else {
        ap_phi_mux_data_708_V_read983_rewind_phi_fu_16420_p6 = data_708_V_read983_rewind_reg_16416.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_709_V_read984_phi_phi_fu_26006_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_709_V_read984_phi_phi_fu_26006_p4 = ap_phi_mux_data_709_V_read984_rewind_phi_fu_16434_p6.read();
    } else {
        ap_phi_mux_data_709_V_read984_phi_phi_fu_26006_p4 = ap_phi_reg_pp0_iter1_data_709_V_read984_phi_reg_26002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_709_V_read984_rewind_phi_fu_16434_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_709_V_read984_rewind_phi_fu_16434_p6 = data_709_V_read984_phi_reg_26002.read();
    } else {
        ap_phi_mux_data_709_V_read984_rewind_phi_fu_16434_p6 = data_709_V_read984_rewind_reg_16430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_70_V_read345_phi_phi_fu_18338_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_70_V_read345_phi_phi_fu_18338_p4 = ap_phi_mux_data_70_V_read345_rewind_phi_fu_7488_p6.read();
    } else {
        ap_phi_mux_data_70_V_read345_phi_phi_fu_18338_p4 = ap_phi_reg_pp0_iter1_data_70_V_read345_phi_reg_18334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_70_V_read345_rewind_phi_fu_7488_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_70_V_read345_rewind_phi_fu_7488_p6 = data_70_V_read345_phi_reg_18334.read();
    } else {
        ap_phi_mux_data_70_V_read345_rewind_phi_fu_7488_p6 = data_70_V_read345_rewind_reg_7484.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_710_V_read985_phi_phi_fu_26018_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_710_V_read985_phi_phi_fu_26018_p4 = ap_phi_mux_data_710_V_read985_rewind_phi_fu_16448_p6.read();
    } else {
        ap_phi_mux_data_710_V_read985_phi_phi_fu_26018_p4 = ap_phi_reg_pp0_iter1_data_710_V_read985_phi_reg_26014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_710_V_read985_rewind_phi_fu_16448_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_710_V_read985_rewind_phi_fu_16448_p6 = data_710_V_read985_phi_reg_26014.read();
    } else {
        ap_phi_mux_data_710_V_read985_rewind_phi_fu_16448_p6 = data_710_V_read985_rewind_reg_16444.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_711_V_read986_phi_phi_fu_26030_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_711_V_read986_phi_phi_fu_26030_p4 = ap_phi_mux_data_711_V_read986_rewind_phi_fu_16462_p6.read();
    } else {
        ap_phi_mux_data_711_V_read986_phi_phi_fu_26030_p4 = ap_phi_reg_pp0_iter1_data_711_V_read986_phi_reg_26026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_711_V_read986_rewind_phi_fu_16462_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_711_V_read986_rewind_phi_fu_16462_p6 = data_711_V_read986_phi_reg_26026.read();
    } else {
        ap_phi_mux_data_711_V_read986_rewind_phi_fu_16462_p6 = data_711_V_read986_rewind_reg_16458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_712_V_read987_phi_phi_fu_26042_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_712_V_read987_phi_phi_fu_26042_p4 = ap_phi_mux_data_712_V_read987_rewind_phi_fu_16476_p6.read();
    } else {
        ap_phi_mux_data_712_V_read987_phi_phi_fu_26042_p4 = ap_phi_reg_pp0_iter1_data_712_V_read987_phi_reg_26038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_712_V_read987_rewind_phi_fu_16476_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_712_V_read987_rewind_phi_fu_16476_p6 = data_712_V_read987_phi_reg_26038.read();
    } else {
        ap_phi_mux_data_712_V_read987_rewind_phi_fu_16476_p6 = data_712_V_read987_rewind_reg_16472.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_713_V_read988_phi_phi_fu_26054_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_713_V_read988_phi_phi_fu_26054_p4 = ap_phi_mux_data_713_V_read988_rewind_phi_fu_16490_p6.read();
    } else {
        ap_phi_mux_data_713_V_read988_phi_phi_fu_26054_p4 = ap_phi_reg_pp0_iter1_data_713_V_read988_phi_reg_26050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_713_V_read988_rewind_phi_fu_16490_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_713_V_read988_rewind_phi_fu_16490_p6 = data_713_V_read988_phi_reg_26050.read();
    } else {
        ap_phi_mux_data_713_V_read988_rewind_phi_fu_16490_p6 = data_713_V_read988_rewind_reg_16486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_714_V_read989_phi_phi_fu_26066_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_714_V_read989_phi_phi_fu_26066_p4 = ap_phi_mux_data_714_V_read989_rewind_phi_fu_16504_p6.read();
    } else {
        ap_phi_mux_data_714_V_read989_phi_phi_fu_26066_p4 = ap_phi_reg_pp0_iter1_data_714_V_read989_phi_reg_26062.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_714_V_read989_rewind_phi_fu_16504_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_714_V_read989_rewind_phi_fu_16504_p6 = data_714_V_read989_phi_reg_26062.read();
    } else {
        ap_phi_mux_data_714_V_read989_rewind_phi_fu_16504_p6 = data_714_V_read989_rewind_reg_16500.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_715_V_read990_phi_phi_fu_26078_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_715_V_read990_phi_phi_fu_26078_p4 = ap_phi_mux_data_715_V_read990_rewind_phi_fu_16518_p6.read();
    } else {
        ap_phi_mux_data_715_V_read990_phi_phi_fu_26078_p4 = ap_phi_reg_pp0_iter1_data_715_V_read990_phi_reg_26074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_715_V_read990_rewind_phi_fu_16518_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_715_V_read990_rewind_phi_fu_16518_p6 = data_715_V_read990_phi_reg_26074.read();
    } else {
        ap_phi_mux_data_715_V_read990_rewind_phi_fu_16518_p6 = data_715_V_read990_rewind_reg_16514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_716_V_read991_phi_phi_fu_26090_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_716_V_read991_phi_phi_fu_26090_p4 = ap_phi_mux_data_716_V_read991_rewind_phi_fu_16532_p6.read();
    } else {
        ap_phi_mux_data_716_V_read991_phi_phi_fu_26090_p4 = ap_phi_reg_pp0_iter1_data_716_V_read991_phi_reg_26086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_716_V_read991_rewind_phi_fu_16532_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_716_V_read991_rewind_phi_fu_16532_p6 = data_716_V_read991_phi_reg_26086.read();
    } else {
        ap_phi_mux_data_716_V_read991_rewind_phi_fu_16532_p6 = data_716_V_read991_rewind_reg_16528.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_717_V_read992_phi_phi_fu_26102_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_717_V_read992_phi_phi_fu_26102_p4 = ap_phi_mux_data_717_V_read992_rewind_phi_fu_16546_p6.read();
    } else {
        ap_phi_mux_data_717_V_read992_phi_phi_fu_26102_p4 = ap_phi_reg_pp0_iter1_data_717_V_read992_phi_reg_26098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_717_V_read992_rewind_phi_fu_16546_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_717_V_read992_rewind_phi_fu_16546_p6 = data_717_V_read992_phi_reg_26098.read();
    } else {
        ap_phi_mux_data_717_V_read992_rewind_phi_fu_16546_p6 = data_717_V_read992_rewind_reg_16542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_718_V_read993_phi_phi_fu_26114_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_718_V_read993_phi_phi_fu_26114_p4 = ap_phi_mux_data_718_V_read993_rewind_phi_fu_16560_p6.read();
    } else {
        ap_phi_mux_data_718_V_read993_phi_phi_fu_26114_p4 = ap_phi_reg_pp0_iter1_data_718_V_read993_phi_reg_26110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_718_V_read993_rewind_phi_fu_16560_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_718_V_read993_rewind_phi_fu_16560_p6 = data_718_V_read993_phi_reg_26110.read();
    } else {
        ap_phi_mux_data_718_V_read993_rewind_phi_fu_16560_p6 = data_718_V_read993_rewind_reg_16556.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_719_V_read994_phi_phi_fu_26126_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_719_V_read994_phi_phi_fu_26126_p4 = ap_phi_mux_data_719_V_read994_rewind_phi_fu_16574_p6.read();
    } else {
        ap_phi_mux_data_719_V_read994_phi_phi_fu_26126_p4 = ap_phi_reg_pp0_iter1_data_719_V_read994_phi_reg_26122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_719_V_read994_rewind_phi_fu_16574_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_719_V_read994_rewind_phi_fu_16574_p6 = data_719_V_read994_phi_reg_26122.read();
    } else {
        ap_phi_mux_data_719_V_read994_rewind_phi_fu_16574_p6 = data_719_V_read994_rewind_reg_16570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_71_V_read346_phi_phi_fu_18350_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_71_V_read346_phi_phi_fu_18350_p4 = ap_phi_mux_data_71_V_read346_rewind_phi_fu_7502_p6.read();
    } else {
        ap_phi_mux_data_71_V_read346_phi_phi_fu_18350_p4 = ap_phi_reg_pp0_iter1_data_71_V_read346_phi_reg_18346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_71_V_read346_rewind_phi_fu_7502_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_71_V_read346_rewind_phi_fu_7502_p6 = data_71_V_read346_phi_reg_18346.read();
    } else {
        ap_phi_mux_data_71_V_read346_rewind_phi_fu_7502_p6 = data_71_V_read346_rewind_reg_7498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_720_V_read995_phi_phi_fu_26138_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_720_V_read995_phi_phi_fu_26138_p4 = ap_phi_mux_data_720_V_read995_rewind_phi_fu_16588_p6.read();
    } else {
        ap_phi_mux_data_720_V_read995_phi_phi_fu_26138_p4 = ap_phi_reg_pp0_iter1_data_720_V_read995_phi_reg_26134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_720_V_read995_rewind_phi_fu_16588_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_720_V_read995_rewind_phi_fu_16588_p6 = data_720_V_read995_phi_reg_26134.read();
    } else {
        ap_phi_mux_data_720_V_read995_rewind_phi_fu_16588_p6 = data_720_V_read995_rewind_reg_16584.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_721_V_read996_phi_phi_fu_26150_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_721_V_read996_phi_phi_fu_26150_p4 = ap_phi_mux_data_721_V_read996_rewind_phi_fu_16602_p6.read();
    } else {
        ap_phi_mux_data_721_V_read996_phi_phi_fu_26150_p4 = ap_phi_reg_pp0_iter1_data_721_V_read996_phi_reg_26146.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_721_V_read996_rewind_phi_fu_16602_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_721_V_read996_rewind_phi_fu_16602_p6 = data_721_V_read996_phi_reg_26146.read();
    } else {
        ap_phi_mux_data_721_V_read996_rewind_phi_fu_16602_p6 = data_721_V_read996_rewind_reg_16598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_722_V_read997_phi_phi_fu_26162_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_722_V_read997_phi_phi_fu_26162_p4 = ap_phi_mux_data_722_V_read997_rewind_phi_fu_16616_p6.read();
    } else {
        ap_phi_mux_data_722_V_read997_phi_phi_fu_26162_p4 = ap_phi_reg_pp0_iter1_data_722_V_read997_phi_reg_26158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_722_V_read997_rewind_phi_fu_16616_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_722_V_read997_rewind_phi_fu_16616_p6 = data_722_V_read997_phi_reg_26158.read();
    } else {
        ap_phi_mux_data_722_V_read997_rewind_phi_fu_16616_p6 = data_722_V_read997_rewind_reg_16612.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_723_V_read998_phi_phi_fu_26174_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_723_V_read998_phi_phi_fu_26174_p4 = ap_phi_mux_data_723_V_read998_rewind_phi_fu_16630_p6.read();
    } else {
        ap_phi_mux_data_723_V_read998_phi_phi_fu_26174_p4 = ap_phi_reg_pp0_iter1_data_723_V_read998_phi_reg_26170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_723_V_read998_rewind_phi_fu_16630_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_723_V_read998_rewind_phi_fu_16630_p6 = data_723_V_read998_phi_reg_26170.read();
    } else {
        ap_phi_mux_data_723_V_read998_rewind_phi_fu_16630_p6 = data_723_V_read998_rewind_reg_16626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_724_V_read999_phi_phi_fu_26186_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_724_V_read999_phi_phi_fu_26186_p4 = ap_phi_mux_data_724_V_read999_rewind_phi_fu_16644_p6.read();
    } else {
        ap_phi_mux_data_724_V_read999_phi_phi_fu_26186_p4 = ap_phi_reg_pp0_iter1_data_724_V_read999_phi_reg_26182.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_724_V_read999_rewind_phi_fu_16644_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_724_V_read999_rewind_phi_fu_16644_p6 = data_724_V_read999_phi_reg_26182.read();
    } else {
        ap_phi_mux_data_724_V_read999_rewind_phi_fu_16644_p6 = data_724_V_read999_rewind_reg_16640.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_725_V_read1000_phi_phi_fu_26198_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_725_V_read1000_phi_phi_fu_26198_p4 = ap_phi_mux_data_725_V_read1000_rewind_phi_fu_16658_p6.read();
    } else {
        ap_phi_mux_data_725_V_read1000_phi_phi_fu_26198_p4 = ap_phi_reg_pp0_iter1_data_725_V_read1000_phi_reg_26194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_725_V_read1000_rewind_phi_fu_16658_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_725_V_read1000_rewind_phi_fu_16658_p6 = data_725_V_read1000_phi_reg_26194.read();
    } else {
        ap_phi_mux_data_725_V_read1000_rewind_phi_fu_16658_p6 = data_725_V_read1000_rewind_reg_16654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_726_V_read1001_phi_phi_fu_26210_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_726_V_read1001_phi_phi_fu_26210_p4 = ap_phi_mux_data_726_V_read1001_rewind_phi_fu_16672_p6.read();
    } else {
        ap_phi_mux_data_726_V_read1001_phi_phi_fu_26210_p4 = ap_phi_reg_pp0_iter1_data_726_V_read1001_phi_reg_26206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_726_V_read1001_rewind_phi_fu_16672_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_726_V_read1001_rewind_phi_fu_16672_p6 = data_726_V_read1001_phi_reg_26206.read();
    } else {
        ap_phi_mux_data_726_V_read1001_rewind_phi_fu_16672_p6 = data_726_V_read1001_rewind_reg_16668.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_727_V_read1002_phi_phi_fu_26222_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_727_V_read1002_phi_phi_fu_26222_p4 = ap_phi_mux_data_727_V_read1002_rewind_phi_fu_16686_p6.read();
    } else {
        ap_phi_mux_data_727_V_read1002_phi_phi_fu_26222_p4 = ap_phi_reg_pp0_iter1_data_727_V_read1002_phi_reg_26218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_727_V_read1002_rewind_phi_fu_16686_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_727_V_read1002_rewind_phi_fu_16686_p6 = data_727_V_read1002_phi_reg_26218.read();
    } else {
        ap_phi_mux_data_727_V_read1002_rewind_phi_fu_16686_p6 = data_727_V_read1002_rewind_reg_16682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_728_V_read1003_phi_phi_fu_26234_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_728_V_read1003_phi_phi_fu_26234_p4 = ap_phi_mux_data_728_V_read1003_rewind_phi_fu_16700_p6.read();
    } else {
        ap_phi_mux_data_728_V_read1003_phi_phi_fu_26234_p4 = ap_phi_reg_pp0_iter1_data_728_V_read1003_phi_reg_26230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_728_V_read1003_rewind_phi_fu_16700_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_728_V_read1003_rewind_phi_fu_16700_p6 = data_728_V_read1003_phi_reg_26230.read();
    } else {
        ap_phi_mux_data_728_V_read1003_rewind_phi_fu_16700_p6 = data_728_V_read1003_rewind_reg_16696.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_729_V_read1004_phi_phi_fu_26246_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_729_V_read1004_phi_phi_fu_26246_p4 = ap_phi_mux_data_729_V_read1004_rewind_phi_fu_16714_p6.read();
    } else {
        ap_phi_mux_data_729_V_read1004_phi_phi_fu_26246_p4 = ap_phi_reg_pp0_iter1_data_729_V_read1004_phi_reg_26242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_729_V_read1004_rewind_phi_fu_16714_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_729_V_read1004_rewind_phi_fu_16714_p6 = data_729_V_read1004_phi_reg_26242.read();
    } else {
        ap_phi_mux_data_729_V_read1004_rewind_phi_fu_16714_p6 = data_729_V_read1004_rewind_reg_16710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_72_V_read347_phi_phi_fu_18362_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_72_V_read347_phi_phi_fu_18362_p4 = ap_phi_mux_data_72_V_read347_rewind_phi_fu_7516_p6.read();
    } else {
        ap_phi_mux_data_72_V_read347_phi_phi_fu_18362_p4 = ap_phi_reg_pp0_iter1_data_72_V_read347_phi_reg_18358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_72_V_read347_rewind_phi_fu_7516_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_72_V_read347_rewind_phi_fu_7516_p6 = data_72_V_read347_phi_reg_18358.read();
    } else {
        ap_phi_mux_data_72_V_read347_rewind_phi_fu_7516_p6 = data_72_V_read347_rewind_reg_7512.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_730_V_read1005_phi_phi_fu_26258_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_730_V_read1005_phi_phi_fu_26258_p4 = ap_phi_mux_data_730_V_read1005_rewind_phi_fu_16728_p6.read();
    } else {
        ap_phi_mux_data_730_V_read1005_phi_phi_fu_26258_p4 = ap_phi_reg_pp0_iter1_data_730_V_read1005_phi_reg_26254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_730_V_read1005_rewind_phi_fu_16728_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_730_V_read1005_rewind_phi_fu_16728_p6 = data_730_V_read1005_phi_reg_26254.read();
    } else {
        ap_phi_mux_data_730_V_read1005_rewind_phi_fu_16728_p6 = data_730_V_read1005_rewind_reg_16724.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_731_V_read1006_phi_phi_fu_26270_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_731_V_read1006_phi_phi_fu_26270_p4 = ap_phi_mux_data_731_V_read1006_rewind_phi_fu_16742_p6.read();
    } else {
        ap_phi_mux_data_731_V_read1006_phi_phi_fu_26270_p4 = ap_phi_reg_pp0_iter1_data_731_V_read1006_phi_reg_26266.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_731_V_read1006_rewind_phi_fu_16742_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_731_V_read1006_rewind_phi_fu_16742_p6 = data_731_V_read1006_phi_reg_26266.read();
    } else {
        ap_phi_mux_data_731_V_read1006_rewind_phi_fu_16742_p6 = data_731_V_read1006_rewind_reg_16738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_732_V_read1007_phi_phi_fu_26282_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_732_V_read1007_phi_phi_fu_26282_p4 = ap_phi_mux_data_732_V_read1007_rewind_phi_fu_16756_p6.read();
    } else {
        ap_phi_mux_data_732_V_read1007_phi_phi_fu_26282_p4 = ap_phi_reg_pp0_iter1_data_732_V_read1007_phi_reg_26278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_732_V_read1007_rewind_phi_fu_16756_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_732_V_read1007_rewind_phi_fu_16756_p6 = data_732_V_read1007_phi_reg_26278.read();
    } else {
        ap_phi_mux_data_732_V_read1007_rewind_phi_fu_16756_p6 = data_732_V_read1007_rewind_reg_16752.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_733_V_read1008_phi_phi_fu_26294_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_733_V_read1008_phi_phi_fu_26294_p4 = ap_phi_mux_data_733_V_read1008_rewind_phi_fu_16770_p6.read();
    } else {
        ap_phi_mux_data_733_V_read1008_phi_phi_fu_26294_p4 = ap_phi_reg_pp0_iter1_data_733_V_read1008_phi_reg_26290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_733_V_read1008_rewind_phi_fu_16770_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_733_V_read1008_rewind_phi_fu_16770_p6 = data_733_V_read1008_phi_reg_26290.read();
    } else {
        ap_phi_mux_data_733_V_read1008_rewind_phi_fu_16770_p6 = data_733_V_read1008_rewind_reg_16766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_734_V_read1009_phi_phi_fu_26306_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_734_V_read1009_phi_phi_fu_26306_p4 = ap_phi_mux_data_734_V_read1009_rewind_phi_fu_16784_p6.read();
    } else {
        ap_phi_mux_data_734_V_read1009_phi_phi_fu_26306_p4 = ap_phi_reg_pp0_iter1_data_734_V_read1009_phi_reg_26302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_734_V_read1009_rewind_phi_fu_16784_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_734_V_read1009_rewind_phi_fu_16784_p6 = data_734_V_read1009_phi_reg_26302.read();
    } else {
        ap_phi_mux_data_734_V_read1009_rewind_phi_fu_16784_p6 = data_734_V_read1009_rewind_reg_16780.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_735_V_read1010_phi_phi_fu_26318_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_735_V_read1010_phi_phi_fu_26318_p4 = ap_phi_mux_data_735_V_read1010_rewind_phi_fu_16798_p6.read();
    } else {
        ap_phi_mux_data_735_V_read1010_phi_phi_fu_26318_p4 = ap_phi_reg_pp0_iter1_data_735_V_read1010_phi_reg_26314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_735_V_read1010_rewind_phi_fu_16798_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_735_V_read1010_rewind_phi_fu_16798_p6 = data_735_V_read1010_phi_reg_26314.read();
    } else {
        ap_phi_mux_data_735_V_read1010_rewind_phi_fu_16798_p6 = data_735_V_read1010_rewind_reg_16794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_736_V_read1011_phi_phi_fu_26330_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_736_V_read1011_phi_phi_fu_26330_p4 = ap_phi_mux_data_736_V_read1011_rewind_phi_fu_16812_p6.read();
    } else {
        ap_phi_mux_data_736_V_read1011_phi_phi_fu_26330_p4 = ap_phi_reg_pp0_iter1_data_736_V_read1011_phi_reg_26326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_736_V_read1011_rewind_phi_fu_16812_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_736_V_read1011_rewind_phi_fu_16812_p6 = data_736_V_read1011_phi_reg_26326.read();
    } else {
        ap_phi_mux_data_736_V_read1011_rewind_phi_fu_16812_p6 = data_736_V_read1011_rewind_reg_16808.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_737_V_read1012_phi_phi_fu_26342_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_737_V_read1012_phi_phi_fu_26342_p4 = ap_phi_mux_data_737_V_read1012_rewind_phi_fu_16826_p6.read();
    } else {
        ap_phi_mux_data_737_V_read1012_phi_phi_fu_26342_p4 = ap_phi_reg_pp0_iter1_data_737_V_read1012_phi_reg_26338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_737_V_read1012_rewind_phi_fu_16826_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_737_V_read1012_rewind_phi_fu_16826_p6 = data_737_V_read1012_phi_reg_26338.read();
    } else {
        ap_phi_mux_data_737_V_read1012_rewind_phi_fu_16826_p6 = data_737_V_read1012_rewind_reg_16822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_738_V_read1013_phi_phi_fu_26354_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_738_V_read1013_phi_phi_fu_26354_p4 = ap_phi_mux_data_738_V_read1013_rewind_phi_fu_16840_p6.read();
    } else {
        ap_phi_mux_data_738_V_read1013_phi_phi_fu_26354_p4 = ap_phi_reg_pp0_iter1_data_738_V_read1013_phi_reg_26350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_738_V_read1013_rewind_phi_fu_16840_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_738_V_read1013_rewind_phi_fu_16840_p6 = data_738_V_read1013_phi_reg_26350.read();
    } else {
        ap_phi_mux_data_738_V_read1013_rewind_phi_fu_16840_p6 = data_738_V_read1013_rewind_reg_16836.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_739_V_read1014_phi_phi_fu_26366_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_739_V_read1014_phi_phi_fu_26366_p4 = ap_phi_mux_data_739_V_read1014_rewind_phi_fu_16854_p6.read();
    } else {
        ap_phi_mux_data_739_V_read1014_phi_phi_fu_26366_p4 = ap_phi_reg_pp0_iter1_data_739_V_read1014_phi_reg_26362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_739_V_read1014_rewind_phi_fu_16854_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_739_V_read1014_rewind_phi_fu_16854_p6 = data_739_V_read1014_phi_reg_26362.read();
    } else {
        ap_phi_mux_data_739_V_read1014_rewind_phi_fu_16854_p6 = data_739_V_read1014_rewind_reg_16850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_73_V_read348_phi_phi_fu_18374_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_73_V_read348_phi_phi_fu_18374_p4 = ap_phi_mux_data_73_V_read348_rewind_phi_fu_7530_p6.read();
    } else {
        ap_phi_mux_data_73_V_read348_phi_phi_fu_18374_p4 = ap_phi_reg_pp0_iter1_data_73_V_read348_phi_reg_18370.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_73_V_read348_rewind_phi_fu_7530_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_73_V_read348_rewind_phi_fu_7530_p6 = data_73_V_read348_phi_reg_18370.read();
    } else {
        ap_phi_mux_data_73_V_read348_rewind_phi_fu_7530_p6 = data_73_V_read348_rewind_reg_7526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_740_V_read1015_phi_phi_fu_26378_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_740_V_read1015_phi_phi_fu_26378_p4 = ap_phi_mux_data_740_V_read1015_rewind_phi_fu_16868_p6.read();
    } else {
        ap_phi_mux_data_740_V_read1015_phi_phi_fu_26378_p4 = ap_phi_reg_pp0_iter1_data_740_V_read1015_phi_reg_26374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_740_V_read1015_rewind_phi_fu_16868_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_740_V_read1015_rewind_phi_fu_16868_p6 = data_740_V_read1015_phi_reg_26374.read();
    } else {
        ap_phi_mux_data_740_V_read1015_rewind_phi_fu_16868_p6 = data_740_V_read1015_rewind_reg_16864.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_741_V_read1016_phi_phi_fu_26390_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_741_V_read1016_phi_phi_fu_26390_p4 = ap_phi_mux_data_741_V_read1016_rewind_phi_fu_16882_p6.read();
    } else {
        ap_phi_mux_data_741_V_read1016_phi_phi_fu_26390_p4 = ap_phi_reg_pp0_iter1_data_741_V_read1016_phi_reg_26386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_741_V_read1016_rewind_phi_fu_16882_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_741_V_read1016_rewind_phi_fu_16882_p6 = data_741_V_read1016_phi_reg_26386.read();
    } else {
        ap_phi_mux_data_741_V_read1016_rewind_phi_fu_16882_p6 = data_741_V_read1016_rewind_reg_16878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_742_V_read1017_phi_phi_fu_26402_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_742_V_read1017_phi_phi_fu_26402_p4 = ap_phi_mux_data_742_V_read1017_rewind_phi_fu_16896_p6.read();
    } else {
        ap_phi_mux_data_742_V_read1017_phi_phi_fu_26402_p4 = ap_phi_reg_pp0_iter1_data_742_V_read1017_phi_reg_26398.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_742_V_read1017_rewind_phi_fu_16896_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_742_V_read1017_rewind_phi_fu_16896_p6 = data_742_V_read1017_phi_reg_26398.read();
    } else {
        ap_phi_mux_data_742_V_read1017_rewind_phi_fu_16896_p6 = data_742_V_read1017_rewind_reg_16892.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_743_V_read1018_phi_phi_fu_26414_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_743_V_read1018_phi_phi_fu_26414_p4 = ap_phi_mux_data_743_V_read1018_rewind_phi_fu_16910_p6.read();
    } else {
        ap_phi_mux_data_743_V_read1018_phi_phi_fu_26414_p4 = ap_phi_reg_pp0_iter1_data_743_V_read1018_phi_reg_26410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_743_V_read1018_rewind_phi_fu_16910_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_743_V_read1018_rewind_phi_fu_16910_p6 = data_743_V_read1018_phi_reg_26410.read();
    } else {
        ap_phi_mux_data_743_V_read1018_rewind_phi_fu_16910_p6 = data_743_V_read1018_rewind_reg_16906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_744_V_read1019_phi_phi_fu_26426_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_744_V_read1019_phi_phi_fu_26426_p4 = ap_phi_mux_data_744_V_read1019_rewind_phi_fu_16924_p6.read();
    } else {
        ap_phi_mux_data_744_V_read1019_phi_phi_fu_26426_p4 = ap_phi_reg_pp0_iter1_data_744_V_read1019_phi_reg_26422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_744_V_read1019_rewind_phi_fu_16924_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_744_V_read1019_rewind_phi_fu_16924_p6 = data_744_V_read1019_phi_reg_26422.read();
    } else {
        ap_phi_mux_data_744_V_read1019_rewind_phi_fu_16924_p6 = data_744_V_read1019_rewind_reg_16920.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_745_V_read1020_phi_phi_fu_26438_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_745_V_read1020_phi_phi_fu_26438_p4 = ap_phi_mux_data_745_V_read1020_rewind_phi_fu_16938_p6.read();
    } else {
        ap_phi_mux_data_745_V_read1020_phi_phi_fu_26438_p4 = ap_phi_reg_pp0_iter1_data_745_V_read1020_phi_reg_26434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_745_V_read1020_rewind_phi_fu_16938_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_745_V_read1020_rewind_phi_fu_16938_p6 = data_745_V_read1020_phi_reg_26434.read();
    } else {
        ap_phi_mux_data_745_V_read1020_rewind_phi_fu_16938_p6 = data_745_V_read1020_rewind_reg_16934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_746_V_read1021_phi_phi_fu_26450_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_746_V_read1021_phi_phi_fu_26450_p4 = ap_phi_mux_data_746_V_read1021_rewind_phi_fu_16952_p6.read();
    } else {
        ap_phi_mux_data_746_V_read1021_phi_phi_fu_26450_p4 = ap_phi_reg_pp0_iter1_data_746_V_read1021_phi_reg_26446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_746_V_read1021_rewind_phi_fu_16952_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_746_V_read1021_rewind_phi_fu_16952_p6 = data_746_V_read1021_phi_reg_26446.read();
    } else {
        ap_phi_mux_data_746_V_read1021_rewind_phi_fu_16952_p6 = data_746_V_read1021_rewind_reg_16948.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_747_V_read1022_phi_phi_fu_26462_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_747_V_read1022_phi_phi_fu_26462_p4 = ap_phi_mux_data_747_V_read1022_rewind_phi_fu_16966_p6.read();
    } else {
        ap_phi_mux_data_747_V_read1022_phi_phi_fu_26462_p4 = ap_phi_reg_pp0_iter1_data_747_V_read1022_phi_reg_26458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_747_V_read1022_rewind_phi_fu_16966_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_747_V_read1022_rewind_phi_fu_16966_p6 = data_747_V_read1022_phi_reg_26458.read();
    } else {
        ap_phi_mux_data_747_V_read1022_rewind_phi_fu_16966_p6 = data_747_V_read1022_rewind_reg_16962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_748_V_read1023_phi_phi_fu_26474_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_748_V_read1023_phi_phi_fu_26474_p4 = ap_phi_mux_data_748_V_read1023_rewind_phi_fu_16980_p6.read();
    } else {
        ap_phi_mux_data_748_V_read1023_phi_phi_fu_26474_p4 = ap_phi_reg_pp0_iter1_data_748_V_read1023_phi_reg_26470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_748_V_read1023_rewind_phi_fu_16980_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_748_V_read1023_rewind_phi_fu_16980_p6 = data_748_V_read1023_phi_reg_26470.read();
    } else {
        ap_phi_mux_data_748_V_read1023_rewind_phi_fu_16980_p6 = data_748_V_read1023_rewind_reg_16976.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_749_V_read1024_phi_phi_fu_26486_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_749_V_read1024_phi_phi_fu_26486_p4 = ap_phi_mux_data_749_V_read1024_rewind_phi_fu_16994_p6.read();
    } else {
        ap_phi_mux_data_749_V_read1024_phi_phi_fu_26486_p4 = ap_phi_reg_pp0_iter1_data_749_V_read1024_phi_reg_26482.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_749_V_read1024_rewind_phi_fu_16994_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_749_V_read1024_rewind_phi_fu_16994_p6 = data_749_V_read1024_phi_reg_26482.read();
    } else {
        ap_phi_mux_data_749_V_read1024_rewind_phi_fu_16994_p6 = data_749_V_read1024_rewind_reg_16990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_74_V_read349_phi_phi_fu_18386_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_74_V_read349_phi_phi_fu_18386_p4 = ap_phi_mux_data_74_V_read349_rewind_phi_fu_7544_p6.read();
    } else {
        ap_phi_mux_data_74_V_read349_phi_phi_fu_18386_p4 = ap_phi_reg_pp0_iter1_data_74_V_read349_phi_reg_18382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_74_V_read349_rewind_phi_fu_7544_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_74_V_read349_rewind_phi_fu_7544_p6 = data_74_V_read349_phi_reg_18382.read();
    } else {
        ap_phi_mux_data_74_V_read349_rewind_phi_fu_7544_p6 = data_74_V_read349_rewind_reg_7540.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_750_V_read1025_phi_phi_fu_26498_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_750_V_read1025_phi_phi_fu_26498_p4 = ap_phi_mux_data_750_V_read1025_rewind_phi_fu_17008_p6.read();
    } else {
        ap_phi_mux_data_750_V_read1025_phi_phi_fu_26498_p4 = ap_phi_reg_pp0_iter1_data_750_V_read1025_phi_reg_26494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_750_V_read1025_rewind_phi_fu_17008_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_750_V_read1025_rewind_phi_fu_17008_p6 = data_750_V_read1025_phi_reg_26494.read();
    } else {
        ap_phi_mux_data_750_V_read1025_rewind_phi_fu_17008_p6 = data_750_V_read1025_rewind_reg_17004.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_751_V_read1026_phi_phi_fu_26510_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_751_V_read1026_phi_phi_fu_26510_p4 = ap_phi_mux_data_751_V_read1026_rewind_phi_fu_17022_p6.read();
    } else {
        ap_phi_mux_data_751_V_read1026_phi_phi_fu_26510_p4 = ap_phi_reg_pp0_iter1_data_751_V_read1026_phi_reg_26506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_751_V_read1026_rewind_phi_fu_17022_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_751_V_read1026_rewind_phi_fu_17022_p6 = data_751_V_read1026_phi_reg_26506.read();
    } else {
        ap_phi_mux_data_751_V_read1026_rewind_phi_fu_17022_p6 = data_751_V_read1026_rewind_reg_17018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_752_V_read1027_phi_phi_fu_26522_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_752_V_read1027_phi_phi_fu_26522_p4 = ap_phi_mux_data_752_V_read1027_rewind_phi_fu_17036_p6.read();
    } else {
        ap_phi_mux_data_752_V_read1027_phi_phi_fu_26522_p4 = ap_phi_reg_pp0_iter1_data_752_V_read1027_phi_reg_26518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_752_V_read1027_rewind_phi_fu_17036_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_752_V_read1027_rewind_phi_fu_17036_p6 = data_752_V_read1027_phi_reg_26518.read();
    } else {
        ap_phi_mux_data_752_V_read1027_rewind_phi_fu_17036_p6 = data_752_V_read1027_rewind_reg_17032.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_753_V_read1028_phi_phi_fu_26534_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_753_V_read1028_phi_phi_fu_26534_p4 = ap_phi_mux_data_753_V_read1028_rewind_phi_fu_17050_p6.read();
    } else {
        ap_phi_mux_data_753_V_read1028_phi_phi_fu_26534_p4 = ap_phi_reg_pp0_iter1_data_753_V_read1028_phi_reg_26530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_753_V_read1028_rewind_phi_fu_17050_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_753_V_read1028_rewind_phi_fu_17050_p6 = data_753_V_read1028_phi_reg_26530.read();
    } else {
        ap_phi_mux_data_753_V_read1028_rewind_phi_fu_17050_p6 = data_753_V_read1028_rewind_reg_17046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_754_V_read1029_phi_phi_fu_26546_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_754_V_read1029_phi_phi_fu_26546_p4 = ap_phi_mux_data_754_V_read1029_rewind_phi_fu_17064_p6.read();
    } else {
        ap_phi_mux_data_754_V_read1029_phi_phi_fu_26546_p4 = ap_phi_reg_pp0_iter1_data_754_V_read1029_phi_reg_26542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_754_V_read1029_rewind_phi_fu_17064_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_754_V_read1029_rewind_phi_fu_17064_p6 = data_754_V_read1029_phi_reg_26542.read();
    } else {
        ap_phi_mux_data_754_V_read1029_rewind_phi_fu_17064_p6 = data_754_V_read1029_rewind_reg_17060.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_755_V_read1030_phi_phi_fu_26558_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_755_V_read1030_phi_phi_fu_26558_p4 = ap_phi_mux_data_755_V_read1030_rewind_phi_fu_17078_p6.read();
    } else {
        ap_phi_mux_data_755_V_read1030_phi_phi_fu_26558_p4 = ap_phi_reg_pp0_iter1_data_755_V_read1030_phi_reg_26554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_755_V_read1030_rewind_phi_fu_17078_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_755_V_read1030_rewind_phi_fu_17078_p6 = data_755_V_read1030_phi_reg_26554.read();
    } else {
        ap_phi_mux_data_755_V_read1030_rewind_phi_fu_17078_p6 = data_755_V_read1030_rewind_reg_17074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_756_V_read1031_phi_phi_fu_26570_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_756_V_read1031_phi_phi_fu_26570_p4 = ap_phi_mux_data_756_V_read1031_rewind_phi_fu_17092_p6.read();
    } else {
        ap_phi_mux_data_756_V_read1031_phi_phi_fu_26570_p4 = ap_phi_reg_pp0_iter1_data_756_V_read1031_phi_reg_26566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_756_V_read1031_rewind_phi_fu_17092_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_756_V_read1031_rewind_phi_fu_17092_p6 = data_756_V_read1031_phi_reg_26566.read();
    } else {
        ap_phi_mux_data_756_V_read1031_rewind_phi_fu_17092_p6 = data_756_V_read1031_rewind_reg_17088.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_757_V_read1032_phi_phi_fu_26582_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_757_V_read1032_phi_phi_fu_26582_p4 = ap_phi_mux_data_757_V_read1032_rewind_phi_fu_17106_p6.read();
    } else {
        ap_phi_mux_data_757_V_read1032_phi_phi_fu_26582_p4 = ap_phi_reg_pp0_iter1_data_757_V_read1032_phi_reg_26578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_757_V_read1032_rewind_phi_fu_17106_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_757_V_read1032_rewind_phi_fu_17106_p6 = data_757_V_read1032_phi_reg_26578.read();
    } else {
        ap_phi_mux_data_757_V_read1032_rewind_phi_fu_17106_p6 = data_757_V_read1032_rewind_reg_17102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_758_V_read1033_phi_phi_fu_26594_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_758_V_read1033_phi_phi_fu_26594_p4 = ap_phi_mux_data_758_V_read1033_rewind_phi_fu_17120_p6.read();
    } else {
        ap_phi_mux_data_758_V_read1033_phi_phi_fu_26594_p4 = ap_phi_reg_pp0_iter1_data_758_V_read1033_phi_reg_26590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_758_V_read1033_rewind_phi_fu_17120_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_758_V_read1033_rewind_phi_fu_17120_p6 = data_758_V_read1033_phi_reg_26590.read();
    } else {
        ap_phi_mux_data_758_V_read1033_rewind_phi_fu_17120_p6 = data_758_V_read1033_rewind_reg_17116.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_759_V_read1034_phi_phi_fu_26606_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_759_V_read1034_phi_phi_fu_26606_p4 = ap_phi_mux_data_759_V_read1034_rewind_phi_fu_17134_p6.read();
    } else {
        ap_phi_mux_data_759_V_read1034_phi_phi_fu_26606_p4 = ap_phi_reg_pp0_iter1_data_759_V_read1034_phi_reg_26602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_759_V_read1034_rewind_phi_fu_17134_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_759_V_read1034_rewind_phi_fu_17134_p6 = data_759_V_read1034_phi_reg_26602.read();
    } else {
        ap_phi_mux_data_759_V_read1034_rewind_phi_fu_17134_p6 = data_759_V_read1034_rewind_reg_17130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_75_V_read350_phi_phi_fu_18398_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_75_V_read350_phi_phi_fu_18398_p4 = ap_phi_mux_data_75_V_read350_rewind_phi_fu_7558_p6.read();
    } else {
        ap_phi_mux_data_75_V_read350_phi_phi_fu_18398_p4 = ap_phi_reg_pp0_iter1_data_75_V_read350_phi_reg_18394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_75_V_read350_rewind_phi_fu_7558_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_75_V_read350_rewind_phi_fu_7558_p6 = data_75_V_read350_phi_reg_18394.read();
    } else {
        ap_phi_mux_data_75_V_read350_rewind_phi_fu_7558_p6 = data_75_V_read350_rewind_reg_7554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_760_V_read1035_phi_phi_fu_26618_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_760_V_read1035_phi_phi_fu_26618_p4 = ap_phi_mux_data_760_V_read1035_rewind_phi_fu_17148_p6.read();
    } else {
        ap_phi_mux_data_760_V_read1035_phi_phi_fu_26618_p4 = ap_phi_reg_pp0_iter1_data_760_V_read1035_phi_reg_26614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_760_V_read1035_rewind_phi_fu_17148_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_760_V_read1035_rewind_phi_fu_17148_p6 = data_760_V_read1035_phi_reg_26614.read();
    } else {
        ap_phi_mux_data_760_V_read1035_rewind_phi_fu_17148_p6 = data_760_V_read1035_rewind_reg_17144.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_761_V_read1036_phi_phi_fu_26630_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_761_V_read1036_phi_phi_fu_26630_p4 = ap_phi_mux_data_761_V_read1036_rewind_phi_fu_17162_p6.read();
    } else {
        ap_phi_mux_data_761_V_read1036_phi_phi_fu_26630_p4 = ap_phi_reg_pp0_iter1_data_761_V_read1036_phi_reg_26626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_761_V_read1036_rewind_phi_fu_17162_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_761_V_read1036_rewind_phi_fu_17162_p6 = data_761_V_read1036_phi_reg_26626.read();
    } else {
        ap_phi_mux_data_761_V_read1036_rewind_phi_fu_17162_p6 = data_761_V_read1036_rewind_reg_17158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_762_V_read1037_phi_phi_fu_26642_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_762_V_read1037_phi_phi_fu_26642_p4 = ap_phi_mux_data_762_V_read1037_rewind_phi_fu_17176_p6.read();
    } else {
        ap_phi_mux_data_762_V_read1037_phi_phi_fu_26642_p4 = ap_phi_reg_pp0_iter1_data_762_V_read1037_phi_reg_26638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_762_V_read1037_rewind_phi_fu_17176_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_762_V_read1037_rewind_phi_fu_17176_p6 = data_762_V_read1037_phi_reg_26638.read();
    } else {
        ap_phi_mux_data_762_V_read1037_rewind_phi_fu_17176_p6 = data_762_V_read1037_rewind_reg_17172.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_763_V_read1038_phi_phi_fu_26654_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_763_V_read1038_phi_phi_fu_26654_p4 = ap_phi_mux_data_763_V_read1038_rewind_phi_fu_17190_p6.read();
    } else {
        ap_phi_mux_data_763_V_read1038_phi_phi_fu_26654_p4 = ap_phi_reg_pp0_iter1_data_763_V_read1038_phi_reg_26650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_763_V_read1038_rewind_phi_fu_17190_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_763_V_read1038_rewind_phi_fu_17190_p6 = data_763_V_read1038_phi_reg_26650.read();
    } else {
        ap_phi_mux_data_763_V_read1038_rewind_phi_fu_17190_p6 = data_763_V_read1038_rewind_reg_17186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_764_V_read1039_phi_phi_fu_26666_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_764_V_read1039_phi_phi_fu_26666_p4 = ap_phi_mux_data_764_V_read1039_rewind_phi_fu_17204_p6.read();
    } else {
        ap_phi_mux_data_764_V_read1039_phi_phi_fu_26666_p4 = ap_phi_reg_pp0_iter1_data_764_V_read1039_phi_reg_26662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_764_V_read1039_rewind_phi_fu_17204_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_764_V_read1039_rewind_phi_fu_17204_p6 = data_764_V_read1039_phi_reg_26662.read();
    } else {
        ap_phi_mux_data_764_V_read1039_rewind_phi_fu_17204_p6 = data_764_V_read1039_rewind_reg_17200.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_765_V_read1040_phi_phi_fu_26678_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_765_V_read1040_phi_phi_fu_26678_p4 = ap_phi_mux_data_765_V_read1040_rewind_phi_fu_17218_p6.read();
    } else {
        ap_phi_mux_data_765_V_read1040_phi_phi_fu_26678_p4 = ap_phi_reg_pp0_iter1_data_765_V_read1040_phi_reg_26674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_765_V_read1040_rewind_phi_fu_17218_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_765_V_read1040_rewind_phi_fu_17218_p6 = data_765_V_read1040_phi_reg_26674.read();
    } else {
        ap_phi_mux_data_765_V_read1040_rewind_phi_fu_17218_p6 = data_765_V_read1040_rewind_reg_17214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_766_V_read1041_phi_phi_fu_26690_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_766_V_read1041_phi_phi_fu_26690_p4 = ap_phi_mux_data_766_V_read1041_rewind_phi_fu_17232_p6.read();
    } else {
        ap_phi_mux_data_766_V_read1041_phi_phi_fu_26690_p4 = ap_phi_reg_pp0_iter1_data_766_V_read1041_phi_reg_26686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_766_V_read1041_rewind_phi_fu_17232_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_766_V_read1041_rewind_phi_fu_17232_p6 = data_766_V_read1041_phi_reg_26686.read();
    } else {
        ap_phi_mux_data_766_V_read1041_rewind_phi_fu_17232_p6 = data_766_V_read1041_rewind_reg_17228.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_767_V_read1042_phi_phi_fu_26702_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_767_V_read1042_phi_phi_fu_26702_p4 = ap_phi_mux_data_767_V_read1042_rewind_phi_fu_17246_p6.read();
    } else {
        ap_phi_mux_data_767_V_read1042_phi_phi_fu_26702_p4 = ap_phi_reg_pp0_iter1_data_767_V_read1042_phi_reg_26698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_767_V_read1042_rewind_phi_fu_17246_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_767_V_read1042_rewind_phi_fu_17246_p6 = data_767_V_read1042_phi_reg_26698.read();
    } else {
        ap_phi_mux_data_767_V_read1042_rewind_phi_fu_17246_p6 = data_767_V_read1042_rewind_reg_17242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_768_V_read1043_phi_phi_fu_26714_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_768_V_read1043_phi_phi_fu_26714_p4 = ap_phi_mux_data_768_V_read1043_rewind_phi_fu_17260_p6.read();
    } else {
        ap_phi_mux_data_768_V_read1043_phi_phi_fu_26714_p4 = ap_phi_reg_pp0_iter1_data_768_V_read1043_phi_reg_26710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_768_V_read1043_rewind_phi_fu_17260_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_768_V_read1043_rewind_phi_fu_17260_p6 = data_768_V_read1043_phi_reg_26710.read();
    } else {
        ap_phi_mux_data_768_V_read1043_rewind_phi_fu_17260_p6 = data_768_V_read1043_rewind_reg_17256.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_769_V_read1044_phi_phi_fu_26726_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_769_V_read1044_phi_phi_fu_26726_p4 = ap_phi_mux_data_769_V_read1044_rewind_phi_fu_17274_p6.read();
    } else {
        ap_phi_mux_data_769_V_read1044_phi_phi_fu_26726_p4 = ap_phi_reg_pp0_iter1_data_769_V_read1044_phi_reg_26722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_769_V_read1044_rewind_phi_fu_17274_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_769_V_read1044_rewind_phi_fu_17274_p6 = data_769_V_read1044_phi_reg_26722.read();
    } else {
        ap_phi_mux_data_769_V_read1044_rewind_phi_fu_17274_p6 = data_769_V_read1044_rewind_reg_17270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_76_V_read351_phi_phi_fu_18410_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_76_V_read351_phi_phi_fu_18410_p4 = ap_phi_mux_data_76_V_read351_rewind_phi_fu_7572_p6.read();
    } else {
        ap_phi_mux_data_76_V_read351_phi_phi_fu_18410_p4 = ap_phi_reg_pp0_iter1_data_76_V_read351_phi_reg_18406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_76_V_read351_rewind_phi_fu_7572_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_76_V_read351_rewind_phi_fu_7572_p6 = data_76_V_read351_phi_reg_18406.read();
    } else {
        ap_phi_mux_data_76_V_read351_rewind_phi_fu_7572_p6 = data_76_V_read351_rewind_reg_7568.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_770_V_read1045_phi_phi_fu_26738_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_770_V_read1045_phi_phi_fu_26738_p4 = ap_phi_mux_data_770_V_read1045_rewind_phi_fu_17288_p6.read();
    } else {
        ap_phi_mux_data_770_V_read1045_phi_phi_fu_26738_p4 = ap_phi_reg_pp0_iter1_data_770_V_read1045_phi_reg_26734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_770_V_read1045_rewind_phi_fu_17288_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_770_V_read1045_rewind_phi_fu_17288_p6 = data_770_V_read1045_phi_reg_26734.read();
    } else {
        ap_phi_mux_data_770_V_read1045_rewind_phi_fu_17288_p6 = data_770_V_read1045_rewind_reg_17284.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_771_V_read1046_phi_phi_fu_26750_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_771_V_read1046_phi_phi_fu_26750_p4 = ap_phi_mux_data_771_V_read1046_rewind_phi_fu_17302_p6.read();
    } else {
        ap_phi_mux_data_771_V_read1046_phi_phi_fu_26750_p4 = ap_phi_reg_pp0_iter1_data_771_V_read1046_phi_reg_26746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_771_V_read1046_rewind_phi_fu_17302_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_771_V_read1046_rewind_phi_fu_17302_p6 = data_771_V_read1046_phi_reg_26746.read();
    } else {
        ap_phi_mux_data_771_V_read1046_rewind_phi_fu_17302_p6 = data_771_V_read1046_rewind_reg_17298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_772_V_read1047_phi_phi_fu_26762_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_772_V_read1047_phi_phi_fu_26762_p4 = ap_phi_mux_data_772_V_read1047_rewind_phi_fu_17316_p6.read();
    } else {
        ap_phi_mux_data_772_V_read1047_phi_phi_fu_26762_p4 = ap_phi_reg_pp0_iter1_data_772_V_read1047_phi_reg_26758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_772_V_read1047_rewind_phi_fu_17316_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_772_V_read1047_rewind_phi_fu_17316_p6 = data_772_V_read1047_phi_reg_26758.read();
    } else {
        ap_phi_mux_data_772_V_read1047_rewind_phi_fu_17316_p6 = data_772_V_read1047_rewind_reg_17312.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_773_V_read1048_phi_phi_fu_26774_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_773_V_read1048_phi_phi_fu_26774_p4 = ap_phi_mux_data_773_V_read1048_rewind_phi_fu_17330_p6.read();
    } else {
        ap_phi_mux_data_773_V_read1048_phi_phi_fu_26774_p4 = ap_phi_reg_pp0_iter1_data_773_V_read1048_phi_reg_26770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_773_V_read1048_rewind_phi_fu_17330_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_773_V_read1048_rewind_phi_fu_17330_p6 = data_773_V_read1048_phi_reg_26770.read();
    } else {
        ap_phi_mux_data_773_V_read1048_rewind_phi_fu_17330_p6 = data_773_V_read1048_rewind_reg_17326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_774_V_read1049_phi_phi_fu_26786_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_774_V_read1049_phi_phi_fu_26786_p4 = ap_phi_mux_data_774_V_read1049_rewind_phi_fu_17344_p6.read();
    } else {
        ap_phi_mux_data_774_V_read1049_phi_phi_fu_26786_p4 = ap_phi_reg_pp0_iter1_data_774_V_read1049_phi_reg_26782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_774_V_read1049_rewind_phi_fu_17344_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_774_V_read1049_rewind_phi_fu_17344_p6 = data_774_V_read1049_phi_reg_26782.read();
    } else {
        ap_phi_mux_data_774_V_read1049_rewind_phi_fu_17344_p6 = data_774_V_read1049_rewind_reg_17340.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_775_V_read1050_phi_phi_fu_26798_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_775_V_read1050_phi_phi_fu_26798_p4 = ap_phi_mux_data_775_V_read1050_rewind_phi_fu_17358_p6.read();
    } else {
        ap_phi_mux_data_775_V_read1050_phi_phi_fu_26798_p4 = ap_phi_reg_pp0_iter1_data_775_V_read1050_phi_reg_26794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_775_V_read1050_rewind_phi_fu_17358_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_775_V_read1050_rewind_phi_fu_17358_p6 = data_775_V_read1050_phi_reg_26794.read();
    } else {
        ap_phi_mux_data_775_V_read1050_rewind_phi_fu_17358_p6 = data_775_V_read1050_rewind_reg_17354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_776_V_read1051_phi_phi_fu_26810_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_776_V_read1051_phi_phi_fu_26810_p4 = ap_phi_mux_data_776_V_read1051_rewind_phi_fu_17372_p6.read();
    } else {
        ap_phi_mux_data_776_V_read1051_phi_phi_fu_26810_p4 = ap_phi_reg_pp0_iter1_data_776_V_read1051_phi_reg_26806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_776_V_read1051_rewind_phi_fu_17372_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_776_V_read1051_rewind_phi_fu_17372_p6 = data_776_V_read1051_phi_reg_26806.read();
    } else {
        ap_phi_mux_data_776_V_read1051_rewind_phi_fu_17372_p6 = data_776_V_read1051_rewind_reg_17368.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_777_V_read1052_phi_phi_fu_26822_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_777_V_read1052_phi_phi_fu_26822_p4 = ap_phi_mux_data_777_V_read1052_rewind_phi_fu_17386_p6.read();
    } else {
        ap_phi_mux_data_777_V_read1052_phi_phi_fu_26822_p4 = ap_phi_reg_pp0_iter1_data_777_V_read1052_phi_reg_26818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_777_V_read1052_rewind_phi_fu_17386_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_777_V_read1052_rewind_phi_fu_17386_p6 = data_777_V_read1052_phi_reg_26818.read();
    } else {
        ap_phi_mux_data_777_V_read1052_rewind_phi_fu_17386_p6 = data_777_V_read1052_rewind_reg_17382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_778_V_read1053_phi_phi_fu_26834_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_778_V_read1053_phi_phi_fu_26834_p4 = ap_phi_mux_data_778_V_read1053_rewind_phi_fu_17400_p6.read();
    } else {
        ap_phi_mux_data_778_V_read1053_phi_phi_fu_26834_p4 = ap_phi_reg_pp0_iter1_data_778_V_read1053_phi_reg_26830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_778_V_read1053_rewind_phi_fu_17400_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_778_V_read1053_rewind_phi_fu_17400_p6 = data_778_V_read1053_phi_reg_26830.read();
    } else {
        ap_phi_mux_data_778_V_read1053_rewind_phi_fu_17400_p6 = data_778_V_read1053_rewind_reg_17396.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_779_V_read1054_phi_phi_fu_26846_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_779_V_read1054_phi_phi_fu_26846_p4 = ap_phi_mux_data_779_V_read1054_rewind_phi_fu_17414_p6.read();
    } else {
        ap_phi_mux_data_779_V_read1054_phi_phi_fu_26846_p4 = ap_phi_reg_pp0_iter1_data_779_V_read1054_phi_reg_26842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_779_V_read1054_rewind_phi_fu_17414_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_779_V_read1054_rewind_phi_fu_17414_p6 = data_779_V_read1054_phi_reg_26842.read();
    } else {
        ap_phi_mux_data_779_V_read1054_rewind_phi_fu_17414_p6 = data_779_V_read1054_rewind_reg_17410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_77_V_read352_phi_phi_fu_18422_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_77_V_read352_phi_phi_fu_18422_p4 = ap_phi_mux_data_77_V_read352_rewind_phi_fu_7586_p6.read();
    } else {
        ap_phi_mux_data_77_V_read352_phi_phi_fu_18422_p4 = ap_phi_reg_pp0_iter1_data_77_V_read352_phi_reg_18418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_77_V_read352_rewind_phi_fu_7586_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_77_V_read352_rewind_phi_fu_7586_p6 = data_77_V_read352_phi_reg_18418.read();
    } else {
        ap_phi_mux_data_77_V_read352_rewind_phi_fu_7586_p6 = data_77_V_read352_rewind_reg_7582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_780_V_read1055_phi_phi_fu_26858_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_780_V_read1055_phi_phi_fu_26858_p4 = ap_phi_mux_data_780_V_read1055_rewind_phi_fu_17428_p6.read();
    } else {
        ap_phi_mux_data_780_V_read1055_phi_phi_fu_26858_p4 = ap_phi_reg_pp0_iter1_data_780_V_read1055_phi_reg_26854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_780_V_read1055_rewind_phi_fu_17428_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_780_V_read1055_rewind_phi_fu_17428_p6 = data_780_V_read1055_phi_reg_26854.read();
    } else {
        ap_phi_mux_data_780_V_read1055_rewind_phi_fu_17428_p6 = data_780_V_read1055_rewind_reg_17424.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_781_V_read1056_phi_phi_fu_26870_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_781_V_read1056_phi_phi_fu_26870_p4 = ap_phi_mux_data_781_V_read1056_rewind_phi_fu_17442_p6.read();
    } else {
        ap_phi_mux_data_781_V_read1056_phi_phi_fu_26870_p4 = ap_phi_reg_pp0_iter1_data_781_V_read1056_phi_reg_26866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_781_V_read1056_rewind_phi_fu_17442_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_781_V_read1056_rewind_phi_fu_17442_p6 = data_781_V_read1056_phi_reg_26866.read();
    } else {
        ap_phi_mux_data_781_V_read1056_rewind_phi_fu_17442_p6 = data_781_V_read1056_rewind_reg_17438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_782_V_read1057_phi_phi_fu_26882_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_782_V_read1057_phi_phi_fu_26882_p4 = ap_phi_mux_data_782_V_read1057_rewind_phi_fu_17456_p6.read();
    } else {
        ap_phi_mux_data_782_V_read1057_phi_phi_fu_26882_p4 = ap_phi_reg_pp0_iter1_data_782_V_read1057_phi_reg_26878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_782_V_read1057_rewind_phi_fu_17456_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_782_V_read1057_rewind_phi_fu_17456_p6 = data_782_V_read1057_phi_reg_26878.read();
    } else {
        ap_phi_mux_data_782_V_read1057_rewind_phi_fu_17456_p6 = data_782_V_read1057_rewind_reg_17452.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_783_V_read1058_phi_phi_fu_26894_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_783_V_read1058_phi_phi_fu_26894_p4 = ap_phi_mux_data_783_V_read1058_rewind_phi_fu_17470_p6.read();
    } else {
        ap_phi_mux_data_783_V_read1058_phi_phi_fu_26894_p4 = ap_phi_reg_pp0_iter1_data_783_V_read1058_phi_reg_26890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_783_V_read1058_rewind_phi_fu_17470_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_783_V_read1058_rewind_phi_fu_17470_p6 = data_783_V_read1058_phi_reg_26890.read();
    } else {
        ap_phi_mux_data_783_V_read1058_rewind_phi_fu_17470_p6 = data_783_V_read1058_rewind_reg_17466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_78_V_read353_phi_phi_fu_18434_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_78_V_read353_phi_phi_fu_18434_p4 = ap_phi_mux_data_78_V_read353_rewind_phi_fu_7600_p6.read();
    } else {
        ap_phi_mux_data_78_V_read353_phi_phi_fu_18434_p4 = ap_phi_reg_pp0_iter1_data_78_V_read353_phi_reg_18430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_78_V_read353_rewind_phi_fu_7600_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_78_V_read353_rewind_phi_fu_7600_p6 = data_78_V_read353_phi_reg_18430.read();
    } else {
        ap_phi_mux_data_78_V_read353_rewind_phi_fu_7600_p6 = data_78_V_read353_rewind_reg_7596.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_79_V_read354_phi_phi_fu_18446_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_79_V_read354_phi_phi_fu_18446_p4 = ap_phi_mux_data_79_V_read354_rewind_phi_fu_7614_p6.read();
    } else {
        ap_phi_mux_data_79_V_read354_phi_phi_fu_18446_p4 = ap_phi_reg_pp0_iter1_data_79_V_read354_phi_reg_18442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_79_V_read354_rewind_phi_fu_7614_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_79_V_read354_rewind_phi_fu_7614_p6 = data_79_V_read354_phi_reg_18442.read();
    } else {
        ap_phi_mux_data_79_V_read354_rewind_phi_fu_7614_p6 = data_79_V_read354_rewind_reg_7610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_7_V_read282_phi_phi_fu_17582_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_7_V_read282_phi_phi_fu_17582_p4 = ap_phi_mux_data_7_V_read282_rewind_phi_fu_6606_p6.read();
    } else {
        ap_phi_mux_data_7_V_read282_phi_phi_fu_17582_p4 = ap_phi_reg_pp0_iter1_data_7_V_read282_phi_reg_17578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_7_V_read282_rewind_phi_fu_6606_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_7_V_read282_rewind_phi_fu_6606_p6 = data_7_V_read282_phi_reg_17578.read();
    } else {
        ap_phi_mux_data_7_V_read282_rewind_phi_fu_6606_p6 = data_7_V_read282_rewind_reg_6602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_80_V_read355_phi_phi_fu_18458_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_80_V_read355_phi_phi_fu_18458_p4 = ap_phi_mux_data_80_V_read355_rewind_phi_fu_7628_p6.read();
    } else {
        ap_phi_mux_data_80_V_read355_phi_phi_fu_18458_p4 = ap_phi_reg_pp0_iter1_data_80_V_read355_phi_reg_18454.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_80_V_read355_rewind_phi_fu_7628_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_80_V_read355_rewind_phi_fu_7628_p6 = data_80_V_read355_phi_reg_18454.read();
    } else {
        ap_phi_mux_data_80_V_read355_rewind_phi_fu_7628_p6 = data_80_V_read355_rewind_reg_7624.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_81_V_read356_phi_phi_fu_18470_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_81_V_read356_phi_phi_fu_18470_p4 = ap_phi_mux_data_81_V_read356_rewind_phi_fu_7642_p6.read();
    } else {
        ap_phi_mux_data_81_V_read356_phi_phi_fu_18470_p4 = ap_phi_reg_pp0_iter1_data_81_V_read356_phi_reg_18466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_81_V_read356_rewind_phi_fu_7642_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_81_V_read356_rewind_phi_fu_7642_p6 = data_81_V_read356_phi_reg_18466.read();
    } else {
        ap_phi_mux_data_81_V_read356_rewind_phi_fu_7642_p6 = data_81_V_read356_rewind_reg_7638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_82_V_read357_phi_phi_fu_18482_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_82_V_read357_phi_phi_fu_18482_p4 = ap_phi_mux_data_82_V_read357_rewind_phi_fu_7656_p6.read();
    } else {
        ap_phi_mux_data_82_V_read357_phi_phi_fu_18482_p4 = ap_phi_reg_pp0_iter1_data_82_V_read357_phi_reg_18478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_82_V_read357_rewind_phi_fu_7656_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_82_V_read357_rewind_phi_fu_7656_p6 = data_82_V_read357_phi_reg_18478.read();
    } else {
        ap_phi_mux_data_82_V_read357_rewind_phi_fu_7656_p6 = data_82_V_read357_rewind_reg_7652.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_83_V_read358_phi_phi_fu_18494_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_83_V_read358_phi_phi_fu_18494_p4 = ap_phi_mux_data_83_V_read358_rewind_phi_fu_7670_p6.read();
    } else {
        ap_phi_mux_data_83_V_read358_phi_phi_fu_18494_p4 = ap_phi_reg_pp0_iter1_data_83_V_read358_phi_reg_18490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_83_V_read358_rewind_phi_fu_7670_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_83_V_read358_rewind_phi_fu_7670_p6 = data_83_V_read358_phi_reg_18490.read();
    } else {
        ap_phi_mux_data_83_V_read358_rewind_phi_fu_7670_p6 = data_83_V_read358_rewind_reg_7666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_84_V_read359_phi_phi_fu_18506_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_84_V_read359_phi_phi_fu_18506_p4 = ap_phi_mux_data_84_V_read359_rewind_phi_fu_7684_p6.read();
    } else {
        ap_phi_mux_data_84_V_read359_phi_phi_fu_18506_p4 = ap_phi_reg_pp0_iter1_data_84_V_read359_phi_reg_18502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_84_V_read359_rewind_phi_fu_7684_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_84_V_read359_rewind_phi_fu_7684_p6 = data_84_V_read359_phi_reg_18502.read();
    } else {
        ap_phi_mux_data_84_V_read359_rewind_phi_fu_7684_p6 = data_84_V_read359_rewind_reg_7680.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_85_V_read360_phi_phi_fu_18518_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_85_V_read360_phi_phi_fu_18518_p4 = ap_phi_mux_data_85_V_read360_rewind_phi_fu_7698_p6.read();
    } else {
        ap_phi_mux_data_85_V_read360_phi_phi_fu_18518_p4 = ap_phi_reg_pp0_iter1_data_85_V_read360_phi_reg_18514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_85_V_read360_rewind_phi_fu_7698_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_85_V_read360_rewind_phi_fu_7698_p6 = data_85_V_read360_phi_reg_18514.read();
    } else {
        ap_phi_mux_data_85_V_read360_rewind_phi_fu_7698_p6 = data_85_V_read360_rewind_reg_7694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_86_V_read361_phi_phi_fu_18530_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_86_V_read361_phi_phi_fu_18530_p4 = ap_phi_mux_data_86_V_read361_rewind_phi_fu_7712_p6.read();
    } else {
        ap_phi_mux_data_86_V_read361_phi_phi_fu_18530_p4 = ap_phi_reg_pp0_iter1_data_86_V_read361_phi_reg_18526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_86_V_read361_rewind_phi_fu_7712_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_86_V_read361_rewind_phi_fu_7712_p6 = data_86_V_read361_phi_reg_18526.read();
    } else {
        ap_phi_mux_data_86_V_read361_rewind_phi_fu_7712_p6 = data_86_V_read361_rewind_reg_7708.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_87_V_read362_phi_phi_fu_18542_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_87_V_read362_phi_phi_fu_18542_p4 = ap_phi_mux_data_87_V_read362_rewind_phi_fu_7726_p6.read();
    } else {
        ap_phi_mux_data_87_V_read362_phi_phi_fu_18542_p4 = ap_phi_reg_pp0_iter1_data_87_V_read362_phi_reg_18538.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_87_V_read362_rewind_phi_fu_7726_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_87_V_read362_rewind_phi_fu_7726_p6 = data_87_V_read362_phi_reg_18538.read();
    } else {
        ap_phi_mux_data_87_V_read362_rewind_phi_fu_7726_p6 = data_87_V_read362_rewind_reg_7722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_88_V_read363_phi_phi_fu_18554_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_88_V_read363_phi_phi_fu_18554_p4 = ap_phi_mux_data_88_V_read363_rewind_phi_fu_7740_p6.read();
    } else {
        ap_phi_mux_data_88_V_read363_phi_phi_fu_18554_p4 = ap_phi_reg_pp0_iter1_data_88_V_read363_phi_reg_18550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_88_V_read363_rewind_phi_fu_7740_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_88_V_read363_rewind_phi_fu_7740_p6 = data_88_V_read363_phi_reg_18550.read();
    } else {
        ap_phi_mux_data_88_V_read363_rewind_phi_fu_7740_p6 = data_88_V_read363_rewind_reg_7736.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_89_V_read364_phi_phi_fu_18566_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_89_V_read364_phi_phi_fu_18566_p4 = ap_phi_mux_data_89_V_read364_rewind_phi_fu_7754_p6.read();
    } else {
        ap_phi_mux_data_89_V_read364_phi_phi_fu_18566_p4 = ap_phi_reg_pp0_iter1_data_89_V_read364_phi_reg_18562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_89_V_read364_rewind_phi_fu_7754_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_89_V_read364_rewind_phi_fu_7754_p6 = data_89_V_read364_phi_reg_18562.read();
    } else {
        ap_phi_mux_data_89_V_read364_rewind_phi_fu_7754_p6 = data_89_V_read364_rewind_reg_7750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_8_V_read283_phi_phi_fu_17594_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_8_V_read283_phi_phi_fu_17594_p4 = ap_phi_mux_data_8_V_read283_rewind_phi_fu_6620_p6.read();
    } else {
        ap_phi_mux_data_8_V_read283_phi_phi_fu_17594_p4 = ap_phi_reg_pp0_iter1_data_8_V_read283_phi_reg_17590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_8_V_read283_rewind_phi_fu_6620_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_8_V_read283_rewind_phi_fu_6620_p6 = data_8_V_read283_phi_reg_17590.read();
    } else {
        ap_phi_mux_data_8_V_read283_rewind_phi_fu_6620_p6 = data_8_V_read283_rewind_reg_6616.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_90_V_read365_phi_phi_fu_18578_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_90_V_read365_phi_phi_fu_18578_p4 = ap_phi_mux_data_90_V_read365_rewind_phi_fu_7768_p6.read();
    } else {
        ap_phi_mux_data_90_V_read365_phi_phi_fu_18578_p4 = ap_phi_reg_pp0_iter1_data_90_V_read365_phi_reg_18574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_90_V_read365_rewind_phi_fu_7768_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_90_V_read365_rewind_phi_fu_7768_p6 = data_90_V_read365_phi_reg_18574.read();
    } else {
        ap_phi_mux_data_90_V_read365_rewind_phi_fu_7768_p6 = data_90_V_read365_rewind_reg_7764.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_91_V_read366_phi_phi_fu_18590_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_91_V_read366_phi_phi_fu_18590_p4 = ap_phi_mux_data_91_V_read366_rewind_phi_fu_7782_p6.read();
    } else {
        ap_phi_mux_data_91_V_read366_phi_phi_fu_18590_p4 = ap_phi_reg_pp0_iter1_data_91_V_read366_phi_reg_18586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_91_V_read366_rewind_phi_fu_7782_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_91_V_read366_rewind_phi_fu_7782_p6 = data_91_V_read366_phi_reg_18586.read();
    } else {
        ap_phi_mux_data_91_V_read366_rewind_phi_fu_7782_p6 = data_91_V_read366_rewind_reg_7778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_92_V_read367_phi_phi_fu_18602_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_92_V_read367_phi_phi_fu_18602_p4 = ap_phi_mux_data_92_V_read367_rewind_phi_fu_7796_p6.read();
    } else {
        ap_phi_mux_data_92_V_read367_phi_phi_fu_18602_p4 = ap_phi_reg_pp0_iter1_data_92_V_read367_phi_reg_18598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_92_V_read367_rewind_phi_fu_7796_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_92_V_read367_rewind_phi_fu_7796_p6 = data_92_V_read367_phi_reg_18598.read();
    } else {
        ap_phi_mux_data_92_V_read367_rewind_phi_fu_7796_p6 = data_92_V_read367_rewind_reg_7792.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_93_V_read368_phi_phi_fu_18614_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_93_V_read368_phi_phi_fu_18614_p4 = ap_phi_mux_data_93_V_read368_rewind_phi_fu_7810_p6.read();
    } else {
        ap_phi_mux_data_93_V_read368_phi_phi_fu_18614_p4 = ap_phi_reg_pp0_iter1_data_93_V_read368_phi_reg_18610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_93_V_read368_rewind_phi_fu_7810_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_93_V_read368_rewind_phi_fu_7810_p6 = data_93_V_read368_phi_reg_18610.read();
    } else {
        ap_phi_mux_data_93_V_read368_rewind_phi_fu_7810_p6 = data_93_V_read368_rewind_reg_7806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_94_V_read369_phi_phi_fu_18626_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_94_V_read369_phi_phi_fu_18626_p4 = ap_phi_mux_data_94_V_read369_rewind_phi_fu_7824_p6.read();
    } else {
        ap_phi_mux_data_94_V_read369_phi_phi_fu_18626_p4 = ap_phi_reg_pp0_iter1_data_94_V_read369_phi_reg_18622.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_94_V_read369_rewind_phi_fu_7824_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_94_V_read369_rewind_phi_fu_7824_p6 = data_94_V_read369_phi_reg_18622.read();
    } else {
        ap_phi_mux_data_94_V_read369_rewind_phi_fu_7824_p6 = data_94_V_read369_rewind_reg_7820.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_95_V_read370_phi_phi_fu_18638_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_95_V_read370_phi_phi_fu_18638_p4 = ap_phi_mux_data_95_V_read370_rewind_phi_fu_7838_p6.read();
    } else {
        ap_phi_mux_data_95_V_read370_phi_phi_fu_18638_p4 = ap_phi_reg_pp0_iter1_data_95_V_read370_phi_reg_18634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_95_V_read370_rewind_phi_fu_7838_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_95_V_read370_rewind_phi_fu_7838_p6 = data_95_V_read370_phi_reg_18634.read();
    } else {
        ap_phi_mux_data_95_V_read370_rewind_phi_fu_7838_p6 = data_95_V_read370_rewind_reg_7834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_96_V_read371_phi_phi_fu_18650_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_96_V_read371_phi_phi_fu_18650_p4 = ap_phi_mux_data_96_V_read371_rewind_phi_fu_7852_p6.read();
    } else {
        ap_phi_mux_data_96_V_read371_phi_phi_fu_18650_p4 = ap_phi_reg_pp0_iter1_data_96_V_read371_phi_reg_18646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_96_V_read371_rewind_phi_fu_7852_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_96_V_read371_rewind_phi_fu_7852_p6 = data_96_V_read371_phi_reg_18646.read();
    } else {
        ap_phi_mux_data_96_V_read371_rewind_phi_fu_7852_p6 = data_96_V_read371_rewind_reg_7848.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_97_V_read372_phi_phi_fu_18662_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_97_V_read372_phi_phi_fu_18662_p4 = ap_phi_mux_data_97_V_read372_rewind_phi_fu_7866_p6.read();
    } else {
        ap_phi_mux_data_97_V_read372_phi_phi_fu_18662_p4 = ap_phi_reg_pp0_iter1_data_97_V_read372_phi_reg_18658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_97_V_read372_rewind_phi_fu_7866_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_97_V_read372_rewind_phi_fu_7866_p6 = data_97_V_read372_phi_reg_18658.read();
    } else {
        ap_phi_mux_data_97_V_read372_rewind_phi_fu_7866_p6 = data_97_V_read372_rewind_reg_7862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_98_V_read373_phi_phi_fu_18674_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_98_V_read373_phi_phi_fu_18674_p4 = ap_phi_mux_data_98_V_read373_rewind_phi_fu_7880_p6.read();
    } else {
        ap_phi_mux_data_98_V_read373_phi_phi_fu_18674_p4 = ap_phi_reg_pp0_iter1_data_98_V_read373_phi_reg_18670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_98_V_read373_rewind_phi_fu_7880_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_98_V_read373_rewind_phi_fu_7880_p6 = data_98_V_read373_phi_reg_18670.read();
    } else {
        ap_phi_mux_data_98_V_read373_rewind_phi_fu_7880_p6 = data_98_V_read373_rewind_reg_7876.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_99_V_read374_phi_phi_fu_18686_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_99_V_read374_phi_phi_fu_18686_p4 = ap_phi_mux_data_99_V_read374_rewind_phi_fu_7894_p6.read();
    } else {
        ap_phi_mux_data_99_V_read374_phi_phi_fu_18686_p4 = ap_phi_reg_pp0_iter1_data_99_V_read374_phi_reg_18682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_99_V_read374_rewind_phi_fu_7894_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_99_V_read374_rewind_phi_fu_7894_p6 = data_99_V_read374_phi_reg_18682.read();
    } else {
        ap_phi_mux_data_99_V_read374_rewind_phi_fu_7894_p6 = data_99_V_read374_rewind_reg_7890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_9_V_read284_phi_phi_fu_17606_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_9_V_read284_phi_phi_fu_17606_p4 = ap_phi_mux_data_9_V_read284_rewind_phi_fu_6634_p6.read();
    } else {
        ap_phi_mux_data_9_V_read284_phi_phi_fu_17606_p4 = ap_phi_reg_pp0_iter1_data_9_V_read284_phi_reg_17602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_9_V_read284_rewind_phi_fu_6634_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_9_V_read284_rewind_phi_fu_6634_p6 = data_9_V_read284_phi_reg_17602.read();
    } else {
        ap_phi_mux_data_9_V_read284_rewind_phi_fu_6634_p6 = data_9_V_read284_rewind_reg_6630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_do_init_phi_fu_6478_p6() {
    if (esl_seteq<1,1,1>(ap_condition_6265.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln151_reg_44207.read())) {
            ap_phi_mux_do_init_phi_fu_6478_p6 = ap_const_lv1_1;
        } else if (esl_seteq<1,1,1>(icmp_ln151_reg_44207.read(), ap_const_lv1_0)) {
            ap_phi_mux_do_init_phi_fu_6478_p6 = ap_const_lv1_0;
        } else {
            ap_phi_mux_do_init_phi_fu_6478_p6 = do_init_reg_6474.read();
        }
    } else {
        ap_phi_mux_do_init_phi_fu_6478_p6 = do_init_reg_6474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_in_index_0_i_i273_phi_fu_17484_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()))) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln151_reg_44207_pp0_iter1_reg.read())) {
            ap_phi_mux_in_index_0_i_i273_phi_fu_17484_p6 = ap_const_lv32_0;
        } else if (esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0)) {
            ap_phi_mux_in_index_0_i_i273_phi_fu_17484_p6 = select_ln168_reg_44263.read();
        } else {
            ap_phi_mux_in_index_0_i_i273_phi_fu_17484_p6 = in_index_0_i_i273_reg_17480.read();
        }
    } else {
        ap_phi_mux_in_index_0_i_i273_phi_fu_17484_p6 = in_index_0_i_i273_reg_17480.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_w_index274_phi_fu_6494_p6() {
    if (esl_seteq<1,1,1>(ap_condition_6265.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln151_reg_44207.read())) {
            ap_phi_mux_w_index274_phi_fu_6494_p6 = ap_const_lv14_0;
        } else if (esl_seteq<1,1,1>(icmp_ln151_reg_44207.read(), ap_const_lv1_0)) {
            ap_phi_mux_w_index274_phi_fu_6494_p6 = w_index_reg_44202.read();
        } else {
            ap_phi_mux_w_index274_phi_fu_6494_p6 = w_index274_reg_6490.read();
        }
    } else {
        ap_phi_mux_w_index274_phi_fu_6494_p6 = w_index274_reg_6490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_0_V_read275_phi_reg_17494() {
    ap_phi_reg_pp0_iter0_data_0_V_read275_phi_reg_17494 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_100_V_read375_phi_reg_18694() {
    ap_phi_reg_pp0_iter0_data_100_V_read375_phi_reg_18694 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_101_V_read376_phi_reg_18706() {
    ap_phi_reg_pp0_iter0_data_101_V_read376_phi_reg_18706 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_102_V_read377_phi_reg_18718() {
    ap_phi_reg_pp0_iter0_data_102_V_read377_phi_reg_18718 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_103_V_read378_phi_reg_18730() {
    ap_phi_reg_pp0_iter0_data_103_V_read378_phi_reg_18730 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_104_V_read379_phi_reg_18742() {
    ap_phi_reg_pp0_iter0_data_104_V_read379_phi_reg_18742 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_105_V_read380_phi_reg_18754() {
    ap_phi_reg_pp0_iter0_data_105_V_read380_phi_reg_18754 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_106_V_read381_phi_reg_18766() {
    ap_phi_reg_pp0_iter0_data_106_V_read381_phi_reg_18766 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_107_V_read382_phi_reg_18778() {
    ap_phi_reg_pp0_iter0_data_107_V_read382_phi_reg_18778 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_108_V_read383_phi_reg_18790() {
    ap_phi_reg_pp0_iter0_data_108_V_read383_phi_reg_18790 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_109_V_read384_phi_reg_18802() {
    ap_phi_reg_pp0_iter0_data_109_V_read384_phi_reg_18802 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_10_V_read285_phi_reg_17614() {
    ap_phi_reg_pp0_iter0_data_10_V_read285_phi_reg_17614 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_110_V_read385_phi_reg_18814() {
    ap_phi_reg_pp0_iter0_data_110_V_read385_phi_reg_18814 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_111_V_read386_phi_reg_18826() {
    ap_phi_reg_pp0_iter0_data_111_V_read386_phi_reg_18826 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_112_V_read387_phi_reg_18838() {
    ap_phi_reg_pp0_iter0_data_112_V_read387_phi_reg_18838 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_113_V_read388_phi_reg_18850() {
    ap_phi_reg_pp0_iter0_data_113_V_read388_phi_reg_18850 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_114_V_read389_phi_reg_18862() {
    ap_phi_reg_pp0_iter0_data_114_V_read389_phi_reg_18862 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_115_V_read390_phi_reg_18874() {
    ap_phi_reg_pp0_iter0_data_115_V_read390_phi_reg_18874 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_116_V_read391_phi_reg_18886() {
    ap_phi_reg_pp0_iter0_data_116_V_read391_phi_reg_18886 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_117_V_read392_phi_reg_18898() {
    ap_phi_reg_pp0_iter0_data_117_V_read392_phi_reg_18898 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_118_V_read393_phi_reg_18910() {
    ap_phi_reg_pp0_iter0_data_118_V_read393_phi_reg_18910 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_119_V_read394_phi_reg_18922() {
    ap_phi_reg_pp0_iter0_data_119_V_read394_phi_reg_18922 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_11_V_read286_phi_reg_17626() {
    ap_phi_reg_pp0_iter0_data_11_V_read286_phi_reg_17626 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_120_V_read395_phi_reg_18934() {
    ap_phi_reg_pp0_iter0_data_120_V_read395_phi_reg_18934 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_121_V_read396_phi_reg_18946() {
    ap_phi_reg_pp0_iter0_data_121_V_read396_phi_reg_18946 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_122_V_read397_phi_reg_18958() {
    ap_phi_reg_pp0_iter0_data_122_V_read397_phi_reg_18958 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_123_V_read398_phi_reg_18970() {
    ap_phi_reg_pp0_iter0_data_123_V_read398_phi_reg_18970 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_124_V_read399_phi_reg_18982() {
    ap_phi_reg_pp0_iter0_data_124_V_read399_phi_reg_18982 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_125_V_read400_phi_reg_18994() {
    ap_phi_reg_pp0_iter0_data_125_V_read400_phi_reg_18994 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_126_V_read401_phi_reg_19006() {
    ap_phi_reg_pp0_iter0_data_126_V_read401_phi_reg_19006 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_127_V_read402_phi_reg_19018() {
    ap_phi_reg_pp0_iter0_data_127_V_read402_phi_reg_19018 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_128_V_read403_phi_reg_19030() {
    ap_phi_reg_pp0_iter0_data_128_V_read403_phi_reg_19030 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_129_V_read404_phi_reg_19042() {
    ap_phi_reg_pp0_iter0_data_129_V_read404_phi_reg_19042 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_12_V_read287_phi_reg_17638() {
    ap_phi_reg_pp0_iter0_data_12_V_read287_phi_reg_17638 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_130_V_read405_phi_reg_19054() {
    ap_phi_reg_pp0_iter0_data_130_V_read405_phi_reg_19054 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_131_V_read406_phi_reg_19066() {
    ap_phi_reg_pp0_iter0_data_131_V_read406_phi_reg_19066 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_132_V_read407_phi_reg_19078() {
    ap_phi_reg_pp0_iter0_data_132_V_read407_phi_reg_19078 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_133_V_read408_phi_reg_19090() {
    ap_phi_reg_pp0_iter0_data_133_V_read408_phi_reg_19090 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_134_V_read409_phi_reg_19102() {
    ap_phi_reg_pp0_iter0_data_134_V_read409_phi_reg_19102 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_135_V_read410_phi_reg_19114() {
    ap_phi_reg_pp0_iter0_data_135_V_read410_phi_reg_19114 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_136_V_read411_phi_reg_19126() {
    ap_phi_reg_pp0_iter0_data_136_V_read411_phi_reg_19126 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_137_V_read412_phi_reg_19138() {
    ap_phi_reg_pp0_iter0_data_137_V_read412_phi_reg_19138 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_138_V_read413_phi_reg_19150() {
    ap_phi_reg_pp0_iter0_data_138_V_read413_phi_reg_19150 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_139_V_read414_phi_reg_19162() {
    ap_phi_reg_pp0_iter0_data_139_V_read414_phi_reg_19162 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_13_V_read288_phi_reg_17650() {
    ap_phi_reg_pp0_iter0_data_13_V_read288_phi_reg_17650 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_140_V_read415_phi_reg_19174() {
    ap_phi_reg_pp0_iter0_data_140_V_read415_phi_reg_19174 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_141_V_read416_phi_reg_19186() {
    ap_phi_reg_pp0_iter0_data_141_V_read416_phi_reg_19186 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_142_V_read417_phi_reg_19198() {
    ap_phi_reg_pp0_iter0_data_142_V_read417_phi_reg_19198 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_143_V_read418_phi_reg_19210() {
    ap_phi_reg_pp0_iter0_data_143_V_read418_phi_reg_19210 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_144_V_read419_phi_reg_19222() {
    ap_phi_reg_pp0_iter0_data_144_V_read419_phi_reg_19222 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_145_V_read420_phi_reg_19234() {
    ap_phi_reg_pp0_iter0_data_145_V_read420_phi_reg_19234 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_146_V_read421_phi_reg_19246() {
    ap_phi_reg_pp0_iter0_data_146_V_read421_phi_reg_19246 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_147_V_read422_phi_reg_19258() {
    ap_phi_reg_pp0_iter0_data_147_V_read422_phi_reg_19258 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_148_V_read423_phi_reg_19270() {
    ap_phi_reg_pp0_iter0_data_148_V_read423_phi_reg_19270 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_149_V_read424_phi_reg_19282() {
    ap_phi_reg_pp0_iter0_data_149_V_read424_phi_reg_19282 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_14_V_read289_phi_reg_17662() {
    ap_phi_reg_pp0_iter0_data_14_V_read289_phi_reg_17662 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_150_V_read425_phi_reg_19294() {
    ap_phi_reg_pp0_iter0_data_150_V_read425_phi_reg_19294 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_151_V_read426_phi_reg_19306() {
    ap_phi_reg_pp0_iter0_data_151_V_read426_phi_reg_19306 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_152_V_read427_phi_reg_19318() {
    ap_phi_reg_pp0_iter0_data_152_V_read427_phi_reg_19318 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_153_V_read428_phi_reg_19330() {
    ap_phi_reg_pp0_iter0_data_153_V_read428_phi_reg_19330 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_154_V_read429_phi_reg_19342() {
    ap_phi_reg_pp0_iter0_data_154_V_read429_phi_reg_19342 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_155_V_read430_phi_reg_19354() {
    ap_phi_reg_pp0_iter0_data_155_V_read430_phi_reg_19354 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_156_V_read431_phi_reg_19366() {
    ap_phi_reg_pp0_iter0_data_156_V_read431_phi_reg_19366 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_157_V_read432_phi_reg_19378() {
    ap_phi_reg_pp0_iter0_data_157_V_read432_phi_reg_19378 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_158_V_read433_phi_reg_19390() {
    ap_phi_reg_pp0_iter0_data_158_V_read433_phi_reg_19390 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_159_V_read434_phi_reg_19402() {
    ap_phi_reg_pp0_iter0_data_159_V_read434_phi_reg_19402 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_15_V_read290_phi_reg_17674() {
    ap_phi_reg_pp0_iter0_data_15_V_read290_phi_reg_17674 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_160_V_read435_phi_reg_19414() {
    ap_phi_reg_pp0_iter0_data_160_V_read435_phi_reg_19414 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_161_V_read436_phi_reg_19426() {
    ap_phi_reg_pp0_iter0_data_161_V_read436_phi_reg_19426 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_162_V_read437_phi_reg_19438() {
    ap_phi_reg_pp0_iter0_data_162_V_read437_phi_reg_19438 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_163_V_read438_phi_reg_19450() {
    ap_phi_reg_pp0_iter0_data_163_V_read438_phi_reg_19450 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_164_V_read439_phi_reg_19462() {
    ap_phi_reg_pp0_iter0_data_164_V_read439_phi_reg_19462 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_165_V_read440_phi_reg_19474() {
    ap_phi_reg_pp0_iter0_data_165_V_read440_phi_reg_19474 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_166_V_read441_phi_reg_19486() {
    ap_phi_reg_pp0_iter0_data_166_V_read441_phi_reg_19486 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_167_V_read442_phi_reg_19498() {
    ap_phi_reg_pp0_iter0_data_167_V_read442_phi_reg_19498 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_168_V_read443_phi_reg_19510() {
    ap_phi_reg_pp0_iter0_data_168_V_read443_phi_reg_19510 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_169_V_read444_phi_reg_19522() {
    ap_phi_reg_pp0_iter0_data_169_V_read444_phi_reg_19522 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_16_V_read291_phi_reg_17686() {
    ap_phi_reg_pp0_iter0_data_16_V_read291_phi_reg_17686 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_170_V_read445_phi_reg_19534() {
    ap_phi_reg_pp0_iter0_data_170_V_read445_phi_reg_19534 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_171_V_read446_phi_reg_19546() {
    ap_phi_reg_pp0_iter0_data_171_V_read446_phi_reg_19546 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_172_V_read447_phi_reg_19558() {
    ap_phi_reg_pp0_iter0_data_172_V_read447_phi_reg_19558 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_173_V_read448_phi_reg_19570() {
    ap_phi_reg_pp0_iter0_data_173_V_read448_phi_reg_19570 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_174_V_read449_phi_reg_19582() {
    ap_phi_reg_pp0_iter0_data_174_V_read449_phi_reg_19582 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_175_V_read450_phi_reg_19594() {
    ap_phi_reg_pp0_iter0_data_175_V_read450_phi_reg_19594 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_176_V_read451_phi_reg_19606() {
    ap_phi_reg_pp0_iter0_data_176_V_read451_phi_reg_19606 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_177_V_read452_phi_reg_19618() {
    ap_phi_reg_pp0_iter0_data_177_V_read452_phi_reg_19618 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_178_V_read453_phi_reg_19630() {
    ap_phi_reg_pp0_iter0_data_178_V_read453_phi_reg_19630 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_179_V_read454_phi_reg_19642() {
    ap_phi_reg_pp0_iter0_data_179_V_read454_phi_reg_19642 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_17_V_read292_phi_reg_17698() {
    ap_phi_reg_pp0_iter0_data_17_V_read292_phi_reg_17698 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_180_V_read455_phi_reg_19654() {
    ap_phi_reg_pp0_iter0_data_180_V_read455_phi_reg_19654 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_181_V_read456_phi_reg_19666() {
    ap_phi_reg_pp0_iter0_data_181_V_read456_phi_reg_19666 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_182_V_read457_phi_reg_19678() {
    ap_phi_reg_pp0_iter0_data_182_V_read457_phi_reg_19678 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_183_V_read458_phi_reg_19690() {
    ap_phi_reg_pp0_iter0_data_183_V_read458_phi_reg_19690 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_184_V_read459_phi_reg_19702() {
    ap_phi_reg_pp0_iter0_data_184_V_read459_phi_reg_19702 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_185_V_read460_phi_reg_19714() {
    ap_phi_reg_pp0_iter0_data_185_V_read460_phi_reg_19714 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_186_V_read461_phi_reg_19726() {
    ap_phi_reg_pp0_iter0_data_186_V_read461_phi_reg_19726 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_187_V_read462_phi_reg_19738() {
    ap_phi_reg_pp0_iter0_data_187_V_read462_phi_reg_19738 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_188_V_read463_phi_reg_19750() {
    ap_phi_reg_pp0_iter0_data_188_V_read463_phi_reg_19750 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_189_V_read464_phi_reg_19762() {
    ap_phi_reg_pp0_iter0_data_189_V_read464_phi_reg_19762 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_18_V_read293_phi_reg_17710() {
    ap_phi_reg_pp0_iter0_data_18_V_read293_phi_reg_17710 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_190_V_read465_phi_reg_19774() {
    ap_phi_reg_pp0_iter0_data_190_V_read465_phi_reg_19774 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_191_V_read466_phi_reg_19786() {
    ap_phi_reg_pp0_iter0_data_191_V_read466_phi_reg_19786 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_192_V_read467_phi_reg_19798() {
    ap_phi_reg_pp0_iter0_data_192_V_read467_phi_reg_19798 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_193_V_read468_phi_reg_19810() {
    ap_phi_reg_pp0_iter0_data_193_V_read468_phi_reg_19810 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_194_V_read469_phi_reg_19822() {
    ap_phi_reg_pp0_iter0_data_194_V_read469_phi_reg_19822 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_195_V_read470_phi_reg_19834() {
    ap_phi_reg_pp0_iter0_data_195_V_read470_phi_reg_19834 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_196_V_read471_phi_reg_19846() {
    ap_phi_reg_pp0_iter0_data_196_V_read471_phi_reg_19846 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_197_V_read472_phi_reg_19858() {
    ap_phi_reg_pp0_iter0_data_197_V_read472_phi_reg_19858 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_198_V_read473_phi_reg_19870() {
    ap_phi_reg_pp0_iter0_data_198_V_read473_phi_reg_19870 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_199_V_read474_phi_reg_19882() {
    ap_phi_reg_pp0_iter0_data_199_V_read474_phi_reg_19882 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_19_V_read294_phi_reg_17722() {
    ap_phi_reg_pp0_iter0_data_19_V_read294_phi_reg_17722 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_1_V_read276_phi_reg_17506() {
    ap_phi_reg_pp0_iter0_data_1_V_read276_phi_reg_17506 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_200_V_read475_phi_reg_19894() {
    ap_phi_reg_pp0_iter0_data_200_V_read475_phi_reg_19894 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_201_V_read476_phi_reg_19906() {
    ap_phi_reg_pp0_iter0_data_201_V_read476_phi_reg_19906 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_202_V_read477_phi_reg_19918() {
    ap_phi_reg_pp0_iter0_data_202_V_read477_phi_reg_19918 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_203_V_read478_phi_reg_19930() {
    ap_phi_reg_pp0_iter0_data_203_V_read478_phi_reg_19930 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_204_V_read479_phi_reg_19942() {
    ap_phi_reg_pp0_iter0_data_204_V_read479_phi_reg_19942 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_205_V_read480_phi_reg_19954() {
    ap_phi_reg_pp0_iter0_data_205_V_read480_phi_reg_19954 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_206_V_read481_phi_reg_19966() {
    ap_phi_reg_pp0_iter0_data_206_V_read481_phi_reg_19966 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_207_V_read482_phi_reg_19978() {
    ap_phi_reg_pp0_iter0_data_207_V_read482_phi_reg_19978 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_208_V_read483_phi_reg_19990() {
    ap_phi_reg_pp0_iter0_data_208_V_read483_phi_reg_19990 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_209_V_read484_phi_reg_20002() {
    ap_phi_reg_pp0_iter0_data_209_V_read484_phi_reg_20002 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_20_V_read295_phi_reg_17734() {
    ap_phi_reg_pp0_iter0_data_20_V_read295_phi_reg_17734 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_210_V_read485_phi_reg_20014() {
    ap_phi_reg_pp0_iter0_data_210_V_read485_phi_reg_20014 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_211_V_read486_phi_reg_20026() {
    ap_phi_reg_pp0_iter0_data_211_V_read486_phi_reg_20026 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_212_V_read487_phi_reg_20038() {
    ap_phi_reg_pp0_iter0_data_212_V_read487_phi_reg_20038 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_213_V_read488_phi_reg_20050() {
    ap_phi_reg_pp0_iter0_data_213_V_read488_phi_reg_20050 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_214_V_read489_phi_reg_20062() {
    ap_phi_reg_pp0_iter0_data_214_V_read489_phi_reg_20062 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_215_V_read490_phi_reg_20074() {
    ap_phi_reg_pp0_iter0_data_215_V_read490_phi_reg_20074 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_216_V_read491_phi_reg_20086() {
    ap_phi_reg_pp0_iter0_data_216_V_read491_phi_reg_20086 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_217_V_read492_phi_reg_20098() {
    ap_phi_reg_pp0_iter0_data_217_V_read492_phi_reg_20098 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_218_V_read493_phi_reg_20110() {
    ap_phi_reg_pp0_iter0_data_218_V_read493_phi_reg_20110 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_219_V_read494_phi_reg_20122() {
    ap_phi_reg_pp0_iter0_data_219_V_read494_phi_reg_20122 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_21_V_read296_phi_reg_17746() {
    ap_phi_reg_pp0_iter0_data_21_V_read296_phi_reg_17746 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_220_V_read495_phi_reg_20134() {
    ap_phi_reg_pp0_iter0_data_220_V_read495_phi_reg_20134 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_221_V_read496_phi_reg_20146() {
    ap_phi_reg_pp0_iter0_data_221_V_read496_phi_reg_20146 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_222_V_read497_phi_reg_20158() {
    ap_phi_reg_pp0_iter0_data_222_V_read497_phi_reg_20158 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_223_V_read498_phi_reg_20170() {
    ap_phi_reg_pp0_iter0_data_223_V_read498_phi_reg_20170 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_224_V_read499_phi_reg_20182() {
    ap_phi_reg_pp0_iter0_data_224_V_read499_phi_reg_20182 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_225_V_read500_phi_reg_20194() {
    ap_phi_reg_pp0_iter0_data_225_V_read500_phi_reg_20194 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_226_V_read501_phi_reg_20206() {
    ap_phi_reg_pp0_iter0_data_226_V_read501_phi_reg_20206 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_227_V_read502_phi_reg_20218() {
    ap_phi_reg_pp0_iter0_data_227_V_read502_phi_reg_20218 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_228_V_read503_phi_reg_20230() {
    ap_phi_reg_pp0_iter0_data_228_V_read503_phi_reg_20230 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_229_V_read504_phi_reg_20242() {
    ap_phi_reg_pp0_iter0_data_229_V_read504_phi_reg_20242 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_22_V_read297_phi_reg_17758() {
    ap_phi_reg_pp0_iter0_data_22_V_read297_phi_reg_17758 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_230_V_read505_phi_reg_20254() {
    ap_phi_reg_pp0_iter0_data_230_V_read505_phi_reg_20254 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_231_V_read506_phi_reg_20266() {
    ap_phi_reg_pp0_iter0_data_231_V_read506_phi_reg_20266 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_232_V_read507_phi_reg_20278() {
    ap_phi_reg_pp0_iter0_data_232_V_read507_phi_reg_20278 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_233_V_read508_phi_reg_20290() {
    ap_phi_reg_pp0_iter0_data_233_V_read508_phi_reg_20290 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_234_V_read509_phi_reg_20302() {
    ap_phi_reg_pp0_iter0_data_234_V_read509_phi_reg_20302 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_235_V_read510_phi_reg_20314() {
    ap_phi_reg_pp0_iter0_data_235_V_read510_phi_reg_20314 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_236_V_read511_phi_reg_20326() {
    ap_phi_reg_pp0_iter0_data_236_V_read511_phi_reg_20326 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_237_V_read512_phi_reg_20338() {
    ap_phi_reg_pp0_iter0_data_237_V_read512_phi_reg_20338 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_238_V_read513_phi_reg_20350() {
    ap_phi_reg_pp0_iter0_data_238_V_read513_phi_reg_20350 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_239_V_read514_phi_reg_20362() {
    ap_phi_reg_pp0_iter0_data_239_V_read514_phi_reg_20362 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_23_V_read298_phi_reg_17770() {
    ap_phi_reg_pp0_iter0_data_23_V_read298_phi_reg_17770 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_240_V_read515_phi_reg_20374() {
    ap_phi_reg_pp0_iter0_data_240_V_read515_phi_reg_20374 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_241_V_read516_phi_reg_20386() {
    ap_phi_reg_pp0_iter0_data_241_V_read516_phi_reg_20386 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_242_V_read517_phi_reg_20398() {
    ap_phi_reg_pp0_iter0_data_242_V_read517_phi_reg_20398 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_243_V_read518_phi_reg_20410() {
    ap_phi_reg_pp0_iter0_data_243_V_read518_phi_reg_20410 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_244_V_read519_phi_reg_20422() {
    ap_phi_reg_pp0_iter0_data_244_V_read519_phi_reg_20422 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_245_V_read520_phi_reg_20434() {
    ap_phi_reg_pp0_iter0_data_245_V_read520_phi_reg_20434 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_246_V_read521_phi_reg_20446() {
    ap_phi_reg_pp0_iter0_data_246_V_read521_phi_reg_20446 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_247_V_read522_phi_reg_20458() {
    ap_phi_reg_pp0_iter0_data_247_V_read522_phi_reg_20458 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_248_V_read523_phi_reg_20470() {
    ap_phi_reg_pp0_iter0_data_248_V_read523_phi_reg_20470 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_249_V_read524_phi_reg_20482() {
    ap_phi_reg_pp0_iter0_data_249_V_read524_phi_reg_20482 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_24_V_read299_phi_reg_17782() {
    ap_phi_reg_pp0_iter0_data_24_V_read299_phi_reg_17782 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_250_V_read525_phi_reg_20494() {
    ap_phi_reg_pp0_iter0_data_250_V_read525_phi_reg_20494 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_251_V_read526_phi_reg_20506() {
    ap_phi_reg_pp0_iter0_data_251_V_read526_phi_reg_20506 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_252_V_read527_phi_reg_20518() {
    ap_phi_reg_pp0_iter0_data_252_V_read527_phi_reg_20518 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_253_V_read528_phi_reg_20530() {
    ap_phi_reg_pp0_iter0_data_253_V_read528_phi_reg_20530 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_254_V_read529_phi_reg_20542() {
    ap_phi_reg_pp0_iter0_data_254_V_read529_phi_reg_20542 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_255_V_read530_phi_reg_20554() {
    ap_phi_reg_pp0_iter0_data_255_V_read530_phi_reg_20554 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_256_V_read531_phi_reg_20566() {
    ap_phi_reg_pp0_iter0_data_256_V_read531_phi_reg_20566 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_257_V_read532_phi_reg_20578() {
    ap_phi_reg_pp0_iter0_data_257_V_read532_phi_reg_20578 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_258_V_read533_phi_reg_20590() {
    ap_phi_reg_pp0_iter0_data_258_V_read533_phi_reg_20590 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_259_V_read534_phi_reg_20602() {
    ap_phi_reg_pp0_iter0_data_259_V_read534_phi_reg_20602 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_25_V_read300_phi_reg_17794() {
    ap_phi_reg_pp0_iter0_data_25_V_read300_phi_reg_17794 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_260_V_read535_phi_reg_20614() {
    ap_phi_reg_pp0_iter0_data_260_V_read535_phi_reg_20614 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_261_V_read536_phi_reg_20626() {
    ap_phi_reg_pp0_iter0_data_261_V_read536_phi_reg_20626 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_262_V_read537_phi_reg_20638() {
    ap_phi_reg_pp0_iter0_data_262_V_read537_phi_reg_20638 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_263_V_read538_phi_reg_20650() {
    ap_phi_reg_pp0_iter0_data_263_V_read538_phi_reg_20650 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_264_V_read539_phi_reg_20662() {
    ap_phi_reg_pp0_iter0_data_264_V_read539_phi_reg_20662 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_265_V_read540_phi_reg_20674() {
    ap_phi_reg_pp0_iter0_data_265_V_read540_phi_reg_20674 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_266_V_read541_phi_reg_20686() {
    ap_phi_reg_pp0_iter0_data_266_V_read541_phi_reg_20686 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_267_V_read542_phi_reg_20698() {
    ap_phi_reg_pp0_iter0_data_267_V_read542_phi_reg_20698 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_268_V_read543_phi_reg_20710() {
    ap_phi_reg_pp0_iter0_data_268_V_read543_phi_reg_20710 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_269_V_read544_phi_reg_20722() {
    ap_phi_reg_pp0_iter0_data_269_V_read544_phi_reg_20722 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_26_V_read301_phi_reg_17806() {
    ap_phi_reg_pp0_iter0_data_26_V_read301_phi_reg_17806 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_270_V_read545_phi_reg_20734() {
    ap_phi_reg_pp0_iter0_data_270_V_read545_phi_reg_20734 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_271_V_read546_phi_reg_20746() {
    ap_phi_reg_pp0_iter0_data_271_V_read546_phi_reg_20746 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_272_V_read547_phi_reg_20758() {
    ap_phi_reg_pp0_iter0_data_272_V_read547_phi_reg_20758 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_273_V_read548_phi_reg_20770() {
    ap_phi_reg_pp0_iter0_data_273_V_read548_phi_reg_20770 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_274_V_read549_phi_reg_20782() {
    ap_phi_reg_pp0_iter0_data_274_V_read549_phi_reg_20782 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_275_V_read550_phi_reg_20794() {
    ap_phi_reg_pp0_iter0_data_275_V_read550_phi_reg_20794 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_276_V_read551_phi_reg_20806() {
    ap_phi_reg_pp0_iter0_data_276_V_read551_phi_reg_20806 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_277_V_read552_phi_reg_20818() {
    ap_phi_reg_pp0_iter0_data_277_V_read552_phi_reg_20818 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_278_V_read553_phi_reg_20830() {
    ap_phi_reg_pp0_iter0_data_278_V_read553_phi_reg_20830 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_279_V_read554_phi_reg_20842() {
    ap_phi_reg_pp0_iter0_data_279_V_read554_phi_reg_20842 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_27_V_read302_phi_reg_17818() {
    ap_phi_reg_pp0_iter0_data_27_V_read302_phi_reg_17818 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_280_V_read555_phi_reg_20854() {
    ap_phi_reg_pp0_iter0_data_280_V_read555_phi_reg_20854 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_281_V_read556_phi_reg_20866() {
    ap_phi_reg_pp0_iter0_data_281_V_read556_phi_reg_20866 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_282_V_read557_phi_reg_20878() {
    ap_phi_reg_pp0_iter0_data_282_V_read557_phi_reg_20878 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_283_V_read558_phi_reg_20890() {
    ap_phi_reg_pp0_iter0_data_283_V_read558_phi_reg_20890 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_284_V_read559_phi_reg_20902() {
    ap_phi_reg_pp0_iter0_data_284_V_read559_phi_reg_20902 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_285_V_read560_phi_reg_20914() {
    ap_phi_reg_pp0_iter0_data_285_V_read560_phi_reg_20914 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_286_V_read561_phi_reg_20926() {
    ap_phi_reg_pp0_iter0_data_286_V_read561_phi_reg_20926 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_287_V_read562_phi_reg_20938() {
    ap_phi_reg_pp0_iter0_data_287_V_read562_phi_reg_20938 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_288_V_read563_phi_reg_20950() {
    ap_phi_reg_pp0_iter0_data_288_V_read563_phi_reg_20950 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_289_V_read564_phi_reg_20962() {
    ap_phi_reg_pp0_iter0_data_289_V_read564_phi_reg_20962 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_28_V_read303_phi_reg_17830() {
    ap_phi_reg_pp0_iter0_data_28_V_read303_phi_reg_17830 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_290_V_read565_phi_reg_20974() {
    ap_phi_reg_pp0_iter0_data_290_V_read565_phi_reg_20974 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_291_V_read566_phi_reg_20986() {
    ap_phi_reg_pp0_iter0_data_291_V_read566_phi_reg_20986 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_292_V_read567_phi_reg_20998() {
    ap_phi_reg_pp0_iter0_data_292_V_read567_phi_reg_20998 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_293_V_read568_phi_reg_21010() {
    ap_phi_reg_pp0_iter0_data_293_V_read568_phi_reg_21010 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_294_V_read569_phi_reg_21022() {
    ap_phi_reg_pp0_iter0_data_294_V_read569_phi_reg_21022 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_295_V_read570_phi_reg_21034() {
    ap_phi_reg_pp0_iter0_data_295_V_read570_phi_reg_21034 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_296_V_read571_phi_reg_21046() {
    ap_phi_reg_pp0_iter0_data_296_V_read571_phi_reg_21046 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_297_V_read572_phi_reg_21058() {
    ap_phi_reg_pp0_iter0_data_297_V_read572_phi_reg_21058 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_298_V_read573_phi_reg_21070() {
    ap_phi_reg_pp0_iter0_data_298_V_read573_phi_reg_21070 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_299_V_read574_phi_reg_21082() {
    ap_phi_reg_pp0_iter0_data_299_V_read574_phi_reg_21082 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_29_V_read304_phi_reg_17842() {
    ap_phi_reg_pp0_iter0_data_29_V_read304_phi_reg_17842 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_2_V_read277_phi_reg_17518() {
    ap_phi_reg_pp0_iter0_data_2_V_read277_phi_reg_17518 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_300_V_read575_phi_reg_21094() {
    ap_phi_reg_pp0_iter0_data_300_V_read575_phi_reg_21094 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_301_V_read576_phi_reg_21106() {
    ap_phi_reg_pp0_iter0_data_301_V_read576_phi_reg_21106 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_302_V_read577_phi_reg_21118() {
    ap_phi_reg_pp0_iter0_data_302_V_read577_phi_reg_21118 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_303_V_read578_phi_reg_21130() {
    ap_phi_reg_pp0_iter0_data_303_V_read578_phi_reg_21130 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_304_V_read579_phi_reg_21142() {
    ap_phi_reg_pp0_iter0_data_304_V_read579_phi_reg_21142 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_305_V_read580_phi_reg_21154() {
    ap_phi_reg_pp0_iter0_data_305_V_read580_phi_reg_21154 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_306_V_read581_phi_reg_21166() {
    ap_phi_reg_pp0_iter0_data_306_V_read581_phi_reg_21166 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_307_V_read582_phi_reg_21178() {
    ap_phi_reg_pp0_iter0_data_307_V_read582_phi_reg_21178 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_308_V_read583_phi_reg_21190() {
    ap_phi_reg_pp0_iter0_data_308_V_read583_phi_reg_21190 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_309_V_read584_phi_reg_21202() {
    ap_phi_reg_pp0_iter0_data_309_V_read584_phi_reg_21202 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_30_V_read305_phi_reg_17854() {
    ap_phi_reg_pp0_iter0_data_30_V_read305_phi_reg_17854 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_310_V_read585_phi_reg_21214() {
    ap_phi_reg_pp0_iter0_data_310_V_read585_phi_reg_21214 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_311_V_read586_phi_reg_21226() {
    ap_phi_reg_pp0_iter0_data_311_V_read586_phi_reg_21226 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_312_V_read587_phi_reg_21238() {
    ap_phi_reg_pp0_iter0_data_312_V_read587_phi_reg_21238 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_313_V_read588_phi_reg_21250() {
    ap_phi_reg_pp0_iter0_data_313_V_read588_phi_reg_21250 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_314_V_read589_phi_reg_21262() {
    ap_phi_reg_pp0_iter0_data_314_V_read589_phi_reg_21262 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_315_V_read590_phi_reg_21274() {
    ap_phi_reg_pp0_iter0_data_315_V_read590_phi_reg_21274 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_316_V_read591_phi_reg_21286() {
    ap_phi_reg_pp0_iter0_data_316_V_read591_phi_reg_21286 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_317_V_read592_phi_reg_21298() {
    ap_phi_reg_pp0_iter0_data_317_V_read592_phi_reg_21298 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_318_V_read593_phi_reg_21310() {
    ap_phi_reg_pp0_iter0_data_318_V_read593_phi_reg_21310 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_319_V_read594_phi_reg_21322() {
    ap_phi_reg_pp0_iter0_data_319_V_read594_phi_reg_21322 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_31_V_read306_phi_reg_17866() {
    ap_phi_reg_pp0_iter0_data_31_V_read306_phi_reg_17866 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_320_V_read595_phi_reg_21334() {
    ap_phi_reg_pp0_iter0_data_320_V_read595_phi_reg_21334 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_321_V_read596_phi_reg_21346() {
    ap_phi_reg_pp0_iter0_data_321_V_read596_phi_reg_21346 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_322_V_read597_phi_reg_21358() {
    ap_phi_reg_pp0_iter0_data_322_V_read597_phi_reg_21358 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_323_V_read598_phi_reg_21370() {
    ap_phi_reg_pp0_iter0_data_323_V_read598_phi_reg_21370 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_324_V_read599_phi_reg_21382() {
    ap_phi_reg_pp0_iter0_data_324_V_read599_phi_reg_21382 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_325_V_read600_phi_reg_21394() {
    ap_phi_reg_pp0_iter0_data_325_V_read600_phi_reg_21394 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_326_V_read601_phi_reg_21406() {
    ap_phi_reg_pp0_iter0_data_326_V_read601_phi_reg_21406 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_327_V_read602_phi_reg_21418() {
    ap_phi_reg_pp0_iter0_data_327_V_read602_phi_reg_21418 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_328_V_read603_phi_reg_21430() {
    ap_phi_reg_pp0_iter0_data_328_V_read603_phi_reg_21430 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_329_V_read604_phi_reg_21442() {
    ap_phi_reg_pp0_iter0_data_329_V_read604_phi_reg_21442 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_32_V_read307_phi_reg_17878() {
    ap_phi_reg_pp0_iter0_data_32_V_read307_phi_reg_17878 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_330_V_read605_phi_reg_21454() {
    ap_phi_reg_pp0_iter0_data_330_V_read605_phi_reg_21454 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_331_V_read606_phi_reg_21466() {
    ap_phi_reg_pp0_iter0_data_331_V_read606_phi_reg_21466 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_332_V_read607_phi_reg_21478() {
    ap_phi_reg_pp0_iter0_data_332_V_read607_phi_reg_21478 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_333_V_read608_phi_reg_21490() {
    ap_phi_reg_pp0_iter0_data_333_V_read608_phi_reg_21490 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_334_V_read609_phi_reg_21502() {
    ap_phi_reg_pp0_iter0_data_334_V_read609_phi_reg_21502 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_335_V_read610_phi_reg_21514() {
    ap_phi_reg_pp0_iter0_data_335_V_read610_phi_reg_21514 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_336_V_read611_phi_reg_21526() {
    ap_phi_reg_pp0_iter0_data_336_V_read611_phi_reg_21526 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_337_V_read612_phi_reg_21538() {
    ap_phi_reg_pp0_iter0_data_337_V_read612_phi_reg_21538 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_338_V_read613_phi_reg_21550() {
    ap_phi_reg_pp0_iter0_data_338_V_read613_phi_reg_21550 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_339_V_read614_phi_reg_21562() {
    ap_phi_reg_pp0_iter0_data_339_V_read614_phi_reg_21562 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_33_V_read308_phi_reg_17890() {
    ap_phi_reg_pp0_iter0_data_33_V_read308_phi_reg_17890 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_340_V_read615_phi_reg_21574() {
    ap_phi_reg_pp0_iter0_data_340_V_read615_phi_reg_21574 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_341_V_read616_phi_reg_21586() {
    ap_phi_reg_pp0_iter0_data_341_V_read616_phi_reg_21586 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_342_V_read617_phi_reg_21598() {
    ap_phi_reg_pp0_iter0_data_342_V_read617_phi_reg_21598 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_343_V_read618_phi_reg_21610() {
    ap_phi_reg_pp0_iter0_data_343_V_read618_phi_reg_21610 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_344_V_read619_phi_reg_21622() {
    ap_phi_reg_pp0_iter0_data_344_V_read619_phi_reg_21622 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_345_V_read620_phi_reg_21634() {
    ap_phi_reg_pp0_iter0_data_345_V_read620_phi_reg_21634 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_346_V_read621_phi_reg_21646() {
    ap_phi_reg_pp0_iter0_data_346_V_read621_phi_reg_21646 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_reg_pp0_iter0_data_347_V_read622_phi_reg_21658() {
    ap_phi_reg_pp0_iter0_data_347_V_read622_phi_reg_21658 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

}

