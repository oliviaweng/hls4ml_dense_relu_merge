// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_H__
#define __dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 4;
  static const unsigned AddressRange = 12544;
  static const unsigned AddressWidth = 14;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_ram) {
        for (unsigned i = 0; i < 784 ; i = i + 1) {
            ram[i] = "0b0000";
        }
        for (unsigned i = 784; i < 1568 ; i = i + 1) {
            ram[i] = "0b0001";
        }
        for (unsigned i = 1568; i < 2352 ; i = i + 1) {
            ram[i] = "0b0010";
        }
        for (unsigned i = 2352; i < 3136 ; i = i + 1) {
            ram[i] = "0b0011";
        }
        for (unsigned i = 3136; i < 3920 ; i = i + 1) {
            ram[i] = "0b0100";
        }
        for (unsigned i = 3920; i < 4704 ; i = i + 1) {
            ram[i] = "0b0101";
        }
        for (unsigned i = 4704; i < 5488 ; i = i + 1) {
            ram[i] = "0b0110";
        }
        for (unsigned i = 5488; i < 6272 ; i = i + 1) {
            ram[i] = "0b0111";
        }
        for (unsigned i = 6272; i < 7056 ; i = i + 1) {
            ram[i] = "0b1000";
        }
        for (unsigned i = 7056; i < 7840 ; i = i + 1) {
            ram[i] = "0b1001";
        }
        for (unsigned i = 7840; i < 8624 ; i = i + 1) {
            ram[i] = "0b1010";
        }
        for (unsigned i = 8624; i < 9408 ; i = i + 1) {
            ram[i] = "0b1011";
        }
        for (unsigned i = 9408; i < 10192 ; i = i + 1) {
            ram[i] = "0b1100";
        }
        for (unsigned i = 10192; i < 10976 ; i = i + 1) {
            ram[i] = "0b1101";
        }
        for (unsigned i = 10976; i < 11760 ; i = i + 1) {
            ram[i] = "0b1110";
        }
        for (unsigned i = 11760; i < 12544 ; i = i + 1) {
            ram[i] = "0b1111";
        }


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb) {


static const unsigned DataWidth = 4;
static const unsigned AddressRange = 12544;
static const unsigned AddressWidth = 14;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_ram* meminst;


SC_CTOR(dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb) {
meminst = new dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_ram("dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_outibkb() {
    delete meminst;
}


};//endmodule
#endif
