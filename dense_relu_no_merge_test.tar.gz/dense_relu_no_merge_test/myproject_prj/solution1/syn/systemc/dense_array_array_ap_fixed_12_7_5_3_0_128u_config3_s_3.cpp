#include "dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[1];
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_CS_fsm_state4() {
    ap_CS_fsm_state4 = ap_CS_fsm.read()[2];
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_CS_fsm_state5() {
    ap_CS_fsm_state5 = ap_CS_fsm.read()[3];
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_CS_fsm_state6() {
    ap_CS_fsm_state6 = ap_CS_fsm.read()[4];
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1049.read()));
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1049.read()));
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_block_state1() {
    ap_block_state1 = (esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1));
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_block_state2_pp0_stage0_iter0() {
    ap_block_state2_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_block_state3_pp0_stage0_iter1() {
    ap_block_state3_pp0_stage0_iter1 = esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1049.read());
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_condition_pp0_exit_iter0_state2() {
    if (esl_seteq<1,1,1>(icmp_ln41_fu_4973_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_1;
    } else {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_done() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_done_reg.read();
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_ap_ready() {
    ap_ready = internal_ap_ready.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_0_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_0_V_blk_n = data_stream_V_data_0_V_empty_n.read();
    } else {
        data_stream_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_0_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_0_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_0_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_10_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_10_V_blk_n = data_stream_V_data_10_V_empty_n.read();
    } else {
        data_stream_V_data_10_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_10_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_10_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_10_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_11_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_11_V_blk_n = data_stream_V_data_11_V_empty_n.read();
    } else {
        data_stream_V_data_11_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_11_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_11_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_11_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_12_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_12_V_blk_n = data_stream_V_data_12_V_empty_n.read();
    } else {
        data_stream_V_data_12_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_12_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_12_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_12_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_13_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_13_V_blk_n = data_stream_V_data_13_V_empty_n.read();
    } else {
        data_stream_V_data_13_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_13_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_13_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_13_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_14_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_14_V_blk_n = data_stream_V_data_14_V_empty_n.read();
    } else {
        data_stream_V_data_14_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_14_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_14_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_14_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_15_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_15_V_blk_n = data_stream_V_data_15_V_empty_n.read();
    } else {
        data_stream_V_data_15_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_15_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_15_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_15_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_16_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_16_V_blk_n = data_stream_V_data_16_V_empty_n.read();
    } else {
        data_stream_V_data_16_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_16_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_16_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_16_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_17_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_17_V_blk_n = data_stream_V_data_17_V_empty_n.read();
    } else {
        data_stream_V_data_17_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_17_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_17_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_17_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_18_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_18_V_blk_n = data_stream_V_data_18_V_empty_n.read();
    } else {
        data_stream_V_data_18_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_18_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_18_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_18_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_19_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_19_V_blk_n = data_stream_V_data_19_V_empty_n.read();
    } else {
        data_stream_V_data_19_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_19_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_19_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_19_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_1_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_1_V_blk_n = data_stream_V_data_1_V_empty_n.read();
    } else {
        data_stream_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_1_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_1_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_1_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_20_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_20_V_blk_n = data_stream_V_data_20_V_empty_n.read();
    } else {
        data_stream_V_data_20_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_20_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_20_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_20_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_21_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_21_V_blk_n = data_stream_V_data_21_V_empty_n.read();
    } else {
        data_stream_V_data_21_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_21_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_21_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_21_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_22_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_22_V_blk_n = data_stream_V_data_22_V_empty_n.read();
    } else {
        data_stream_V_data_22_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_22_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_22_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_22_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_23_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_23_V_blk_n = data_stream_V_data_23_V_empty_n.read();
    } else {
        data_stream_V_data_23_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_23_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_23_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_23_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_24_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_24_V_blk_n = data_stream_V_data_24_V_empty_n.read();
    } else {
        data_stream_V_data_24_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_24_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_24_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_24_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_25_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_25_V_blk_n = data_stream_V_data_25_V_empty_n.read();
    } else {
        data_stream_V_data_25_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_25_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_25_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_25_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_26_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_26_V_blk_n = data_stream_V_data_26_V_empty_n.read();
    } else {
        data_stream_V_data_26_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_26_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_26_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_26_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_27_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_27_V_blk_n = data_stream_V_data_27_V_empty_n.read();
    } else {
        data_stream_V_data_27_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_27_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_27_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_27_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_2_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_2_V_blk_n = data_stream_V_data_2_V_empty_n.read();
    } else {
        data_stream_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_2_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_2_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_2_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_3_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_3_V_blk_n = data_stream_V_data_3_V_empty_n.read();
    } else {
        data_stream_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_3_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_3_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_3_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_4_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_4_V_blk_n = data_stream_V_data_4_V_empty_n.read();
    } else {
        data_stream_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_4_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_4_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_4_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_5_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_5_V_blk_n = data_stream_V_data_5_V_empty_n.read();
    } else {
        data_stream_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_5_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_5_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_5_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_6_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_6_V_blk_n = data_stream_V_data_6_V_empty_n.read();
    } else {
        data_stream_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_6_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_6_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_6_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_7_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_7_V_blk_n = data_stream_V_data_7_V_empty_n.read();
    } else {
        data_stream_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_7_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_7_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_7_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_8_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_8_V_blk_n = data_stream_V_data_8_V_empty_n.read();
    } else {
        data_stream_V_data_8_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_8_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_8_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_8_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_9_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        data_stream_V_data_9_V_blk_n = data_stream_V_data_9_V_empty_n.read();
    } else {
        data_stream_V_data_9_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_data_stream_V_data_9_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        data_stream_V_data_9_V_read = ap_const_logic_1;
    } else {
        data_stream_V_data_9_V_read = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_grp_dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_fu_4181_ap_start() {
    grp_dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_fu_4181_ap_start = grp_dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s_fu_4181_ap_start_reg.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_i_in_fu_4979_p2() {
    i_in_fu_4979_p2 = (!i_in_0_reg_4170.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(i_in_0_reg_4170.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_icmp_ln41_fu_4973_p2() {
    icmp_ln41_fu_4973_p2 = (!i_in_0_reg_4170.read().is_01() || !ap_const_lv5_1C.is_01())? sc_lv<1>(): sc_lv<1>(i_in_0_reg_4170.read() == ap_const_lv5_1C);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_internal_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        internal_ap_ready = ap_const_logic_1;
    } else {
        internal_ap_ready = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_io_acc_block_signal_op1049() {
    io_acc_block_signal_op1049 = (data_stream_V_data_0_V_empty_n.read() & data_stream_V_data_1_V_empty_n.read() & data_stream_V_data_2_V_empty_n.read() & data_stream_V_data_3_V_empty_n.read() & data_stream_V_data_4_V_empty_n.read() & data_stream_V_data_5_V_empty_n.read() & data_stream_V_data_6_V_empty_n.read() & data_stream_V_data_7_V_empty_n.read() & data_stream_V_data_8_V_empty_n.read() & data_stream_V_data_9_V_empty_n.read() & data_stream_V_data_10_V_empty_n.read() & data_stream_V_data_11_V_empty_n.read() & data_stream_V_data_12_V_empty_n.read() & data_stream_V_data_13_V_empty_n.read() & data_stream_V_data_14_V_empty_n.read() & data_stream_V_data_15_V_empty_n.read() & data_stream_V_data_16_V_empty_n.read() & data_stream_V_data_17_V_empty_n.read() & data_stream_V_data_18_V_empty_n.read() & data_stream_V_data_19_V_empty_n.read() & data_stream_V_data_20_V_empty_n.read() & data_stream_V_data_21_V_empty_n.read() & data_stream_V_data_22_V_empty_n.read() & data_stream_V_data_23_V_empty_n.read() & data_stream_V_data_24_V_empty_n.read() & data_stream_V_data_25_V_empty_n.read() & data_stream_V_data_26_V_empty_n.read() & data_stream_V_data_27_V_empty_n.read());
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_io_acc_block_signal_op2838() {
    io_acc_block_signal_op2838 = (res_stream_V_data_0_V_full_n.read() & res_stream_V_data_1_V_full_n.read() & res_stream_V_data_2_V_full_n.read() & res_stream_V_data_3_V_full_n.read() & res_stream_V_data_4_V_full_n.read() & res_stream_V_data_5_V_full_n.read() & res_stream_V_data_6_V_full_n.read() & res_stream_V_data_7_V_full_n.read() & res_stream_V_data_8_V_full_n.read() & res_stream_V_data_9_V_full_n.read() & res_stream_V_data_10_V_full_n.read() & res_stream_V_data_11_V_full_n.read() & res_stream_V_data_12_V_full_n.read() & res_stream_V_data_13_V_full_n.read() & res_stream_V_data_14_V_full_n.read() & res_stream_V_data_15_V_full_n.read() & res_stream_V_data_16_V_full_n.read() & res_stream_V_data_17_V_full_n.read() & res_stream_V_data_18_V_full_n.read() & res_stream_V_data_19_V_full_n.read() & res_stream_V_data_20_V_full_n.read() & res_stream_V_data_21_V_full_n.read() & res_stream_V_data_22_V_full_n.read() & res_stream_V_data_23_V_full_n.read() & res_stream_V_data_24_V_full_n.read() & res_stream_V_data_25_V_full_n.read() & res_stream_V_data_26_V_full_n.read() & res_stream_V_data_27_V_full_n.read() & res_stream_V_data_28_V_full_n.read() & res_stream_V_data_29_V_full_n.read() & res_stream_V_data_30_V_full_n.read() & res_stream_V_data_31_V_full_n.read() & res_stream_V_data_32_V_full_n.read() & res_stream_V_data_33_V_full_n.read() & res_stream_V_data_34_V_full_n.read() & res_stream_V_data_35_V_full_n.read() & res_stream_V_data_36_V_full_n.read() & res_stream_V_data_37_V_full_n.read() & res_stream_V_data_38_V_full_n.read() & res_stream_V_data_39_V_full_n.read() & res_stream_V_data_40_V_full_n.read() & res_stream_V_data_41_V_full_n.read() & res_stream_V_data_42_V_full_n.read() & res_stream_V_data_43_V_full_n.read() & res_stream_V_data_44_V_full_n.read() & res_stream_V_data_45_V_full_n.read() & res_stream_V_data_46_V_full_n.read() & res_stream_V_data_47_V_full_n.read() & res_stream_V_data_48_V_full_n.read() & res_stream_V_data_49_V_full_n.read() & res_stream_V_data_50_V_full_n.read() & res_stream_V_data_51_V_full_n.read() & res_stream_V_data_52_V_full_n.read() & res_stream_V_data_53_V_full_n.read() & res_stream_V_data_54_V_full_n.read() & res_stream_V_data_55_V_full_n.read() & res_stream_V_data_56_V_full_n.read() & res_stream_V_data_57_V_full_n.read() & res_stream_V_data_58_V_full_n.read() & res_stream_V_data_59_V_full_n.read() & res_stream_V_data_60_V_full_n.read() & res_stream_V_data_61_V_full_n.read() & res_stream_V_data_62_V_full_n.read() & res_stream_V_data_63_V_full_n.read() & res_stream_V_data_64_V_full_n.read() & res_stream_V_data_65_V_full_n.read() & res_stream_V_data_66_V_full_n.read() & res_stream_V_data_67_V_full_n.read() & res_stream_V_data_68_V_full_n.read() & res_stream_V_data_69_V_full_n.read() & res_stream_V_data_70_V_full_n.read() & res_stream_V_data_71_V_full_n.read() & res_stream_V_data_72_V_full_n.read() & res_stream_V_data_73_V_full_n.read() & res_stream_V_data_74_V_full_n.read() & res_stream_V_data_75_V_full_n.read() & res_stream_V_data_76_V_full_n.read() & res_stream_V_data_77_V_full_n.read() & res_stream_V_data_78_V_full_n.read() & res_stream_V_data_79_V_full_n.read() & res_stream_V_data_80_V_full_n.read() & res_stream_V_data_81_V_full_n.read() & res_stream_V_data_82_V_full_n.read() & res_stream_V_data_83_V_full_n.read() & res_stream_V_data_84_V_full_n.read() & res_stream_V_data_85_V_full_n.read() & res_stream_V_data_86_V_full_n.read() & res_stream_V_data_87_V_full_n.read() & res_stream_V_data_88_V_full_n.read() & res_stream_V_data_89_V_full_n.read() & res_stream_V_data_90_V_full_n.read() & res_stream_V_data_91_V_full_n.read() & res_stream_V_data_92_V_full_n.read() & res_stream_V_data_93_V_full_n.read() & res_stream_V_data_94_V_full_n.read() & res_stream_V_data_95_V_full_n.read() & res_stream_V_data_96_V_full_n.read() & res_stream_V_data_97_V_full_n.read() & res_stream_V_data_98_V_full_n.read() & res_stream_V_data_99_V_full_n.read() & res_stream_V_data_100_V_full_n.read() & res_stream_V_data_101_V_full_n.read() & res_stream_V_data_102_V_full_n.read() & res_stream_V_data_103_V_full_n.read() & res_stream_V_data_104_V_full_n.read() & res_stream_V_data_105_V_full_n.read() & res_stream_V_data_106_V_full_n.read() & res_stream_V_data_107_V_full_n.read() & res_stream_V_data_108_V_full_n.read() & res_stream_V_data_109_V_full_n.read() & res_stream_V_data_110_V_full_n.read() & res_stream_V_data_111_V_full_n.read() & res_stream_V_data_112_V_full_n.read() & res_stream_V_data_113_V_full_n.read() & res_stream_V_data_114_V_full_n.read() & res_stream_V_data_115_V_full_n.read() & res_stream_V_data_116_V_full_n.read() & res_stream_V_data_117_V_full_n.read() & res_stream_V_data_118_V_full_n.read() & res_stream_V_data_119_V_full_n.read() & res_stream_V_data_120_V_full_n.read() & res_stream_V_data_121_V_full_n.read() & res_stream_V_data_122_V_full_n.read() & res_stream_V_data_123_V_full_n.read() & res_stream_V_data_124_V_full_n.read() & res_stream_V_data_125_V_full_n.read() & res_stream_V_data_126_V_full_n.read() & res_stream_V_data_127_V_full_n.read());
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_or_ln203_1_fu_5011_p2() {
    or_ln203_1_fu_5011_p2 = (sub_ln203_fu_5005_p2.read() | ap_const_lv10_2);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_or_ln203_2_fu_5554_p2() {
    or_ln203_2_fu_5554_p2 = (sub_ln203_reg_17420.read() | ap_const_lv10_3);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_or_ln203_fu_5269_p2() {
    or_ln203_fu_5269_p2 = (sub_ln203_reg_17420.read() | ap_const_lv10_1);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_real_start() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_full_n.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()))) {
        real_start = ap_const_logic_0;
    } else {
        real_start = ap_start.read();
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_0_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_0_V_blk_n = res_stream_V_data_0_V_full_n.read();
    } else {
        res_stream_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_0_V_din() {
    res_stream_V_data_0_V_din = tmp_data_0_V_reg_21356.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_0_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_0_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_0_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_100_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_100_V_blk_n = res_stream_V_data_100_V_full_n.read();
    } else {
        res_stream_V_data_100_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_100_V_din() {
    res_stream_V_data_100_V_din = tmp_data_100_V_reg_21856.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_100_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_100_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_100_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_101_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_101_V_blk_n = res_stream_V_data_101_V_full_n.read();
    } else {
        res_stream_V_data_101_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_101_V_din() {
    res_stream_V_data_101_V_din = tmp_data_101_V_reg_21861.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_101_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_101_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_101_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_102_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_102_V_blk_n = res_stream_V_data_102_V_full_n.read();
    } else {
        res_stream_V_data_102_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_102_V_din() {
    res_stream_V_data_102_V_din = tmp_data_102_V_reg_21866.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_102_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_102_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_102_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_103_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_103_V_blk_n = res_stream_V_data_103_V_full_n.read();
    } else {
        res_stream_V_data_103_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_103_V_din() {
    res_stream_V_data_103_V_din = tmp_data_103_V_reg_21871.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_103_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_103_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_103_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_104_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_104_V_blk_n = res_stream_V_data_104_V_full_n.read();
    } else {
        res_stream_V_data_104_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_104_V_din() {
    res_stream_V_data_104_V_din = tmp_data_104_V_reg_21876.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_104_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_104_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_104_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_105_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_105_V_blk_n = res_stream_V_data_105_V_full_n.read();
    } else {
        res_stream_V_data_105_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_105_V_din() {
    res_stream_V_data_105_V_din = tmp_data_105_V_reg_21881.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_105_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_105_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_105_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_106_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_106_V_blk_n = res_stream_V_data_106_V_full_n.read();
    } else {
        res_stream_V_data_106_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_106_V_din() {
    res_stream_V_data_106_V_din = tmp_data_106_V_reg_21886.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_106_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_106_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_106_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_107_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_107_V_blk_n = res_stream_V_data_107_V_full_n.read();
    } else {
        res_stream_V_data_107_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_107_V_din() {
    res_stream_V_data_107_V_din = tmp_data_107_V_reg_21891.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_107_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_107_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_107_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_108_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_108_V_blk_n = res_stream_V_data_108_V_full_n.read();
    } else {
        res_stream_V_data_108_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_108_V_din() {
    res_stream_V_data_108_V_din = tmp_data_108_V_reg_21896.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_108_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_108_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_108_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_109_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_109_V_blk_n = res_stream_V_data_109_V_full_n.read();
    } else {
        res_stream_V_data_109_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_109_V_din() {
    res_stream_V_data_109_V_din = tmp_data_109_V_reg_21901.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_109_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_109_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_109_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_10_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_10_V_blk_n = res_stream_V_data_10_V_full_n.read();
    } else {
        res_stream_V_data_10_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_10_V_din() {
    res_stream_V_data_10_V_din = tmp_data_10_V_reg_21406.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_10_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_10_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_10_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_110_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_110_V_blk_n = res_stream_V_data_110_V_full_n.read();
    } else {
        res_stream_V_data_110_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_110_V_din() {
    res_stream_V_data_110_V_din = tmp_data_110_V_reg_21906.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_110_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_110_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_110_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_111_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_111_V_blk_n = res_stream_V_data_111_V_full_n.read();
    } else {
        res_stream_V_data_111_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_111_V_din() {
    res_stream_V_data_111_V_din = tmp_data_111_V_reg_21911.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_111_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_111_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_111_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_112_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_112_V_blk_n = res_stream_V_data_112_V_full_n.read();
    } else {
        res_stream_V_data_112_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_112_V_din() {
    res_stream_V_data_112_V_din = tmp_data_112_V_reg_21916.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_112_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_112_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_112_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_113_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_113_V_blk_n = res_stream_V_data_113_V_full_n.read();
    } else {
        res_stream_V_data_113_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_113_V_din() {
    res_stream_V_data_113_V_din = tmp_data_113_V_reg_21921.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_113_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_113_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_113_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_114_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_114_V_blk_n = res_stream_V_data_114_V_full_n.read();
    } else {
        res_stream_V_data_114_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_114_V_din() {
    res_stream_V_data_114_V_din = tmp_data_114_V_reg_21926.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_114_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_114_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_114_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_115_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_115_V_blk_n = res_stream_V_data_115_V_full_n.read();
    } else {
        res_stream_V_data_115_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_115_V_din() {
    res_stream_V_data_115_V_din = tmp_data_115_V_reg_21931.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_115_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_115_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_115_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_116_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_116_V_blk_n = res_stream_V_data_116_V_full_n.read();
    } else {
        res_stream_V_data_116_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_116_V_din() {
    res_stream_V_data_116_V_din = tmp_data_116_V_reg_21936.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_116_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_116_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_116_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_117_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_117_V_blk_n = res_stream_V_data_117_V_full_n.read();
    } else {
        res_stream_V_data_117_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_117_V_din() {
    res_stream_V_data_117_V_din = tmp_data_117_V_reg_21941.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_117_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_117_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_117_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_118_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_118_V_blk_n = res_stream_V_data_118_V_full_n.read();
    } else {
        res_stream_V_data_118_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_118_V_din() {
    res_stream_V_data_118_V_din = tmp_data_118_V_reg_21946.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_118_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_118_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_118_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_119_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_119_V_blk_n = res_stream_V_data_119_V_full_n.read();
    } else {
        res_stream_V_data_119_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_119_V_din() {
    res_stream_V_data_119_V_din = tmp_data_119_V_reg_21951.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_119_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_119_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_119_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_11_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_11_V_blk_n = res_stream_V_data_11_V_full_n.read();
    } else {
        res_stream_V_data_11_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_11_V_din() {
    res_stream_V_data_11_V_din = tmp_data_11_V_reg_21411.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_11_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_11_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_11_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_120_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_120_V_blk_n = res_stream_V_data_120_V_full_n.read();
    } else {
        res_stream_V_data_120_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_120_V_din() {
    res_stream_V_data_120_V_din = tmp_data_120_V_reg_21956.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_120_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_120_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_120_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_121_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_121_V_blk_n = res_stream_V_data_121_V_full_n.read();
    } else {
        res_stream_V_data_121_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_121_V_din() {
    res_stream_V_data_121_V_din = tmp_data_121_V_reg_21961.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_121_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_121_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_121_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_122_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_122_V_blk_n = res_stream_V_data_122_V_full_n.read();
    } else {
        res_stream_V_data_122_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_122_V_din() {
    res_stream_V_data_122_V_din = tmp_data_122_V_reg_21966.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_122_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_122_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_122_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_123_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_123_V_blk_n = res_stream_V_data_123_V_full_n.read();
    } else {
        res_stream_V_data_123_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_123_V_din() {
    res_stream_V_data_123_V_din = tmp_data_123_V_reg_21971.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_123_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_123_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_123_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_124_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_124_V_blk_n = res_stream_V_data_124_V_full_n.read();
    } else {
        res_stream_V_data_124_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_124_V_din() {
    res_stream_V_data_124_V_din = tmp_data_124_V_reg_21976.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_124_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_124_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_124_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_125_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_125_V_blk_n = res_stream_V_data_125_V_full_n.read();
    } else {
        res_stream_V_data_125_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_125_V_din() {
    res_stream_V_data_125_V_din = tmp_data_125_V_reg_21981.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_125_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_125_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_125_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_126_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_126_V_blk_n = res_stream_V_data_126_V_full_n.read();
    } else {
        res_stream_V_data_126_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_126_V_din() {
    res_stream_V_data_126_V_din = tmp_data_126_V_reg_21986.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_126_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_126_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_126_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_127_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_127_V_blk_n = res_stream_V_data_127_V_full_n.read();
    } else {
        res_stream_V_data_127_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_127_V_din() {
    res_stream_V_data_127_V_din = tmp_data_127_V_reg_21991.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_127_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_127_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_127_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_12_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_12_V_blk_n = res_stream_V_data_12_V_full_n.read();
    } else {
        res_stream_V_data_12_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_12_V_din() {
    res_stream_V_data_12_V_din = tmp_data_12_V_reg_21416.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_12_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_12_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_12_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_13_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_13_V_blk_n = res_stream_V_data_13_V_full_n.read();
    } else {
        res_stream_V_data_13_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_13_V_din() {
    res_stream_V_data_13_V_din = tmp_data_13_V_reg_21421.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_13_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_13_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_13_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_14_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_14_V_blk_n = res_stream_V_data_14_V_full_n.read();
    } else {
        res_stream_V_data_14_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_14_V_din() {
    res_stream_V_data_14_V_din = tmp_data_14_V_reg_21426.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_14_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_14_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_14_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_15_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_15_V_blk_n = res_stream_V_data_15_V_full_n.read();
    } else {
        res_stream_V_data_15_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_15_V_din() {
    res_stream_V_data_15_V_din = tmp_data_15_V_reg_21431.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_15_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_15_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_15_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_16_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_16_V_blk_n = res_stream_V_data_16_V_full_n.read();
    } else {
        res_stream_V_data_16_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_16_V_din() {
    res_stream_V_data_16_V_din = tmp_data_16_V_reg_21436.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_16_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_16_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_16_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_17_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_17_V_blk_n = res_stream_V_data_17_V_full_n.read();
    } else {
        res_stream_V_data_17_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_17_V_din() {
    res_stream_V_data_17_V_din = tmp_data_17_V_reg_21441.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_17_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_17_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_17_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_18_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_18_V_blk_n = res_stream_V_data_18_V_full_n.read();
    } else {
        res_stream_V_data_18_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_18_V_din() {
    res_stream_V_data_18_V_din = tmp_data_18_V_reg_21446.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_18_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_18_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_18_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_19_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_19_V_blk_n = res_stream_V_data_19_V_full_n.read();
    } else {
        res_stream_V_data_19_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_19_V_din() {
    res_stream_V_data_19_V_din = tmp_data_19_V_reg_21451.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_19_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_19_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_19_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_1_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_1_V_blk_n = res_stream_V_data_1_V_full_n.read();
    } else {
        res_stream_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_1_V_din() {
    res_stream_V_data_1_V_din = tmp_data_1_V_reg_21361.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_1_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_1_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_1_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_20_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_20_V_blk_n = res_stream_V_data_20_V_full_n.read();
    } else {
        res_stream_V_data_20_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_20_V_din() {
    res_stream_V_data_20_V_din = tmp_data_20_V_reg_21456.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_20_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_20_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_20_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_21_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_21_V_blk_n = res_stream_V_data_21_V_full_n.read();
    } else {
        res_stream_V_data_21_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_21_V_din() {
    res_stream_V_data_21_V_din = tmp_data_21_V_reg_21461.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_21_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_21_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_21_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_22_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_22_V_blk_n = res_stream_V_data_22_V_full_n.read();
    } else {
        res_stream_V_data_22_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_22_V_din() {
    res_stream_V_data_22_V_din = tmp_data_22_V_reg_21466.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_22_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_22_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_22_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_23_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_23_V_blk_n = res_stream_V_data_23_V_full_n.read();
    } else {
        res_stream_V_data_23_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_23_V_din() {
    res_stream_V_data_23_V_din = tmp_data_23_V_reg_21471.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_23_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_23_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_23_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_24_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_24_V_blk_n = res_stream_V_data_24_V_full_n.read();
    } else {
        res_stream_V_data_24_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_24_V_din() {
    res_stream_V_data_24_V_din = tmp_data_24_V_reg_21476.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_24_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_24_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_24_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_25_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_25_V_blk_n = res_stream_V_data_25_V_full_n.read();
    } else {
        res_stream_V_data_25_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_25_V_din() {
    res_stream_V_data_25_V_din = tmp_data_25_V_reg_21481.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_25_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_25_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_25_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_26_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_26_V_blk_n = res_stream_V_data_26_V_full_n.read();
    } else {
        res_stream_V_data_26_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_26_V_din() {
    res_stream_V_data_26_V_din = tmp_data_26_V_reg_21486.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_26_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_26_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_26_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_27_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_27_V_blk_n = res_stream_V_data_27_V_full_n.read();
    } else {
        res_stream_V_data_27_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_27_V_din() {
    res_stream_V_data_27_V_din = tmp_data_27_V_reg_21491.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_27_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_27_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_27_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_28_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_28_V_blk_n = res_stream_V_data_28_V_full_n.read();
    } else {
        res_stream_V_data_28_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_28_V_din() {
    res_stream_V_data_28_V_din = tmp_data_28_V_reg_21496.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_28_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_28_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_28_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_29_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_29_V_blk_n = res_stream_V_data_29_V_full_n.read();
    } else {
        res_stream_V_data_29_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_29_V_din() {
    res_stream_V_data_29_V_din = tmp_data_29_V_reg_21501.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_29_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_29_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_29_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_2_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_2_V_blk_n = res_stream_V_data_2_V_full_n.read();
    } else {
        res_stream_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_2_V_din() {
    res_stream_V_data_2_V_din = tmp_data_2_V_reg_21366.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_2_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_2_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_2_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_30_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_30_V_blk_n = res_stream_V_data_30_V_full_n.read();
    } else {
        res_stream_V_data_30_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_30_V_din() {
    res_stream_V_data_30_V_din = tmp_data_30_V_reg_21506.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_30_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_30_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_30_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_31_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_31_V_blk_n = res_stream_V_data_31_V_full_n.read();
    } else {
        res_stream_V_data_31_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_31_V_din() {
    res_stream_V_data_31_V_din = tmp_data_31_V_reg_21511.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_31_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_31_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_31_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_32_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_32_V_blk_n = res_stream_V_data_32_V_full_n.read();
    } else {
        res_stream_V_data_32_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_32_V_din() {
    res_stream_V_data_32_V_din = tmp_data_32_V_reg_21516.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_32_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_32_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_32_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_33_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_33_V_blk_n = res_stream_V_data_33_V_full_n.read();
    } else {
        res_stream_V_data_33_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_33_V_din() {
    res_stream_V_data_33_V_din = tmp_data_33_V_reg_21521.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_33_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_33_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_33_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_34_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_34_V_blk_n = res_stream_V_data_34_V_full_n.read();
    } else {
        res_stream_V_data_34_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_34_V_din() {
    res_stream_V_data_34_V_din = tmp_data_34_V_reg_21526.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_34_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_34_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_34_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_35_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_35_V_blk_n = res_stream_V_data_35_V_full_n.read();
    } else {
        res_stream_V_data_35_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_35_V_din() {
    res_stream_V_data_35_V_din = tmp_data_35_V_reg_21531.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_35_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_35_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_35_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_36_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_36_V_blk_n = res_stream_V_data_36_V_full_n.read();
    } else {
        res_stream_V_data_36_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_36_V_din() {
    res_stream_V_data_36_V_din = tmp_data_36_V_reg_21536.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_36_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_36_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_36_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_37_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_37_V_blk_n = res_stream_V_data_37_V_full_n.read();
    } else {
        res_stream_V_data_37_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_37_V_din() {
    res_stream_V_data_37_V_din = tmp_data_37_V_reg_21541.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_37_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_37_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_37_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_38_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_38_V_blk_n = res_stream_V_data_38_V_full_n.read();
    } else {
        res_stream_V_data_38_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_38_V_din() {
    res_stream_V_data_38_V_din = tmp_data_38_V_reg_21546.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_38_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_38_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_38_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_39_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_39_V_blk_n = res_stream_V_data_39_V_full_n.read();
    } else {
        res_stream_V_data_39_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_39_V_din() {
    res_stream_V_data_39_V_din = tmp_data_39_V_reg_21551.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_39_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_39_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_39_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_3_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_3_V_blk_n = res_stream_V_data_3_V_full_n.read();
    } else {
        res_stream_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_3_V_din() {
    res_stream_V_data_3_V_din = tmp_data_3_V_reg_21371.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_3_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_3_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_3_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_40_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_40_V_blk_n = res_stream_V_data_40_V_full_n.read();
    } else {
        res_stream_V_data_40_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_40_V_din() {
    res_stream_V_data_40_V_din = tmp_data_40_V_reg_21556.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_40_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_40_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_40_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_41_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_41_V_blk_n = res_stream_V_data_41_V_full_n.read();
    } else {
        res_stream_V_data_41_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_41_V_din() {
    res_stream_V_data_41_V_din = tmp_data_41_V_reg_21561.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_41_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_41_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_41_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_42_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_42_V_blk_n = res_stream_V_data_42_V_full_n.read();
    } else {
        res_stream_V_data_42_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_42_V_din() {
    res_stream_V_data_42_V_din = tmp_data_42_V_reg_21566.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_42_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_42_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_42_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_43_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_43_V_blk_n = res_stream_V_data_43_V_full_n.read();
    } else {
        res_stream_V_data_43_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_43_V_din() {
    res_stream_V_data_43_V_din = tmp_data_43_V_reg_21571.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_43_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_43_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_43_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_44_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_44_V_blk_n = res_stream_V_data_44_V_full_n.read();
    } else {
        res_stream_V_data_44_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_44_V_din() {
    res_stream_V_data_44_V_din = tmp_data_44_V_reg_21576.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_44_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_44_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_44_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_45_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_45_V_blk_n = res_stream_V_data_45_V_full_n.read();
    } else {
        res_stream_V_data_45_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_45_V_din() {
    res_stream_V_data_45_V_din = tmp_data_45_V_reg_21581.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_45_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_45_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_45_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_46_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_46_V_blk_n = res_stream_V_data_46_V_full_n.read();
    } else {
        res_stream_V_data_46_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_46_V_din() {
    res_stream_V_data_46_V_din = tmp_data_46_V_reg_21586.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_46_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_46_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_46_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_47_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_47_V_blk_n = res_stream_V_data_47_V_full_n.read();
    } else {
        res_stream_V_data_47_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_47_V_din() {
    res_stream_V_data_47_V_din = tmp_data_47_V_reg_21591.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_47_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_47_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_47_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_48_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_48_V_blk_n = res_stream_V_data_48_V_full_n.read();
    } else {
        res_stream_V_data_48_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_48_V_din() {
    res_stream_V_data_48_V_din = tmp_data_48_V_reg_21596.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_48_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_48_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_48_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_49_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_49_V_blk_n = res_stream_V_data_49_V_full_n.read();
    } else {
        res_stream_V_data_49_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_49_V_din() {
    res_stream_V_data_49_V_din = tmp_data_49_V_reg_21601.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_49_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_49_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_49_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_4_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_4_V_blk_n = res_stream_V_data_4_V_full_n.read();
    } else {
        res_stream_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_4_V_din() {
    res_stream_V_data_4_V_din = tmp_data_4_V_reg_21376.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_4_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_4_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_4_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_50_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_50_V_blk_n = res_stream_V_data_50_V_full_n.read();
    } else {
        res_stream_V_data_50_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_50_V_din() {
    res_stream_V_data_50_V_din = tmp_data_50_V_reg_21606.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_50_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_50_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_50_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_51_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_51_V_blk_n = res_stream_V_data_51_V_full_n.read();
    } else {
        res_stream_V_data_51_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_51_V_din() {
    res_stream_V_data_51_V_din = tmp_data_51_V_reg_21611.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_51_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_51_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_51_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_52_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_52_V_blk_n = res_stream_V_data_52_V_full_n.read();
    } else {
        res_stream_V_data_52_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_52_V_din() {
    res_stream_V_data_52_V_din = tmp_data_52_V_reg_21616.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_52_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_52_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_52_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_53_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_53_V_blk_n = res_stream_V_data_53_V_full_n.read();
    } else {
        res_stream_V_data_53_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_53_V_din() {
    res_stream_V_data_53_V_din = tmp_data_53_V_reg_21621.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_53_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_53_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_53_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_54_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_54_V_blk_n = res_stream_V_data_54_V_full_n.read();
    } else {
        res_stream_V_data_54_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_54_V_din() {
    res_stream_V_data_54_V_din = tmp_data_54_V_reg_21626.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_54_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_54_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_54_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_55_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_55_V_blk_n = res_stream_V_data_55_V_full_n.read();
    } else {
        res_stream_V_data_55_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_55_V_din() {
    res_stream_V_data_55_V_din = tmp_data_55_V_reg_21631.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_55_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_55_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_55_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_56_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_56_V_blk_n = res_stream_V_data_56_V_full_n.read();
    } else {
        res_stream_V_data_56_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_56_V_din() {
    res_stream_V_data_56_V_din = tmp_data_56_V_reg_21636.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_56_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_56_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_56_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_57_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_57_V_blk_n = res_stream_V_data_57_V_full_n.read();
    } else {
        res_stream_V_data_57_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_57_V_din() {
    res_stream_V_data_57_V_din = tmp_data_57_V_reg_21641.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_57_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_57_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_57_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_58_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_58_V_blk_n = res_stream_V_data_58_V_full_n.read();
    } else {
        res_stream_V_data_58_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_58_V_din() {
    res_stream_V_data_58_V_din = tmp_data_58_V_reg_21646.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_58_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_58_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_58_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_59_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_59_V_blk_n = res_stream_V_data_59_V_full_n.read();
    } else {
        res_stream_V_data_59_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_59_V_din() {
    res_stream_V_data_59_V_din = tmp_data_59_V_reg_21651.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_59_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_59_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_59_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_5_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_5_V_blk_n = res_stream_V_data_5_V_full_n.read();
    } else {
        res_stream_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_5_V_din() {
    res_stream_V_data_5_V_din = tmp_data_5_V_reg_21381.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_5_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_5_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_5_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_60_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_60_V_blk_n = res_stream_V_data_60_V_full_n.read();
    } else {
        res_stream_V_data_60_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_60_V_din() {
    res_stream_V_data_60_V_din = tmp_data_60_V_reg_21656.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_60_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_60_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_60_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_61_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_61_V_blk_n = res_stream_V_data_61_V_full_n.read();
    } else {
        res_stream_V_data_61_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_61_V_din() {
    res_stream_V_data_61_V_din = tmp_data_61_V_reg_21661.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_61_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_61_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_61_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_62_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_62_V_blk_n = res_stream_V_data_62_V_full_n.read();
    } else {
        res_stream_V_data_62_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_62_V_din() {
    res_stream_V_data_62_V_din = tmp_data_62_V_reg_21666.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_62_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_62_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_62_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_63_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_63_V_blk_n = res_stream_V_data_63_V_full_n.read();
    } else {
        res_stream_V_data_63_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_63_V_din() {
    res_stream_V_data_63_V_din = tmp_data_63_V_reg_21671.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_63_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_63_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_63_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_64_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_64_V_blk_n = res_stream_V_data_64_V_full_n.read();
    } else {
        res_stream_V_data_64_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_64_V_din() {
    res_stream_V_data_64_V_din = tmp_data_64_V_reg_21676.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_64_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_64_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_64_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_65_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_65_V_blk_n = res_stream_V_data_65_V_full_n.read();
    } else {
        res_stream_V_data_65_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_65_V_din() {
    res_stream_V_data_65_V_din = tmp_data_65_V_reg_21681.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_65_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_65_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_65_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_66_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_66_V_blk_n = res_stream_V_data_66_V_full_n.read();
    } else {
        res_stream_V_data_66_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_66_V_din() {
    res_stream_V_data_66_V_din = tmp_data_66_V_reg_21686.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_66_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_66_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_66_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_67_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_67_V_blk_n = res_stream_V_data_67_V_full_n.read();
    } else {
        res_stream_V_data_67_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_67_V_din() {
    res_stream_V_data_67_V_din = tmp_data_67_V_reg_21691.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_67_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_67_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_67_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_68_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_68_V_blk_n = res_stream_V_data_68_V_full_n.read();
    } else {
        res_stream_V_data_68_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_68_V_din() {
    res_stream_V_data_68_V_din = tmp_data_68_V_reg_21696.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_68_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_68_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_68_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_69_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_69_V_blk_n = res_stream_V_data_69_V_full_n.read();
    } else {
        res_stream_V_data_69_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_69_V_din() {
    res_stream_V_data_69_V_din = tmp_data_69_V_reg_21701.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_69_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_69_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_69_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_6_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_6_V_blk_n = res_stream_V_data_6_V_full_n.read();
    } else {
        res_stream_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_6_V_din() {
    res_stream_V_data_6_V_din = tmp_data_6_V_reg_21386.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_6_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_6_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_6_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_70_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_70_V_blk_n = res_stream_V_data_70_V_full_n.read();
    } else {
        res_stream_V_data_70_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_70_V_din() {
    res_stream_V_data_70_V_din = tmp_data_70_V_reg_21706.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_70_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_70_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_70_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_71_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_71_V_blk_n = res_stream_V_data_71_V_full_n.read();
    } else {
        res_stream_V_data_71_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_71_V_din() {
    res_stream_V_data_71_V_din = tmp_data_71_V_reg_21711.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_71_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_71_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_71_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_72_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_72_V_blk_n = res_stream_V_data_72_V_full_n.read();
    } else {
        res_stream_V_data_72_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_72_V_din() {
    res_stream_V_data_72_V_din = tmp_data_72_V_reg_21716.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_72_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_72_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_72_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_73_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_73_V_blk_n = res_stream_V_data_73_V_full_n.read();
    } else {
        res_stream_V_data_73_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_73_V_din() {
    res_stream_V_data_73_V_din = tmp_data_73_V_reg_21721.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_73_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_73_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_73_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_74_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_74_V_blk_n = res_stream_V_data_74_V_full_n.read();
    } else {
        res_stream_V_data_74_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_74_V_din() {
    res_stream_V_data_74_V_din = tmp_data_74_V_reg_21726.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_74_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_74_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_74_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_75_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_75_V_blk_n = res_stream_V_data_75_V_full_n.read();
    } else {
        res_stream_V_data_75_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_75_V_din() {
    res_stream_V_data_75_V_din = tmp_data_75_V_reg_21731.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_75_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_75_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_75_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_76_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_76_V_blk_n = res_stream_V_data_76_V_full_n.read();
    } else {
        res_stream_V_data_76_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_76_V_din() {
    res_stream_V_data_76_V_din = tmp_data_76_V_reg_21736.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_76_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_76_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_76_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_77_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_77_V_blk_n = res_stream_V_data_77_V_full_n.read();
    } else {
        res_stream_V_data_77_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_77_V_din() {
    res_stream_V_data_77_V_din = tmp_data_77_V_reg_21741.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_77_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_77_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_77_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_78_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_78_V_blk_n = res_stream_V_data_78_V_full_n.read();
    } else {
        res_stream_V_data_78_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_78_V_din() {
    res_stream_V_data_78_V_din = tmp_data_78_V_reg_21746.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_78_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_78_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_78_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_79_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_79_V_blk_n = res_stream_V_data_79_V_full_n.read();
    } else {
        res_stream_V_data_79_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_79_V_din() {
    res_stream_V_data_79_V_din = tmp_data_79_V_reg_21751.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_79_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_79_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_79_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_7_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_7_V_blk_n = res_stream_V_data_7_V_full_n.read();
    } else {
        res_stream_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_7_V_din() {
    res_stream_V_data_7_V_din = tmp_data_7_V_reg_21391.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_7_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_7_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_7_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_80_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_80_V_blk_n = res_stream_V_data_80_V_full_n.read();
    } else {
        res_stream_V_data_80_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_80_V_din() {
    res_stream_V_data_80_V_din = tmp_data_80_V_reg_21756.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_80_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_80_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_80_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_81_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_81_V_blk_n = res_stream_V_data_81_V_full_n.read();
    } else {
        res_stream_V_data_81_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_81_V_din() {
    res_stream_V_data_81_V_din = tmp_data_81_V_reg_21761.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_81_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_81_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_81_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_82_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_82_V_blk_n = res_stream_V_data_82_V_full_n.read();
    } else {
        res_stream_V_data_82_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_82_V_din() {
    res_stream_V_data_82_V_din = tmp_data_82_V_reg_21766.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_82_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_82_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_82_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_83_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_83_V_blk_n = res_stream_V_data_83_V_full_n.read();
    } else {
        res_stream_V_data_83_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_83_V_din() {
    res_stream_V_data_83_V_din = tmp_data_83_V_reg_21771.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_83_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_83_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_83_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_84_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_84_V_blk_n = res_stream_V_data_84_V_full_n.read();
    } else {
        res_stream_V_data_84_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_84_V_din() {
    res_stream_V_data_84_V_din = tmp_data_84_V_reg_21776.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_84_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_84_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_84_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_85_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_85_V_blk_n = res_stream_V_data_85_V_full_n.read();
    } else {
        res_stream_V_data_85_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_85_V_din() {
    res_stream_V_data_85_V_din = tmp_data_85_V_reg_21781.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_85_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_85_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_85_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_86_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_86_V_blk_n = res_stream_V_data_86_V_full_n.read();
    } else {
        res_stream_V_data_86_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_86_V_din() {
    res_stream_V_data_86_V_din = tmp_data_86_V_reg_21786.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_86_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_86_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_86_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_87_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_87_V_blk_n = res_stream_V_data_87_V_full_n.read();
    } else {
        res_stream_V_data_87_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_87_V_din() {
    res_stream_V_data_87_V_din = tmp_data_87_V_reg_21791.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_87_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_87_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_87_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_88_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_88_V_blk_n = res_stream_V_data_88_V_full_n.read();
    } else {
        res_stream_V_data_88_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_88_V_din() {
    res_stream_V_data_88_V_din = tmp_data_88_V_reg_21796.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_88_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_88_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_88_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_89_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_89_V_blk_n = res_stream_V_data_89_V_full_n.read();
    } else {
        res_stream_V_data_89_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_89_V_din() {
    res_stream_V_data_89_V_din = tmp_data_89_V_reg_21801.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_89_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_89_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_89_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_8_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_8_V_blk_n = res_stream_V_data_8_V_full_n.read();
    } else {
        res_stream_V_data_8_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_8_V_din() {
    res_stream_V_data_8_V_din = tmp_data_8_V_reg_21396.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_8_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_8_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_8_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_90_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_90_V_blk_n = res_stream_V_data_90_V_full_n.read();
    } else {
        res_stream_V_data_90_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_90_V_din() {
    res_stream_V_data_90_V_din = tmp_data_90_V_reg_21806.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_90_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_90_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_90_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_91_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_91_V_blk_n = res_stream_V_data_91_V_full_n.read();
    } else {
        res_stream_V_data_91_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_91_V_din() {
    res_stream_V_data_91_V_din = tmp_data_91_V_reg_21811.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_91_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_91_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_91_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_92_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_92_V_blk_n = res_stream_V_data_92_V_full_n.read();
    } else {
        res_stream_V_data_92_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_92_V_din() {
    res_stream_V_data_92_V_din = tmp_data_92_V_reg_21816.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_92_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_92_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_92_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_93_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_93_V_blk_n = res_stream_V_data_93_V_full_n.read();
    } else {
        res_stream_V_data_93_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_93_V_din() {
    res_stream_V_data_93_V_din = tmp_data_93_V_reg_21821.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_93_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_93_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_93_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_94_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_94_V_blk_n = res_stream_V_data_94_V_full_n.read();
    } else {
        res_stream_V_data_94_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_94_V_din() {
    res_stream_V_data_94_V_din = tmp_data_94_V_reg_21826.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_94_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_94_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_94_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_95_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_95_V_blk_n = res_stream_V_data_95_V_full_n.read();
    } else {
        res_stream_V_data_95_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_95_V_din() {
    res_stream_V_data_95_V_din = tmp_data_95_V_reg_21831.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_95_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_95_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_95_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_96_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_96_V_blk_n = res_stream_V_data_96_V_full_n.read();
    } else {
        res_stream_V_data_96_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_96_V_din() {
    res_stream_V_data_96_V_din = tmp_data_96_V_reg_21836.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_96_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_96_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_96_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_97_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_97_V_blk_n = res_stream_V_data_97_V_full_n.read();
    } else {
        res_stream_V_data_97_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_97_V_din() {
    res_stream_V_data_97_V_din = tmp_data_97_V_reg_21841.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_97_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_97_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_97_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_98_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_98_V_blk_n = res_stream_V_data_98_V_full_n.read();
    } else {
        res_stream_V_data_98_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_98_V_din() {
    res_stream_V_data_98_V_din = tmp_data_98_V_reg_21846.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_98_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_98_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_98_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_99_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_99_V_blk_n = res_stream_V_data_99_V_full_n.read();
    } else {
        res_stream_V_data_99_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_99_V_din() {
    res_stream_V_data_99_V_din = tmp_data_99_V_reg_21851.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_99_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_99_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_99_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_9_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        res_stream_V_data_9_V_blk_n = res_stream_V_data_9_V_full_n.read();
    } else {
        res_stream_V_data_9_V_blk_n = ap_const_logic_1;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_9_V_din() {
    res_stream_V_data_9_V_din = tmp_data_9_V_reg_21401.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_res_stream_V_data_9_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op2838.read(), ap_const_logic_1))) {
        res_stream_V_data_9_V_write = ap_const_logic_1;
    } else {
        res_stream_V_data_9_V_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_shl_ln48_1_fu_4993_p3() {
    shl_ln48_1_fu_4993_p3 = esl_concat<5,2>(i_in_0_reg_4170.read(), ap_const_lv2_0);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_shl_ln_fu_4985_p3() {
    shl_ln_fu_4985_p3 = esl_concat<5,5>(i_in_0_reg_4170.read(), ap_const_lv5_0);
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_start_out() {
    start_out = real_start.read();
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_start_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, real_start.read()))) {
        start_write = ap_const_logic_1;
    } else {
        start_write = ap_const_logic_0;
    }
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_sub_ln203_fu_5005_p2() {
    sub_ln203_fu_5005_p2 = (!shl_ln_fu_4985_p3.read().is_01() || !zext_ln203_fu_5001_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(shl_ln_fu_4985_p3.read()) - sc_biguint<10>(zext_ln203_fu_5001_p1.read()));
}

void dense_array_array_ap_fixed_12_7_5_3_0_128u_config3_s::thread_zext_ln203_fu_5001_p1() {
    zext_ln203_fu_5001_p1 = esl_zext<10,7>(shl_ln48_1_fu_4993_p3.read());
}

}

