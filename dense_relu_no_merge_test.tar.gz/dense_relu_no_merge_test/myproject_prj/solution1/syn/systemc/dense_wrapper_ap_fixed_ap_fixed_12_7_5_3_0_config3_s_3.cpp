#include "dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_0_V_fu_37435_p2() {
    acc_0_V_fu_37435_p2 = (!trunc_ln2_reg_44268.read().is_01() || !phi_ln_fu_37398_p18.read().is_01())? sc_lv<12>(): (sc_biguint<12>(trunc_ln2_reg_44268.read()) + sc_biguint<12>(phi_ln_fu_37398_p18.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_112_V_fu_39423_p2() {
    acc_112_V_fu_39423_p2 = (!phi_ln1265_7_fu_39161_p130.read().is_01() || !trunc_ln708_7_reg_44303.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_7_fu_39161_p130.read()) + sc_biguint<12>(trunc_ln708_7_reg_44303.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_16_V_fu_37718_p2() {
    acc_16_V_fu_37718_p2 = (!phi_ln1265_1_fu_37456_p130.read().is_01() || !trunc_ln708_1_reg_44273.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_1_fu_37456_p130.read()) + sc_biguint<12>(trunc_ln708_1_reg_44273.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_32_V_fu_38001_p2() {
    acc_32_V_fu_38001_p2 = (!phi_ln1265_2_fu_37739_p130.read().is_01() || !trunc_ln708_2_reg_44278.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_2_fu_37739_p130.read()) + sc_biguint<12>(trunc_ln708_2_reg_44278.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_48_V_fu_38284_p2() {
    acc_48_V_fu_38284_p2 = (!phi_ln1265_3_fu_38022_p130.read().is_01() || !trunc_ln708_3_reg_44283.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_3_fu_38022_p130.read()) + sc_biguint<12>(trunc_ln708_3_reg_44283.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_64_V_fu_38574_p2() {
    acc_64_V_fu_38574_p2 = (!phi_ln1265_4_fu_38312_p130.read().is_01() || !trunc_ln708_4_reg_44288.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_4_fu_38312_p130.read()) + sc_biguint<12>(trunc_ln708_4_reg_44288.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_80_V_fu_38857_p2() {
    acc_80_V_fu_38857_p2 = (!phi_ln1265_5_fu_38595_p130.read().is_01() || !trunc_ln708_5_reg_44293.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_5_fu_38595_p130.read()) + sc_biguint<12>(trunc_ln708_5_reg_44293.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_acc_96_V_fu_39140_p2() {
    acc_96_V_fu_39140_p2 = (!phi_ln1265_6_fu_38878_p130.read().is_01() || !trunc_ln708_6_reg_44298.read().is_01())? sc_lv<12>(): (sc_biguint<12>(phi_ln1265_6_fu_38878_p130.read()) + sc_biguint<12>(trunc_ln708_6_reg_44298.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[1];
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_state2_pp0_stage0_iter0() {
    ap_block_state2_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_state3_pp0_stage0_iter1() {
    ap_block_state3_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_state4_pp0_stage0_iter2() {
    ap_block_state4_pp0_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_block_state5_pp0_stage0_iter3() {
    ap_block_state5_pp0_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_condition_41() {
    ap_condition_41 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_condition_6234() {
    ap_condition_6234 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_condition_6265() {
    ap_condition_6265 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0));
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_done() {
    if (((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln151_reg_44207_pp0_iter2_reg.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_enable_reg_pp0_iter0() {
    ap_enable_reg_pp0_iter0 = ap_start.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter3.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_idle_pp0_0to2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()))) {
        ap_idle_pp0_0to2 = ap_const_logic_1;
    } else {
        ap_idle_pp0_0to2 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_0_1_phi_fu_28698_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_0_1_phi_fu_28698_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_0_1_phi_fu_28698_p32 = res_0_V_write_assign234_reg_27168.read();
    } else {
        ap_phi_mux_acc_V_0_1_phi_fu_28698_p32 = ap_phi_reg_pp0_iter3_acc_V_0_1_reg_28694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_100_1_phi_fu_34476_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_100_1_phi_fu_34476_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_100_1_phi_fu_34476_p32 = res_100_V_write_assign72_reg_28302.read();
    } else {
        ap_phi_mux_acc_V_100_1_phi_fu_34476_p32 = ap_phi_reg_pp0_iter3_acc_V_100_1_reg_34472.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_101_1_phi_fu_34422_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_101_1_phi_fu_34422_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_101_1_phi_fu_34422_p32 = res_101_V_write_assign70_reg_28316.read();
    } else {
        ap_phi_mux_acc_V_101_1_phi_fu_34422_p32 = ap_phi_reg_pp0_iter3_acc_V_101_1_reg_34418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_102_1_phi_fu_34368_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_102_1_phi_fu_34368_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_102_1_phi_fu_34368_p32 = res_102_V_write_assign68_reg_28330.read();
    } else {
        ap_phi_mux_acc_V_102_1_phi_fu_34368_p32 = ap_phi_reg_pp0_iter3_acc_V_102_1_reg_34364.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_103_1_phi_fu_34314_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_103_1_phi_fu_34314_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_103_1_phi_fu_34314_p32 = res_103_V_write_assign66_reg_28344.read();
    } else {
        ap_phi_mux_acc_V_103_1_phi_fu_34314_p32 = ap_phi_reg_pp0_iter3_acc_V_103_1_reg_34310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_104_1_phi_fu_34260_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_104_1_phi_fu_34260_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_104_1_phi_fu_34260_p32 = res_104_V_write_assign64_reg_28358.read();
    } else {
        ap_phi_mux_acc_V_104_1_phi_fu_34260_p32 = ap_phi_reg_pp0_iter3_acc_V_104_1_reg_34256.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_105_1_phi_fu_34206_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_105_1_phi_fu_34206_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_105_1_phi_fu_34206_p32 = res_105_V_write_assign62_reg_28372.read();
    } else {
        ap_phi_mux_acc_V_105_1_phi_fu_34206_p32 = ap_phi_reg_pp0_iter3_acc_V_105_1_reg_34202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_106_1_phi_fu_34152_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_106_1_phi_fu_34152_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_106_1_phi_fu_34152_p32 = res_106_V_write_assign60_reg_28386.read();
    } else {
        ap_phi_mux_acc_V_106_1_phi_fu_34152_p32 = ap_phi_reg_pp0_iter3_acc_V_106_1_reg_34148.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_107_1_phi_fu_34098_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_107_1_phi_fu_34098_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_107_1_phi_fu_34098_p32 = res_107_V_write_assign58_reg_28400.read();
    } else {
        ap_phi_mux_acc_V_107_1_phi_fu_34098_p32 = ap_phi_reg_pp0_iter3_acc_V_107_1_reg_34094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_108_1_phi_fu_34044_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_108_1_phi_fu_34044_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_108_1_phi_fu_34044_p32 = res_108_V_write_assign56_reg_28414.read();
    } else {
        ap_phi_mux_acc_V_108_1_phi_fu_34044_p32 = ap_phi_reg_pp0_iter3_acc_V_108_1_reg_34040.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_109_1_phi_fu_33990_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_109_1_phi_fu_33990_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_109_1_phi_fu_33990_p32 = res_109_V_write_assign54_reg_28428.read();
    } else {
        ap_phi_mux_acc_V_109_1_phi_fu_33990_p32 = ap_phi_reg_pp0_iter3_acc_V_109_1_reg_33986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_10_1_phi_fu_29238_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_10_1_phi_fu_29238_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_10_1_phi_fu_29238_p32 = res_10_V_write_assign254_reg_27028.read();
    } else {
        ap_phi_mux_acc_V_10_1_phi_fu_29238_p32 = ap_phi_reg_pp0_iter3_acc_V_10_1_reg_29234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_110_1_phi_fu_33936_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_110_1_phi_fu_33936_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_110_1_phi_fu_33936_p32 = res_110_V_write_assign52_reg_28442.read();
    } else {
        ap_phi_mux_acc_V_110_1_phi_fu_33936_p32 = ap_phi_reg_pp0_iter3_acc_V_110_1_reg_33932.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_111_1_phi_fu_33882_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_111_1_phi_fu_33882_p32 = res_111_V_write_assign50_reg_28456.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_111_1_phi_fu_33882_p32 = acc_96_V_fu_39140_p2.read();
    } else {
        ap_phi_mux_acc_V_111_1_phi_fu_33882_p32 = ap_phi_reg_pp0_iter3_acc_V_111_1_reg_33878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_112_1_phi_fu_35556_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_112_1_phi_fu_35556_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_112_1_phi_fu_35556_p32 = res_112_V_write_assign48_reg_28470.read();
    } else {
        ap_phi_mux_acc_V_112_1_phi_fu_35556_p32 = ap_phi_reg_pp0_iter3_acc_V_112_1_reg_35552.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_113_1_phi_fu_35502_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_113_1_phi_fu_35502_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_113_1_phi_fu_35502_p32 = res_113_V_write_assign46_reg_28484.read();
    } else {
        ap_phi_mux_acc_V_113_1_phi_fu_35502_p32 = ap_phi_reg_pp0_iter3_acc_V_113_1_reg_35498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_114_1_phi_fu_35448_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_114_1_phi_fu_35448_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_114_1_phi_fu_35448_p32 = res_114_V_write_assign44_reg_28498.read();
    } else {
        ap_phi_mux_acc_V_114_1_phi_fu_35448_p32 = ap_phi_reg_pp0_iter3_acc_V_114_1_reg_35444.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_115_1_phi_fu_35394_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_115_1_phi_fu_35394_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_115_1_phi_fu_35394_p32 = res_115_V_write_assign42_reg_28512.read();
    } else {
        ap_phi_mux_acc_V_115_1_phi_fu_35394_p32 = ap_phi_reg_pp0_iter3_acc_V_115_1_reg_35390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_116_1_phi_fu_35340_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_116_1_phi_fu_35340_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_116_1_phi_fu_35340_p32 = res_116_V_write_assign40_reg_28526.read();
    } else {
        ap_phi_mux_acc_V_116_1_phi_fu_35340_p32 = ap_phi_reg_pp0_iter3_acc_V_116_1_reg_35336.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_117_1_phi_fu_35286_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_117_1_phi_fu_35286_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_117_1_phi_fu_35286_p32 = res_117_V_write_assign38_reg_28540.read();
    } else {
        ap_phi_mux_acc_V_117_1_phi_fu_35286_p32 = ap_phi_reg_pp0_iter3_acc_V_117_1_reg_35282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_118_1_phi_fu_35232_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_118_1_phi_fu_35232_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_118_1_phi_fu_35232_p32 = res_118_V_write_assign36_reg_28554.read();
    } else {
        ap_phi_mux_acc_V_118_1_phi_fu_35232_p32 = ap_phi_reg_pp0_iter3_acc_V_118_1_reg_35228.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_119_1_phi_fu_35178_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_119_1_phi_fu_35178_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_119_1_phi_fu_35178_p32 = res_119_V_write_assign34_reg_28568.read();
    } else {
        ap_phi_mux_acc_V_119_1_phi_fu_35178_p32 = ap_phi_reg_pp0_iter3_acc_V_119_1_reg_35174.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_11_1_phi_fu_29292_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_11_1_phi_fu_29292_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_11_1_phi_fu_29292_p32 = res_11_V_write_assign256_reg_27014.read();
    } else {
        ap_phi_mux_acc_V_11_1_phi_fu_29292_p32 = ap_phi_reg_pp0_iter3_acc_V_11_1_reg_29288.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_120_1_phi_fu_35124_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_120_1_phi_fu_35124_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_120_1_phi_fu_35124_p32 = res_120_V_write_assign32_reg_28582.read();
    } else {
        ap_phi_mux_acc_V_120_1_phi_fu_35124_p32 = ap_phi_reg_pp0_iter3_acc_V_120_1_reg_35120.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_121_1_phi_fu_35070_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_121_1_phi_fu_35070_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_121_1_phi_fu_35070_p32 = res_121_V_write_assign30_reg_28596.read();
    } else {
        ap_phi_mux_acc_V_121_1_phi_fu_35070_p32 = ap_phi_reg_pp0_iter3_acc_V_121_1_reg_35066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_122_1_phi_fu_35016_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_122_1_phi_fu_35016_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_122_1_phi_fu_35016_p32 = res_122_V_write_assign28_reg_28610.read();
    } else {
        ap_phi_mux_acc_V_122_1_phi_fu_35016_p32 = ap_phi_reg_pp0_iter3_acc_V_122_1_reg_35012.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_123_1_phi_fu_34962_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_123_1_phi_fu_34962_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_123_1_phi_fu_34962_p32 = res_123_V_write_assign26_reg_28624.read();
    } else {
        ap_phi_mux_acc_V_123_1_phi_fu_34962_p32 = ap_phi_reg_pp0_iter3_acc_V_123_1_reg_34958.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_124_1_phi_fu_34908_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_124_1_phi_fu_34908_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_124_1_phi_fu_34908_p32 = res_124_V_write_assign24_reg_28638.read();
    } else {
        ap_phi_mux_acc_V_124_1_phi_fu_34908_p32 = ap_phi_reg_pp0_iter3_acc_V_124_1_reg_34904.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_125_1_phi_fu_34854_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_125_1_phi_fu_34854_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_125_1_phi_fu_34854_p32 = res_125_V_write_assign22_reg_28652.read();
    } else {
        ap_phi_mux_acc_V_125_1_phi_fu_34854_p32 = ap_phi_reg_pp0_iter3_acc_V_125_1_reg_34850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_126_1_phi_fu_34800_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_126_1_phi_fu_34800_p32 = acc_112_V_fu_39423_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_126_1_phi_fu_34800_p32 = res_126_V_write_assign20_reg_28666.read();
    } else {
        ap_phi_mux_acc_V_126_1_phi_fu_34800_p32 = ap_phi_reg_pp0_iter3_acc_V_126_1_reg_34796.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_127_1_phi_fu_34746_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_127_1_phi_fu_34746_p32 = res_127_V_write_assign18_reg_28680.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_127_1_phi_fu_34746_p32 = acc_112_V_fu_39423_p2.read();
    } else {
        ap_phi_mux_acc_V_127_1_phi_fu_34746_p32 = ap_phi_reg_pp0_iter3_acc_V_127_1_reg_34742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_12_1_phi_fu_29346_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_12_1_phi_fu_29346_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_12_1_phi_fu_29346_p32 = res_12_V_write_assign258_reg_27000.read();
    } else {
        ap_phi_mux_acc_V_12_1_phi_fu_29346_p32 = ap_phi_reg_pp0_iter3_acc_V_12_1_reg_29342.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_13_1_phi_fu_29400_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_13_1_phi_fu_29400_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_13_1_phi_fu_29400_p32 = res_13_V_write_assign260_reg_26986.read();
    } else {
        ap_phi_mux_acc_V_13_1_phi_fu_29400_p32 = ap_phi_reg_pp0_iter3_acc_V_13_1_reg_29396.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_14_1_phi_fu_29454_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_14_1_phi_fu_29454_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_14_1_phi_fu_29454_p32 = res_14_V_write_assign262_reg_26972.read();
    } else {
        ap_phi_mux_acc_V_14_1_phi_fu_29454_p32 = ap_phi_reg_pp0_iter3_acc_V_14_1_reg_29450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_15_1_phi_fu_29508_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_15_1_phi_fu_29508_p32 = res_15_V_write_assign264_reg_26958.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_15_1_phi_fu_29508_p32 = acc_0_V_fu_37435_p2.read();
    } else {
        ap_phi_mux_acc_V_15_1_phi_fu_29508_p32 = ap_phi_reg_pp0_iter3_acc_V_15_1_reg_29504.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_16_1_phi_fu_30210_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_16_1_phi_fu_30210_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_16_1_phi_fu_30210_p32 = res_16_V_write_assign266_reg_26944.read();
    } else {
        ap_phi_mux_acc_V_16_1_phi_fu_30210_p32 = ap_phi_reg_pp0_iter3_acc_V_16_1_reg_30206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_17_1_phi_fu_30264_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_17_1_phi_fu_30264_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_17_1_phi_fu_30264_p32 = res_17_V_write_assign268_reg_26930.read();
    } else {
        ap_phi_mux_acc_V_17_1_phi_fu_30264_p32 = ap_phi_reg_pp0_iter3_acc_V_17_1_reg_30260.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_18_1_phi_fu_30318_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_18_1_phi_fu_30318_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_18_1_phi_fu_30318_p32 = res_18_V_write_assign270_reg_26916.read();
    } else {
        ap_phi_mux_acc_V_18_1_phi_fu_30318_p32 = ap_phi_reg_pp0_iter3_acc_V_18_1_reg_30314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_19_1_phi_fu_30372_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_19_1_phi_fu_30372_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_19_1_phi_fu_30372_p32 = res_19_V_write_assign272_reg_26902.read();
    } else {
        ap_phi_mux_acc_V_19_1_phi_fu_30372_p32 = ap_phi_reg_pp0_iter3_acc_V_19_1_reg_30368.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_1_1_phi_fu_28752_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_1_1_phi_fu_28752_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_1_1_phi_fu_28752_p32 = res_1_V_write_assign236_reg_27154.read();
    } else {
        ap_phi_mux_acc_V_1_1_phi_fu_28752_p32 = ap_phi_reg_pp0_iter3_acc_V_1_1_reg_28748.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_20_1_phi_fu_30156_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_20_1_phi_fu_30156_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_20_1_phi_fu_30156_p32 = res_20_V_write_assign232_reg_27182.read();
    } else {
        ap_phi_mux_acc_V_20_1_phi_fu_30156_p32 = ap_phi_reg_pp0_iter3_acc_V_20_1_reg_30152.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_21_1_phi_fu_30102_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_21_1_phi_fu_30102_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_21_1_phi_fu_30102_p32 = res_21_V_write_assign230_reg_27196.read();
    } else {
        ap_phi_mux_acc_V_21_1_phi_fu_30102_p32 = ap_phi_reg_pp0_iter3_acc_V_21_1_reg_30098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_22_1_phi_fu_30048_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_22_1_phi_fu_30048_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_22_1_phi_fu_30048_p32 = res_22_V_write_assign228_reg_27210.read();
    } else {
        ap_phi_mux_acc_V_22_1_phi_fu_30048_p32 = ap_phi_reg_pp0_iter3_acc_V_22_1_reg_30044.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_23_1_phi_fu_29994_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_23_1_phi_fu_29994_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_23_1_phi_fu_29994_p32 = res_23_V_write_assign226_reg_27224.read();
    } else {
        ap_phi_mux_acc_V_23_1_phi_fu_29994_p32 = ap_phi_reg_pp0_iter3_acc_V_23_1_reg_29990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_24_1_phi_fu_29940_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_24_1_phi_fu_29940_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_24_1_phi_fu_29940_p32 = res_24_V_write_assign224_reg_27238.read();
    } else {
        ap_phi_mux_acc_V_24_1_phi_fu_29940_p32 = ap_phi_reg_pp0_iter3_acc_V_24_1_reg_29936.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_25_1_phi_fu_29886_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_25_1_phi_fu_29886_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_25_1_phi_fu_29886_p32 = res_25_V_write_assign222_reg_27252.read();
    } else {
        ap_phi_mux_acc_V_25_1_phi_fu_29886_p32 = ap_phi_reg_pp0_iter3_acc_V_25_1_reg_29882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_26_1_phi_fu_29832_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_26_1_phi_fu_29832_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_26_1_phi_fu_29832_p32 = res_26_V_write_assign220_reg_27266.read();
    } else {
        ap_phi_mux_acc_V_26_1_phi_fu_29832_p32 = ap_phi_reg_pp0_iter3_acc_V_26_1_reg_29828.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_27_1_phi_fu_29778_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_27_1_phi_fu_29778_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_27_1_phi_fu_29778_p32 = res_27_V_write_assign218_reg_27280.read();
    } else {
        ap_phi_mux_acc_V_27_1_phi_fu_29778_p32 = ap_phi_reg_pp0_iter3_acc_V_27_1_reg_29774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_28_1_phi_fu_29724_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_28_1_phi_fu_29724_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_28_1_phi_fu_29724_p32 = res_28_V_write_assign216_reg_27294.read();
    } else {
        ap_phi_mux_acc_V_28_1_phi_fu_29724_p32 = ap_phi_reg_pp0_iter3_acc_V_28_1_reg_29720.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_29_1_phi_fu_29670_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_29_1_phi_fu_29670_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_29_1_phi_fu_29670_p32 = res_29_V_write_assign214_reg_27308.read();
    } else {
        ap_phi_mux_acc_V_29_1_phi_fu_29670_p32 = ap_phi_reg_pp0_iter3_acc_V_29_1_reg_29666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_2_1_phi_fu_28806_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_2_1_phi_fu_28806_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_2_1_phi_fu_28806_p32 = res_2_V_write_assign238_reg_27140.read();
    } else {
        ap_phi_mux_acc_V_2_1_phi_fu_28806_p32 = ap_phi_reg_pp0_iter3_acc_V_2_1_reg_28802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_30_1_phi_fu_29616_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_30_1_phi_fu_29616_p32 = acc_16_V_fu_37718_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_30_1_phi_fu_29616_p32 = res_30_V_write_assign212_reg_27322.read();
    } else {
        ap_phi_mux_acc_V_30_1_phi_fu_29616_p32 = ap_phi_reg_pp0_iter3_acc_V_30_1_reg_29612.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_31_1_phi_fu_29562_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_31_1_phi_fu_29562_p32 = res_31_V_write_assign210_reg_27336.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_31_1_phi_fu_29562_p32 = acc_16_V_fu_37718_p2.read();
    } else {
        ap_phi_mux_acc_V_31_1_phi_fu_29562_p32 = ap_phi_reg_pp0_iter3_acc_V_31_1_reg_29558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_32_1_phi_fu_31236_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_32_1_phi_fu_31236_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_32_1_phi_fu_31236_p32 = res_32_V_write_assign208_reg_27350.read();
    } else {
        ap_phi_mux_acc_V_32_1_phi_fu_31236_p32 = ap_phi_reg_pp0_iter3_acc_V_32_1_reg_31232.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_33_1_phi_fu_31182_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_33_1_phi_fu_31182_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_33_1_phi_fu_31182_p32 = res_33_V_write_assign206_reg_27364.read();
    } else {
        ap_phi_mux_acc_V_33_1_phi_fu_31182_p32 = ap_phi_reg_pp0_iter3_acc_V_33_1_reg_31178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_34_1_phi_fu_31128_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_34_1_phi_fu_31128_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_34_1_phi_fu_31128_p32 = res_34_V_write_assign204_reg_27378.read();
    } else {
        ap_phi_mux_acc_V_34_1_phi_fu_31128_p32 = ap_phi_reg_pp0_iter3_acc_V_34_1_reg_31124.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_35_1_phi_fu_31074_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_35_1_phi_fu_31074_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_35_1_phi_fu_31074_p32 = res_35_V_write_assign202_reg_27392.read();
    } else {
        ap_phi_mux_acc_V_35_1_phi_fu_31074_p32 = ap_phi_reg_pp0_iter3_acc_V_35_1_reg_31070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_36_1_phi_fu_31020_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_36_1_phi_fu_31020_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_36_1_phi_fu_31020_p32 = res_36_V_write_assign200_reg_27406.read();
    } else {
        ap_phi_mux_acc_V_36_1_phi_fu_31020_p32 = ap_phi_reg_pp0_iter3_acc_V_36_1_reg_31016.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_37_1_phi_fu_30966_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_37_1_phi_fu_30966_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_37_1_phi_fu_30966_p32 = res_37_V_write_assign198_reg_27420.read();
    } else {
        ap_phi_mux_acc_V_37_1_phi_fu_30966_p32 = ap_phi_reg_pp0_iter3_acc_V_37_1_reg_30962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_38_1_phi_fu_30912_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_38_1_phi_fu_30912_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_38_1_phi_fu_30912_p32 = res_38_V_write_assign196_reg_27434.read();
    } else {
        ap_phi_mux_acc_V_38_1_phi_fu_30912_p32 = ap_phi_reg_pp0_iter3_acc_V_38_1_reg_30908.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_39_1_phi_fu_30858_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_39_1_phi_fu_30858_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_39_1_phi_fu_30858_p32 = res_39_V_write_assign194_reg_27448.read();
    } else {
        ap_phi_mux_acc_V_39_1_phi_fu_30858_p32 = ap_phi_reg_pp0_iter3_acc_V_39_1_reg_30854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_3_1_phi_fu_28860_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_3_1_phi_fu_28860_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_3_1_phi_fu_28860_p32 = res_3_V_write_assign240_reg_27126.read();
    } else {
        ap_phi_mux_acc_V_3_1_phi_fu_28860_p32 = ap_phi_reg_pp0_iter3_acc_V_3_1_reg_28856.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_40_1_phi_fu_30804_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_40_1_phi_fu_30804_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_40_1_phi_fu_30804_p32 = res_40_V_write_assign192_reg_27462.read();
    } else {
        ap_phi_mux_acc_V_40_1_phi_fu_30804_p32 = ap_phi_reg_pp0_iter3_acc_V_40_1_reg_30800.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_41_1_phi_fu_30750_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_41_1_phi_fu_30750_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_41_1_phi_fu_30750_p32 = res_41_V_write_assign190_reg_27476.read();
    } else {
        ap_phi_mux_acc_V_41_1_phi_fu_30750_p32 = ap_phi_reg_pp0_iter3_acc_V_41_1_reg_30746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_42_1_phi_fu_30696_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_42_1_phi_fu_30696_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_42_1_phi_fu_30696_p32 = res_42_V_write_assign188_reg_27490.read();
    } else {
        ap_phi_mux_acc_V_42_1_phi_fu_30696_p32 = ap_phi_reg_pp0_iter3_acc_V_42_1_reg_30692.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_43_1_phi_fu_30642_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_43_1_phi_fu_30642_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_43_1_phi_fu_30642_p32 = res_43_V_write_assign186_reg_27504.read();
    } else {
        ap_phi_mux_acc_V_43_1_phi_fu_30642_p32 = ap_phi_reg_pp0_iter3_acc_V_43_1_reg_30638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_44_1_phi_fu_30588_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_44_1_phi_fu_30588_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_44_1_phi_fu_30588_p32 = res_44_V_write_assign184_reg_27518.read();
    } else {
        ap_phi_mux_acc_V_44_1_phi_fu_30588_p32 = ap_phi_reg_pp0_iter3_acc_V_44_1_reg_30584.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_45_1_phi_fu_30534_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_45_1_phi_fu_30534_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_45_1_phi_fu_30534_p32 = res_45_V_write_assign182_reg_27532.read();
    } else {
        ap_phi_mux_acc_V_45_1_phi_fu_30534_p32 = ap_phi_reg_pp0_iter3_acc_V_45_1_reg_30530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_46_1_phi_fu_30480_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_46_1_phi_fu_30480_p32 = acc_32_V_fu_38001_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_46_1_phi_fu_30480_p32 = res_46_V_write_assign180_reg_27546.read();
    } else {
        ap_phi_mux_acc_V_46_1_phi_fu_30480_p32 = ap_phi_reg_pp0_iter3_acc_V_46_1_reg_30476.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_47_1_phi_fu_30426_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_47_1_phi_fu_30426_p32 = res_47_V_write_assign178_reg_27560.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_47_1_phi_fu_30426_p32 = acc_32_V_fu_38001_p2.read();
    } else {
        ap_phi_mux_acc_V_47_1_phi_fu_30426_p32 = ap_phi_reg_pp0_iter3_acc_V_47_1_reg_30422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_48_1_phi_fu_32100_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_48_1_phi_fu_32100_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_48_1_phi_fu_32100_p32 = res_48_V_write_assign176_reg_27574.read();
    } else {
        ap_phi_mux_acc_V_48_1_phi_fu_32100_p32 = ap_phi_reg_pp0_iter3_acc_V_48_1_reg_32096.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_49_1_phi_fu_32046_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_49_1_phi_fu_32046_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_49_1_phi_fu_32046_p32 = res_49_V_write_assign174_reg_27588.read();
    } else {
        ap_phi_mux_acc_V_49_1_phi_fu_32046_p32 = ap_phi_reg_pp0_iter3_acc_V_49_1_reg_32042.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_4_1_phi_fu_28914_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_4_1_phi_fu_28914_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_4_1_phi_fu_28914_p32 = res_4_V_write_assign242_reg_27112.read();
    } else {
        ap_phi_mux_acc_V_4_1_phi_fu_28914_p32 = ap_phi_reg_pp0_iter3_acc_V_4_1_reg_28910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_50_1_phi_fu_31992_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_50_1_phi_fu_31992_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_50_1_phi_fu_31992_p32 = res_50_V_write_assign172_reg_27602.read();
    } else {
        ap_phi_mux_acc_V_50_1_phi_fu_31992_p32 = ap_phi_reg_pp0_iter3_acc_V_50_1_reg_31988.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_51_1_phi_fu_31938_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_51_1_phi_fu_31938_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_51_1_phi_fu_31938_p32 = res_51_V_write_assign170_reg_27616.read();
    } else {
        ap_phi_mux_acc_V_51_1_phi_fu_31938_p32 = ap_phi_reg_pp0_iter3_acc_V_51_1_reg_31934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_52_1_phi_fu_31884_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_52_1_phi_fu_31884_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_52_1_phi_fu_31884_p32 = res_52_V_write_assign168_reg_27630.read();
    } else {
        ap_phi_mux_acc_V_52_1_phi_fu_31884_p32 = ap_phi_reg_pp0_iter3_acc_V_52_1_reg_31880.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_53_1_phi_fu_31830_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_53_1_phi_fu_31830_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_53_1_phi_fu_31830_p32 = res_53_V_write_assign166_reg_27644.read();
    } else {
        ap_phi_mux_acc_V_53_1_phi_fu_31830_p32 = ap_phi_reg_pp0_iter3_acc_V_53_1_reg_31826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_54_1_phi_fu_31776_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_54_1_phi_fu_31776_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_54_1_phi_fu_31776_p32 = res_54_V_write_assign164_reg_27658.read();
    } else {
        ap_phi_mux_acc_V_54_1_phi_fu_31776_p32 = ap_phi_reg_pp0_iter3_acc_V_54_1_reg_31772.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_55_1_phi_fu_31722_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_55_1_phi_fu_31722_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_55_1_phi_fu_31722_p32 = res_55_V_write_assign162_reg_27672.read();
    } else {
        ap_phi_mux_acc_V_55_1_phi_fu_31722_p32 = ap_phi_reg_pp0_iter3_acc_V_55_1_reg_31718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_56_1_phi_fu_31668_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_56_1_phi_fu_31668_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_56_1_phi_fu_31668_p32 = res_56_V_write_assign160_reg_27686.read();
    } else {
        ap_phi_mux_acc_V_56_1_phi_fu_31668_p32 = ap_phi_reg_pp0_iter3_acc_V_56_1_reg_31664.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_57_1_phi_fu_31614_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_57_1_phi_fu_31614_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_57_1_phi_fu_31614_p32 = res_57_V_write_assign158_reg_27700.read();
    } else {
        ap_phi_mux_acc_V_57_1_phi_fu_31614_p32 = ap_phi_reg_pp0_iter3_acc_V_57_1_reg_31610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_58_1_phi_fu_31560_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_58_1_phi_fu_31560_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_58_1_phi_fu_31560_p32 = res_58_V_write_assign156_reg_27714.read();
    } else {
        ap_phi_mux_acc_V_58_1_phi_fu_31560_p32 = ap_phi_reg_pp0_iter3_acc_V_58_1_reg_31556.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_59_1_phi_fu_31506_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_59_1_phi_fu_31506_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_59_1_phi_fu_31506_p32 = res_59_V_write_assign154_reg_27728.read();
    } else {
        ap_phi_mux_acc_V_59_1_phi_fu_31506_p32 = ap_phi_reg_pp0_iter3_acc_V_59_1_reg_31502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_5_1_phi_fu_28968_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_5_1_phi_fu_28968_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_5_1_phi_fu_28968_p32 = res_5_V_write_assign244_reg_27098.read();
    } else {
        ap_phi_mux_acc_V_5_1_phi_fu_28968_p32 = ap_phi_reg_pp0_iter3_acc_V_5_1_reg_28964.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_60_1_phi_fu_31452_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_60_1_phi_fu_31452_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_60_1_phi_fu_31452_p32 = res_60_V_write_assign152_reg_27742.read();
    } else {
        ap_phi_mux_acc_V_60_1_phi_fu_31452_p32 = ap_phi_reg_pp0_iter3_acc_V_60_1_reg_31448.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_61_1_phi_fu_31398_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_61_1_phi_fu_31398_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_61_1_phi_fu_31398_p32 = res_61_V_write_assign150_reg_27756.read();
    } else {
        ap_phi_mux_acc_V_61_1_phi_fu_31398_p32 = ap_phi_reg_pp0_iter3_acc_V_61_1_reg_31394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_62_1_phi_fu_31344_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_62_1_phi_fu_31344_p32 = acc_48_V_fu_38284_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_62_1_phi_fu_31344_p32 = res_62_V_write_assign148_reg_27770.read();
    } else {
        ap_phi_mux_acc_V_62_1_phi_fu_31344_p32 = ap_phi_reg_pp0_iter3_acc_V_62_1_reg_31340.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_63_1_phi_fu_31290_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_63_1_phi_fu_31290_p32 = res_63_V_write_assign146_reg_27784.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_63_1_phi_fu_31290_p32 = acc_48_V_fu_38284_p2.read();
    } else {
        ap_phi_mux_acc_V_63_1_phi_fu_31290_p32 = ap_phi_reg_pp0_iter3_acc_V_63_1_reg_31286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_64_1_phi_fu_32964_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40)) {
        ap_phi_mux_acc_V_64_1_phi_fu_32964_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_64_1_phi_fu_32964_p32 = res_64_V_write_assign144_reg_27798.read();
    } else {
        ap_phi_mux_acc_V_64_1_phi_fu_32964_p32 = ap_phi_reg_pp0_iter3_acc_V_64_1_reg_32960.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_65_1_phi_fu_32910_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41)) {
        ap_phi_mux_acc_V_65_1_phi_fu_32910_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_65_1_phi_fu_32910_p32 = res_65_V_write_assign142_reg_27812.read();
    } else {
        ap_phi_mux_acc_V_65_1_phi_fu_32910_p32 = ap_phi_reg_pp0_iter3_acc_V_65_1_reg_32906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_66_1_phi_fu_32856_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42)) {
        ap_phi_mux_acc_V_66_1_phi_fu_32856_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_66_1_phi_fu_32856_p32 = res_66_V_write_assign140_reg_27826.read();
    } else {
        ap_phi_mux_acc_V_66_1_phi_fu_32856_p32 = ap_phi_reg_pp0_iter3_acc_V_66_1_reg_32852.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_67_1_phi_fu_32802_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43)) {
        ap_phi_mux_acc_V_67_1_phi_fu_32802_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_67_1_phi_fu_32802_p32 = res_67_V_write_assign138_reg_27840.read();
    } else {
        ap_phi_mux_acc_V_67_1_phi_fu_32802_p32 = ap_phi_reg_pp0_iter3_acc_V_67_1_reg_32798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_68_1_phi_fu_32748_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44)) {
        ap_phi_mux_acc_V_68_1_phi_fu_32748_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_68_1_phi_fu_32748_p32 = res_68_V_write_assign136_reg_27854.read();
    } else {
        ap_phi_mux_acc_V_68_1_phi_fu_32748_p32 = ap_phi_reg_pp0_iter3_acc_V_68_1_reg_32744.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_69_1_phi_fu_32694_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45)) {
        ap_phi_mux_acc_V_69_1_phi_fu_32694_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_69_1_phi_fu_32694_p32 = res_69_V_write_assign134_reg_27868.read();
    } else {
        ap_phi_mux_acc_V_69_1_phi_fu_32694_p32 = ap_phi_reg_pp0_iter3_acc_V_69_1_reg_32690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_6_1_phi_fu_29022_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_6_1_phi_fu_29022_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_6_1_phi_fu_29022_p32 = res_6_V_write_assign246_reg_27084.read();
    } else {
        ap_phi_mux_acc_V_6_1_phi_fu_29022_p32 = ap_phi_reg_pp0_iter3_acc_V_6_1_reg_29018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_70_1_phi_fu_32640_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46)) {
        ap_phi_mux_acc_V_70_1_phi_fu_32640_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_70_1_phi_fu_32640_p32 = res_70_V_write_assign132_reg_27882.read();
    } else {
        ap_phi_mux_acc_V_70_1_phi_fu_32640_p32 = ap_phi_reg_pp0_iter3_acc_V_70_1_reg_32636.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_71_1_phi_fu_32586_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47)) {
        ap_phi_mux_acc_V_71_1_phi_fu_32586_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_71_1_phi_fu_32586_p32 = res_71_V_write_assign130_reg_27896.read();
    } else {
        ap_phi_mux_acc_V_71_1_phi_fu_32586_p32 = ap_phi_reg_pp0_iter3_acc_V_71_1_reg_32582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_72_1_phi_fu_32532_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48)) {
        ap_phi_mux_acc_V_72_1_phi_fu_32532_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_72_1_phi_fu_32532_p32 = res_72_V_write_assign128_reg_27910.read();
    } else {
        ap_phi_mux_acc_V_72_1_phi_fu_32532_p32 = ap_phi_reg_pp0_iter3_acc_V_72_1_reg_32528.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_73_1_phi_fu_32478_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49)) {
        ap_phi_mux_acc_V_73_1_phi_fu_32478_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_73_1_phi_fu_32478_p32 = res_73_V_write_assign126_reg_27924.read();
    } else {
        ap_phi_mux_acc_V_73_1_phi_fu_32478_p32 = ap_phi_reg_pp0_iter3_acc_V_73_1_reg_32474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_74_1_phi_fu_32424_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A)) {
        ap_phi_mux_acc_V_74_1_phi_fu_32424_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_74_1_phi_fu_32424_p32 = res_74_V_write_assign124_reg_27938.read();
    } else {
        ap_phi_mux_acc_V_74_1_phi_fu_32424_p32 = ap_phi_reg_pp0_iter3_acc_V_74_1_reg_32420.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_75_1_phi_fu_32370_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B)) {
        ap_phi_mux_acc_V_75_1_phi_fu_32370_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_75_1_phi_fu_32370_p32 = res_75_V_write_assign122_reg_27952.read();
    } else {
        ap_phi_mux_acc_V_75_1_phi_fu_32370_p32 = ap_phi_reg_pp0_iter3_acc_V_75_1_reg_32366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_76_1_phi_fu_32316_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C)) {
        ap_phi_mux_acc_V_76_1_phi_fu_32316_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_76_1_phi_fu_32316_p32 = res_76_V_write_assign120_reg_27966.read();
    } else {
        ap_phi_mux_acc_V_76_1_phi_fu_32316_p32 = ap_phi_reg_pp0_iter3_acc_V_76_1_reg_32312.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_77_1_phi_fu_32262_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D)) {
        ap_phi_mux_acc_V_77_1_phi_fu_32262_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_77_1_phi_fu_32262_p32 = res_77_V_write_assign118_reg_27980.read();
    } else {
        ap_phi_mux_acc_V_77_1_phi_fu_32262_p32 = ap_phi_reg_pp0_iter3_acc_V_77_1_reg_32258.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_78_1_phi_fu_32208_p32() {
    if (esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)) {
        ap_phi_mux_acc_V_78_1_phi_fu_32208_p32 = acc_64_V_fu_38574_p2.read();
    } else if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
                esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
                (!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                 !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E)))) {
        ap_phi_mux_acc_V_78_1_phi_fu_32208_p32 = res_78_V_write_assign116_reg_27994.read();
    } else {
        ap_phi_mux_acc_V_78_1_phi_fu_32208_p32 = ap_phi_reg_pp0_iter3_acc_V_78_1_reg_32204.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_79_1_phi_fu_32154_p32() {
    if ((esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) || 
         esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E))) {
        ap_phi_mux_acc_V_79_1_phi_fu_32154_p32 = res_79_V_write_assign114_reg_28008.read();
    } else if ((!esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_40) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_41) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_42) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_43) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_44) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_45) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_46) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_47) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_48) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_49) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4A) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4B) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4C) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4D) && 
                !esl_seteq<1,7,7>(or_ln_fu_38305_p3.read(), ap_const_lv7_4E))) {
        ap_phi_mux_acc_V_79_1_phi_fu_32154_p32 = acc_64_V_fu_38574_p2.read();
    } else {
        ap_phi_mux_acc_V_79_1_phi_fu_32154_p32 = ap_phi_reg_pp0_iter3_acc_V_79_1_reg_32150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_7_1_phi_fu_29076_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_7_1_phi_fu_29076_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_7_1_phi_fu_29076_p32 = res_7_V_write_assign248_reg_27070.read();
    } else {
        ap_phi_mux_acc_V_7_1_phi_fu_29076_p32 = ap_phi_reg_pp0_iter3_acc_V_7_1_reg_29072.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_80_1_phi_fu_33828_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_80_1_phi_fu_33828_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_80_1_phi_fu_33828_p32 = res_80_V_write_assign112_reg_28022.read();
    } else {
        ap_phi_mux_acc_V_80_1_phi_fu_33828_p32 = ap_phi_reg_pp0_iter3_acc_V_80_1_reg_33824.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_81_1_phi_fu_33774_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_81_1_phi_fu_33774_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_81_1_phi_fu_33774_p32 = res_81_V_write_assign110_reg_28036.read();
    } else {
        ap_phi_mux_acc_V_81_1_phi_fu_33774_p32 = ap_phi_reg_pp0_iter3_acc_V_81_1_reg_33770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_82_1_phi_fu_33720_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_82_1_phi_fu_33720_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_82_1_phi_fu_33720_p32 = res_82_V_write_assign108_reg_28050.read();
    } else {
        ap_phi_mux_acc_V_82_1_phi_fu_33720_p32 = ap_phi_reg_pp0_iter3_acc_V_82_1_reg_33716.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_83_1_phi_fu_33666_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_83_1_phi_fu_33666_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_83_1_phi_fu_33666_p32 = res_83_V_write_assign106_reg_28064.read();
    } else {
        ap_phi_mux_acc_V_83_1_phi_fu_33666_p32 = ap_phi_reg_pp0_iter3_acc_V_83_1_reg_33662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_84_1_phi_fu_33612_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4)) {
        ap_phi_mux_acc_V_84_1_phi_fu_33612_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_84_1_phi_fu_33612_p32 = res_84_V_write_assign104_reg_28078.read();
    } else {
        ap_phi_mux_acc_V_84_1_phi_fu_33612_p32 = ap_phi_reg_pp0_iter3_acc_V_84_1_reg_33608.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_85_1_phi_fu_33558_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5)) {
        ap_phi_mux_acc_V_85_1_phi_fu_33558_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_85_1_phi_fu_33558_p32 = res_85_V_write_assign102_reg_28092.read();
    } else {
        ap_phi_mux_acc_V_85_1_phi_fu_33558_p32 = ap_phi_reg_pp0_iter3_acc_V_85_1_reg_33554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_86_1_phi_fu_33504_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6)) {
        ap_phi_mux_acc_V_86_1_phi_fu_33504_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_86_1_phi_fu_33504_p32 = res_86_V_write_assign100_reg_28106.read();
    } else {
        ap_phi_mux_acc_V_86_1_phi_fu_33504_p32 = ap_phi_reg_pp0_iter3_acc_V_86_1_reg_33500.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_87_1_phi_fu_33450_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7)) {
        ap_phi_mux_acc_V_87_1_phi_fu_33450_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_87_1_phi_fu_33450_p32 = res_87_V_write_assign98_reg_28120.read();
    } else {
        ap_phi_mux_acc_V_87_1_phi_fu_33450_p32 = ap_phi_reg_pp0_iter3_acc_V_87_1_reg_33446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_88_1_phi_fu_33396_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_88_1_phi_fu_33396_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_88_1_phi_fu_33396_p32 = res_88_V_write_assign96_reg_28134.read();
    } else {
        ap_phi_mux_acc_V_88_1_phi_fu_33396_p32 = ap_phi_reg_pp0_iter3_acc_V_88_1_reg_33392.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_89_1_phi_fu_33342_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_89_1_phi_fu_33342_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_89_1_phi_fu_33342_p32 = res_89_V_write_assign94_reg_28148.read();
    } else {
        ap_phi_mux_acc_V_89_1_phi_fu_33342_p32 = ap_phi_reg_pp0_iter3_acc_V_89_1_reg_33338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_8_1_phi_fu_29130_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8)) {
        ap_phi_mux_acc_V_8_1_phi_fu_29130_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_8_1_phi_fu_29130_p32 = res_8_V_write_assign250_reg_27056.read();
    } else {
        ap_phi_mux_acc_V_8_1_phi_fu_29130_p32 = ap_phi_reg_pp0_iter3_acc_V_8_1_reg_29126.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_90_1_phi_fu_33288_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A)) {
        ap_phi_mux_acc_V_90_1_phi_fu_33288_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_90_1_phi_fu_33288_p32 = res_90_V_write_assign92_reg_28162.read();
    } else {
        ap_phi_mux_acc_V_90_1_phi_fu_33288_p32 = ap_phi_reg_pp0_iter3_acc_V_90_1_reg_33284.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_91_1_phi_fu_33234_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B)) {
        ap_phi_mux_acc_V_91_1_phi_fu_33234_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_91_1_phi_fu_33234_p32 = res_91_V_write_assign90_reg_28176.read();
    } else {
        ap_phi_mux_acc_V_91_1_phi_fu_33234_p32 = ap_phi_reg_pp0_iter3_acc_V_91_1_reg_33230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_92_1_phi_fu_33180_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C)) {
        ap_phi_mux_acc_V_92_1_phi_fu_33180_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_92_1_phi_fu_33180_p32 = res_92_V_write_assign88_reg_28190.read();
    } else {
        ap_phi_mux_acc_V_92_1_phi_fu_33180_p32 = ap_phi_reg_pp0_iter3_acc_V_92_1_reg_33176.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_93_1_phi_fu_33126_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D)) {
        ap_phi_mux_acc_V_93_1_phi_fu_33126_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_93_1_phi_fu_33126_p32 = res_93_V_write_assign86_reg_28204.read();
    } else {
        ap_phi_mux_acc_V_93_1_phi_fu_33126_p32 = ap_phi_reg_pp0_iter3_acc_V_93_1_reg_33122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_94_1_phi_fu_33072_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E)) {
        ap_phi_mux_acc_V_94_1_phi_fu_33072_p32 = acc_80_V_fu_38857_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_94_1_phi_fu_33072_p32 = res_94_V_write_assign84_reg_28218.read();
    } else {
        ap_phi_mux_acc_V_94_1_phi_fu_33072_p32 = ap_phi_reg_pp0_iter3_acc_V_94_1_reg_33068.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_95_1_phi_fu_33018_p32() {
    if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
         esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_95_1_phi_fu_33018_p32 = res_95_V_write_assign82_reg_28232.read();
    } else if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F)) {
        ap_phi_mux_acc_V_95_1_phi_fu_33018_p32 = acc_80_V_fu_38857_p2.read();
    } else {
        ap_phi_mux_acc_V_95_1_phi_fu_33018_p32 = ap_phi_reg_pp0_iter3_acc_V_95_1_reg_33014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_96_1_phi_fu_34692_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0)) {
        ap_phi_mux_acc_V_96_1_phi_fu_34692_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1))) {
        ap_phi_mux_acc_V_96_1_phi_fu_34692_p32 = res_96_V_write_assign80_reg_28246.read();
    } else {
        ap_phi_mux_acc_V_96_1_phi_fu_34692_p32 = ap_phi_reg_pp0_iter3_acc_V_96_1_reg_34688.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_97_1_phi_fu_34638_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1)) {
        ap_phi_mux_acc_V_97_1_phi_fu_34638_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_97_1_phi_fu_34638_p32 = res_97_V_write_assign78_reg_28260.read();
    } else {
        ap_phi_mux_acc_V_97_1_phi_fu_34638_p32 = ap_phi_reg_pp0_iter3_acc_V_97_1_reg_34634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_98_1_phi_fu_34584_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2)) {
        ap_phi_mux_acc_V_98_1_phi_fu_34584_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_98_1_phi_fu_34584_p32 = res_98_V_write_assign76_reg_28274.read();
    } else {
        ap_phi_mux_acc_V_98_1_phi_fu_34584_p32 = ap_phi_reg_pp0_iter3_acc_V_98_1_reg_34580.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_99_1_phi_fu_34530_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3)) {
        ap_phi_mux_acc_V_99_1_phi_fu_34530_p32 = acc_96_V_fu_39140_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_99_1_phi_fu_34530_p32 = res_99_V_write_assign74_reg_28288.read();
    } else {
        ap_phi_mux_acc_V_99_1_phi_fu_34530_p32 = ap_phi_reg_pp0_iter3_acc_V_99_1_reg_34526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_acc_V_9_1_phi_fu_29184_p32() {
    if (esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_9)) {
        ap_phi_mux_acc_V_9_1_phi_fu_29184_p32 = acc_0_V_fu_37435_p2.read();
    } else if ((esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_F) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_E) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_D) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_C) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_B) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_A) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_8) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_7) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_6) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_5) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_4) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_3) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_2) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_1) || 
                esl_seteq<1,4,4>(out_index_reg_44211_pp0_iter2_reg.read(), ap_const_lv4_0))) {
        ap_phi_mux_acc_V_9_1_phi_fu_29184_p32 = res_9_V_write_assign252_reg_27042.read();
    } else {
        ap_phi_mux_acc_V_9_1_phi_fu_29184_p32 = ap_phi_reg_pp0_iter3_acc_V_9_1_reg_29180.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_0_V_read275_phi_phi_fu_17498_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_0_V_read275_phi_phi_fu_17498_p4 = ap_phi_mux_data_0_V_read275_rewind_phi_fu_6508_p6.read();
    } else {
        ap_phi_mux_data_0_V_read275_phi_phi_fu_17498_p4 = ap_phi_reg_pp0_iter1_data_0_V_read275_phi_reg_17494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_0_V_read275_rewind_phi_fu_6508_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_0_V_read275_rewind_phi_fu_6508_p6 = data_0_V_read275_phi_reg_17494.read();
    } else {
        ap_phi_mux_data_0_V_read275_rewind_phi_fu_6508_p6 = data_0_V_read275_rewind_reg_6504.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_100_V_read375_phi_phi_fu_18698_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_100_V_read375_phi_phi_fu_18698_p4 = ap_phi_mux_data_100_V_read375_rewind_phi_fu_7908_p6.read();
    } else {
        ap_phi_mux_data_100_V_read375_phi_phi_fu_18698_p4 = ap_phi_reg_pp0_iter1_data_100_V_read375_phi_reg_18694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_100_V_read375_rewind_phi_fu_7908_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_100_V_read375_rewind_phi_fu_7908_p6 = data_100_V_read375_phi_reg_18694.read();
    } else {
        ap_phi_mux_data_100_V_read375_rewind_phi_fu_7908_p6 = data_100_V_read375_rewind_reg_7904.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_101_V_read376_phi_phi_fu_18710_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_101_V_read376_phi_phi_fu_18710_p4 = ap_phi_mux_data_101_V_read376_rewind_phi_fu_7922_p6.read();
    } else {
        ap_phi_mux_data_101_V_read376_phi_phi_fu_18710_p4 = ap_phi_reg_pp0_iter1_data_101_V_read376_phi_reg_18706.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_101_V_read376_rewind_phi_fu_7922_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_101_V_read376_rewind_phi_fu_7922_p6 = data_101_V_read376_phi_reg_18706.read();
    } else {
        ap_phi_mux_data_101_V_read376_rewind_phi_fu_7922_p6 = data_101_V_read376_rewind_reg_7918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_102_V_read377_phi_phi_fu_18722_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_102_V_read377_phi_phi_fu_18722_p4 = ap_phi_mux_data_102_V_read377_rewind_phi_fu_7936_p6.read();
    } else {
        ap_phi_mux_data_102_V_read377_phi_phi_fu_18722_p4 = ap_phi_reg_pp0_iter1_data_102_V_read377_phi_reg_18718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_102_V_read377_rewind_phi_fu_7936_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_102_V_read377_rewind_phi_fu_7936_p6 = data_102_V_read377_phi_reg_18718.read();
    } else {
        ap_phi_mux_data_102_V_read377_rewind_phi_fu_7936_p6 = data_102_V_read377_rewind_reg_7932.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_103_V_read378_phi_phi_fu_18734_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_103_V_read378_phi_phi_fu_18734_p4 = ap_phi_mux_data_103_V_read378_rewind_phi_fu_7950_p6.read();
    } else {
        ap_phi_mux_data_103_V_read378_phi_phi_fu_18734_p4 = ap_phi_reg_pp0_iter1_data_103_V_read378_phi_reg_18730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_103_V_read378_rewind_phi_fu_7950_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_103_V_read378_rewind_phi_fu_7950_p6 = data_103_V_read378_phi_reg_18730.read();
    } else {
        ap_phi_mux_data_103_V_read378_rewind_phi_fu_7950_p6 = data_103_V_read378_rewind_reg_7946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_104_V_read379_phi_phi_fu_18746_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_104_V_read379_phi_phi_fu_18746_p4 = ap_phi_mux_data_104_V_read379_rewind_phi_fu_7964_p6.read();
    } else {
        ap_phi_mux_data_104_V_read379_phi_phi_fu_18746_p4 = ap_phi_reg_pp0_iter1_data_104_V_read379_phi_reg_18742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_104_V_read379_rewind_phi_fu_7964_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_104_V_read379_rewind_phi_fu_7964_p6 = data_104_V_read379_phi_reg_18742.read();
    } else {
        ap_phi_mux_data_104_V_read379_rewind_phi_fu_7964_p6 = data_104_V_read379_rewind_reg_7960.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_105_V_read380_phi_phi_fu_18758_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_105_V_read380_phi_phi_fu_18758_p4 = ap_phi_mux_data_105_V_read380_rewind_phi_fu_7978_p6.read();
    } else {
        ap_phi_mux_data_105_V_read380_phi_phi_fu_18758_p4 = ap_phi_reg_pp0_iter1_data_105_V_read380_phi_reg_18754.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_105_V_read380_rewind_phi_fu_7978_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_105_V_read380_rewind_phi_fu_7978_p6 = data_105_V_read380_phi_reg_18754.read();
    } else {
        ap_phi_mux_data_105_V_read380_rewind_phi_fu_7978_p6 = data_105_V_read380_rewind_reg_7974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_106_V_read381_phi_phi_fu_18770_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_106_V_read381_phi_phi_fu_18770_p4 = ap_phi_mux_data_106_V_read381_rewind_phi_fu_7992_p6.read();
    } else {
        ap_phi_mux_data_106_V_read381_phi_phi_fu_18770_p4 = ap_phi_reg_pp0_iter1_data_106_V_read381_phi_reg_18766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_106_V_read381_rewind_phi_fu_7992_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_106_V_read381_rewind_phi_fu_7992_p6 = data_106_V_read381_phi_reg_18766.read();
    } else {
        ap_phi_mux_data_106_V_read381_rewind_phi_fu_7992_p6 = data_106_V_read381_rewind_reg_7988.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_107_V_read382_phi_phi_fu_18782_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_107_V_read382_phi_phi_fu_18782_p4 = ap_phi_mux_data_107_V_read382_rewind_phi_fu_8006_p6.read();
    } else {
        ap_phi_mux_data_107_V_read382_phi_phi_fu_18782_p4 = ap_phi_reg_pp0_iter1_data_107_V_read382_phi_reg_18778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_107_V_read382_rewind_phi_fu_8006_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_107_V_read382_rewind_phi_fu_8006_p6 = data_107_V_read382_phi_reg_18778.read();
    } else {
        ap_phi_mux_data_107_V_read382_rewind_phi_fu_8006_p6 = data_107_V_read382_rewind_reg_8002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_108_V_read383_phi_phi_fu_18794_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_108_V_read383_phi_phi_fu_18794_p4 = ap_phi_mux_data_108_V_read383_rewind_phi_fu_8020_p6.read();
    } else {
        ap_phi_mux_data_108_V_read383_phi_phi_fu_18794_p4 = ap_phi_reg_pp0_iter1_data_108_V_read383_phi_reg_18790.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_108_V_read383_rewind_phi_fu_8020_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_108_V_read383_rewind_phi_fu_8020_p6 = data_108_V_read383_phi_reg_18790.read();
    } else {
        ap_phi_mux_data_108_V_read383_rewind_phi_fu_8020_p6 = data_108_V_read383_rewind_reg_8016.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_109_V_read384_phi_phi_fu_18806_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_109_V_read384_phi_phi_fu_18806_p4 = ap_phi_mux_data_109_V_read384_rewind_phi_fu_8034_p6.read();
    } else {
        ap_phi_mux_data_109_V_read384_phi_phi_fu_18806_p4 = ap_phi_reg_pp0_iter1_data_109_V_read384_phi_reg_18802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_109_V_read384_rewind_phi_fu_8034_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_109_V_read384_rewind_phi_fu_8034_p6 = data_109_V_read384_phi_reg_18802.read();
    } else {
        ap_phi_mux_data_109_V_read384_rewind_phi_fu_8034_p6 = data_109_V_read384_rewind_reg_8030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_10_V_read285_phi_phi_fu_17618_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_10_V_read285_phi_phi_fu_17618_p4 = ap_phi_mux_data_10_V_read285_rewind_phi_fu_6648_p6.read();
    } else {
        ap_phi_mux_data_10_V_read285_phi_phi_fu_17618_p4 = ap_phi_reg_pp0_iter1_data_10_V_read285_phi_reg_17614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_10_V_read285_rewind_phi_fu_6648_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_10_V_read285_rewind_phi_fu_6648_p6 = data_10_V_read285_phi_reg_17614.read();
    } else {
        ap_phi_mux_data_10_V_read285_rewind_phi_fu_6648_p6 = data_10_V_read285_rewind_reg_6644.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_110_V_read385_phi_phi_fu_18818_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_110_V_read385_phi_phi_fu_18818_p4 = ap_phi_mux_data_110_V_read385_rewind_phi_fu_8048_p6.read();
    } else {
        ap_phi_mux_data_110_V_read385_phi_phi_fu_18818_p4 = ap_phi_reg_pp0_iter1_data_110_V_read385_phi_reg_18814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_110_V_read385_rewind_phi_fu_8048_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_110_V_read385_rewind_phi_fu_8048_p6 = data_110_V_read385_phi_reg_18814.read();
    } else {
        ap_phi_mux_data_110_V_read385_rewind_phi_fu_8048_p6 = data_110_V_read385_rewind_reg_8044.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_111_V_read386_phi_phi_fu_18830_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_111_V_read386_phi_phi_fu_18830_p4 = ap_phi_mux_data_111_V_read386_rewind_phi_fu_8062_p6.read();
    } else {
        ap_phi_mux_data_111_V_read386_phi_phi_fu_18830_p4 = ap_phi_reg_pp0_iter1_data_111_V_read386_phi_reg_18826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_111_V_read386_rewind_phi_fu_8062_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_111_V_read386_rewind_phi_fu_8062_p6 = data_111_V_read386_phi_reg_18826.read();
    } else {
        ap_phi_mux_data_111_V_read386_rewind_phi_fu_8062_p6 = data_111_V_read386_rewind_reg_8058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_112_V_read387_phi_phi_fu_18842_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_112_V_read387_phi_phi_fu_18842_p4 = ap_phi_mux_data_112_V_read387_rewind_phi_fu_8076_p6.read();
    } else {
        ap_phi_mux_data_112_V_read387_phi_phi_fu_18842_p4 = ap_phi_reg_pp0_iter1_data_112_V_read387_phi_reg_18838.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_112_V_read387_rewind_phi_fu_8076_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_112_V_read387_rewind_phi_fu_8076_p6 = data_112_V_read387_phi_reg_18838.read();
    } else {
        ap_phi_mux_data_112_V_read387_rewind_phi_fu_8076_p6 = data_112_V_read387_rewind_reg_8072.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_113_V_read388_phi_phi_fu_18854_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_113_V_read388_phi_phi_fu_18854_p4 = ap_phi_mux_data_113_V_read388_rewind_phi_fu_8090_p6.read();
    } else {
        ap_phi_mux_data_113_V_read388_phi_phi_fu_18854_p4 = ap_phi_reg_pp0_iter1_data_113_V_read388_phi_reg_18850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_113_V_read388_rewind_phi_fu_8090_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_113_V_read388_rewind_phi_fu_8090_p6 = data_113_V_read388_phi_reg_18850.read();
    } else {
        ap_phi_mux_data_113_V_read388_rewind_phi_fu_8090_p6 = data_113_V_read388_rewind_reg_8086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_114_V_read389_phi_phi_fu_18866_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_114_V_read389_phi_phi_fu_18866_p4 = ap_phi_mux_data_114_V_read389_rewind_phi_fu_8104_p6.read();
    } else {
        ap_phi_mux_data_114_V_read389_phi_phi_fu_18866_p4 = ap_phi_reg_pp0_iter1_data_114_V_read389_phi_reg_18862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_114_V_read389_rewind_phi_fu_8104_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_114_V_read389_rewind_phi_fu_8104_p6 = data_114_V_read389_phi_reg_18862.read();
    } else {
        ap_phi_mux_data_114_V_read389_rewind_phi_fu_8104_p6 = data_114_V_read389_rewind_reg_8100.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_115_V_read390_phi_phi_fu_18878_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_115_V_read390_phi_phi_fu_18878_p4 = ap_phi_mux_data_115_V_read390_rewind_phi_fu_8118_p6.read();
    } else {
        ap_phi_mux_data_115_V_read390_phi_phi_fu_18878_p4 = ap_phi_reg_pp0_iter1_data_115_V_read390_phi_reg_18874.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_115_V_read390_rewind_phi_fu_8118_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_115_V_read390_rewind_phi_fu_8118_p6 = data_115_V_read390_phi_reg_18874.read();
    } else {
        ap_phi_mux_data_115_V_read390_rewind_phi_fu_8118_p6 = data_115_V_read390_rewind_reg_8114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_116_V_read391_phi_phi_fu_18890_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_116_V_read391_phi_phi_fu_18890_p4 = ap_phi_mux_data_116_V_read391_rewind_phi_fu_8132_p6.read();
    } else {
        ap_phi_mux_data_116_V_read391_phi_phi_fu_18890_p4 = ap_phi_reg_pp0_iter1_data_116_V_read391_phi_reg_18886.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_116_V_read391_rewind_phi_fu_8132_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_116_V_read391_rewind_phi_fu_8132_p6 = data_116_V_read391_phi_reg_18886.read();
    } else {
        ap_phi_mux_data_116_V_read391_rewind_phi_fu_8132_p6 = data_116_V_read391_rewind_reg_8128.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_117_V_read392_phi_phi_fu_18902_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_117_V_read392_phi_phi_fu_18902_p4 = ap_phi_mux_data_117_V_read392_rewind_phi_fu_8146_p6.read();
    } else {
        ap_phi_mux_data_117_V_read392_phi_phi_fu_18902_p4 = ap_phi_reg_pp0_iter1_data_117_V_read392_phi_reg_18898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_117_V_read392_rewind_phi_fu_8146_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_117_V_read392_rewind_phi_fu_8146_p6 = data_117_V_read392_phi_reg_18898.read();
    } else {
        ap_phi_mux_data_117_V_read392_rewind_phi_fu_8146_p6 = data_117_V_read392_rewind_reg_8142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_118_V_read393_phi_phi_fu_18914_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_118_V_read393_phi_phi_fu_18914_p4 = ap_phi_mux_data_118_V_read393_rewind_phi_fu_8160_p6.read();
    } else {
        ap_phi_mux_data_118_V_read393_phi_phi_fu_18914_p4 = ap_phi_reg_pp0_iter1_data_118_V_read393_phi_reg_18910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_118_V_read393_rewind_phi_fu_8160_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_118_V_read393_rewind_phi_fu_8160_p6 = data_118_V_read393_phi_reg_18910.read();
    } else {
        ap_phi_mux_data_118_V_read393_rewind_phi_fu_8160_p6 = data_118_V_read393_rewind_reg_8156.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_119_V_read394_phi_phi_fu_18926_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_119_V_read394_phi_phi_fu_18926_p4 = ap_phi_mux_data_119_V_read394_rewind_phi_fu_8174_p6.read();
    } else {
        ap_phi_mux_data_119_V_read394_phi_phi_fu_18926_p4 = ap_phi_reg_pp0_iter1_data_119_V_read394_phi_reg_18922.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_119_V_read394_rewind_phi_fu_8174_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_119_V_read394_rewind_phi_fu_8174_p6 = data_119_V_read394_phi_reg_18922.read();
    } else {
        ap_phi_mux_data_119_V_read394_rewind_phi_fu_8174_p6 = data_119_V_read394_rewind_reg_8170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_11_V_read286_phi_phi_fu_17630_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_11_V_read286_phi_phi_fu_17630_p4 = ap_phi_mux_data_11_V_read286_rewind_phi_fu_6662_p6.read();
    } else {
        ap_phi_mux_data_11_V_read286_phi_phi_fu_17630_p4 = ap_phi_reg_pp0_iter1_data_11_V_read286_phi_reg_17626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_11_V_read286_rewind_phi_fu_6662_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_11_V_read286_rewind_phi_fu_6662_p6 = data_11_V_read286_phi_reg_17626.read();
    } else {
        ap_phi_mux_data_11_V_read286_rewind_phi_fu_6662_p6 = data_11_V_read286_rewind_reg_6658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_120_V_read395_phi_phi_fu_18938_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_120_V_read395_phi_phi_fu_18938_p4 = ap_phi_mux_data_120_V_read395_rewind_phi_fu_8188_p6.read();
    } else {
        ap_phi_mux_data_120_V_read395_phi_phi_fu_18938_p4 = ap_phi_reg_pp0_iter1_data_120_V_read395_phi_reg_18934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_120_V_read395_rewind_phi_fu_8188_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_120_V_read395_rewind_phi_fu_8188_p6 = data_120_V_read395_phi_reg_18934.read();
    } else {
        ap_phi_mux_data_120_V_read395_rewind_phi_fu_8188_p6 = data_120_V_read395_rewind_reg_8184.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_121_V_read396_phi_phi_fu_18950_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_121_V_read396_phi_phi_fu_18950_p4 = ap_phi_mux_data_121_V_read396_rewind_phi_fu_8202_p6.read();
    } else {
        ap_phi_mux_data_121_V_read396_phi_phi_fu_18950_p4 = ap_phi_reg_pp0_iter1_data_121_V_read396_phi_reg_18946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_121_V_read396_rewind_phi_fu_8202_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_121_V_read396_rewind_phi_fu_8202_p6 = data_121_V_read396_phi_reg_18946.read();
    } else {
        ap_phi_mux_data_121_V_read396_rewind_phi_fu_8202_p6 = data_121_V_read396_rewind_reg_8198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_122_V_read397_phi_phi_fu_18962_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_122_V_read397_phi_phi_fu_18962_p4 = ap_phi_mux_data_122_V_read397_rewind_phi_fu_8216_p6.read();
    } else {
        ap_phi_mux_data_122_V_read397_phi_phi_fu_18962_p4 = ap_phi_reg_pp0_iter1_data_122_V_read397_phi_reg_18958.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_122_V_read397_rewind_phi_fu_8216_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_122_V_read397_rewind_phi_fu_8216_p6 = data_122_V_read397_phi_reg_18958.read();
    } else {
        ap_phi_mux_data_122_V_read397_rewind_phi_fu_8216_p6 = data_122_V_read397_rewind_reg_8212.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_123_V_read398_phi_phi_fu_18974_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_123_V_read398_phi_phi_fu_18974_p4 = ap_phi_mux_data_123_V_read398_rewind_phi_fu_8230_p6.read();
    } else {
        ap_phi_mux_data_123_V_read398_phi_phi_fu_18974_p4 = ap_phi_reg_pp0_iter1_data_123_V_read398_phi_reg_18970.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_123_V_read398_rewind_phi_fu_8230_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_123_V_read398_rewind_phi_fu_8230_p6 = data_123_V_read398_phi_reg_18970.read();
    } else {
        ap_phi_mux_data_123_V_read398_rewind_phi_fu_8230_p6 = data_123_V_read398_rewind_reg_8226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_124_V_read399_phi_phi_fu_18986_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_124_V_read399_phi_phi_fu_18986_p4 = ap_phi_mux_data_124_V_read399_rewind_phi_fu_8244_p6.read();
    } else {
        ap_phi_mux_data_124_V_read399_phi_phi_fu_18986_p4 = ap_phi_reg_pp0_iter1_data_124_V_read399_phi_reg_18982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_124_V_read399_rewind_phi_fu_8244_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_124_V_read399_rewind_phi_fu_8244_p6 = data_124_V_read399_phi_reg_18982.read();
    } else {
        ap_phi_mux_data_124_V_read399_rewind_phi_fu_8244_p6 = data_124_V_read399_rewind_reg_8240.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_125_V_read400_phi_phi_fu_18998_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_125_V_read400_phi_phi_fu_18998_p4 = ap_phi_mux_data_125_V_read400_rewind_phi_fu_8258_p6.read();
    } else {
        ap_phi_mux_data_125_V_read400_phi_phi_fu_18998_p4 = ap_phi_reg_pp0_iter1_data_125_V_read400_phi_reg_18994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_125_V_read400_rewind_phi_fu_8258_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_125_V_read400_rewind_phi_fu_8258_p6 = data_125_V_read400_phi_reg_18994.read();
    } else {
        ap_phi_mux_data_125_V_read400_rewind_phi_fu_8258_p6 = data_125_V_read400_rewind_reg_8254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_126_V_read401_phi_phi_fu_19010_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_126_V_read401_phi_phi_fu_19010_p4 = ap_phi_mux_data_126_V_read401_rewind_phi_fu_8272_p6.read();
    } else {
        ap_phi_mux_data_126_V_read401_phi_phi_fu_19010_p4 = ap_phi_reg_pp0_iter1_data_126_V_read401_phi_reg_19006.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_126_V_read401_rewind_phi_fu_8272_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_126_V_read401_rewind_phi_fu_8272_p6 = data_126_V_read401_phi_reg_19006.read();
    } else {
        ap_phi_mux_data_126_V_read401_rewind_phi_fu_8272_p6 = data_126_V_read401_rewind_reg_8268.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_127_V_read402_phi_phi_fu_19022_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_127_V_read402_phi_phi_fu_19022_p4 = ap_phi_mux_data_127_V_read402_rewind_phi_fu_8286_p6.read();
    } else {
        ap_phi_mux_data_127_V_read402_phi_phi_fu_19022_p4 = ap_phi_reg_pp0_iter1_data_127_V_read402_phi_reg_19018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_127_V_read402_rewind_phi_fu_8286_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_127_V_read402_rewind_phi_fu_8286_p6 = data_127_V_read402_phi_reg_19018.read();
    } else {
        ap_phi_mux_data_127_V_read402_rewind_phi_fu_8286_p6 = data_127_V_read402_rewind_reg_8282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_128_V_read403_phi_phi_fu_19034_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_128_V_read403_phi_phi_fu_19034_p4 = ap_phi_mux_data_128_V_read403_rewind_phi_fu_8300_p6.read();
    } else {
        ap_phi_mux_data_128_V_read403_phi_phi_fu_19034_p4 = ap_phi_reg_pp0_iter1_data_128_V_read403_phi_reg_19030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_128_V_read403_rewind_phi_fu_8300_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_128_V_read403_rewind_phi_fu_8300_p6 = data_128_V_read403_phi_reg_19030.read();
    } else {
        ap_phi_mux_data_128_V_read403_rewind_phi_fu_8300_p6 = data_128_V_read403_rewind_reg_8296.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_129_V_read404_phi_phi_fu_19046_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_129_V_read404_phi_phi_fu_19046_p4 = ap_phi_mux_data_129_V_read404_rewind_phi_fu_8314_p6.read();
    } else {
        ap_phi_mux_data_129_V_read404_phi_phi_fu_19046_p4 = ap_phi_reg_pp0_iter1_data_129_V_read404_phi_reg_19042.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_129_V_read404_rewind_phi_fu_8314_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_129_V_read404_rewind_phi_fu_8314_p6 = data_129_V_read404_phi_reg_19042.read();
    } else {
        ap_phi_mux_data_129_V_read404_rewind_phi_fu_8314_p6 = data_129_V_read404_rewind_reg_8310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_12_V_read287_phi_phi_fu_17642_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_12_V_read287_phi_phi_fu_17642_p4 = ap_phi_mux_data_12_V_read287_rewind_phi_fu_6676_p6.read();
    } else {
        ap_phi_mux_data_12_V_read287_phi_phi_fu_17642_p4 = ap_phi_reg_pp0_iter1_data_12_V_read287_phi_reg_17638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_12_V_read287_rewind_phi_fu_6676_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_12_V_read287_rewind_phi_fu_6676_p6 = data_12_V_read287_phi_reg_17638.read();
    } else {
        ap_phi_mux_data_12_V_read287_rewind_phi_fu_6676_p6 = data_12_V_read287_rewind_reg_6672.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_130_V_read405_phi_phi_fu_19058_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_130_V_read405_phi_phi_fu_19058_p4 = ap_phi_mux_data_130_V_read405_rewind_phi_fu_8328_p6.read();
    } else {
        ap_phi_mux_data_130_V_read405_phi_phi_fu_19058_p4 = ap_phi_reg_pp0_iter1_data_130_V_read405_phi_reg_19054.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_130_V_read405_rewind_phi_fu_8328_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_130_V_read405_rewind_phi_fu_8328_p6 = data_130_V_read405_phi_reg_19054.read();
    } else {
        ap_phi_mux_data_130_V_read405_rewind_phi_fu_8328_p6 = data_130_V_read405_rewind_reg_8324.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_131_V_read406_phi_phi_fu_19070_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_131_V_read406_phi_phi_fu_19070_p4 = ap_phi_mux_data_131_V_read406_rewind_phi_fu_8342_p6.read();
    } else {
        ap_phi_mux_data_131_V_read406_phi_phi_fu_19070_p4 = ap_phi_reg_pp0_iter1_data_131_V_read406_phi_reg_19066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_131_V_read406_rewind_phi_fu_8342_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_131_V_read406_rewind_phi_fu_8342_p6 = data_131_V_read406_phi_reg_19066.read();
    } else {
        ap_phi_mux_data_131_V_read406_rewind_phi_fu_8342_p6 = data_131_V_read406_rewind_reg_8338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_132_V_read407_phi_phi_fu_19082_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_132_V_read407_phi_phi_fu_19082_p4 = ap_phi_mux_data_132_V_read407_rewind_phi_fu_8356_p6.read();
    } else {
        ap_phi_mux_data_132_V_read407_phi_phi_fu_19082_p4 = ap_phi_reg_pp0_iter1_data_132_V_read407_phi_reg_19078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_132_V_read407_rewind_phi_fu_8356_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_132_V_read407_rewind_phi_fu_8356_p6 = data_132_V_read407_phi_reg_19078.read();
    } else {
        ap_phi_mux_data_132_V_read407_rewind_phi_fu_8356_p6 = data_132_V_read407_rewind_reg_8352.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_133_V_read408_phi_phi_fu_19094_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_133_V_read408_phi_phi_fu_19094_p4 = ap_phi_mux_data_133_V_read408_rewind_phi_fu_8370_p6.read();
    } else {
        ap_phi_mux_data_133_V_read408_phi_phi_fu_19094_p4 = ap_phi_reg_pp0_iter1_data_133_V_read408_phi_reg_19090.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_133_V_read408_rewind_phi_fu_8370_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_133_V_read408_rewind_phi_fu_8370_p6 = data_133_V_read408_phi_reg_19090.read();
    } else {
        ap_phi_mux_data_133_V_read408_rewind_phi_fu_8370_p6 = data_133_V_read408_rewind_reg_8366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_134_V_read409_phi_phi_fu_19106_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_134_V_read409_phi_phi_fu_19106_p4 = ap_phi_mux_data_134_V_read409_rewind_phi_fu_8384_p6.read();
    } else {
        ap_phi_mux_data_134_V_read409_phi_phi_fu_19106_p4 = ap_phi_reg_pp0_iter1_data_134_V_read409_phi_reg_19102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_134_V_read409_rewind_phi_fu_8384_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_134_V_read409_rewind_phi_fu_8384_p6 = data_134_V_read409_phi_reg_19102.read();
    } else {
        ap_phi_mux_data_134_V_read409_rewind_phi_fu_8384_p6 = data_134_V_read409_rewind_reg_8380.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_135_V_read410_phi_phi_fu_19118_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_135_V_read410_phi_phi_fu_19118_p4 = ap_phi_mux_data_135_V_read410_rewind_phi_fu_8398_p6.read();
    } else {
        ap_phi_mux_data_135_V_read410_phi_phi_fu_19118_p4 = ap_phi_reg_pp0_iter1_data_135_V_read410_phi_reg_19114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_135_V_read410_rewind_phi_fu_8398_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_135_V_read410_rewind_phi_fu_8398_p6 = data_135_V_read410_phi_reg_19114.read();
    } else {
        ap_phi_mux_data_135_V_read410_rewind_phi_fu_8398_p6 = data_135_V_read410_rewind_reg_8394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_136_V_read411_phi_phi_fu_19130_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_136_V_read411_phi_phi_fu_19130_p4 = ap_phi_mux_data_136_V_read411_rewind_phi_fu_8412_p6.read();
    } else {
        ap_phi_mux_data_136_V_read411_phi_phi_fu_19130_p4 = ap_phi_reg_pp0_iter1_data_136_V_read411_phi_reg_19126.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_136_V_read411_rewind_phi_fu_8412_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_136_V_read411_rewind_phi_fu_8412_p6 = data_136_V_read411_phi_reg_19126.read();
    } else {
        ap_phi_mux_data_136_V_read411_rewind_phi_fu_8412_p6 = data_136_V_read411_rewind_reg_8408.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_137_V_read412_phi_phi_fu_19142_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_137_V_read412_phi_phi_fu_19142_p4 = ap_phi_mux_data_137_V_read412_rewind_phi_fu_8426_p6.read();
    } else {
        ap_phi_mux_data_137_V_read412_phi_phi_fu_19142_p4 = ap_phi_reg_pp0_iter1_data_137_V_read412_phi_reg_19138.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_137_V_read412_rewind_phi_fu_8426_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_137_V_read412_rewind_phi_fu_8426_p6 = data_137_V_read412_phi_reg_19138.read();
    } else {
        ap_phi_mux_data_137_V_read412_rewind_phi_fu_8426_p6 = data_137_V_read412_rewind_reg_8422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_138_V_read413_phi_phi_fu_19154_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_138_V_read413_phi_phi_fu_19154_p4 = ap_phi_mux_data_138_V_read413_rewind_phi_fu_8440_p6.read();
    } else {
        ap_phi_mux_data_138_V_read413_phi_phi_fu_19154_p4 = ap_phi_reg_pp0_iter1_data_138_V_read413_phi_reg_19150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_138_V_read413_rewind_phi_fu_8440_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_138_V_read413_rewind_phi_fu_8440_p6 = data_138_V_read413_phi_reg_19150.read();
    } else {
        ap_phi_mux_data_138_V_read413_rewind_phi_fu_8440_p6 = data_138_V_read413_rewind_reg_8436.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_139_V_read414_phi_phi_fu_19166_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_139_V_read414_phi_phi_fu_19166_p4 = ap_phi_mux_data_139_V_read414_rewind_phi_fu_8454_p6.read();
    } else {
        ap_phi_mux_data_139_V_read414_phi_phi_fu_19166_p4 = ap_phi_reg_pp0_iter1_data_139_V_read414_phi_reg_19162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_139_V_read414_rewind_phi_fu_8454_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_139_V_read414_rewind_phi_fu_8454_p6 = data_139_V_read414_phi_reg_19162.read();
    } else {
        ap_phi_mux_data_139_V_read414_rewind_phi_fu_8454_p6 = data_139_V_read414_rewind_reg_8450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_13_V_read288_phi_phi_fu_17654_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_13_V_read288_phi_phi_fu_17654_p4 = ap_phi_mux_data_13_V_read288_rewind_phi_fu_6690_p6.read();
    } else {
        ap_phi_mux_data_13_V_read288_phi_phi_fu_17654_p4 = ap_phi_reg_pp0_iter1_data_13_V_read288_phi_reg_17650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_13_V_read288_rewind_phi_fu_6690_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_13_V_read288_rewind_phi_fu_6690_p6 = data_13_V_read288_phi_reg_17650.read();
    } else {
        ap_phi_mux_data_13_V_read288_rewind_phi_fu_6690_p6 = data_13_V_read288_rewind_reg_6686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_140_V_read415_phi_phi_fu_19178_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_140_V_read415_phi_phi_fu_19178_p4 = ap_phi_mux_data_140_V_read415_rewind_phi_fu_8468_p6.read();
    } else {
        ap_phi_mux_data_140_V_read415_phi_phi_fu_19178_p4 = ap_phi_reg_pp0_iter1_data_140_V_read415_phi_reg_19174.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_140_V_read415_rewind_phi_fu_8468_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_140_V_read415_rewind_phi_fu_8468_p6 = data_140_V_read415_phi_reg_19174.read();
    } else {
        ap_phi_mux_data_140_V_read415_rewind_phi_fu_8468_p6 = data_140_V_read415_rewind_reg_8464.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_141_V_read416_phi_phi_fu_19190_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_141_V_read416_phi_phi_fu_19190_p4 = ap_phi_mux_data_141_V_read416_rewind_phi_fu_8482_p6.read();
    } else {
        ap_phi_mux_data_141_V_read416_phi_phi_fu_19190_p4 = ap_phi_reg_pp0_iter1_data_141_V_read416_phi_reg_19186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_141_V_read416_rewind_phi_fu_8482_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_141_V_read416_rewind_phi_fu_8482_p6 = data_141_V_read416_phi_reg_19186.read();
    } else {
        ap_phi_mux_data_141_V_read416_rewind_phi_fu_8482_p6 = data_141_V_read416_rewind_reg_8478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_142_V_read417_phi_phi_fu_19202_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_142_V_read417_phi_phi_fu_19202_p4 = ap_phi_mux_data_142_V_read417_rewind_phi_fu_8496_p6.read();
    } else {
        ap_phi_mux_data_142_V_read417_phi_phi_fu_19202_p4 = ap_phi_reg_pp0_iter1_data_142_V_read417_phi_reg_19198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_142_V_read417_rewind_phi_fu_8496_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_142_V_read417_rewind_phi_fu_8496_p6 = data_142_V_read417_phi_reg_19198.read();
    } else {
        ap_phi_mux_data_142_V_read417_rewind_phi_fu_8496_p6 = data_142_V_read417_rewind_reg_8492.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_143_V_read418_phi_phi_fu_19214_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_143_V_read418_phi_phi_fu_19214_p4 = ap_phi_mux_data_143_V_read418_rewind_phi_fu_8510_p6.read();
    } else {
        ap_phi_mux_data_143_V_read418_phi_phi_fu_19214_p4 = ap_phi_reg_pp0_iter1_data_143_V_read418_phi_reg_19210.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_143_V_read418_rewind_phi_fu_8510_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_143_V_read418_rewind_phi_fu_8510_p6 = data_143_V_read418_phi_reg_19210.read();
    } else {
        ap_phi_mux_data_143_V_read418_rewind_phi_fu_8510_p6 = data_143_V_read418_rewind_reg_8506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_144_V_read419_phi_phi_fu_19226_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_144_V_read419_phi_phi_fu_19226_p4 = ap_phi_mux_data_144_V_read419_rewind_phi_fu_8524_p6.read();
    } else {
        ap_phi_mux_data_144_V_read419_phi_phi_fu_19226_p4 = ap_phi_reg_pp0_iter1_data_144_V_read419_phi_reg_19222.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_144_V_read419_rewind_phi_fu_8524_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_144_V_read419_rewind_phi_fu_8524_p6 = data_144_V_read419_phi_reg_19222.read();
    } else {
        ap_phi_mux_data_144_V_read419_rewind_phi_fu_8524_p6 = data_144_V_read419_rewind_reg_8520.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_145_V_read420_phi_phi_fu_19238_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_145_V_read420_phi_phi_fu_19238_p4 = ap_phi_mux_data_145_V_read420_rewind_phi_fu_8538_p6.read();
    } else {
        ap_phi_mux_data_145_V_read420_phi_phi_fu_19238_p4 = ap_phi_reg_pp0_iter1_data_145_V_read420_phi_reg_19234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_145_V_read420_rewind_phi_fu_8538_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_145_V_read420_rewind_phi_fu_8538_p6 = data_145_V_read420_phi_reg_19234.read();
    } else {
        ap_phi_mux_data_145_V_read420_rewind_phi_fu_8538_p6 = data_145_V_read420_rewind_reg_8534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_146_V_read421_phi_phi_fu_19250_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_146_V_read421_phi_phi_fu_19250_p4 = ap_phi_mux_data_146_V_read421_rewind_phi_fu_8552_p6.read();
    } else {
        ap_phi_mux_data_146_V_read421_phi_phi_fu_19250_p4 = ap_phi_reg_pp0_iter1_data_146_V_read421_phi_reg_19246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_146_V_read421_rewind_phi_fu_8552_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_146_V_read421_rewind_phi_fu_8552_p6 = data_146_V_read421_phi_reg_19246.read();
    } else {
        ap_phi_mux_data_146_V_read421_rewind_phi_fu_8552_p6 = data_146_V_read421_rewind_reg_8548.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_147_V_read422_phi_phi_fu_19262_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_147_V_read422_phi_phi_fu_19262_p4 = ap_phi_mux_data_147_V_read422_rewind_phi_fu_8566_p6.read();
    } else {
        ap_phi_mux_data_147_V_read422_phi_phi_fu_19262_p4 = ap_phi_reg_pp0_iter1_data_147_V_read422_phi_reg_19258.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_147_V_read422_rewind_phi_fu_8566_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_147_V_read422_rewind_phi_fu_8566_p6 = data_147_V_read422_phi_reg_19258.read();
    } else {
        ap_phi_mux_data_147_V_read422_rewind_phi_fu_8566_p6 = data_147_V_read422_rewind_reg_8562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_148_V_read423_phi_phi_fu_19274_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_148_V_read423_phi_phi_fu_19274_p4 = ap_phi_mux_data_148_V_read423_rewind_phi_fu_8580_p6.read();
    } else {
        ap_phi_mux_data_148_V_read423_phi_phi_fu_19274_p4 = ap_phi_reg_pp0_iter1_data_148_V_read423_phi_reg_19270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_148_V_read423_rewind_phi_fu_8580_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_148_V_read423_rewind_phi_fu_8580_p6 = data_148_V_read423_phi_reg_19270.read();
    } else {
        ap_phi_mux_data_148_V_read423_rewind_phi_fu_8580_p6 = data_148_V_read423_rewind_reg_8576.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_149_V_read424_phi_phi_fu_19286_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_149_V_read424_phi_phi_fu_19286_p4 = ap_phi_mux_data_149_V_read424_rewind_phi_fu_8594_p6.read();
    } else {
        ap_phi_mux_data_149_V_read424_phi_phi_fu_19286_p4 = ap_phi_reg_pp0_iter1_data_149_V_read424_phi_reg_19282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_149_V_read424_rewind_phi_fu_8594_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_149_V_read424_rewind_phi_fu_8594_p6 = data_149_V_read424_phi_reg_19282.read();
    } else {
        ap_phi_mux_data_149_V_read424_rewind_phi_fu_8594_p6 = data_149_V_read424_rewind_reg_8590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_14_V_read289_phi_phi_fu_17666_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_14_V_read289_phi_phi_fu_17666_p4 = ap_phi_mux_data_14_V_read289_rewind_phi_fu_6704_p6.read();
    } else {
        ap_phi_mux_data_14_V_read289_phi_phi_fu_17666_p4 = ap_phi_reg_pp0_iter1_data_14_V_read289_phi_reg_17662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_14_V_read289_rewind_phi_fu_6704_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_14_V_read289_rewind_phi_fu_6704_p6 = data_14_V_read289_phi_reg_17662.read();
    } else {
        ap_phi_mux_data_14_V_read289_rewind_phi_fu_6704_p6 = data_14_V_read289_rewind_reg_6700.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_150_V_read425_phi_phi_fu_19298_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_150_V_read425_phi_phi_fu_19298_p4 = ap_phi_mux_data_150_V_read425_rewind_phi_fu_8608_p6.read();
    } else {
        ap_phi_mux_data_150_V_read425_phi_phi_fu_19298_p4 = ap_phi_reg_pp0_iter1_data_150_V_read425_phi_reg_19294.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_150_V_read425_rewind_phi_fu_8608_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_150_V_read425_rewind_phi_fu_8608_p6 = data_150_V_read425_phi_reg_19294.read();
    } else {
        ap_phi_mux_data_150_V_read425_rewind_phi_fu_8608_p6 = data_150_V_read425_rewind_reg_8604.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_151_V_read426_phi_phi_fu_19310_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_151_V_read426_phi_phi_fu_19310_p4 = ap_phi_mux_data_151_V_read426_rewind_phi_fu_8622_p6.read();
    } else {
        ap_phi_mux_data_151_V_read426_phi_phi_fu_19310_p4 = ap_phi_reg_pp0_iter1_data_151_V_read426_phi_reg_19306.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_151_V_read426_rewind_phi_fu_8622_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_151_V_read426_rewind_phi_fu_8622_p6 = data_151_V_read426_phi_reg_19306.read();
    } else {
        ap_phi_mux_data_151_V_read426_rewind_phi_fu_8622_p6 = data_151_V_read426_rewind_reg_8618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_152_V_read427_phi_phi_fu_19322_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_152_V_read427_phi_phi_fu_19322_p4 = ap_phi_mux_data_152_V_read427_rewind_phi_fu_8636_p6.read();
    } else {
        ap_phi_mux_data_152_V_read427_phi_phi_fu_19322_p4 = ap_phi_reg_pp0_iter1_data_152_V_read427_phi_reg_19318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_152_V_read427_rewind_phi_fu_8636_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_152_V_read427_rewind_phi_fu_8636_p6 = data_152_V_read427_phi_reg_19318.read();
    } else {
        ap_phi_mux_data_152_V_read427_rewind_phi_fu_8636_p6 = data_152_V_read427_rewind_reg_8632.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_153_V_read428_phi_phi_fu_19334_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_153_V_read428_phi_phi_fu_19334_p4 = ap_phi_mux_data_153_V_read428_rewind_phi_fu_8650_p6.read();
    } else {
        ap_phi_mux_data_153_V_read428_phi_phi_fu_19334_p4 = ap_phi_reg_pp0_iter1_data_153_V_read428_phi_reg_19330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_153_V_read428_rewind_phi_fu_8650_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_153_V_read428_rewind_phi_fu_8650_p6 = data_153_V_read428_phi_reg_19330.read();
    } else {
        ap_phi_mux_data_153_V_read428_rewind_phi_fu_8650_p6 = data_153_V_read428_rewind_reg_8646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_154_V_read429_phi_phi_fu_19346_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_154_V_read429_phi_phi_fu_19346_p4 = ap_phi_mux_data_154_V_read429_rewind_phi_fu_8664_p6.read();
    } else {
        ap_phi_mux_data_154_V_read429_phi_phi_fu_19346_p4 = ap_phi_reg_pp0_iter1_data_154_V_read429_phi_reg_19342.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_154_V_read429_rewind_phi_fu_8664_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_154_V_read429_rewind_phi_fu_8664_p6 = data_154_V_read429_phi_reg_19342.read();
    } else {
        ap_phi_mux_data_154_V_read429_rewind_phi_fu_8664_p6 = data_154_V_read429_rewind_reg_8660.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_155_V_read430_phi_phi_fu_19358_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_155_V_read430_phi_phi_fu_19358_p4 = ap_phi_mux_data_155_V_read430_rewind_phi_fu_8678_p6.read();
    } else {
        ap_phi_mux_data_155_V_read430_phi_phi_fu_19358_p4 = ap_phi_reg_pp0_iter1_data_155_V_read430_phi_reg_19354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_155_V_read430_rewind_phi_fu_8678_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_155_V_read430_rewind_phi_fu_8678_p6 = data_155_V_read430_phi_reg_19354.read();
    } else {
        ap_phi_mux_data_155_V_read430_rewind_phi_fu_8678_p6 = data_155_V_read430_rewind_reg_8674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_156_V_read431_phi_phi_fu_19370_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_156_V_read431_phi_phi_fu_19370_p4 = ap_phi_mux_data_156_V_read431_rewind_phi_fu_8692_p6.read();
    } else {
        ap_phi_mux_data_156_V_read431_phi_phi_fu_19370_p4 = ap_phi_reg_pp0_iter1_data_156_V_read431_phi_reg_19366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_156_V_read431_rewind_phi_fu_8692_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_156_V_read431_rewind_phi_fu_8692_p6 = data_156_V_read431_phi_reg_19366.read();
    } else {
        ap_phi_mux_data_156_V_read431_rewind_phi_fu_8692_p6 = data_156_V_read431_rewind_reg_8688.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_157_V_read432_phi_phi_fu_19382_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_157_V_read432_phi_phi_fu_19382_p4 = ap_phi_mux_data_157_V_read432_rewind_phi_fu_8706_p6.read();
    } else {
        ap_phi_mux_data_157_V_read432_phi_phi_fu_19382_p4 = ap_phi_reg_pp0_iter1_data_157_V_read432_phi_reg_19378.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_157_V_read432_rewind_phi_fu_8706_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_157_V_read432_rewind_phi_fu_8706_p6 = data_157_V_read432_phi_reg_19378.read();
    } else {
        ap_phi_mux_data_157_V_read432_rewind_phi_fu_8706_p6 = data_157_V_read432_rewind_reg_8702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_158_V_read433_phi_phi_fu_19394_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_158_V_read433_phi_phi_fu_19394_p4 = ap_phi_mux_data_158_V_read433_rewind_phi_fu_8720_p6.read();
    } else {
        ap_phi_mux_data_158_V_read433_phi_phi_fu_19394_p4 = ap_phi_reg_pp0_iter1_data_158_V_read433_phi_reg_19390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_158_V_read433_rewind_phi_fu_8720_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_158_V_read433_rewind_phi_fu_8720_p6 = data_158_V_read433_phi_reg_19390.read();
    } else {
        ap_phi_mux_data_158_V_read433_rewind_phi_fu_8720_p6 = data_158_V_read433_rewind_reg_8716.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_159_V_read434_phi_phi_fu_19406_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_159_V_read434_phi_phi_fu_19406_p4 = ap_phi_mux_data_159_V_read434_rewind_phi_fu_8734_p6.read();
    } else {
        ap_phi_mux_data_159_V_read434_phi_phi_fu_19406_p4 = ap_phi_reg_pp0_iter1_data_159_V_read434_phi_reg_19402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_159_V_read434_rewind_phi_fu_8734_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_159_V_read434_rewind_phi_fu_8734_p6 = data_159_V_read434_phi_reg_19402.read();
    } else {
        ap_phi_mux_data_159_V_read434_rewind_phi_fu_8734_p6 = data_159_V_read434_rewind_reg_8730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_15_V_read290_phi_phi_fu_17678_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_15_V_read290_phi_phi_fu_17678_p4 = ap_phi_mux_data_15_V_read290_rewind_phi_fu_6718_p6.read();
    } else {
        ap_phi_mux_data_15_V_read290_phi_phi_fu_17678_p4 = ap_phi_reg_pp0_iter1_data_15_V_read290_phi_reg_17674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_15_V_read290_rewind_phi_fu_6718_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_15_V_read290_rewind_phi_fu_6718_p6 = data_15_V_read290_phi_reg_17674.read();
    } else {
        ap_phi_mux_data_15_V_read290_rewind_phi_fu_6718_p6 = data_15_V_read290_rewind_reg_6714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_160_V_read435_phi_phi_fu_19418_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_160_V_read435_phi_phi_fu_19418_p4 = ap_phi_mux_data_160_V_read435_rewind_phi_fu_8748_p6.read();
    } else {
        ap_phi_mux_data_160_V_read435_phi_phi_fu_19418_p4 = ap_phi_reg_pp0_iter1_data_160_V_read435_phi_reg_19414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_160_V_read435_rewind_phi_fu_8748_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_160_V_read435_rewind_phi_fu_8748_p6 = data_160_V_read435_phi_reg_19414.read();
    } else {
        ap_phi_mux_data_160_V_read435_rewind_phi_fu_8748_p6 = data_160_V_read435_rewind_reg_8744.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_161_V_read436_phi_phi_fu_19430_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_161_V_read436_phi_phi_fu_19430_p4 = ap_phi_mux_data_161_V_read436_rewind_phi_fu_8762_p6.read();
    } else {
        ap_phi_mux_data_161_V_read436_phi_phi_fu_19430_p4 = ap_phi_reg_pp0_iter1_data_161_V_read436_phi_reg_19426.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_161_V_read436_rewind_phi_fu_8762_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_161_V_read436_rewind_phi_fu_8762_p6 = data_161_V_read436_phi_reg_19426.read();
    } else {
        ap_phi_mux_data_161_V_read436_rewind_phi_fu_8762_p6 = data_161_V_read436_rewind_reg_8758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_162_V_read437_phi_phi_fu_19442_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_162_V_read437_phi_phi_fu_19442_p4 = ap_phi_mux_data_162_V_read437_rewind_phi_fu_8776_p6.read();
    } else {
        ap_phi_mux_data_162_V_read437_phi_phi_fu_19442_p4 = ap_phi_reg_pp0_iter1_data_162_V_read437_phi_reg_19438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_162_V_read437_rewind_phi_fu_8776_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_162_V_read437_rewind_phi_fu_8776_p6 = data_162_V_read437_phi_reg_19438.read();
    } else {
        ap_phi_mux_data_162_V_read437_rewind_phi_fu_8776_p6 = data_162_V_read437_rewind_reg_8772.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_163_V_read438_phi_phi_fu_19454_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_163_V_read438_phi_phi_fu_19454_p4 = ap_phi_mux_data_163_V_read438_rewind_phi_fu_8790_p6.read();
    } else {
        ap_phi_mux_data_163_V_read438_phi_phi_fu_19454_p4 = ap_phi_reg_pp0_iter1_data_163_V_read438_phi_reg_19450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_163_V_read438_rewind_phi_fu_8790_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_163_V_read438_rewind_phi_fu_8790_p6 = data_163_V_read438_phi_reg_19450.read();
    } else {
        ap_phi_mux_data_163_V_read438_rewind_phi_fu_8790_p6 = data_163_V_read438_rewind_reg_8786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_164_V_read439_phi_phi_fu_19466_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_164_V_read439_phi_phi_fu_19466_p4 = ap_phi_mux_data_164_V_read439_rewind_phi_fu_8804_p6.read();
    } else {
        ap_phi_mux_data_164_V_read439_phi_phi_fu_19466_p4 = ap_phi_reg_pp0_iter1_data_164_V_read439_phi_reg_19462.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_164_V_read439_rewind_phi_fu_8804_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_164_V_read439_rewind_phi_fu_8804_p6 = data_164_V_read439_phi_reg_19462.read();
    } else {
        ap_phi_mux_data_164_V_read439_rewind_phi_fu_8804_p6 = data_164_V_read439_rewind_reg_8800.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_165_V_read440_phi_phi_fu_19478_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_165_V_read440_phi_phi_fu_19478_p4 = ap_phi_mux_data_165_V_read440_rewind_phi_fu_8818_p6.read();
    } else {
        ap_phi_mux_data_165_V_read440_phi_phi_fu_19478_p4 = ap_phi_reg_pp0_iter1_data_165_V_read440_phi_reg_19474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_165_V_read440_rewind_phi_fu_8818_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_165_V_read440_rewind_phi_fu_8818_p6 = data_165_V_read440_phi_reg_19474.read();
    } else {
        ap_phi_mux_data_165_V_read440_rewind_phi_fu_8818_p6 = data_165_V_read440_rewind_reg_8814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_166_V_read441_phi_phi_fu_19490_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_166_V_read441_phi_phi_fu_19490_p4 = ap_phi_mux_data_166_V_read441_rewind_phi_fu_8832_p6.read();
    } else {
        ap_phi_mux_data_166_V_read441_phi_phi_fu_19490_p4 = ap_phi_reg_pp0_iter1_data_166_V_read441_phi_reg_19486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_166_V_read441_rewind_phi_fu_8832_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_166_V_read441_rewind_phi_fu_8832_p6 = data_166_V_read441_phi_reg_19486.read();
    } else {
        ap_phi_mux_data_166_V_read441_rewind_phi_fu_8832_p6 = data_166_V_read441_rewind_reg_8828.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_167_V_read442_phi_phi_fu_19502_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_167_V_read442_phi_phi_fu_19502_p4 = ap_phi_mux_data_167_V_read442_rewind_phi_fu_8846_p6.read();
    } else {
        ap_phi_mux_data_167_V_read442_phi_phi_fu_19502_p4 = ap_phi_reg_pp0_iter1_data_167_V_read442_phi_reg_19498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_167_V_read442_rewind_phi_fu_8846_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_167_V_read442_rewind_phi_fu_8846_p6 = data_167_V_read442_phi_reg_19498.read();
    } else {
        ap_phi_mux_data_167_V_read442_rewind_phi_fu_8846_p6 = data_167_V_read442_rewind_reg_8842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_168_V_read443_phi_phi_fu_19514_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_168_V_read443_phi_phi_fu_19514_p4 = ap_phi_mux_data_168_V_read443_rewind_phi_fu_8860_p6.read();
    } else {
        ap_phi_mux_data_168_V_read443_phi_phi_fu_19514_p4 = ap_phi_reg_pp0_iter1_data_168_V_read443_phi_reg_19510.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_168_V_read443_rewind_phi_fu_8860_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_168_V_read443_rewind_phi_fu_8860_p6 = data_168_V_read443_phi_reg_19510.read();
    } else {
        ap_phi_mux_data_168_V_read443_rewind_phi_fu_8860_p6 = data_168_V_read443_rewind_reg_8856.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_169_V_read444_phi_phi_fu_19526_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_169_V_read444_phi_phi_fu_19526_p4 = ap_phi_mux_data_169_V_read444_rewind_phi_fu_8874_p6.read();
    } else {
        ap_phi_mux_data_169_V_read444_phi_phi_fu_19526_p4 = ap_phi_reg_pp0_iter1_data_169_V_read444_phi_reg_19522.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_169_V_read444_rewind_phi_fu_8874_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_169_V_read444_rewind_phi_fu_8874_p6 = data_169_V_read444_phi_reg_19522.read();
    } else {
        ap_phi_mux_data_169_V_read444_rewind_phi_fu_8874_p6 = data_169_V_read444_rewind_reg_8870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_16_V_read291_phi_phi_fu_17690_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_16_V_read291_phi_phi_fu_17690_p4 = ap_phi_mux_data_16_V_read291_rewind_phi_fu_6732_p6.read();
    } else {
        ap_phi_mux_data_16_V_read291_phi_phi_fu_17690_p4 = ap_phi_reg_pp0_iter1_data_16_V_read291_phi_reg_17686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_16_V_read291_rewind_phi_fu_6732_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_16_V_read291_rewind_phi_fu_6732_p6 = data_16_V_read291_phi_reg_17686.read();
    } else {
        ap_phi_mux_data_16_V_read291_rewind_phi_fu_6732_p6 = data_16_V_read291_rewind_reg_6728.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_170_V_read445_phi_phi_fu_19538_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_170_V_read445_phi_phi_fu_19538_p4 = ap_phi_mux_data_170_V_read445_rewind_phi_fu_8888_p6.read();
    } else {
        ap_phi_mux_data_170_V_read445_phi_phi_fu_19538_p4 = ap_phi_reg_pp0_iter1_data_170_V_read445_phi_reg_19534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_170_V_read445_rewind_phi_fu_8888_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_170_V_read445_rewind_phi_fu_8888_p6 = data_170_V_read445_phi_reg_19534.read();
    } else {
        ap_phi_mux_data_170_V_read445_rewind_phi_fu_8888_p6 = data_170_V_read445_rewind_reg_8884.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_171_V_read446_phi_phi_fu_19550_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_171_V_read446_phi_phi_fu_19550_p4 = ap_phi_mux_data_171_V_read446_rewind_phi_fu_8902_p6.read();
    } else {
        ap_phi_mux_data_171_V_read446_phi_phi_fu_19550_p4 = ap_phi_reg_pp0_iter1_data_171_V_read446_phi_reg_19546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_171_V_read446_rewind_phi_fu_8902_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_171_V_read446_rewind_phi_fu_8902_p6 = data_171_V_read446_phi_reg_19546.read();
    } else {
        ap_phi_mux_data_171_V_read446_rewind_phi_fu_8902_p6 = data_171_V_read446_rewind_reg_8898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_172_V_read447_phi_phi_fu_19562_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_172_V_read447_phi_phi_fu_19562_p4 = ap_phi_mux_data_172_V_read447_rewind_phi_fu_8916_p6.read();
    } else {
        ap_phi_mux_data_172_V_read447_phi_phi_fu_19562_p4 = ap_phi_reg_pp0_iter1_data_172_V_read447_phi_reg_19558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_172_V_read447_rewind_phi_fu_8916_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_172_V_read447_rewind_phi_fu_8916_p6 = data_172_V_read447_phi_reg_19558.read();
    } else {
        ap_phi_mux_data_172_V_read447_rewind_phi_fu_8916_p6 = data_172_V_read447_rewind_reg_8912.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_173_V_read448_phi_phi_fu_19574_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_173_V_read448_phi_phi_fu_19574_p4 = ap_phi_mux_data_173_V_read448_rewind_phi_fu_8930_p6.read();
    } else {
        ap_phi_mux_data_173_V_read448_phi_phi_fu_19574_p4 = ap_phi_reg_pp0_iter1_data_173_V_read448_phi_reg_19570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_173_V_read448_rewind_phi_fu_8930_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_173_V_read448_rewind_phi_fu_8930_p6 = data_173_V_read448_phi_reg_19570.read();
    } else {
        ap_phi_mux_data_173_V_read448_rewind_phi_fu_8930_p6 = data_173_V_read448_rewind_reg_8926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_174_V_read449_phi_phi_fu_19586_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_174_V_read449_phi_phi_fu_19586_p4 = ap_phi_mux_data_174_V_read449_rewind_phi_fu_8944_p6.read();
    } else {
        ap_phi_mux_data_174_V_read449_phi_phi_fu_19586_p4 = ap_phi_reg_pp0_iter1_data_174_V_read449_phi_reg_19582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_174_V_read449_rewind_phi_fu_8944_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_174_V_read449_rewind_phi_fu_8944_p6 = data_174_V_read449_phi_reg_19582.read();
    } else {
        ap_phi_mux_data_174_V_read449_rewind_phi_fu_8944_p6 = data_174_V_read449_rewind_reg_8940.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_175_V_read450_phi_phi_fu_19598_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_175_V_read450_phi_phi_fu_19598_p4 = ap_phi_mux_data_175_V_read450_rewind_phi_fu_8958_p6.read();
    } else {
        ap_phi_mux_data_175_V_read450_phi_phi_fu_19598_p4 = ap_phi_reg_pp0_iter1_data_175_V_read450_phi_reg_19594.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_175_V_read450_rewind_phi_fu_8958_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_175_V_read450_rewind_phi_fu_8958_p6 = data_175_V_read450_phi_reg_19594.read();
    } else {
        ap_phi_mux_data_175_V_read450_rewind_phi_fu_8958_p6 = data_175_V_read450_rewind_reg_8954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_176_V_read451_phi_phi_fu_19610_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_176_V_read451_phi_phi_fu_19610_p4 = ap_phi_mux_data_176_V_read451_rewind_phi_fu_8972_p6.read();
    } else {
        ap_phi_mux_data_176_V_read451_phi_phi_fu_19610_p4 = ap_phi_reg_pp0_iter1_data_176_V_read451_phi_reg_19606.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_176_V_read451_rewind_phi_fu_8972_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_176_V_read451_rewind_phi_fu_8972_p6 = data_176_V_read451_phi_reg_19606.read();
    } else {
        ap_phi_mux_data_176_V_read451_rewind_phi_fu_8972_p6 = data_176_V_read451_rewind_reg_8968.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_177_V_read452_phi_phi_fu_19622_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_177_V_read452_phi_phi_fu_19622_p4 = ap_phi_mux_data_177_V_read452_rewind_phi_fu_8986_p6.read();
    } else {
        ap_phi_mux_data_177_V_read452_phi_phi_fu_19622_p4 = ap_phi_reg_pp0_iter1_data_177_V_read452_phi_reg_19618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_177_V_read452_rewind_phi_fu_8986_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_177_V_read452_rewind_phi_fu_8986_p6 = data_177_V_read452_phi_reg_19618.read();
    } else {
        ap_phi_mux_data_177_V_read452_rewind_phi_fu_8986_p6 = data_177_V_read452_rewind_reg_8982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_178_V_read453_phi_phi_fu_19634_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_178_V_read453_phi_phi_fu_19634_p4 = ap_phi_mux_data_178_V_read453_rewind_phi_fu_9000_p6.read();
    } else {
        ap_phi_mux_data_178_V_read453_phi_phi_fu_19634_p4 = ap_phi_reg_pp0_iter1_data_178_V_read453_phi_reg_19630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_178_V_read453_rewind_phi_fu_9000_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_178_V_read453_rewind_phi_fu_9000_p6 = data_178_V_read453_phi_reg_19630.read();
    } else {
        ap_phi_mux_data_178_V_read453_rewind_phi_fu_9000_p6 = data_178_V_read453_rewind_reg_8996.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_179_V_read454_phi_phi_fu_19646_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_179_V_read454_phi_phi_fu_19646_p4 = ap_phi_mux_data_179_V_read454_rewind_phi_fu_9014_p6.read();
    } else {
        ap_phi_mux_data_179_V_read454_phi_phi_fu_19646_p4 = ap_phi_reg_pp0_iter1_data_179_V_read454_phi_reg_19642.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_179_V_read454_rewind_phi_fu_9014_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_179_V_read454_rewind_phi_fu_9014_p6 = data_179_V_read454_phi_reg_19642.read();
    } else {
        ap_phi_mux_data_179_V_read454_rewind_phi_fu_9014_p6 = data_179_V_read454_rewind_reg_9010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_17_V_read292_phi_phi_fu_17702_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_17_V_read292_phi_phi_fu_17702_p4 = ap_phi_mux_data_17_V_read292_rewind_phi_fu_6746_p6.read();
    } else {
        ap_phi_mux_data_17_V_read292_phi_phi_fu_17702_p4 = ap_phi_reg_pp0_iter1_data_17_V_read292_phi_reg_17698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_17_V_read292_rewind_phi_fu_6746_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_17_V_read292_rewind_phi_fu_6746_p6 = data_17_V_read292_phi_reg_17698.read();
    } else {
        ap_phi_mux_data_17_V_read292_rewind_phi_fu_6746_p6 = data_17_V_read292_rewind_reg_6742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_180_V_read455_phi_phi_fu_19658_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_180_V_read455_phi_phi_fu_19658_p4 = ap_phi_mux_data_180_V_read455_rewind_phi_fu_9028_p6.read();
    } else {
        ap_phi_mux_data_180_V_read455_phi_phi_fu_19658_p4 = ap_phi_reg_pp0_iter1_data_180_V_read455_phi_reg_19654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_180_V_read455_rewind_phi_fu_9028_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_180_V_read455_rewind_phi_fu_9028_p6 = data_180_V_read455_phi_reg_19654.read();
    } else {
        ap_phi_mux_data_180_V_read455_rewind_phi_fu_9028_p6 = data_180_V_read455_rewind_reg_9024.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_181_V_read456_phi_phi_fu_19670_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_181_V_read456_phi_phi_fu_19670_p4 = ap_phi_mux_data_181_V_read456_rewind_phi_fu_9042_p6.read();
    } else {
        ap_phi_mux_data_181_V_read456_phi_phi_fu_19670_p4 = ap_phi_reg_pp0_iter1_data_181_V_read456_phi_reg_19666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_181_V_read456_rewind_phi_fu_9042_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_181_V_read456_rewind_phi_fu_9042_p6 = data_181_V_read456_phi_reg_19666.read();
    } else {
        ap_phi_mux_data_181_V_read456_rewind_phi_fu_9042_p6 = data_181_V_read456_rewind_reg_9038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_182_V_read457_phi_phi_fu_19682_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_182_V_read457_phi_phi_fu_19682_p4 = ap_phi_mux_data_182_V_read457_rewind_phi_fu_9056_p6.read();
    } else {
        ap_phi_mux_data_182_V_read457_phi_phi_fu_19682_p4 = ap_phi_reg_pp0_iter1_data_182_V_read457_phi_reg_19678.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_182_V_read457_rewind_phi_fu_9056_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_182_V_read457_rewind_phi_fu_9056_p6 = data_182_V_read457_phi_reg_19678.read();
    } else {
        ap_phi_mux_data_182_V_read457_rewind_phi_fu_9056_p6 = data_182_V_read457_rewind_reg_9052.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_183_V_read458_phi_phi_fu_19694_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_183_V_read458_phi_phi_fu_19694_p4 = ap_phi_mux_data_183_V_read458_rewind_phi_fu_9070_p6.read();
    } else {
        ap_phi_mux_data_183_V_read458_phi_phi_fu_19694_p4 = ap_phi_reg_pp0_iter1_data_183_V_read458_phi_reg_19690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_183_V_read458_rewind_phi_fu_9070_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_183_V_read458_rewind_phi_fu_9070_p6 = data_183_V_read458_phi_reg_19690.read();
    } else {
        ap_phi_mux_data_183_V_read458_rewind_phi_fu_9070_p6 = data_183_V_read458_rewind_reg_9066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_184_V_read459_phi_phi_fu_19706_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_184_V_read459_phi_phi_fu_19706_p4 = ap_phi_mux_data_184_V_read459_rewind_phi_fu_9084_p6.read();
    } else {
        ap_phi_mux_data_184_V_read459_phi_phi_fu_19706_p4 = ap_phi_reg_pp0_iter1_data_184_V_read459_phi_reg_19702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_184_V_read459_rewind_phi_fu_9084_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_184_V_read459_rewind_phi_fu_9084_p6 = data_184_V_read459_phi_reg_19702.read();
    } else {
        ap_phi_mux_data_184_V_read459_rewind_phi_fu_9084_p6 = data_184_V_read459_rewind_reg_9080.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_185_V_read460_phi_phi_fu_19718_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_185_V_read460_phi_phi_fu_19718_p4 = ap_phi_mux_data_185_V_read460_rewind_phi_fu_9098_p6.read();
    } else {
        ap_phi_mux_data_185_V_read460_phi_phi_fu_19718_p4 = ap_phi_reg_pp0_iter1_data_185_V_read460_phi_reg_19714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_185_V_read460_rewind_phi_fu_9098_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_185_V_read460_rewind_phi_fu_9098_p6 = data_185_V_read460_phi_reg_19714.read();
    } else {
        ap_phi_mux_data_185_V_read460_rewind_phi_fu_9098_p6 = data_185_V_read460_rewind_reg_9094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_186_V_read461_phi_phi_fu_19730_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_186_V_read461_phi_phi_fu_19730_p4 = ap_phi_mux_data_186_V_read461_rewind_phi_fu_9112_p6.read();
    } else {
        ap_phi_mux_data_186_V_read461_phi_phi_fu_19730_p4 = ap_phi_reg_pp0_iter1_data_186_V_read461_phi_reg_19726.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_186_V_read461_rewind_phi_fu_9112_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_186_V_read461_rewind_phi_fu_9112_p6 = data_186_V_read461_phi_reg_19726.read();
    } else {
        ap_phi_mux_data_186_V_read461_rewind_phi_fu_9112_p6 = data_186_V_read461_rewind_reg_9108.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_187_V_read462_phi_phi_fu_19742_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_187_V_read462_phi_phi_fu_19742_p4 = ap_phi_mux_data_187_V_read462_rewind_phi_fu_9126_p6.read();
    } else {
        ap_phi_mux_data_187_V_read462_phi_phi_fu_19742_p4 = ap_phi_reg_pp0_iter1_data_187_V_read462_phi_reg_19738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_187_V_read462_rewind_phi_fu_9126_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_187_V_read462_rewind_phi_fu_9126_p6 = data_187_V_read462_phi_reg_19738.read();
    } else {
        ap_phi_mux_data_187_V_read462_rewind_phi_fu_9126_p6 = data_187_V_read462_rewind_reg_9122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_188_V_read463_phi_phi_fu_19754_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_188_V_read463_phi_phi_fu_19754_p4 = ap_phi_mux_data_188_V_read463_rewind_phi_fu_9140_p6.read();
    } else {
        ap_phi_mux_data_188_V_read463_phi_phi_fu_19754_p4 = ap_phi_reg_pp0_iter1_data_188_V_read463_phi_reg_19750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_188_V_read463_rewind_phi_fu_9140_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_188_V_read463_rewind_phi_fu_9140_p6 = data_188_V_read463_phi_reg_19750.read();
    } else {
        ap_phi_mux_data_188_V_read463_rewind_phi_fu_9140_p6 = data_188_V_read463_rewind_reg_9136.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_189_V_read464_phi_phi_fu_19766_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_189_V_read464_phi_phi_fu_19766_p4 = ap_phi_mux_data_189_V_read464_rewind_phi_fu_9154_p6.read();
    } else {
        ap_phi_mux_data_189_V_read464_phi_phi_fu_19766_p4 = ap_phi_reg_pp0_iter1_data_189_V_read464_phi_reg_19762.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_189_V_read464_rewind_phi_fu_9154_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_189_V_read464_rewind_phi_fu_9154_p6 = data_189_V_read464_phi_reg_19762.read();
    } else {
        ap_phi_mux_data_189_V_read464_rewind_phi_fu_9154_p6 = data_189_V_read464_rewind_reg_9150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_18_V_read293_phi_phi_fu_17714_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_18_V_read293_phi_phi_fu_17714_p4 = ap_phi_mux_data_18_V_read293_rewind_phi_fu_6760_p6.read();
    } else {
        ap_phi_mux_data_18_V_read293_phi_phi_fu_17714_p4 = ap_phi_reg_pp0_iter1_data_18_V_read293_phi_reg_17710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_18_V_read293_rewind_phi_fu_6760_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_18_V_read293_rewind_phi_fu_6760_p6 = data_18_V_read293_phi_reg_17710.read();
    } else {
        ap_phi_mux_data_18_V_read293_rewind_phi_fu_6760_p6 = data_18_V_read293_rewind_reg_6756.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_190_V_read465_phi_phi_fu_19778_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_190_V_read465_phi_phi_fu_19778_p4 = ap_phi_mux_data_190_V_read465_rewind_phi_fu_9168_p6.read();
    } else {
        ap_phi_mux_data_190_V_read465_phi_phi_fu_19778_p4 = ap_phi_reg_pp0_iter1_data_190_V_read465_phi_reg_19774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_190_V_read465_rewind_phi_fu_9168_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_190_V_read465_rewind_phi_fu_9168_p6 = data_190_V_read465_phi_reg_19774.read();
    } else {
        ap_phi_mux_data_190_V_read465_rewind_phi_fu_9168_p6 = data_190_V_read465_rewind_reg_9164.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_191_V_read466_phi_phi_fu_19790_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_191_V_read466_phi_phi_fu_19790_p4 = ap_phi_mux_data_191_V_read466_rewind_phi_fu_9182_p6.read();
    } else {
        ap_phi_mux_data_191_V_read466_phi_phi_fu_19790_p4 = ap_phi_reg_pp0_iter1_data_191_V_read466_phi_reg_19786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_191_V_read466_rewind_phi_fu_9182_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_191_V_read466_rewind_phi_fu_9182_p6 = data_191_V_read466_phi_reg_19786.read();
    } else {
        ap_phi_mux_data_191_V_read466_rewind_phi_fu_9182_p6 = data_191_V_read466_rewind_reg_9178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_192_V_read467_phi_phi_fu_19802_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_192_V_read467_phi_phi_fu_19802_p4 = ap_phi_mux_data_192_V_read467_rewind_phi_fu_9196_p6.read();
    } else {
        ap_phi_mux_data_192_V_read467_phi_phi_fu_19802_p4 = ap_phi_reg_pp0_iter1_data_192_V_read467_phi_reg_19798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_192_V_read467_rewind_phi_fu_9196_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_192_V_read467_rewind_phi_fu_9196_p6 = data_192_V_read467_phi_reg_19798.read();
    } else {
        ap_phi_mux_data_192_V_read467_rewind_phi_fu_9196_p6 = data_192_V_read467_rewind_reg_9192.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_193_V_read468_phi_phi_fu_19814_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_193_V_read468_phi_phi_fu_19814_p4 = ap_phi_mux_data_193_V_read468_rewind_phi_fu_9210_p6.read();
    } else {
        ap_phi_mux_data_193_V_read468_phi_phi_fu_19814_p4 = ap_phi_reg_pp0_iter1_data_193_V_read468_phi_reg_19810.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_193_V_read468_rewind_phi_fu_9210_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_193_V_read468_rewind_phi_fu_9210_p6 = data_193_V_read468_phi_reg_19810.read();
    } else {
        ap_phi_mux_data_193_V_read468_rewind_phi_fu_9210_p6 = data_193_V_read468_rewind_reg_9206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_194_V_read469_phi_phi_fu_19826_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_194_V_read469_phi_phi_fu_19826_p4 = ap_phi_mux_data_194_V_read469_rewind_phi_fu_9224_p6.read();
    } else {
        ap_phi_mux_data_194_V_read469_phi_phi_fu_19826_p4 = ap_phi_reg_pp0_iter1_data_194_V_read469_phi_reg_19822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_194_V_read469_rewind_phi_fu_9224_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_194_V_read469_rewind_phi_fu_9224_p6 = data_194_V_read469_phi_reg_19822.read();
    } else {
        ap_phi_mux_data_194_V_read469_rewind_phi_fu_9224_p6 = data_194_V_read469_rewind_reg_9220.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_195_V_read470_phi_phi_fu_19838_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_195_V_read470_phi_phi_fu_19838_p4 = ap_phi_mux_data_195_V_read470_rewind_phi_fu_9238_p6.read();
    } else {
        ap_phi_mux_data_195_V_read470_phi_phi_fu_19838_p4 = ap_phi_reg_pp0_iter1_data_195_V_read470_phi_reg_19834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_195_V_read470_rewind_phi_fu_9238_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_195_V_read470_rewind_phi_fu_9238_p6 = data_195_V_read470_phi_reg_19834.read();
    } else {
        ap_phi_mux_data_195_V_read470_rewind_phi_fu_9238_p6 = data_195_V_read470_rewind_reg_9234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_196_V_read471_phi_phi_fu_19850_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_196_V_read471_phi_phi_fu_19850_p4 = ap_phi_mux_data_196_V_read471_rewind_phi_fu_9252_p6.read();
    } else {
        ap_phi_mux_data_196_V_read471_phi_phi_fu_19850_p4 = ap_phi_reg_pp0_iter1_data_196_V_read471_phi_reg_19846.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_196_V_read471_rewind_phi_fu_9252_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_196_V_read471_rewind_phi_fu_9252_p6 = data_196_V_read471_phi_reg_19846.read();
    } else {
        ap_phi_mux_data_196_V_read471_rewind_phi_fu_9252_p6 = data_196_V_read471_rewind_reg_9248.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_197_V_read472_phi_phi_fu_19862_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_197_V_read472_phi_phi_fu_19862_p4 = ap_phi_mux_data_197_V_read472_rewind_phi_fu_9266_p6.read();
    } else {
        ap_phi_mux_data_197_V_read472_phi_phi_fu_19862_p4 = ap_phi_reg_pp0_iter1_data_197_V_read472_phi_reg_19858.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_197_V_read472_rewind_phi_fu_9266_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_197_V_read472_rewind_phi_fu_9266_p6 = data_197_V_read472_phi_reg_19858.read();
    } else {
        ap_phi_mux_data_197_V_read472_rewind_phi_fu_9266_p6 = data_197_V_read472_rewind_reg_9262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_198_V_read473_phi_phi_fu_19874_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_198_V_read473_phi_phi_fu_19874_p4 = ap_phi_mux_data_198_V_read473_rewind_phi_fu_9280_p6.read();
    } else {
        ap_phi_mux_data_198_V_read473_phi_phi_fu_19874_p4 = ap_phi_reg_pp0_iter1_data_198_V_read473_phi_reg_19870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_198_V_read473_rewind_phi_fu_9280_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_198_V_read473_rewind_phi_fu_9280_p6 = data_198_V_read473_phi_reg_19870.read();
    } else {
        ap_phi_mux_data_198_V_read473_rewind_phi_fu_9280_p6 = data_198_V_read473_rewind_reg_9276.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_199_V_read474_phi_phi_fu_19886_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_199_V_read474_phi_phi_fu_19886_p4 = ap_phi_mux_data_199_V_read474_rewind_phi_fu_9294_p6.read();
    } else {
        ap_phi_mux_data_199_V_read474_phi_phi_fu_19886_p4 = ap_phi_reg_pp0_iter1_data_199_V_read474_phi_reg_19882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_199_V_read474_rewind_phi_fu_9294_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_199_V_read474_rewind_phi_fu_9294_p6 = data_199_V_read474_phi_reg_19882.read();
    } else {
        ap_phi_mux_data_199_V_read474_rewind_phi_fu_9294_p6 = data_199_V_read474_rewind_reg_9290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_19_V_read294_phi_phi_fu_17726_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_19_V_read294_phi_phi_fu_17726_p4 = ap_phi_mux_data_19_V_read294_rewind_phi_fu_6774_p6.read();
    } else {
        ap_phi_mux_data_19_V_read294_phi_phi_fu_17726_p4 = ap_phi_reg_pp0_iter1_data_19_V_read294_phi_reg_17722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_19_V_read294_rewind_phi_fu_6774_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_19_V_read294_rewind_phi_fu_6774_p6 = data_19_V_read294_phi_reg_17722.read();
    } else {
        ap_phi_mux_data_19_V_read294_rewind_phi_fu_6774_p6 = data_19_V_read294_rewind_reg_6770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_1_V_read276_phi_phi_fu_17510_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_1_V_read276_phi_phi_fu_17510_p4 = ap_phi_mux_data_1_V_read276_rewind_phi_fu_6522_p6.read();
    } else {
        ap_phi_mux_data_1_V_read276_phi_phi_fu_17510_p4 = ap_phi_reg_pp0_iter1_data_1_V_read276_phi_reg_17506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_1_V_read276_rewind_phi_fu_6522_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_1_V_read276_rewind_phi_fu_6522_p6 = data_1_V_read276_phi_reg_17506.read();
    } else {
        ap_phi_mux_data_1_V_read276_rewind_phi_fu_6522_p6 = data_1_V_read276_rewind_reg_6518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_200_V_read475_phi_phi_fu_19898_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_200_V_read475_phi_phi_fu_19898_p4 = ap_phi_mux_data_200_V_read475_rewind_phi_fu_9308_p6.read();
    } else {
        ap_phi_mux_data_200_V_read475_phi_phi_fu_19898_p4 = ap_phi_reg_pp0_iter1_data_200_V_read475_phi_reg_19894.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_200_V_read475_rewind_phi_fu_9308_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_200_V_read475_rewind_phi_fu_9308_p6 = data_200_V_read475_phi_reg_19894.read();
    } else {
        ap_phi_mux_data_200_V_read475_rewind_phi_fu_9308_p6 = data_200_V_read475_rewind_reg_9304.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_201_V_read476_phi_phi_fu_19910_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_201_V_read476_phi_phi_fu_19910_p4 = ap_phi_mux_data_201_V_read476_rewind_phi_fu_9322_p6.read();
    } else {
        ap_phi_mux_data_201_V_read476_phi_phi_fu_19910_p4 = ap_phi_reg_pp0_iter1_data_201_V_read476_phi_reg_19906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_201_V_read476_rewind_phi_fu_9322_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_201_V_read476_rewind_phi_fu_9322_p6 = data_201_V_read476_phi_reg_19906.read();
    } else {
        ap_phi_mux_data_201_V_read476_rewind_phi_fu_9322_p6 = data_201_V_read476_rewind_reg_9318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_202_V_read477_phi_phi_fu_19922_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_202_V_read477_phi_phi_fu_19922_p4 = ap_phi_mux_data_202_V_read477_rewind_phi_fu_9336_p6.read();
    } else {
        ap_phi_mux_data_202_V_read477_phi_phi_fu_19922_p4 = ap_phi_reg_pp0_iter1_data_202_V_read477_phi_reg_19918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_202_V_read477_rewind_phi_fu_9336_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_202_V_read477_rewind_phi_fu_9336_p6 = data_202_V_read477_phi_reg_19918.read();
    } else {
        ap_phi_mux_data_202_V_read477_rewind_phi_fu_9336_p6 = data_202_V_read477_rewind_reg_9332.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_203_V_read478_phi_phi_fu_19934_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_203_V_read478_phi_phi_fu_19934_p4 = ap_phi_mux_data_203_V_read478_rewind_phi_fu_9350_p6.read();
    } else {
        ap_phi_mux_data_203_V_read478_phi_phi_fu_19934_p4 = ap_phi_reg_pp0_iter1_data_203_V_read478_phi_reg_19930.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_203_V_read478_rewind_phi_fu_9350_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_203_V_read478_rewind_phi_fu_9350_p6 = data_203_V_read478_phi_reg_19930.read();
    } else {
        ap_phi_mux_data_203_V_read478_rewind_phi_fu_9350_p6 = data_203_V_read478_rewind_reg_9346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_204_V_read479_phi_phi_fu_19946_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_204_V_read479_phi_phi_fu_19946_p4 = ap_phi_mux_data_204_V_read479_rewind_phi_fu_9364_p6.read();
    } else {
        ap_phi_mux_data_204_V_read479_phi_phi_fu_19946_p4 = ap_phi_reg_pp0_iter1_data_204_V_read479_phi_reg_19942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_204_V_read479_rewind_phi_fu_9364_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_204_V_read479_rewind_phi_fu_9364_p6 = data_204_V_read479_phi_reg_19942.read();
    } else {
        ap_phi_mux_data_204_V_read479_rewind_phi_fu_9364_p6 = data_204_V_read479_rewind_reg_9360.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_205_V_read480_phi_phi_fu_19958_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_205_V_read480_phi_phi_fu_19958_p4 = ap_phi_mux_data_205_V_read480_rewind_phi_fu_9378_p6.read();
    } else {
        ap_phi_mux_data_205_V_read480_phi_phi_fu_19958_p4 = ap_phi_reg_pp0_iter1_data_205_V_read480_phi_reg_19954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_205_V_read480_rewind_phi_fu_9378_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_205_V_read480_rewind_phi_fu_9378_p6 = data_205_V_read480_phi_reg_19954.read();
    } else {
        ap_phi_mux_data_205_V_read480_rewind_phi_fu_9378_p6 = data_205_V_read480_rewind_reg_9374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_206_V_read481_phi_phi_fu_19970_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_206_V_read481_phi_phi_fu_19970_p4 = ap_phi_mux_data_206_V_read481_rewind_phi_fu_9392_p6.read();
    } else {
        ap_phi_mux_data_206_V_read481_phi_phi_fu_19970_p4 = ap_phi_reg_pp0_iter1_data_206_V_read481_phi_reg_19966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_206_V_read481_rewind_phi_fu_9392_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_206_V_read481_rewind_phi_fu_9392_p6 = data_206_V_read481_phi_reg_19966.read();
    } else {
        ap_phi_mux_data_206_V_read481_rewind_phi_fu_9392_p6 = data_206_V_read481_rewind_reg_9388.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_207_V_read482_phi_phi_fu_19982_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_207_V_read482_phi_phi_fu_19982_p4 = ap_phi_mux_data_207_V_read482_rewind_phi_fu_9406_p6.read();
    } else {
        ap_phi_mux_data_207_V_read482_phi_phi_fu_19982_p4 = ap_phi_reg_pp0_iter1_data_207_V_read482_phi_reg_19978.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_207_V_read482_rewind_phi_fu_9406_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_207_V_read482_rewind_phi_fu_9406_p6 = data_207_V_read482_phi_reg_19978.read();
    } else {
        ap_phi_mux_data_207_V_read482_rewind_phi_fu_9406_p6 = data_207_V_read482_rewind_reg_9402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_208_V_read483_phi_phi_fu_19994_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_208_V_read483_phi_phi_fu_19994_p4 = ap_phi_mux_data_208_V_read483_rewind_phi_fu_9420_p6.read();
    } else {
        ap_phi_mux_data_208_V_read483_phi_phi_fu_19994_p4 = ap_phi_reg_pp0_iter1_data_208_V_read483_phi_reg_19990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_208_V_read483_rewind_phi_fu_9420_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_208_V_read483_rewind_phi_fu_9420_p6 = data_208_V_read483_phi_reg_19990.read();
    } else {
        ap_phi_mux_data_208_V_read483_rewind_phi_fu_9420_p6 = data_208_V_read483_rewind_reg_9416.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_209_V_read484_phi_phi_fu_20006_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_209_V_read484_phi_phi_fu_20006_p4 = ap_phi_mux_data_209_V_read484_rewind_phi_fu_9434_p6.read();
    } else {
        ap_phi_mux_data_209_V_read484_phi_phi_fu_20006_p4 = ap_phi_reg_pp0_iter1_data_209_V_read484_phi_reg_20002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_209_V_read484_rewind_phi_fu_9434_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_209_V_read484_rewind_phi_fu_9434_p6 = data_209_V_read484_phi_reg_20002.read();
    } else {
        ap_phi_mux_data_209_V_read484_rewind_phi_fu_9434_p6 = data_209_V_read484_rewind_reg_9430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_20_V_read295_phi_phi_fu_17738_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_20_V_read295_phi_phi_fu_17738_p4 = ap_phi_mux_data_20_V_read295_rewind_phi_fu_6788_p6.read();
    } else {
        ap_phi_mux_data_20_V_read295_phi_phi_fu_17738_p4 = ap_phi_reg_pp0_iter1_data_20_V_read295_phi_reg_17734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_20_V_read295_rewind_phi_fu_6788_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_20_V_read295_rewind_phi_fu_6788_p6 = data_20_V_read295_phi_reg_17734.read();
    } else {
        ap_phi_mux_data_20_V_read295_rewind_phi_fu_6788_p6 = data_20_V_read295_rewind_reg_6784.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_210_V_read485_phi_phi_fu_20018_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_210_V_read485_phi_phi_fu_20018_p4 = ap_phi_mux_data_210_V_read485_rewind_phi_fu_9448_p6.read();
    } else {
        ap_phi_mux_data_210_V_read485_phi_phi_fu_20018_p4 = ap_phi_reg_pp0_iter1_data_210_V_read485_phi_reg_20014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_210_V_read485_rewind_phi_fu_9448_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_210_V_read485_rewind_phi_fu_9448_p6 = data_210_V_read485_phi_reg_20014.read();
    } else {
        ap_phi_mux_data_210_V_read485_rewind_phi_fu_9448_p6 = data_210_V_read485_rewind_reg_9444.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_211_V_read486_phi_phi_fu_20030_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_211_V_read486_phi_phi_fu_20030_p4 = ap_phi_mux_data_211_V_read486_rewind_phi_fu_9462_p6.read();
    } else {
        ap_phi_mux_data_211_V_read486_phi_phi_fu_20030_p4 = ap_phi_reg_pp0_iter1_data_211_V_read486_phi_reg_20026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_211_V_read486_rewind_phi_fu_9462_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_211_V_read486_rewind_phi_fu_9462_p6 = data_211_V_read486_phi_reg_20026.read();
    } else {
        ap_phi_mux_data_211_V_read486_rewind_phi_fu_9462_p6 = data_211_V_read486_rewind_reg_9458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_212_V_read487_phi_phi_fu_20042_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_212_V_read487_phi_phi_fu_20042_p4 = ap_phi_mux_data_212_V_read487_rewind_phi_fu_9476_p6.read();
    } else {
        ap_phi_mux_data_212_V_read487_phi_phi_fu_20042_p4 = ap_phi_reg_pp0_iter1_data_212_V_read487_phi_reg_20038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_212_V_read487_rewind_phi_fu_9476_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_212_V_read487_rewind_phi_fu_9476_p6 = data_212_V_read487_phi_reg_20038.read();
    } else {
        ap_phi_mux_data_212_V_read487_rewind_phi_fu_9476_p6 = data_212_V_read487_rewind_reg_9472.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_213_V_read488_phi_phi_fu_20054_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_213_V_read488_phi_phi_fu_20054_p4 = ap_phi_mux_data_213_V_read488_rewind_phi_fu_9490_p6.read();
    } else {
        ap_phi_mux_data_213_V_read488_phi_phi_fu_20054_p4 = ap_phi_reg_pp0_iter1_data_213_V_read488_phi_reg_20050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_213_V_read488_rewind_phi_fu_9490_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_213_V_read488_rewind_phi_fu_9490_p6 = data_213_V_read488_phi_reg_20050.read();
    } else {
        ap_phi_mux_data_213_V_read488_rewind_phi_fu_9490_p6 = data_213_V_read488_rewind_reg_9486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_214_V_read489_phi_phi_fu_20066_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_214_V_read489_phi_phi_fu_20066_p4 = ap_phi_mux_data_214_V_read489_rewind_phi_fu_9504_p6.read();
    } else {
        ap_phi_mux_data_214_V_read489_phi_phi_fu_20066_p4 = ap_phi_reg_pp0_iter1_data_214_V_read489_phi_reg_20062.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_214_V_read489_rewind_phi_fu_9504_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_214_V_read489_rewind_phi_fu_9504_p6 = data_214_V_read489_phi_reg_20062.read();
    } else {
        ap_phi_mux_data_214_V_read489_rewind_phi_fu_9504_p6 = data_214_V_read489_rewind_reg_9500.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_215_V_read490_phi_phi_fu_20078_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_215_V_read490_phi_phi_fu_20078_p4 = ap_phi_mux_data_215_V_read490_rewind_phi_fu_9518_p6.read();
    } else {
        ap_phi_mux_data_215_V_read490_phi_phi_fu_20078_p4 = ap_phi_reg_pp0_iter1_data_215_V_read490_phi_reg_20074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_215_V_read490_rewind_phi_fu_9518_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_215_V_read490_rewind_phi_fu_9518_p6 = data_215_V_read490_phi_reg_20074.read();
    } else {
        ap_phi_mux_data_215_V_read490_rewind_phi_fu_9518_p6 = data_215_V_read490_rewind_reg_9514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_216_V_read491_phi_phi_fu_20090_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_216_V_read491_phi_phi_fu_20090_p4 = ap_phi_mux_data_216_V_read491_rewind_phi_fu_9532_p6.read();
    } else {
        ap_phi_mux_data_216_V_read491_phi_phi_fu_20090_p4 = ap_phi_reg_pp0_iter1_data_216_V_read491_phi_reg_20086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_216_V_read491_rewind_phi_fu_9532_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_216_V_read491_rewind_phi_fu_9532_p6 = data_216_V_read491_phi_reg_20086.read();
    } else {
        ap_phi_mux_data_216_V_read491_rewind_phi_fu_9532_p6 = data_216_V_read491_rewind_reg_9528.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_217_V_read492_phi_phi_fu_20102_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_217_V_read492_phi_phi_fu_20102_p4 = ap_phi_mux_data_217_V_read492_rewind_phi_fu_9546_p6.read();
    } else {
        ap_phi_mux_data_217_V_read492_phi_phi_fu_20102_p4 = ap_phi_reg_pp0_iter1_data_217_V_read492_phi_reg_20098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_217_V_read492_rewind_phi_fu_9546_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_217_V_read492_rewind_phi_fu_9546_p6 = data_217_V_read492_phi_reg_20098.read();
    } else {
        ap_phi_mux_data_217_V_read492_rewind_phi_fu_9546_p6 = data_217_V_read492_rewind_reg_9542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_218_V_read493_phi_phi_fu_20114_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_218_V_read493_phi_phi_fu_20114_p4 = ap_phi_mux_data_218_V_read493_rewind_phi_fu_9560_p6.read();
    } else {
        ap_phi_mux_data_218_V_read493_phi_phi_fu_20114_p4 = ap_phi_reg_pp0_iter1_data_218_V_read493_phi_reg_20110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_218_V_read493_rewind_phi_fu_9560_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_218_V_read493_rewind_phi_fu_9560_p6 = data_218_V_read493_phi_reg_20110.read();
    } else {
        ap_phi_mux_data_218_V_read493_rewind_phi_fu_9560_p6 = data_218_V_read493_rewind_reg_9556.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_219_V_read494_phi_phi_fu_20126_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_219_V_read494_phi_phi_fu_20126_p4 = ap_phi_mux_data_219_V_read494_rewind_phi_fu_9574_p6.read();
    } else {
        ap_phi_mux_data_219_V_read494_phi_phi_fu_20126_p4 = ap_phi_reg_pp0_iter1_data_219_V_read494_phi_reg_20122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_219_V_read494_rewind_phi_fu_9574_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_219_V_read494_rewind_phi_fu_9574_p6 = data_219_V_read494_phi_reg_20122.read();
    } else {
        ap_phi_mux_data_219_V_read494_rewind_phi_fu_9574_p6 = data_219_V_read494_rewind_reg_9570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_21_V_read296_phi_phi_fu_17750_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_21_V_read296_phi_phi_fu_17750_p4 = ap_phi_mux_data_21_V_read296_rewind_phi_fu_6802_p6.read();
    } else {
        ap_phi_mux_data_21_V_read296_phi_phi_fu_17750_p4 = ap_phi_reg_pp0_iter1_data_21_V_read296_phi_reg_17746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_21_V_read296_rewind_phi_fu_6802_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_21_V_read296_rewind_phi_fu_6802_p6 = data_21_V_read296_phi_reg_17746.read();
    } else {
        ap_phi_mux_data_21_V_read296_rewind_phi_fu_6802_p6 = data_21_V_read296_rewind_reg_6798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_220_V_read495_phi_phi_fu_20138_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_220_V_read495_phi_phi_fu_20138_p4 = ap_phi_mux_data_220_V_read495_rewind_phi_fu_9588_p6.read();
    } else {
        ap_phi_mux_data_220_V_read495_phi_phi_fu_20138_p4 = ap_phi_reg_pp0_iter1_data_220_V_read495_phi_reg_20134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_220_V_read495_rewind_phi_fu_9588_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_220_V_read495_rewind_phi_fu_9588_p6 = data_220_V_read495_phi_reg_20134.read();
    } else {
        ap_phi_mux_data_220_V_read495_rewind_phi_fu_9588_p6 = data_220_V_read495_rewind_reg_9584.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_221_V_read496_phi_phi_fu_20150_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_221_V_read496_phi_phi_fu_20150_p4 = ap_phi_mux_data_221_V_read496_rewind_phi_fu_9602_p6.read();
    } else {
        ap_phi_mux_data_221_V_read496_phi_phi_fu_20150_p4 = ap_phi_reg_pp0_iter1_data_221_V_read496_phi_reg_20146.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_221_V_read496_rewind_phi_fu_9602_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_221_V_read496_rewind_phi_fu_9602_p6 = data_221_V_read496_phi_reg_20146.read();
    } else {
        ap_phi_mux_data_221_V_read496_rewind_phi_fu_9602_p6 = data_221_V_read496_rewind_reg_9598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_222_V_read497_phi_phi_fu_20162_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_222_V_read497_phi_phi_fu_20162_p4 = ap_phi_mux_data_222_V_read497_rewind_phi_fu_9616_p6.read();
    } else {
        ap_phi_mux_data_222_V_read497_phi_phi_fu_20162_p4 = ap_phi_reg_pp0_iter1_data_222_V_read497_phi_reg_20158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_222_V_read497_rewind_phi_fu_9616_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_222_V_read497_rewind_phi_fu_9616_p6 = data_222_V_read497_phi_reg_20158.read();
    } else {
        ap_phi_mux_data_222_V_read497_rewind_phi_fu_9616_p6 = data_222_V_read497_rewind_reg_9612.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_223_V_read498_phi_phi_fu_20174_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_223_V_read498_phi_phi_fu_20174_p4 = ap_phi_mux_data_223_V_read498_rewind_phi_fu_9630_p6.read();
    } else {
        ap_phi_mux_data_223_V_read498_phi_phi_fu_20174_p4 = ap_phi_reg_pp0_iter1_data_223_V_read498_phi_reg_20170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_223_V_read498_rewind_phi_fu_9630_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_223_V_read498_rewind_phi_fu_9630_p6 = data_223_V_read498_phi_reg_20170.read();
    } else {
        ap_phi_mux_data_223_V_read498_rewind_phi_fu_9630_p6 = data_223_V_read498_rewind_reg_9626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_224_V_read499_phi_phi_fu_20186_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_224_V_read499_phi_phi_fu_20186_p4 = ap_phi_mux_data_224_V_read499_rewind_phi_fu_9644_p6.read();
    } else {
        ap_phi_mux_data_224_V_read499_phi_phi_fu_20186_p4 = ap_phi_reg_pp0_iter1_data_224_V_read499_phi_reg_20182.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_224_V_read499_rewind_phi_fu_9644_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_224_V_read499_rewind_phi_fu_9644_p6 = data_224_V_read499_phi_reg_20182.read();
    } else {
        ap_phi_mux_data_224_V_read499_rewind_phi_fu_9644_p6 = data_224_V_read499_rewind_reg_9640.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_225_V_read500_phi_phi_fu_20198_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_225_V_read500_phi_phi_fu_20198_p4 = ap_phi_mux_data_225_V_read500_rewind_phi_fu_9658_p6.read();
    } else {
        ap_phi_mux_data_225_V_read500_phi_phi_fu_20198_p4 = ap_phi_reg_pp0_iter1_data_225_V_read500_phi_reg_20194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_225_V_read500_rewind_phi_fu_9658_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_225_V_read500_rewind_phi_fu_9658_p6 = data_225_V_read500_phi_reg_20194.read();
    } else {
        ap_phi_mux_data_225_V_read500_rewind_phi_fu_9658_p6 = data_225_V_read500_rewind_reg_9654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_226_V_read501_phi_phi_fu_20210_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_226_V_read501_phi_phi_fu_20210_p4 = ap_phi_mux_data_226_V_read501_rewind_phi_fu_9672_p6.read();
    } else {
        ap_phi_mux_data_226_V_read501_phi_phi_fu_20210_p4 = ap_phi_reg_pp0_iter1_data_226_V_read501_phi_reg_20206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_226_V_read501_rewind_phi_fu_9672_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_226_V_read501_rewind_phi_fu_9672_p6 = data_226_V_read501_phi_reg_20206.read();
    } else {
        ap_phi_mux_data_226_V_read501_rewind_phi_fu_9672_p6 = data_226_V_read501_rewind_reg_9668.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_227_V_read502_phi_phi_fu_20222_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_227_V_read502_phi_phi_fu_20222_p4 = ap_phi_mux_data_227_V_read502_rewind_phi_fu_9686_p6.read();
    } else {
        ap_phi_mux_data_227_V_read502_phi_phi_fu_20222_p4 = ap_phi_reg_pp0_iter1_data_227_V_read502_phi_reg_20218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_227_V_read502_rewind_phi_fu_9686_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_227_V_read502_rewind_phi_fu_9686_p6 = data_227_V_read502_phi_reg_20218.read();
    } else {
        ap_phi_mux_data_227_V_read502_rewind_phi_fu_9686_p6 = data_227_V_read502_rewind_reg_9682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_228_V_read503_phi_phi_fu_20234_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_228_V_read503_phi_phi_fu_20234_p4 = ap_phi_mux_data_228_V_read503_rewind_phi_fu_9700_p6.read();
    } else {
        ap_phi_mux_data_228_V_read503_phi_phi_fu_20234_p4 = ap_phi_reg_pp0_iter1_data_228_V_read503_phi_reg_20230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_228_V_read503_rewind_phi_fu_9700_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_228_V_read503_rewind_phi_fu_9700_p6 = data_228_V_read503_phi_reg_20230.read();
    } else {
        ap_phi_mux_data_228_V_read503_rewind_phi_fu_9700_p6 = data_228_V_read503_rewind_reg_9696.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_229_V_read504_phi_phi_fu_20246_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_229_V_read504_phi_phi_fu_20246_p4 = ap_phi_mux_data_229_V_read504_rewind_phi_fu_9714_p6.read();
    } else {
        ap_phi_mux_data_229_V_read504_phi_phi_fu_20246_p4 = ap_phi_reg_pp0_iter1_data_229_V_read504_phi_reg_20242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_229_V_read504_rewind_phi_fu_9714_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_229_V_read504_rewind_phi_fu_9714_p6 = data_229_V_read504_phi_reg_20242.read();
    } else {
        ap_phi_mux_data_229_V_read504_rewind_phi_fu_9714_p6 = data_229_V_read504_rewind_reg_9710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_22_V_read297_phi_phi_fu_17762_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_22_V_read297_phi_phi_fu_17762_p4 = ap_phi_mux_data_22_V_read297_rewind_phi_fu_6816_p6.read();
    } else {
        ap_phi_mux_data_22_V_read297_phi_phi_fu_17762_p4 = ap_phi_reg_pp0_iter1_data_22_V_read297_phi_reg_17758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_22_V_read297_rewind_phi_fu_6816_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_22_V_read297_rewind_phi_fu_6816_p6 = data_22_V_read297_phi_reg_17758.read();
    } else {
        ap_phi_mux_data_22_V_read297_rewind_phi_fu_6816_p6 = data_22_V_read297_rewind_reg_6812.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_230_V_read505_phi_phi_fu_20258_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_230_V_read505_phi_phi_fu_20258_p4 = ap_phi_mux_data_230_V_read505_rewind_phi_fu_9728_p6.read();
    } else {
        ap_phi_mux_data_230_V_read505_phi_phi_fu_20258_p4 = ap_phi_reg_pp0_iter1_data_230_V_read505_phi_reg_20254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_230_V_read505_rewind_phi_fu_9728_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_230_V_read505_rewind_phi_fu_9728_p6 = data_230_V_read505_phi_reg_20254.read();
    } else {
        ap_phi_mux_data_230_V_read505_rewind_phi_fu_9728_p6 = data_230_V_read505_rewind_reg_9724.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_231_V_read506_phi_phi_fu_20270_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_231_V_read506_phi_phi_fu_20270_p4 = ap_phi_mux_data_231_V_read506_rewind_phi_fu_9742_p6.read();
    } else {
        ap_phi_mux_data_231_V_read506_phi_phi_fu_20270_p4 = ap_phi_reg_pp0_iter1_data_231_V_read506_phi_reg_20266.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_231_V_read506_rewind_phi_fu_9742_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_231_V_read506_rewind_phi_fu_9742_p6 = data_231_V_read506_phi_reg_20266.read();
    } else {
        ap_phi_mux_data_231_V_read506_rewind_phi_fu_9742_p6 = data_231_V_read506_rewind_reg_9738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_232_V_read507_phi_phi_fu_20282_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_232_V_read507_phi_phi_fu_20282_p4 = ap_phi_mux_data_232_V_read507_rewind_phi_fu_9756_p6.read();
    } else {
        ap_phi_mux_data_232_V_read507_phi_phi_fu_20282_p4 = ap_phi_reg_pp0_iter1_data_232_V_read507_phi_reg_20278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_232_V_read507_rewind_phi_fu_9756_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_232_V_read507_rewind_phi_fu_9756_p6 = data_232_V_read507_phi_reg_20278.read();
    } else {
        ap_phi_mux_data_232_V_read507_rewind_phi_fu_9756_p6 = data_232_V_read507_rewind_reg_9752.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_233_V_read508_phi_phi_fu_20294_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_233_V_read508_phi_phi_fu_20294_p4 = ap_phi_mux_data_233_V_read508_rewind_phi_fu_9770_p6.read();
    } else {
        ap_phi_mux_data_233_V_read508_phi_phi_fu_20294_p4 = ap_phi_reg_pp0_iter1_data_233_V_read508_phi_reg_20290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_233_V_read508_rewind_phi_fu_9770_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_233_V_read508_rewind_phi_fu_9770_p6 = data_233_V_read508_phi_reg_20290.read();
    } else {
        ap_phi_mux_data_233_V_read508_rewind_phi_fu_9770_p6 = data_233_V_read508_rewind_reg_9766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_234_V_read509_phi_phi_fu_20306_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_234_V_read509_phi_phi_fu_20306_p4 = ap_phi_mux_data_234_V_read509_rewind_phi_fu_9784_p6.read();
    } else {
        ap_phi_mux_data_234_V_read509_phi_phi_fu_20306_p4 = ap_phi_reg_pp0_iter1_data_234_V_read509_phi_reg_20302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_234_V_read509_rewind_phi_fu_9784_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_234_V_read509_rewind_phi_fu_9784_p6 = data_234_V_read509_phi_reg_20302.read();
    } else {
        ap_phi_mux_data_234_V_read509_rewind_phi_fu_9784_p6 = data_234_V_read509_rewind_reg_9780.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_235_V_read510_phi_phi_fu_20318_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_235_V_read510_phi_phi_fu_20318_p4 = ap_phi_mux_data_235_V_read510_rewind_phi_fu_9798_p6.read();
    } else {
        ap_phi_mux_data_235_V_read510_phi_phi_fu_20318_p4 = ap_phi_reg_pp0_iter1_data_235_V_read510_phi_reg_20314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_235_V_read510_rewind_phi_fu_9798_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_235_V_read510_rewind_phi_fu_9798_p6 = data_235_V_read510_phi_reg_20314.read();
    } else {
        ap_phi_mux_data_235_V_read510_rewind_phi_fu_9798_p6 = data_235_V_read510_rewind_reg_9794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_236_V_read511_phi_phi_fu_20330_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_236_V_read511_phi_phi_fu_20330_p4 = ap_phi_mux_data_236_V_read511_rewind_phi_fu_9812_p6.read();
    } else {
        ap_phi_mux_data_236_V_read511_phi_phi_fu_20330_p4 = ap_phi_reg_pp0_iter1_data_236_V_read511_phi_reg_20326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_236_V_read511_rewind_phi_fu_9812_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_236_V_read511_rewind_phi_fu_9812_p6 = data_236_V_read511_phi_reg_20326.read();
    } else {
        ap_phi_mux_data_236_V_read511_rewind_phi_fu_9812_p6 = data_236_V_read511_rewind_reg_9808.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_237_V_read512_phi_phi_fu_20342_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_237_V_read512_phi_phi_fu_20342_p4 = ap_phi_mux_data_237_V_read512_rewind_phi_fu_9826_p6.read();
    } else {
        ap_phi_mux_data_237_V_read512_phi_phi_fu_20342_p4 = ap_phi_reg_pp0_iter1_data_237_V_read512_phi_reg_20338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_237_V_read512_rewind_phi_fu_9826_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_237_V_read512_rewind_phi_fu_9826_p6 = data_237_V_read512_phi_reg_20338.read();
    } else {
        ap_phi_mux_data_237_V_read512_rewind_phi_fu_9826_p6 = data_237_V_read512_rewind_reg_9822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_238_V_read513_phi_phi_fu_20354_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_238_V_read513_phi_phi_fu_20354_p4 = ap_phi_mux_data_238_V_read513_rewind_phi_fu_9840_p6.read();
    } else {
        ap_phi_mux_data_238_V_read513_phi_phi_fu_20354_p4 = ap_phi_reg_pp0_iter1_data_238_V_read513_phi_reg_20350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_238_V_read513_rewind_phi_fu_9840_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_238_V_read513_rewind_phi_fu_9840_p6 = data_238_V_read513_phi_reg_20350.read();
    } else {
        ap_phi_mux_data_238_V_read513_rewind_phi_fu_9840_p6 = data_238_V_read513_rewind_reg_9836.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_239_V_read514_phi_phi_fu_20366_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_239_V_read514_phi_phi_fu_20366_p4 = ap_phi_mux_data_239_V_read514_rewind_phi_fu_9854_p6.read();
    } else {
        ap_phi_mux_data_239_V_read514_phi_phi_fu_20366_p4 = ap_phi_reg_pp0_iter1_data_239_V_read514_phi_reg_20362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_239_V_read514_rewind_phi_fu_9854_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_239_V_read514_rewind_phi_fu_9854_p6 = data_239_V_read514_phi_reg_20362.read();
    } else {
        ap_phi_mux_data_239_V_read514_rewind_phi_fu_9854_p6 = data_239_V_read514_rewind_reg_9850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_23_V_read298_phi_phi_fu_17774_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_23_V_read298_phi_phi_fu_17774_p4 = ap_phi_mux_data_23_V_read298_rewind_phi_fu_6830_p6.read();
    } else {
        ap_phi_mux_data_23_V_read298_phi_phi_fu_17774_p4 = ap_phi_reg_pp0_iter1_data_23_V_read298_phi_reg_17770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_23_V_read298_rewind_phi_fu_6830_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_23_V_read298_rewind_phi_fu_6830_p6 = data_23_V_read298_phi_reg_17770.read();
    } else {
        ap_phi_mux_data_23_V_read298_rewind_phi_fu_6830_p6 = data_23_V_read298_rewind_reg_6826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_240_V_read515_phi_phi_fu_20378_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_240_V_read515_phi_phi_fu_20378_p4 = ap_phi_mux_data_240_V_read515_rewind_phi_fu_9868_p6.read();
    } else {
        ap_phi_mux_data_240_V_read515_phi_phi_fu_20378_p4 = ap_phi_reg_pp0_iter1_data_240_V_read515_phi_reg_20374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_240_V_read515_rewind_phi_fu_9868_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_240_V_read515_rewind_phi_fu_9868_p6 = data_240_V_read515_phi_reg_20374.read();
    } else {
        ap_phi_mux_data_240_V_read515_rewind_phi_fu_9868_p6 = data_240_V_read515_rewind_reg_9864.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_241_V_read516_phi_phi_fu_20390_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_241_V_read516_phi_phi_fu_20390_p4 = ap_phi_mux_data_241_V_read516_rewind_phi_fu_9882_p6.read();
    } else {
        ap_phi_mux_data_241_V_read516_phi_phi_fu_20390_p4 = ap_phi_reg_pp0_iter1_data_241_V_read516_phi_reg_20386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_241_V_read516_rewind_phi_fu_9882_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_241_V_read516_rewind_phi_fu_9882_p6 = data_241_V_read516_phi_reg_20386.read();
    } else {
        ap_phi_mux_data_241_V_read516_rewind_phi_fu_9882_p6 = data_241_V_read516_rewind_reg_9878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_242_V_read517_phi_phi_fu_20402_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_242_V_read517_phi_phi_fu_20402_p4 = ap_phi_mux_data_242_V_read517_rewind_phi_fu_9896_p6.read();
    } else {
        ap_phi_mux_data_242_V_read517_phi_phi_fu_20402_p4 = ap_phi_reg_pp0_iter1_data_242_V_read517_phi_reg_20398.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_242_V_read517_rewind_phi_fu_9896_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_242_V_read517_rewind_phi_fu_9896_p6 = data_242_V_read517_phi_reg_20398.read();
    } else {
        ap_phi_mux_data_242_V_read517_rewind_phi_fu_9896_p6 = data_242_V_read517_rewind_reg_9892.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_243_V_read518_phi_phi_fu_20414_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_243_V_read518_phi_phi_fu_20414_p4 = ap_phi_mux_data_243_V_read518_rewind_phi_fu_9910_p6.read();
    } else {
        ap_phi_mux_data_243_V_read518_phi_phi_fu_20414_p4 = ap_phi_reg_pp0_iter1_data_243_V_read518_phi_reg_20410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_243_V_read518_rewind_phi_fu_9910_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_243_V_read518_rewind_phi_fu_9910_p6 = data_243_V_read518_phi_reg_20410.read();
    } else {
        ap_phi_mux_data_243_V_read518_rewind_phi_fu_9910_p6 = data_243_V_read518_rewind_reg_9906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_244_V_read519_phi_phi_fu_20426_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_244_V_read519_phi_phi_fu_20426_p4 = ap_phi_mux_data_244_V_read519_rewind_phi_fu_9924_p6.read();
    } else {
        ap_phi_mux_data_244_V_read519_phi_phi_fu_20426_p4 = ap_phi_reg_pp0_iter1_data_244_V_read519_phi_reg_20422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_244_V_read519_rewind_phi_fu_9924_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_244_V_read519_rewind_phi_fu_9924_p6 = data_244_V_read519_phi_reg_20422.read();
    } else {
        ap_phi_mux_data_244_V_read519_rewind_phi_fu_9924_p6 = data_244_V_read519_rewind_reg_9920.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_245_V_read520_phi_phi_fu_20438_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_245_V_read520_phi_phi_fu_20438_p4 = ap_phi_mux_data_245_V_read520_rewind_phi_fu_9938_p6.read();
    } else {
        ap_phi_mux_data_245_V_read520_phi_phi_fu_20438_p4 = ap_phi_reg_pp0_iter1_data_245_V_read520_phi_reg_20434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_245_V_read520_rewind_phi_fu_9938_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_245_V_read520_rewind_phi_fu_9938_p6 = data_245_V_read520_phi_reg_20434.read();
    } else {
        ap_phi_mux_data_245_V_read520_rewind_phi_fu_9938_p6 = data_245_V_read520_rewind_reg_9934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_246_V_read521_phi_phi_fu_20450_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_246_V_read521_phi_phi_fu_20450_p4 = ap_phi_mux_data_246_V_read521_rewind_phi_fu_9952_p6.read();
    } else {
        ap_phi_mux_data_246_V_read521_phi_phi_fu_20450_p4 = ap_phi_reg_pp0_iter1_data_246_V_read521_phi_reg_20446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_246_V_read521_rewind_phi_fu_9952_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_246_V_read521_rewind_phi_fu_9952_p6 = data_246_V_read521_phi_reg_20446.read();
    } else {
        ap_phi_mux_data_246_V_read521_rewind_phi_fu_9952_p6 = data_246_V_read521_rewind_reg_9948.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_247_V_read522_phi_phi_fu_20462_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_247_V_read522_phi_phi_fu_20462_p4 = ap_phi_mux_data_247_V_read522_rewind_phi_fu_9966_p6.read();
    } else {
        ap_phi_mux_data_247_V_read522_phi_phi_fu_20462_p4 = ap_phi_reg_pp0_iter1_data_247_V_read522_phi_reg_20458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_247_V_read522_rewind_phi_fu_9966_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_247_V_read522_rewind_phi_fu_9966_p6 = data_247_V_read522_phi_reg_20458.read();
    } else {
        ap_phi_mux_data_247_V_read522_rewind_phi_fu_9966_p6 = data_247_V_read522_rewind_reg_9962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_248_V_read523_phi_phi_fu_20474_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_248_V_read523_phi_phi_fu_20474_p4 = ap_phi_mux_data_248_V_read523_rewind_phi_fu_9980_p6.read();
    } else {
        ap_phi_mux_data_248_V_read523_phi_phi_fu_20474_p4 = ap_phi_reg_pp0_iter1_data_248_V_read523_phi_reg_20470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_248_V_read523_rewind_phi_fu_9980_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_248_V_read523_rewind_phi_fu_9980_p6 = data_248_V_read523_phi_reg_20470.read();
    } else {
        ap_phi_mux_data_248_V_read523_rewind_phi_fu_9980_p6 = data_248_V_read523_rewind_reg_9976.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_249_V_read524_phi_phi_fu_20486_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_249_V_read524_phi_phi_fu_20486_p4 = ap_phi_mux_data_249_V_read524_rewind_phi_fu_9994_p6.read();
    } else {
        ap_phi_mux_data_249_V_read524_phi_phi_fu_20486_p4 = ap_phi_reg_pp0_iter1_data_249_V_read524_phi_reg_20482.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_249_V_read524_rewind_phi_fu_9994_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_249_V_read524_rewind_phi_fu_9994_p6 = data_249_V_read524_phi_reg_20482.read();
    } else {
        ap_phi_mux_data_249_V_read524_rewind_phi_fu_9994_p6 = data_249_V_read524_rewind_reg_9990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_24_V_read299_phi_phi_fu_17786_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_24_V_read299_phi_phi_fu_17786_p4 = ap_phi_mux_data_24_V_read299_rewind_phi_fu_6844_p6.read();
    } else {
        ap_phi_mux_data_24_V_read299_phi_phi_fu_17786_p4 = ap_phi_reg_pp0_iter1_data_24_V_read299_phi_reg_17782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_24_V_read299_rewind_phi_fu_6844_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_24_V_read299_rewind_phi_fu_6844_p6 = data_24_V_read299_phi_reg_17782.read();
    } else {
        ap_phi_mux_data_24_V_read299_rewind_phi_fu_6844_p6 = data_24_V_read299_rewind_reg_6840.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_250_V_read525_phi_phi_fu_20498_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_250_V_read525_phi_phi_fu_20498_p4 = ap_phi_mux_data_250_V_read525_rewind_phi_fu_10008_p6.read();
    } else {
        ap_phi_mux_data_250_V_read525_phi_phi_fu_20498_p4 = ap_phi_reg_pp0_iter1_data_250_V_read525_phi_reg_20494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_250_V_read525_rewind_phi_fu_10008_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_250_V_read525_rewind_phi_fu_10008_p6 = data_250_V_read525_phi_reg_20494.read();
    } else {
        ap_phi_mux_data_250_V_read525_rewind_phi_fu_10008_p6 = data_250_V_read525_rewind_reg_10004.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_251_V_read526_phi_phi_fu_20510_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_251_V_read526_phi_phi_fu_20510_p4 = ap_phi_mux_data_251_V_read526_rewind_phi_fu_10022_p6.read();
    } else {
        ap_phi_mux_data_251_V_read526_phi_phi_fu_20510_p4 = ap_phi_reg_pp0_iter1_data_251_V_read526_phi_reg_20506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_251_V_read526_rewind_phi_fu_10022_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_251_V_read526_rewind_phi_fu_10022_p6 = data_251_V_read526_phi_reg_20506.read();
    } else {
        ap_phi_mux_data_251_V_read526_rewind_phi_fu_10022_p6 = data_251_V_read526_rewind_reg_10018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_252_V_read527_phi_phi_fu_20522_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_252_V_read527_phi_phi_fu_20522_p4 = ap_phi_mux_data_252_V_read527_rewind_phi_fu_10036_p6.read();
    } else {
        ap_phi_mux_data_252_V_read527_phi_phi_fu_20522_p4 = ap_phi_reg_pp0_iter1_data_252_V_read527_phi_reg_20518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_252_V_read527_rewind_phi_fu_10036_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_252_V_read527_rewind_phi_fu_10036_p6 = data_252_V_read527_phi_reg_20518.read();
    } else {
        ap_phi_mux_data_252_V_read527_rewind_phi_fu_10036_p6 = data_252_V_read527_rewind_reg_10032.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_253_V_read528_phi_phi_fu_20534_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_253_V_read528_phi_phi_fu_20534_p4 = ap_phi_mux_data_253_V_read528_rewind_phi_fu_10050_p6.read();
    } else {
        ap_phi_mux_data_253_V_read528_phi_phi_fu_20534_p4 = ap_phi_reg_pp0_iter1_data_253_V_read528_phi_reg_20530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_253_V_read528_rewind_phi_fu_10050_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_253_V_read528_rewind_phi_fu_10050_p6 = data_253_V_read528_phi_reg_20530.read();
    } else {
        ap_phi_mux_data_253_V_read528_rewind_phi_fu_10050_p6 = data_253_V_read528_rewind_reg_10046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_254_V_read529_phi_phi_fu_20546_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_254_V_read529_phi_phi_fu_20546_p4 = ap_phi_mux_data_254_V_read529_rewind_phi_fu_10064_p6.read();
    } else {
        ap_phi_mux_data_254_V_read529_phi_phi_fu_20546_p4 = ap_phi_reg_pp0_iter1_data_254_V_read529_phi_reg_20542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_254_V_read529_rewind_phi_fu_10064_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_254_V_read529_rewind_phi_fu_10064_p6 = data_254_V_read529_phi_reg_20542.read();
    } else {
        ap_phi_mux_data_254_V_read529_rewind_phi_fu_10064_p6 = data_254_V_read529_rewind_reg_10060.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_255_V_read530_phi_phi_fu_20558_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_255_V_read530_phi_phi_fu_20558_p4 = ap_phi_mux_data_255_V_read530_rewind_phi_fu_10078_p6.read();
    } else {
        ap_phi_mux_data_255_V_read530_phi_phi_fu_20558_p4 = ap_phi_reg_pp0_iter1_data_255_V_read530_phi_reg_20554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_255_V_read530_rewind_phi_fu_10078_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_255_V_read530_rewind_phi_fu_10078_p6 = data_255_V_read530_phi_reg_20554.read();
    } else {
        ap_phi_mux_data_255_V_read530_rewind_phi_fu_10078_p6 = data_255_V_read530_rewind_reg_10074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_256_V_read531_phi_phi_fu_20570_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_256_V_read531_phi_phi_fu_20570_p4 = ap_phi_mux_data_256_V_read531_rewind_phi_fu_10092_p6.read();
    } else {
        ap_phi_mux_data_256_V_read531_phi_phi_fu_20570_p4 = ap_phi_reg_pp0_iter1_data_256_V_read531_phi_reg_20566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_256_V_read531_rewind_phi_fu_10092_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_256_V_read531_rewind_phi_fu_10092_p6 = data_256_V_read531_phi_reg_20566.read();
    } else {
        ap_phi_mux_data_256_V_read531_rewind_phi_fu_10092_p6 = data_256_V_read531_rewind_reg_10088.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_257_V_read532_phi_phi_fu_20582_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_257_V_read532_phi_phi_fu_20582_p4 = ap_phi_mux_data_257_V_read532_rewind_phi_fu_10106_p6.read();
    } else {
        ap_phi_mux_data_257_V_read532_phi_phi_fu_20582_p4 = ap_phi_reg_pp0_iter1_data_257_V_read532_phi_reg_20578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_257_V_read532_rewind_phi_fu_10106_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_257_V_read532_rewind_phi_fu_10106_p6 = data_257_V_read532_phi_reg_20578.read();
    } else {
        ap_phi_mux_data_257_V_read532_rewind_phi_fu_10106_p6 = data_257_V_read532_rewind_reg_10102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_258_V_read533_phi_phi_fu_20594_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_258_V_read533_phi_phi_fu_20594_p4 = ap_phi_mux_data_258_V_read533_rewind_phi_fu_10120_p6.read();
    } else {
        ap_phi_mux_data_258_V_read533_phi_phi_fu_20594_p4 = ap_phi_reg_pp0_iter1_data_258_V_read533_phi_reg_20590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_258_V_read533_rewind_phi_fu_10120_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_258_V_read533_rewind_phi_fu_10120_p6 = data_258_V_read533_phi_reg_20590.read();
    } else {
        ap_phi_mux_data_258_V_read533_rewind_phi_fu_10120_p6 = data_258_V_read533_rewind_reg_10116.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_259_V_read534_phi_phi_fu_20606_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_259_V_read534_phi_phi_fu_20606_p4 = ap_phi_mux_data_259_V_read534_rewind_phi_fu_10134_p6.read();
    } else {
        ap_phi_mux_data_259_V_read534_phi_phi_fu_20606_p4 = ap_phi_reg_pp0_iter1_data_259_V_read534_phi_reg_20602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_259_V_read534_rewind_phi_fu_10134_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_259_V_read534_rewind_phi_fu_10134_p6 = data_259_V_read534_phi_reg_20602.read();
    } else {
        ap_phi_mux_data_259_V_read534_rewind_phi_fu_10134_p6 = data_259_V_read534_rewind_reg_10130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_25_V_read300_phi_phi_fu_17798_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_25_V_read300_phi_phi_fu_17798_p4 = ap_phi_mux_data_25_V_read300_rewind_phi_fu_6858_p6.read();
    } else {
        ap_phi_mux_data_25_V_read300_phi_phi_fu_17798_p4 = ap_phi_reg_pp0_iter1_data_25_V_read300_phi_reg_17794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_25_V_read300_rewind_phi_fu_6858_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_25_V_read300_rewind_phi_fu_6858_p6 = data_25_V_read300_phi_reg_17794.read();
    } else {
        ap_phi_mux_data_25_V_read300_rewind_phi_fu_6858_p6 = data_25_V_read300_rewind_reg_6854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_260_V_read535_phi_phi_fu_20618_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_260_V_read535_phi_phi_fu_20618_p4 = ap_phi_mux_data_260_V_read535_rewind_phi_fu_10148_p6.read();
    } else {
        ap_phi_mux_data_260_V_read535_phi_phi_fu_20618_p4 = ap_phi_reg_pp0_iter1_data_260_V_read535_phi_reg_20614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_260_V_read535_rewind_phi_fu_10148_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_260_V_read535_rewind_phi_fu_10148_p6 = data_260_V_read535_phi_reg_20614.read();
    } else {
        ap_phi_mux_data_260_V_read535_rewind_phi_fu_10148_p6 = data_260_V_read535_rewind_reg_10144.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_261_V_read536_phi_phi_fu_20630_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_261_V_read536_phi_phi_fu_20630_p4 = ap_phi_mux_data_261_V_read536_rewind_phi_fu_10162_p6.read();
    } else {
        ap_phi_mux_data_261_V_read536_phi_phi_fu_20630_p4 = ap_phi_reg_pp0_iter1_data_261_V_read536_phi_reg_20626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_261_V_read536_rewind_phi_fu_10162_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_261_V_read536_rewind_phi_fu_10162_p6 = data_261_V_read536_phi_reg_20626.read();
    } else {
        ap_phi_mux_data_261_V_read536_rewind_phi_fu_10162_p6 = data_261_V_read536_rewind_reg_10158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_262_V_read537_phi_phi_fu_20642_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_262_V_read537_phi_phi_fu_20642_p4 = ap_phi_mux_data_262_V_read537_rewind_phi_fu_10176_p6.read();
    } else {
        ap_phi_mux_data_262_V_read537_phi_phi_fu_20642_p4 = ap_phi_reg_pp0_iter1_data_262_V_read537_phi_reg_20638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_262_V_read537_rewind_phi_fu_10176_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_262_V_read537_rewind_phi_fu_10176_p6 = data_262_V_read537_phi_reg_20638.read();
    } else {
        ap_phi_mux_data_262_V_read537_rewind_phi_fu_10176_p6 = data_262_V_read537_rewind_reg_10172.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_263_V_read538_phi_phi_fu_20654_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_263_V_read538_phi_phi_fu_20654_p4 = ap_phi_mux_data_263_V_read538_rewind_phi_fu_10190_p6.read();
    } else {
        ap_phi_mux_data_263_V_read538_phi_phi_fu_20654_p4 = ap_phi_reg_pp0_iter1_data_263_V_read538_phi_reg_20650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_263_V_read538_rewind_phi_fu_10190_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_263_V_read538_rewind_phi_fu_10190_p6 = data_263_V_read538_phi_reg_20650.read();
    } else {
        ap_phi_mux_data_263_V_read538_rewind_phi_fu_10190_p6 = data_263_V_read538_rewind_reg_10186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_264_V_read539_phi_phi_fu_20666_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_264_V_read539_phi_phi_fu_20666_p4 = ap_phi_mux_data_264_V_read539_rewind_phi_fu_10204_p6.read();
    } else {
        ap_phi_mux_data_264_V_read539_phi_phi_fu_20666_p4 = ap_phi_reg_pp0_iter1_data_264_V_read539_phi_reg_20662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_264_V_read539_rewind_phi_fu_10204_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_264_V_read539_rewind_phi_fu_10204_p6 = data_264_V_read539_phi_reg_20662.read();
    } else {
        ap_phi_mux_data_264_V_read539_rewind_phi_fu_10204_p6 = data_264_V_read539_rewind_reg_10200.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_265_V_read540_phi_phi_fu_20678_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_265_V_read540_phi_phi_fu_20678_p4 = ap_phi_mux_data_265_V_read540_rewind_phi_fu_10218_p6.read();
    } else {
        ap_phi_mux_data_265_V_read540_phi_phi_fu_20678_p4 = ap_phi_reg_pp0_iter1_data_265_V_read540_phi_reg_20674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_265_V_read540_rewind_phi_fu_10218_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_265_V_read540_rewind_phi_fu_10218_p6 = data_265_V_read540_phi_reg_20674.read();
    } else {
        ap_phi_mux_data_265_V_read540_rewind_phi_fu_10218_p6 = data_265_V_read540_rewind_reg_10214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_266_V_read541_phi_phi_fu_20690_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_266_V_read541_phi_phi_fu_20690_p4 = ap_phi_mux_data_266_V_read541_rewind_phi_fu_10232_p6.read();
    } else {
        ap_phi_mux_data_266_V_read541_phi_phi_fu_20690_p4 = ap_phi_reg_pp0_iter1_data_266_V_read541_phi_reg_20686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_266_V_read541_rewind_phi_fu_10232_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_266_V_read541_rewind_phi_fu_10232_p6 = data_266_V_read541_phi_reg_20686.read();
    } else {
        ap_phi_mux_data_266_V_read541_rewind_phi_fu_10232_p6 = data_266_V_read541_rewind_reg_10228.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_267_V_read542_phi_phi_fu_20702_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_267_V_read542_phi_phi_fu_20702_p4 = ap_phi_mux_data_267_V_read542_rewind_phi_fu_10246_p6.read();
    } else {
        ap_phi_mux_data_267_V_read542_phi_phi_fu_20702_p4 = ap_phi_reg_pp0_iter1_data_267_V_read542_phi_reg_20698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_267_V_read542_rewind_phi_fu_10246_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_267_V_read542_rewind_phi_fu_10246_p6 = data_267_V_read542_phi_reg_20698.read();
    } else {
        ap_phi_mux_data_267_V_read542_rewind_phi_fu_10246_p6 = data_267_V_read542_rewind_reg_10242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_268_V_read543_phi_phi_fu_20714_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_268_V_read543_phi_phi_fu_20714_p4 = ap_phi_mux_data_268_V_read543_rewind_phi_fu_10260_p6.read();
    } else {
        ap_phi_mux_data_268_V_read543_phi_phi_fu_20714_p4 = ap_phi_reg_pp0_iter1_data_268_V_read543_phi_reg_20710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_268_V_read543_rewind_phi_fu_10260_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_268_V_read543_rewind_phi_fu_10260_p6 = data_268_V_read543_phi_reg_20710.read();
    } else {
        ap_phi_mux_data_268_V_read543_rewind_phi_fu_10260_p6 = data_268_V_read543_rewind_reg_10256.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_269_V_read544_phi_phi_fu_20726_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_269_V_read544_phi_phi_fu_20726_p4 = ap_phi_mux_data_269_V_read544_rewind_phi_fu_10274_p6.read();
    } else {
        ap_phi_mux_data_269_V_read544_phi_phi_fu_20726_p4 = ap_phi_reg_pp0_iter1_data_269_V_read544_phi_reg_20722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_269_V_read544_rewind_phi_fu_10274_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_269_V_read544_rewind_phi_fu_10274_p6 = data_269_V_read544_phi_reg_20722.read();
    } else {
        ap_phi_mux_data_269_V_read544_rewind_phi_fu_10274_p6 = data_269_V_read544_rewind_reg_10270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_26_V_read301_phi_phi_fu_17810_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_26_V_read301_phi_phi_fu_17810_p4 = ap_phi_mux_data_26_V_read301_rewind_phi_fu_6872_p6.read();
    } else {
        ap_phi_mux_data_26_V_read301_phi_phi_fu_17810_p4 = ap_phi_reg_pp0_iter1_data_26_V_read301_phi_reg_17806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_26_V_read301_rewind_phi_fu_6872_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_26_V_read301_rewind_phi_fu_6872_p6 = data_26_V_read301_phi_reg_17806.read();
    } else {
        ap_phi_mux_data_26_V_read301_rewind_phi_fu_6872_p6 = data_26_V_read301_rewind_reg_6868.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_270_V_read545_phi_phi_fu_20738_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_270_V_read545_phi_phi_fu_20738_p4 = ap_phi_mux_data_270_V_read545_rewind_phi_fu_10288_p6.read();
    } else {
        ap_phi_mux_data_270_V_read545_phi_phi_fu_20738_p4 = ap_phi_reg_pp0_iter1_data_270_V_read545_phi_reg_20734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_270_V_read545_rewind_phi_fu_10288_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_270_V_read545_rewind_phi_fu_10288_p6 = data_270_V_read545_phi_reg_20734.read();
    } else {
        ap_phi_mux_data_270_V_read545_rewind_phi_fu_10288_p6 = data_270_V_read545_rewind_reg_10284.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_271_V_read546_phi_phi_fu_20750_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_271_V_read546_phi_phi_fu_20750_p4 = ap_phi_mux_data_271_V_read546_rewind_phi_fu_10302_p6.read();
    } else {
        ap_phi_mux_data_271_V_read546_phi_phi_fu_20750_p4 = ap_phi_reg_pp0_iter1_data_271_V_read546_phi_reg_20746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_271_V_read546_rewind_phi_fu_10302_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_271_V_read546_rewind_phi_fu_10302_p6 = data_271_V_read546_phi_reg_20746.read();
    } else {
        ap_phi_mux_data_271_V_read546_rewind_phi_fu_10302_p6 = data_271_V_read546_rewind_reg_10298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_272_V_read547_phi_phi_fu_20762_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_272_V_read547_phi_phi_fu_20762_p4 = ap_phi_mux_data_272_V_read547_rewind_phi_fu_10316_p6.read();
    } else {
        ap_phi_mux_data_272_V_read547_phi_phi_fu_20762_p4 = ap_phi_reg_pp0_iter1_data_272_V_read547_phi_reg_20758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_272_V_read547_rewind_phi_fu_10316_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_272_V_read547_rewind_phi_fu_10316_p6 = data_272_V_read547_phi_reg_20758.read();
    } else {
        ap_phi_mux_data_272_V_read547_rewind_phi_fu_10316_p6 = data_272_V_read547_rewind_reg_10312.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_273_V_read548_phi_phi_fu_20774_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_273_V_read548_phi_phi_fu_20774_p4 = ap_phi_mux_data_273_V_read548_rewind_phi_fu_10330_p6.read();
    } else {
        ap_phi_mux_data_273_V_read548_phi_phi_fu_20774_p4 = ap_phi_reg_pp0_iter1_data_273_V_read548_phi_reg_20770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_273_V_read548_rewind_phi_fu_10330_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_273_V_read548_rewind_phi_fu_10330_p6 = data_273_V_read548_phi_reg_20770.read();
    } else {
        ap_phi_mux_data_273_V_read548_rewind_phi_fu_10330_p6 = data_273_V_read548_rewind_reg_10326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_274_V_read549_phi_phi_fu_20786_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_274_V_read549_phi_phi_fu_20786_p4 = ap_phi_mux_data_274_V_read549_rewind_phi_fu_10344_p6.read();
    } else {
        ap_phi_mux_data_274_V_read549_phi_phi_fu_20786_p4 = ap_phi_reg_pp0_iter1_data_274_V_read549_phi_reg_20782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_274_V_read549_rewind_phi_fu_10344_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_274_V_read549_rewind_phi_fu_10344_p6 = data_274_V_read549_phi_reg_20782.read();
    } else {
        ap_phi_mux_data_274_V_read549_rewind_phi_fu_10344_p6 = data_274_V_read549_rewind_reg_10340.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_275_V_read550_phi_phi_fu_20798_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_275_V_read550_phi_phi_fu_20798_p4 = ap_phi_mux_data_275_V_read550_rewind_phi_fu_10358_p6.read();
    } else {
        ap_phi_mux_data_275_V_read550_phi_phi_fu_20798_p4 = ap_phi_reg_pp0_iter1_data_275_V_read550_phi_reg_20794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_275_V_read550_rewind_phi_fu_10358_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_275_V_read550_rewind_phi_fu_10358_p6 = data_275_V_read550_phi_reg_20794.read();
    } else {
        ap_phi_mux_data_275_V_read550_rewind_phi_fu_10358_p6 = data_275_V_read550_rewind_reg_10354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_276_V_read551_phi_phi_fu_20810_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_276_V_read551_phi_phi_fu_20810_p4 = ap_phi_mux_data_276_V_read551_rewind_phi_fu_10372_p6.read();
    } else {
        ap_phi_mux_data_276_V_read551_phi_phi_fu_20810_p4 = ap_phi_reg_pp0_iter1_data_276_V_read551_phi_reg_20806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_276_V_read551_rewind_phi_fu_10372_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_276_V_read551_rewind_phi_fu_10372_p6 = data_276_V_read551_phi_reg_20806.read();
    } else {
        ap_phi_mux_data_276_V_read551_rewind_phi_fu_10372_p6 = data_276_V_read551_rewind_reg_10368.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_277_V_read552_phi_phi_fu_20822_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_277_V_read552_phi_phi_fu_20822_p4 = ap_phi_mux_data_277_V_read552_rewind_phi_fu_10386_p6.read();
    } else {
        ap_phi_mux_data_277_V_read552_phi_phi_fu_20822_p4 = ap_phi_reg_pp0_iter1_data_277_V_read552_phi_reg_20818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_277_V_read552_rewind_phi_fu_10386_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_277_V_read552_rewind_phi_fu_10386_p6 = data_277_V_read552_phi_reg_20818.read();
    } else {
        ap_phi_mux_data_277_V_read552_rewind_phi_fu_10386_p6 = data_277_V_read552_rewind_reg_10382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_278_V_read553_phi_phi_fu_20834_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_278_V_read553_phi_phi_fu_20834_p4 = ap_phi_mux_data_278_V_read553_rewind_phi_fu_10400_p6.read();
    } else {
        ap_phi_mux_data_278_V_read553_phi_phi_fu_20834_p4 = ap_phi_reg_pp0_iter1_data_278_V_read553_phi_reg_20830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_278_V_read553_rewind_phi_fu_10400_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_278_V_read553_rewind_phi_fu_10400_p6 = data_278_V_read553_phi_reg_20830.read();
    } else {
        ap_phi_mux_data_278_V_read553_rewind_phi_fu_10400_p6 = data_278_V_read553_rewind_reg_10396.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_279_V_read554_phi_phi_fu_20846_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_279_V_read554_phi_phi_fu_20846_p4 = ap_phi_mux_data_279_V_read554_rewind_phi_fu_10414_p6.read();
    } else {
        ap_phi_mux_data_279_V_read554_phi_phi_fu_20846_p4 = ap_phi_reg_pp0_iter1_data_279_V_read554_phi_reg_20842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_279_V_read554_rewind_phi_fu_10414_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_279_V_read554_rewind_phi_fu_10414_p6 = data_279_V_read554_phi_reg_20842.read();
    } else {
        ap_phi_mux_data_279_V_read554_rewind_phi_fu_10414_p6 = data_279_V_read554_rewind_reg_10410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_27_V_read302_phi_phi_fu_17822_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_27_V_read302_phi_phi_fu_17822_p4 = ap_phi_mux_data_27_V_read302_rewind_phi_fu_6886_p6.read();
    } else {
        ap_phi_mux_data_27_V_read302_phi_phi_fu_17822_p4 = ap_phi_reg_pp0_iter1_data_27_V_read302_phi_reg_17818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_27_V_read302_rewind_phi_fu_6886_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_27_V_read302_rewind_phi_fu_6886_p6 = data_27_V_read302_phi_reg_17818.read();
    } else {
        ap_phi_mux_data_27_V_read302_rewind_phi_fu_6886_p6 = data_27_V_read302_rewind_reg_6882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_280_V_read555_phi_phi_fu_20858_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_280_V_read555_phi_phi_fu_20858_p4 = ap_phi_mux_data_280_V_read555_rewind_phi_fu_10428_p6.read();
    } else {
        ap_phi_mux_data_280_V_read555_phi_phi_fu_20858_p4 = ap_phi_reg_pp0_iter1_data_280_V_read555_phi_reg_20854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_280_V_read555_rewind_phi_fu_10428_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_280_V_read555_rewind_phi_fu_10428_p6 = data_280_V_read555_phi_reg_20854.read();
    } else {
        ap_phi_mux_data_280_V_read555_rewind_phi_fu_10428_p6 = data_280_V_read555_rewind_reg_10424.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_281_V_read556_phi_phi_fu_20870_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_281_V_read556_phi_phi_fu_20870_p4 = ap_phi_mux_data_281_V_read556_rewind_phi_fu_10442_p6.read();
    } else {
        ap_phi_mux_data_281_V_read556_phi_phi_fu_20870_p4 = ap_phi_reg_pp0_iter1_data_281_V_read556_phi_reg_20866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_281_V_read556_rewind_phi_fu_10442_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_281_V_read556_rewind_phi_fu_10442_p6 = data_281_V_read556_phi_reg_20866.read();
    } else {
        ap_phi_mux_data_281_V_read556_rewind_phi_fu_10442_p6 = data_281_V_read556_rewind_reg_10438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_282_V_read557_phi_phi_fu_20882_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_282_V_read557_phi_phi_fu_20882_p4 = ap_phi_mux_data_282_V_read557_rewind_phi_fu_10456_p6.read();
    } else {
        ap_phi_mux_data_282_V_read557_phi_phi_fu_20882_p4 = ap_phi_reg_pp0_iter1_data_282_V_read557_phi_reg_20878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_282_V_read557_rewind_phi_fu_10456_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_282_V_read557_rewind_phi_fu_10456_p6 = data_282_V_read557_phi_reg_20878.read();
    } else {
        ap_phi_mux_data_282_V_read557_rewind_phi_fu_10456_p6 = data_282_V_read557_rewind_reg_10452.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_283_V_read558_phi_phi_fu_20894_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_283_V_read558_phi_phi_fu_20894_p4 = ap_phi_mux_data_283_V_read558_rewind_phi_fu_10470_p6.read();
    } else {
        ap_phi_mux_data_283_V_read558_phi_phi_fu_20894_p4 = ap_phi_reg_pp0_iter1_data_283_V_read558_phi_reg_20890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_283_V_read558_rewind_phi_fu_10470_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_283_V_read558_rewind_phi_fu_10470_p6 = data_283_V_read558_phi_reg_20890.read();
    } else {
        ap_phi_mux_data_283_V_read558_rewind_phi_fu_10470_p6 = data_283_V_read558_rewind_reg_10466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_284_V_read559_phi_phi_fu_20906_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_284_V_read559_phi_phi_fu_20906_p4 = ap_phi_mux_data_284_V_read559_rewind_phi_fu_10484_p6.read();
    } else {
        ap_phi_mux_data_284_V_read559_phi_phi_fu_20906_p4 = ap_phi_reg_pp0_iter1_data_284_V_read559_phi_reg_20902.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_284_V_read559_rewind_phi_fu_10484_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_284_V_read559_rewind_phi_fu_10484_p6 = data_284_V_read559_phi_reg_20902.read();
    } else {
        ap_phi_mux_data_284_V_read559_rewind_phi_fu_10484_p6 = data_284_V_read559_rewind_reg_10480.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_285_V_read560_phi_phi_fu_20918_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_285_V_read560_phi_phi_fu_20918_p4 = ap_phi_mux_data_285_V_read560_rewind_phi_fu_10498_p6.read();
    } else {
        ap_phi_mux_data_285_V_read560_phi_phi_fu_20918_p4 = ap_phi_reg_pp0_iter1_data_285_V_read560_phi_reg_20914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_285_V_read560_rewind_phi_fu_10498_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_285_V_read560_rewind_phi_fu_10498_p6 = data_285_V_read560_phi_reg_20914.read();
    } else {
        ap_phi_mux_data_285_V_read560_rewind_phi_fu_10498_p6 = data_285_V_read560_rewind_reg_10494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_286_V_read561_phi_phi_fu_20930_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_286_V_read561_phi_phi_fu_20930_p4 = ap_phi_mux_data_286_V_read561_rewind_phi_fu_10512_p6.read();
    } else {
        ap_phi_mux_data_286_V_read561_phi_phi_fu_20930_p4 = ap_phi_reg_pp0_iter1_data_286_V_read561_phi_reg_20926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_286_V_read561_rewind_phi_fu_10512_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_286_V_read561_rewind_phi_fu_10512_p6 = data_286_V_read561_phi_reg_20926.read();
    } else {
        ap_phi_mux_data_286_V_read561_rewind_phi_fu_10512_p6 = data_286_V_read561_rewind_reg_10508.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_287_V_read562_phi_phi_fu_20942_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_287_V_read562_phi_phi_fu_20942_p4 = ap_phi_mux_data_287_V_read562_rewind_phi_fu_10526_p6.read();
    } else {
        ap_phi_mux_data_287_V_read562_phi_phi_fu_20942_p4 = ap_phi_reg_pp0_iter1_data_287_V_read562_phi_reg_20938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_287_V_read562_rewind_phi_fu_10526_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_287_V_read562_rewind_phi_fu_10526_p6 = data_287_V_read562_phi_reg_20938.read();
    } else {
        ap_phi_mux_data_287_V_read562_rewind_phi_fu_10526_p6 = data_287_V_read562_rewind_reg_10522.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_288_V_read563_phi_phi_fu_20954_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_288_V_read563_phi_phi_fu_20954_p4 = ap_phi_mux_data_288_V_read563_rewind_phi_fu_10540_p6.read();
    } else {
        ap_phi_mux_data_288_V_read563_phi_phi_fu_20954_p4 = ap_phi_reg_pp0_iter1_data_288_V_read563_phi_reg_20950.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_288_V_read563_rewind_phi_fu_10540_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_288_V_read563_rewind_phi_fu_10540_p6 = data_288_V_read563_phi_reg_20950.read();
    } else {
        ap_phi_mux_data_288_V_read563_rewind_phi_fu_10540_p6 = data_288_V_read563_rewind_reg_10536.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_289_V_read564_phi_phi_fu_20966_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_289_V_read564_phi_phi_fu_20966_p4 = ap_phi_mux_data_289_V_read564_rewind_phi_fu_10554_p6.read();
    } else {
        ap_phi_mux_data_289_V_read564_phi_phi_fu_20966_p4 = ap_phi_reg_pp0_iter1_data_289_V_read564_phi_reg_20962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_289_V_read564_rewind_phi_fu_10554_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_289_V_read564_rewind_phi_fu_10554_p6 = data_289_V_read564_phi_reg_20962.read();
    } else {
        ap_phi_mux_data_289_V_read564_rewind_phi_fu_10554_p6 = data_289_V_read564_rewind_reg_10550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_28_V_read303_phi_phi_fu_17834_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_28_V_read303_phi_phi_fu_17834_p4 = ap_phi_mux_data_28_V_read303_rewind_phi_fu_6900_p6.read();
    } else {
        ap_phi_mux_data_28_V_read303_phi_phi_fu_17834_p4 = ap_phi_reg_pp0_iter1_data_28_V_read303_phi_reg_17830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_28_V_read303_rewind_phi_fu_6900_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_28_V_read303_rewind_phi_fu_6900_p6 = data_28_V_read303_phi_reg_17830.read();
    } else {
        ap_phi_mux_data_28_V_read303_rewind_phi_fu_6900_p6 = data_28_V_read303_rewind_reg_6896.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_290_V_read565_phi_phi_fu_20978_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_290_V_read565_phi_phi_fu_20978_p4 = ap_phi_mux_data_290_V_read565_rewind_phi_fu_10568_p6.read();
    } else {
        ap_phi_mux_data_290_V_read565_phi_phi_fu_20978_p4 = ap_phi_reg_pp0_iter1_data_290_V_read565_phi_reg_20974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_290_V_read565_rewind_phi_fu_10568_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_290_V_read565_rewind_phi_fu_10568_p6 = data_290_V_read565_phi_reg_20974.read();
    } else {
        ap_phi_mux_data_290_V_read565_rewind_phi_fu_10568_p6 = data_290_V_read565_rewind_reg_10564.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_291_V_read566_phi_phi_fu_20990_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_291_V_read566_phi_phi_fu_20990_p4 = ap_phi_mux_data_291_V_read566_rewind_phi_fu_10582_p6.read();
    } else {
        ap_phi_mux_data_291_V_read566_phi_phi_fu_20990_p4 = ap_phi_reg_pp0_iter1_data_291_V_read566_phi_reg_20986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_291_V_read566_rewind_phi_fu_10582_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_291_V_read566_rewind_phi_fu_10582_p6 = data_291_V_read566_phi_reg_20986.read();
    } else {
        ap_phi_mux_data_291_V_read566_rewind_phi_fu_10582_p6 = data_291_V_read566_rewind_reg_10578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_292_V_read567_phi_phi_fu_21002_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_292_V_read567_phi_phi_fu_21002_p4 = ap_phi_mux_data_292_V_read567_rewind_phi_fu_10596_p6.read();
    } else {
        ap_phi_mux_data_292_V_read567_phi_phi_fu_21002_p4 = ap_phi_reg_pp0_iter1_data_292_V_read567_phi_reg_20998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_292_V_read567_rewind_phi_fu_10596_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_292_V_read567_rewind_phi_fu_10596_p6 = data_292_V_read567_phi_reg_20998.read();
    } else {
        ap_phi_mux_data_292_V_read567_rewind_phi_fu_10596_p6 = data_292_V_read567_rewind_reg_10592.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_293_V_read568_phi_phi_fu_21014_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_293_V_read568_phi_phi_fu_21014_p4 = ap_phi_mux_data_293_V_read568_rewind_phi_fu_10610_p6.read();
    } else {
        ap_phi_mux_data_293_V_read568_phi_phi_fu_21014_p4 = ap_phi_reg_pp0_iter1_data_293_V_read568_phi_reg_21010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_293_V_read568_rewind_phi_fu_10610_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_293_V_read568_rewind_phi_fu_10610_p6 = data_293_V_read568_phi_reg_21010.read();
    } else {
        ap_phi_mux_data_293_V_read568_rewind_phi_fu_10610_p6 = data_293_V_read568_rewind_reg_10606.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_294_V_read569_phi_phi_fu_21026_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_294_V_read569_phi_phi_fu_21026_p4 = ap_phi_mux_data_294_V_read569_rewind_phi_fu_10624_p6.read();
    } else {
        ap_phi_mux_data_294_V_read569_phi_phi_fu_21026_p4 = ap_phi_reg_pp0_iter1_data_294_V_read569_phi_reg_21022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_294_V_read569_rewind_phi_fu_10624_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_294_V_read569_rewind_phi_fu_10624_p6 = data_294_V_read569_phi_reg_21022.read();
    } else {
        ap_phi_mux_data_294_V_read569_rewind_phi_fu_10624_p6 = data_294_V_read569_rewind_reg_10620.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_295_V_read570_phi_phi_fu_21038_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_295_V_read570_phi_phi_fu_21038_p4 = ap_phi_mux_data_295_V_read570_rewind_phi_fu_10638_p6.read();
    } else {
        ap_phi_mux_data_295_V_read570_phi_phi_fu_21038_p4 = ap_phi_reg_pp0_iter1_data_295_V_read570_phi_reg_21034.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_295_V_read570_rewind_phi_fu_10638_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_295_V_read570_rewind_phi_fu_10638_p6 = data_295_V_read570_phi_reg_21034.read();
    } else {
        ap_phi_mux_data_295_V_read570_rewind_phi_fu_10638_p6 = data_295_V_read570_rewind_reg_10634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_296_V_read571_phi_phi_fu_21050_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_296_V_read571_phi_phi_fu_21050_p4 = ap_phi_mux_data_296_V_read571_rewind_phi_fu_10652_p6.read();
    } else {
        ap_phi_mux_data_296_V_read571_phi_phi_fu_21050_p4 = ap_phi_reg_pp0_iter1_data_296_V_read571_phi_reg_21046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_296_V_read571_rewind_phi_fu_10652_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_296_V_read571_rewind_phi_fu_10652_p6 = data_296_V_read571_phi_reg_21046.read();
    } else {
        ap_phi_mux_data_296_V_read571_rewind_phi_fu_10652_p6 = data_296_V_read571_rewind_reg_10648.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_297_V_read572_phi_phi_fu_21062_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_297_V_read572_phi_phi_fu_21062_p4 = ap_phi_mux_data_297_V_read572_rewind_phi_fu_10666_p6.read();
    } else {
        ap_phi_mux_data_297_V_read572_phi_phi_fu_21062_p4 = ap_phi_reg_pp0_iter1_data_297_V_read572_phi_reg_21058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_297_V_read572_rewind_phi_fu_10666_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_297_V_read572_rewind_phi_fu_10666_p6 = data_297_V_read572_phi_reg_21058.read();
    } else {
        ap_phi_mux_data_297_V_read572_rewind_phi_fu_10666_p6 = data_297_V_read572_rewind_reg_10662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_298_V_read573_phi_phi_fu_21074_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_298_V_read573_phi_phi_fu_21074_p4 = ap_phi_mux_data_298_V_read573_rewind_phi_fu_10680_p6.read();
    } else {
        ap_phi_mux_data_298_V_read573_phi_phi_fu_21074_p4 = ap_phi_reg_pp0_iter1_data_298_V_read573_phi_reg_21070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_298_V_read573_rewind_phi_fu_10680_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_298_V_read573_rewind_phi_fu_10680_p6 = data_298_V_read573_phi_reg_21070.read();
    } else {
        ap_phi_mux_data_298_V_read573_rewind_phi_fu_10680_p6 = data_298_V_read573_rewind_reg_10676.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_299_V_read574_phi_phi_fu_21086_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_299_V_read574_phi_phi_fu_21086_p4 = ap_phi_mux_data_299_V_read574_rewind_phi_fu_10694_p6.read();
    } else {
        ap_phi_mux_data_299_V_read574_phi_phi_fu_21086_p4 = ap_phi_reg_pp0_iter1_data_299_V_read574_phi_reg_21082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_299_V_read574_rewind_phi_fu_10694_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_299_V_read574_rewind_phi_fu_10694_p6 = data_299_V_read574_phi_reg_21082.read();
    } else {
        ap_phi_mux_data_299_V_read574_rewind_phi_fu_10694_p6 = data_299_V_read574_rewind_reg_10690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_29_V_read304_phi_phi_fu_17846_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_29_V_read304_phi_phi_fu_17846_p4 = ap_phi_mux_data_29_V_read304_rewind_phi_fu_6914_p6.read();
    } else {
        ap_phi_mux_data_29_V_read304_phi_phi_fu_17846_p4 = ap_phi_reg_pp0_iter1_data_29_V_read304_phi_reg_17842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_29_V_read304_rewind_phi_fu_6914_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_29_V_read304_rewind_phi_fu_6914_p6 = data_29_V_read304_phi_reg_17842.read();
    } else {
        ap_phi_mux_data_29_V_read304_rewind_phi_fu_6914_p6 = data_29_V_read304_rewind_reg_6910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_2_V_read277_phi_phi_fu_17522_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_2_V_read277_phi_phi_fu_17522_p4 = ap_phi_mux_data_2_V_read277_rewind_phi_fu_6536_p6.read();
    } else {
        ap_phi_mux_data_2_V_read277_phi_phi_fu_17522_p4 = ap_phi_reg_pp0_iter1_data_2_V_read277_phi_reg_17518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_2_V_read277_rewind_phi_fu_6536_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_2_V_read277_rewind_phi_fu_6536_p6 = data_2_V_read277_phi_reg_17518.read();
    } else {
        ap_phi_mux_data_2_V_read277_rewind_phi_fu_6536_p6 = data_2_V_read277_rewind_reg_6532.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_300_V_read575_phi_phi_fu_21098_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_300_V_read575_phi_phi_fu_21098_p4 = ap_phi_mux_data_300_V_read575_rewind_phi_fu_10708_p6.read();
    } else {
        ap_phi_mux_data_300_V_read575_phi_phi_fu_21098_p4 = ap_phi_reg_pp0_iter1_data_300_V_read575_phi_reg_21094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_300_V_read575_rewind_phi_fu_10708_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_300_V_read575_rewind_phi_fu_10708_p6 = data_300_V_read575_phi_reg_21094.read();
    } else {
        ap_phi_mux_data_300_V_read575_rewind_phi_fu_10708_p6 = data_300_V_read575_rewind_reg_10704.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_301_V_read576_phi_phi_fu_21110_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_301_V_read576_phi_phi_fu_21110_p4 = ap_phi_mux_data_301_V_read576_rewind_phi_fu_10722_p6.read();
    } else {
        ap_phi_mux_data_301_V_read576_phi_phi_fu_21110_p4 = ap_phi_reg_pp0_iter1_data_301_V_read576_phi_reg_21106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_301_V_read576_rewind_phi_fu_10722_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_301_V_read576_rewind_phi_fu_10722_p6 = data_301_V_read576_phi_reg_21106.read();
    } else {
        ap_phi_mux_data_301_V_read576_rewind_phi_fu_10722_p6 = data_301_V_read576_rewind_reg_10718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_302_V_read577_phi_phi_fu_21122_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_302_V_read577_phi_phi_fu_21122_p4 = ap_phi_mux_data_302_V_read577_rewind_phi_fu_10736_p6.read();
    } else {
        ap_phi_mux_data_302_V_read577_phi_phi_fu_21122_p4 = ap_phi_reg_pp0_iter1_data_302_V_read577_phi_reg_21118.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_302_V_read577_rewind_phi_fu_10736_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_302_V_read577_rewind_phi_fu_10736_p6 = data_302_V_read577_phi_reg_21118.read();
    } else {
        ap_phi_mux_data_302_V_read577_rewind_phi_fu_10736_p6 = data_302_V_read577_rewind_reg_10732.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_303_V_read578_phi_phi_fu_21134_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_303_V_read578_phi_phi_fu_21134_p4 = ap_phi_mux_data_303_V_read578_rewind_phi_fu_10750_p6.read();
    } else {
        ap_phi_mux_data_303_V_read578_phi_phi_fu_21134_p4 = ap_phi_reg_pp0_iter1_data_303_V_read578_phi_reg_21130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_303_V_read578_rewind_phi_fu_10750_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_303_V_read578_rewind_phi_fu_10750_p6 = data_303_V_read578_phi_reg_21130.read();
    } else {
        ap_phi_mux_data_303_V_read578_rewind_phi_fu_10750_p6 = data_303_V_read578_rewind_reg_10746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_304_V_read579_phi_phi_fu_21146_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_304_V_read579_phi_phi_fu_21146_p4 = ap_phi_mux_data_304_V_read579_rewind_phi_fu_10764_p6.read();
    } else {
        ap_phi_mux_data_304_V_read579_phi_phi_fu_21146_p4 = ap_phi_reg_pp0_iter1_data_304_V_read579_phi_reg_21142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_304_V_read579_rewind_phi_fu_10764_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_304_V_read579_rewind_phi_fu_10764_p6 = data_304_V_read579_phi_reg_21142.read();
    } else {
        ap_phi_mux_data_304_V_read579_rewind_phi_fu_10764_p6 = data_304_V_read579_rewind_reg_10760.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_305_V_read580_phi_phi_fu_21158_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_305_V_read580_phi_phi_fu_21158_p4 = ap_phi_mux_data_305_V_read580_rewind_phi_fu_10778_p6.read();
    } else {
        ap_phi_mux_data_305_V_read580_phi_phi_fu_21158_p4 = ap_phi_reg_pp0_iter1_data_305_V_read580_phi_reg_21154.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_305_V_read580_rewind_phi_fu_10778_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_305_V_read580_rewind_phi_fu_10778_p6 = data_305_V_read580_phi_reg_21154.read();
    } else {
        ap_phi_mux_data_305_V_read580_rewind_phi_fu_10778_p6 = data_305_V_read580_rewind_reg_10774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_306_V_read581_phi_phi_fu_21170_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_306_V_read581_phi_phi_fu_21170_p4 = ap_phi_mux_data_306_V_read581_rewind_phi_fu_10792_p6.read();
    } else {
        ap_phi_mux_data_306_V_read581_phi_phi_fu_21170_p4 = ap_phi_reg_pp0_iter1_data_306_V_read581_phi_reg_21166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_306_V_read581_rewind_phi_fu_10792_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_306_V_read581_rewind_phi_fu_10792_p6 = data_306_V_read581_phi_reg_21166.read();
    } else {
        ap_phi_mux_data_306_V_read581_rewind_phi_fu_10792_p6 = data_306_V_read581_rewind_reg_10788.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_307_V_read582_phi_phi_fu_21182_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_307_V_read582_phi_phi_fu_21182_p4 = ap_phi_mux_data_307_V_read582_rewind_phi_fu_10806_p6.read();
    } else {
        ap_phi_mux_data_307_V_read582_phi_phi_fu_21182_p4 = ap_phi_reg_pp0_iter1_data_307_V_read582_phi_reg_21178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_307_V_read582_rewind_phi_fu_10806_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_307_V_read582_rewind_phi_fu_10806_p6 = data_307_V_read582_phi_reg_21178.read();
    } else {
        ap_phi_mux_data_307_V_read582_rewind_phi_fu_10806_p6 = data_307_V_read582_rewind_reg_10802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_308_V_read583_phi_phi_fu_21194_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_308_V_read583_phi_phi_fu_21194_p4 = ap_phi_mux_data_308_V_read583_rewind_phi_fu_10820_p6.read();
    } else {
        ap_phi_mux_data_308_V_read583_phi_phi_fu_21194_p4 = ap_phi_reg_pp0_iter1_data_308_V_read583_phi_reg_21190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_308_V_read583_rewind_phi_fu_10820_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_308_V_read583_rewind_phi_fu_10820_p6 = data_308_V_read583_phi_reg_21190.read();
    } else {
        ap_phi_mux_data_308_V_read583_rewind_phi_fu_10820_p6 = data_308_V_read583_rewind_reg_10816.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_309_V_read584_phi_phi_fu_21206_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_309_V_read584_phi_phi_fu_21206_p4 = ap_phi_mux_data_309_V_read584_rewind_phi_fu_10834_p6.read();
    } else {
        ap_phi_mux_data_309_V_read584_phi_phi_fu_21206_p4 = ap_phi_reg_pp0_iter1_data_309_V_read584_phi_reg_21202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_309_V_read584_rewind_phi_fu_10834_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_309_V_read584_rewind_phi_fu_10834_p6 = data_309_V_read584_phi_reg_21202.read();
    } else {
        ap_phi_mux_data_309_V_read584_rewind_phi_fu_10834_p6 = data_309_V_read584_rewind_reg_10830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_30_V_read305_phi_phi_fu_17858_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_30_V_read305_phi_phi_fu_17858_p4 = ap_phi_mux_data_30_V_read305_rewind_phi_fu_6928_p6.read();
    } else {
        ap_phi_mux_data_30_V_read305_phi_phi_fu_17858_p4 = ap_phi_reg_pp0_iter1_data_30_V_read305_phi_reg_17854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_30_V_read305_rewind_phi_fu_6928_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_30_V_read305_rewind_phi_fu_6928_p6 = data_30_V_read305_phi_reg_17854.read();
    } else {
        ap_phi_mux_data_30_V_read305_rewind_phi_fu_6928_p6 = data_30_V_read305_rewind_reg_6924.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_310_V_read585_phi_phi_fu_21218_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_310_V_read585_phi_phi_fu_21218_p4 = ap_phi_mux_data_310_V_read585_rewind_phi_fu_10848_p6.read();
    } else {
        ap_phi_mux_data_310_V_read585_phi_phi_fu_21218_p4 = ap_phi_reg_pp0_iter1_data_310_V_read585_phi_reg_21214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_310_V_read585_rewind_phi_fu_10848_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_310_V_read585_rewind_phi_fu_10848_p6 = data_310_V_read585_phi_reg_21214.read();
    } else {
        ap_phi_mux_data_310_V_read585_rewind_phi_fu_10848_p6 = data_310_V_read585_rewind_reg_10844.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_311_V_read586_phi_phi_fu_21230_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_311_V_read586_phi_phi_fu_21230_p4 = ap_phi_mux_data_311_V_read586_rewind_phi_fu_10862_p6.read();
    } else {
        ap_phi_mux_data_311_V_read586_phi_phi_fu_21230_p4 = ap_phi_reg_pp0_iter1_data_311_V_read586_phi_reg_21226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_311_V_read586_rewind_phi_fu_10862_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_311_V_read586_rewind_phi_fu_10862_p6 = data_311_V_read586_phi_reg_21226.read();
    } else {
        ap_phi_mux_data_311_V_read586_rewind_phi_fu_10862_p6 = data_311_V_read586_rewind_reg_10858.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_312_V_read587_phi_phi_fu_21242_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_312_V_read587_phi_phi_fu_21242_p4 = ap_phi_mux_data_312_V_read587_rewind_phi_fu_10876_p6.read();
    } else {
        ap_phi_mux_data_312_V_read587_phi_phi_fu_21242_p4 = ap_phi_reg_pp0_iter1_data_312_V_read587_phi_reg_21238.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_312_V_read587_rewind_phi_fu_10876_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_312_V_read587_rewind_phi_fu_10876_p6 = data_312_V_read587_phi_reg_21238.read();
    } else {
        ap_phi_mux_data_312_V_read587_rewind_phi_fu_10876_p6 = data_312_V_read587_rewind_reg_10872.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_313_V_read588_phi_phi_fu_21254_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_313_V_read588_phi_phi_fu_21254_p4 = ap_phi_mux_data_313_V_read588_rewind_phi_fu_10890_p6.read();
    } else {
        ap_phi_mux_data_313_V_read588_phi_phi_fu_21254_p4 = ap_phi_reg_pp0_iter1_data_313_V_read588_phi_reg_21250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_313_V_read588_rewind_phi_fu_10890_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_313_V_read588_rewind_phi_fu_10890_p6 = data_313_V_read588_phi_reg_21250.read();
    } else {
        ap_phi_mux_data_313_V_read588_rewind_phi_fu_10890_p6 = data_313_V_read588_rewind_reg_10886.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_314_V_read589_phi_phi_fu_21266_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_314_V_read589_phi_phi_fu_21266_p4 = ap_phi_mux_data_314_V_read589_rewind_phi_fu_10904_p6.read();
    } else {
        ap_phi_mux_data_314_V_read589_phi_phi_fu_21266_p4 = ap_phi_reg_pp0_iter1_data_314_V_read589_phi_reg_21262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_314_V_read589_rewind_phi_fu_10904_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_314_V_read589_rewind_phi_fu_10904_p6 = data_314_V_read589_phi_reg_21262.read();
    } else {
        ap_phi_mux_data_314_V_read589_rewind_phi_fu_10904_p6 = data_314_V_read589_rewind_reg_10900.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_315_V_read590_phi_phi_fu_21278_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_315_V_read590_phi_phi_fu_21278_p4 = ap_phi_mux_data_315_V_read590_rewind_phi_fu_10918_p6.read();
    } else {
        ap_phi_mux_data_315_V_read590_phi_phi_fu_21278_p4 = ap_phi_reg_pp0_iter1_data_315_V_read590_phi_reg_21274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_315_V_read590_rewind_phi_fu_10918_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_315_V_read590_rewind_phi_fu_10918_p6 = data_315_V_read590_phi_reg_21274.read();
    } else {
        ap_phi_mux_data_315_V_read590_rewind_phi_fu_10918_p6 = data_315_V_read590_rewind_reg_10914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_316_V_read591_phi_phi_fu_21290_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_316_V_read591_phi_phi_fu_21290_p4 = ap_phi_mux_data_316_V_read591_rewind_phi_fu_10932_p6.read();
    } else {
        ap_phi_mux_data_316_V_read591_phi_phi_fu_21290_p4 = ap_phi_reg_pp0_iter1_data_316_V_read591_phi_reg_21286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_316_V_read591_rewind_phi_fu_10932_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_316_V_read591_rewind_phi_fu_10932_p6 = data_316_V_read591_phi_reg_21286.read();
    } else {
        ap_phi_mux_data_316_V_read591_rewind_phi_fu_10932_p6 = data_316_V_read591_rewind_reg_10928.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_317_V_read592_phi_phi_fu_21302_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_317_V_read592_phi_phi_fu_21302_p4 = ap_phi_mux_data_317_V_read592_rewind_phi_fu_10946_p6.read();
    } else {
        ap_phi_mux_data_317_V_read592_phi_phi_fu_21302_p4 = ap_phi_reg_pp0_iter1_data_317_V_read592_phi_reg_21298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_317_V_read592_rewind_phi_fu_10946_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_317_V_read592_rewind_phi_fu_10946_p6 = data_317_V_read592_phi_reg_21298.read();
    } else {
        ap_phi_mux_data_317_V_read592_rewind_phi_fu_10946_p6 = data_317_V_read592_rewind_reg_10942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_318_V_read593_phi_phi_fu_21314_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_318_V_read593_phi_phi_fu_21314_p4 = ap_phi_mux_data_318_V_read593_rewind_phi_fu_10960_p6.read();
    } else {
        ap_phi_mux_data_318_V_read593_phi_phi_fu_21314_p4 = ap_phi_reg_pp0_iter1_data_318_V_read593_phi_reg_21310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_318_V_read593_rewind_phi_fu_10960_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_318_V_read593_rewind_phi_fu_10960_p6 = data_318_V_read593_phi_reg_21310.read();
    } else {
        ap_phi_mux_data_318_V_read593_rewind_phi_fu_10960_p6 = data_318_V_read593_rewind_reg_10956.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_319_V_read594_phi_phi_fu_21326_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_319_V_read594_phi_phi_fu_21326_p4 = ap_phi_mux_data_319_V_read594_rewind_phi_fu_10974_p6.read();
    } else {
        ap_phi_mux_data_319_V_read594_phi_phi_fu_21326_p4 = ap_phi_reg_pp0_iter1_data_319_V_read594_phi_reg_21322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_319_V_read594_rewind_phi_fu_10974_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_319_V_read594_rewind_phi_fu_10974_p6 = data_319_V_read594_phi_reg_21322.read();
    } else {
        ap_phi_mux_data_319_V_read594_rewind_phi_fu_10974_p6 = data_319_V_read594_rewind_reg_10970.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_31_V_read306_phi_phi_fu_17870_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_31_V_read306_phi_phi_fu_17870_p4 = ap_phi_mux_data_31_V_read306_rewind_phi_fu_6942_p6.read();
    } else {
        ap_phi_mux_data_31_V_read306_phi_phi_fu_17870_p4 = ap_phi_reg_pp0_iter1_data_31_V_read306_phi_reg_17866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_31_V_read306_rewind_phi_fu_6942_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_31_V_read306_rewind_phi_fu_6942_p6 = data_31_V_read306_phi_reg_17866.read();
    } else {
        ap_phi_mux_data_31_V_read306_rewind_phi_fu_6942_p6 = data_31_V_read306_rewind_reg_6938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_320_V_read595_phi_phi_fu_21338_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_320_V_read595_phi_phi_fu_21338_p4 = ap_phi_mux_data_320_V_read595_rewind_phi_fu_10988_p6.read();
    } else {
        ap_phi_mux_data_320_V_read595_phi_phi_fu_21338_p4 = ap_phi_reg_pp0_iter1_data_320_V_read595_phi_reg_21334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_320_V_read595_rewind_phi_fu_10988_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_320_V_read595_rewind_phi_fu_10988_p6 = data_320_V_read595_phi_reg_21334.read();
    } else {
        ap_phi_mux_data_320_V_read595_rewind_phi_fu_10988_p6 = data_320_V_read595_rewind_reg_10984.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_321_V_read596_phi_phi_fu_21350_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_321_V_read596_phi_phi_fu_21350_p4 = ap_phi_mux_data_321_V_read596_rewind_phi_fu_11002_p6.read();
    } else {
        ap_phi_mux_data_321_V_read596_phi_phi_fu_21350_p4 = ap_phi_reg_pp0_iter1_data_321_V_read596_phi_reg_21346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_321_V_read596_rewind_phi_fu_11002_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_321_V_read596_rewind_phi_fu_11002_p6 = data_321_V_read596_phi_reg_21346.read();
    } else {
        ap_phi_mux_data_321_V_read596_rewind_phi_fu_11002_p6 = data_321_V_read596_rewind_reg_10998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_322_V_read597_phi_phi_fu_21362_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_322_V_read597_phi_phi_fu_21362_p4 = ap_phi_mux_data_322_V_read597_rewind_phi_fu_11016_p6.read();
    } else {
        ap_phi_mux_data_322_V_read597_phi_phi_fu_21362_p4 = ap_phi_reg_pp0_iter1_data_322_V_read597_phi_reg_21358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_322_V_read597_rewind_phi_fu_11016_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_322_V_read597_rewind_phi_fu_11016_p6 = data_322_V_read597_phi_reg_21358.read();
    } else {
        ap_phi_mux_data_322_V_read597_rewind_phi_fu_11016_p6 = data_322_V_read597_rewind_reg_11012.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_323_V_read598_phi_phi_fu_21374_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_323_V_read598_phi_phi_fu_21374_p4 = ap_phi_mux_data_323_V_read598_rewind_phi_fu_11030_p6.read();
    } else {
        ap_phi_mux_data_323_V_read598_phi_phi_fu_21374_p4 = ap_phi_reg_pp0_iter1_data_323_V_read598_phi_reg_21370.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_323_V_read598_rewind_phi_fu_11030_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_323_V_read598_rewind_phi_fu_11030_p6 = data_323_V_read598_phi_reg_21370.read();
    } else {
        ap_phi_mux_data_323_V_read598_rewind_phi_fu_11030_p6 = data_323_V_read598_rewind_reg_11026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_324_V_read599_phi_phi_fu_21386_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_324_V_read599_phi_phi_fu_21386_p4 = ap_phi_mux_data_324_V_read599_rewind_phi_fu_11044_p6.read();
    } else {
        ap_phi_mux_data_324_V_read599_phi_phi_fu_21386_p4 = ap_phi_reg_pp0_iter1_data_324_V_read599_phi_reg_21382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_324_V_read599_rewind_phi_fu_11044_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_324_V_read599_rewind_phi_fu_11044_p6 = data_324_V_read599_phi_reg_21382.read();
    } else {
        ap_phi_mux_data_324_V_read599_rewind_phi_fu_11044_p6 = data_324_V_read599_rewind_reg_11040.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_325_V_read600_phi_phi_fu_21398_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_325_V_read600_phi_phi_fu_21398_p4 = ap_phi_mux_data_325_V_read600_rewind_phi_fu_11058_p6.read();
    } else {
        ap_phi_mux_data_325_V_read600_phi_phi_fu_21398_p4 = ap_phi_reg_pp0_iter1_data_325_V_read600_phi_reg_21394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_325_V_read600_rewind_phi_fu_11058_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_325_V_read600_rewind_phi_fu_11058_p6 = data_325_V_read600_phi_reg_21394.read();
    } else {
        ap_phi_mux_data_325_V_read600_rewind_phi_fu_11058_p6 = data_325_V_read600_rewind_reg_11054.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_326_V_read601_phi_phi_fu_21410_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_326_V_read601_phi_phi_fu_21410_p4 = ap_phi_mux_data_326_V_read601_rewind_phi_fu_11072_p6.read();
    } else {
        ap_phi_mux_data_326_V_read601_phi_phi_fu_21410_p4 = ap_phi_reg_pp0_iter1_data_326_V_read601_phi_reg_21406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_326_V_read601_rewind_phi_fu_11072_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_326_V_read601_rewind_phi_fu_11072_p6 = data_326_V_read601_phi_reg_21406.read();
    } else {
        ap_phi_mux_data_326_V_read601_rewind_phi_fu_11072_p6 = data_326_V_read601_rewind_reg_11068.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_327_V_read602_phi_phi_fu_21422_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_327_V_read602_phi_phi_fu_21422_p4 = ap_phi_mux_data_327_V_read602_rewind_phi_fu_11086_p6.read();
    } else {
        ap_phi_mux_data_327_V_read602_phi_phi_fu_21422_p4 = ap_phi_reg_pp0_iter1_data_327_V_read602_phi_reg_21418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_327_V_read602_rewind_phi_fu_11086_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_327_V_read602_rewind_phi_fu_11086_p6 = data_327_V_read602_phi_reg_21418.read();
    } else {
        ap_phi_mux_data_327_V_read602_rewind_phi_fu_11086_p6 = data_327_V_read602_rewind_reg_11082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_328_V_read603_phi_phi_fu_21434_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_328_V_read603_phi_phi_fu_21434_p4 = ap_phi_mux_data_328_V_read603_rewind_phi_fu_11100_p6.read();
    } else {
        ap_phi_mux_data_328_V_read603_phi_phi_fu_21434_p4 = ap_phi_reg_pp0_iter1_data_328_V_read603_phi_reg_21430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_328_V_read603_rewind_phi_fu_11100_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_328_V_read603_rewind_phi_fu_11100_p6 = data_328_V_read603_phi_reg_21430.read();
    } else {
        ap_phi_mux_data_328_V_read603_rewind_phi_fu_11100_p6 = data_328_V_read603_rewind_reg_11096.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_329_V_read604_phi_phi_fu_21446_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_329_V_read604_phi_phi_fu_21446_p4 = ap_phi_mux_data_329_V_read604_rewind_phi_fu_11114_p6.read();
    } else {
        ap_phi_mux_data_329_V_read604_phi_phi_fu_21446_p4 = ap_phi_reg_pp0_iter1_data_329_V_read604_phi_reg_21442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_329_V_read604_rewind_phi_fu_11114_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_329_V_read604_rewind_phi_fu_11114_p6 = data_329_V_read604_phi_reg_21442.read();
    } else {
        ap_phi_mux_data_329_V_read604_rewind_phi_fu_11114_p6 = data_329_V_read604_rewind_reg_11110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_32_V_read307_phi_phi_fu_17882_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_32_V_read307_phi_phi_fu_17882_p4 = ap_phi_mux_data_32_V_read307_rewind_phi_fu_6956_p6.read();
    } else {
        ap_phi_mux_data_32_V_read307_phi_phi_fu_17882_p4 = ap_phi_reg_pp0_iter1_data_32_V_read307_phi_reg_17878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_32_V_read307_rewind_phi_fu_6956_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_32_V_read307_rewind_phi_fu_6956_p6 = data_32_V_read307_phi_reg_17878.read();
    } else {
        ap_phi_mux_data_32_V_read307_rewind_phi_fu_6956_p6 = data_32_V_read307_rewind_reg_6952.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_330_V_read605_phi_phi_fu_21458_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_330_V_read605_phi_phi_fu_21458_p4 = ap_phi_mux_data_330_V_read605_rewind_phi_fu_11128_p6.read();
    } else {
        ap_phi_mux_data_330_V_read605_phi_phi_fu_21458_p4 = ap_phi_reg_pp0_iter1_data_330_V_read605_phi_reg_21454.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_330_V_read605_rewind_phi_fu_11128_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_330_V_read605_rewind_phi_fu_11128_p6 = data_330_V_read605_phi_reg_21454.read();
    } else {
        ap_phi_mux_data_330_V_read605_rewind_phi_fu_11128_p6 = data_330_V_read605_rewind_reg_11124.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_331_V_read606_phi_phi_fu_21470_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_331_V_read606_phi_phi_fu_21470_p4 = ap_phi_mux_data_331_V_read606_rewind_phi_fu_11142_p6.read();
    } else {
        ap_phi_mux_data_331_V_read606_phi_phi_fu_21470_p4 = ap_phi_reg_pp0_iter1_data_331_V_read606_phi_reg_21466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_331_V_read606_rewind_phi_fu_11142_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_331_V_read606_rewind_phi_fu_11142_p6 = data_331_V_read606_phi_reg_21466.read();
    } else {
        ap_phi_mux_data_331_V_read606_rewind_phi_fu_11142_p6 = data_331_V_read606_rewind_reg_11138.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_332_V_read607_phi_phi_fu_21482_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_332_V_read607_phi_phi_fu_21482_p4 = ap_phi_mux_data_332_V_read607_rewind_phi_fu_11156_p6.read();
    } else {
        ap_phi_mux_data_332_V_read607_phi_phi_fu_21482_p4 = ap_phi_reg_pp0_iter1_data_332_V_read607_phi_reg_21478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_332_V_read607_rewind_phi_fu_11156_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_332_V_read607_rewind_phi_fu_11156_p6 = data_332_V_read607_phi_reg_21478.read();
    } else {
        ap_phi_mux_data_332_V_read607_rewind_phi_fu_11156_p6 = data_332_V_read607_rewind_reg_11152.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_333_V_read608_phi_phi_fu_21494_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_333_V_read608_phi_phi_fu_21494_p4 = ap_phi_mux_data_333_V_read608_rewind_phi_fu_11170_p6.read();
    } else {
        ap_phi_mux_data_333_V_read608_phi_phi_fu_21494_p4 = ap_phi_reg_pp0_iter1_data_333_V_read608_phi_reg_21490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_333_V_read608_rewind_phi_fu_11170_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_333_V_read608_rewind_phi_fu_11170_p6 = data_333_V_read608_phi_reg_21490.read();
    } else {
        ap_phi_mux_data_333_V_read608_rewind_phi_fu_11170_p6 = data_333_V_read608_rewind_reg_11166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_334_V_read609_phi_phi_fu_21506_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_334_V_read609_phi_phi_fu_21506_p4 = ap_phi_mux_data_334_V_read609_rewind_phi_fu_11184_p6.read();
    } else {
        ap_phi_mux_data_334_V_read609_phi_phi_fu_21506_p4 = ap_phi_reg_pp0_iter1_data_334_V_read609_phi_reg_21502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_334_V_read609_rewind_phi_fu_11184_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_334_V_read609_rewind_phi_fu_11184_p6 = data_334_V_read609_phi_reg_21502.read();
    } else {
        ap_phi_mux_data_334_V_read609_rewind_phi_fu_11184_p6 = data_334_V_read609_rewind_reg_11180.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_335_V_read610_phi_phi_fu_21518_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_335_V_read610_phi_phi_fu_21518_p4 = ap_phi_mux_data_335_V_read610_rewind_phi_fu_11198_p6.read();
    } else {
        ap_phi_mux_data_335_V_read610_phi_phi_fu_21518_p4 = ap_phi_reg_pp0_iter1_data_335_V_read610_phi_reg_21514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_335_V_read610_rewind_phi_fu_11198_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_335_V_read610_rewind_phi_fu_11198_p6 = data_335_V_read610_phi_reg_21514.read();
    } else {
        ap_phi_mux_data_335_V_read610_rewind_phi_fu_11198_p6 = data_335_V_read610_rewind_reg_11194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_336_V_read611_phi_phi_fu_21530_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_336_V_read611_phi_phi_fu_21530_p4 = ap_phi_mux_data_336_V_read611_rewind_phi_fu_11212_p6.read();
    } else {
        ap_phi_mux_data_336_V_read611_phi_phi_fu_21530_p4 = ap_phi_reg_pp0_iter1_data_336_V_read611_phi_reg_21526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_336_V_read611_rewind_phi_fu_11212_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_336_V_read611_rewind_phi_fu_11212_p6 = data_336_V_read611_phi_reg_21526.read();
    } else {
        ap_phi_mux_data_336_V_read611_rewind_phi_fu_11212_p6 = data_336_V_read611_rewind_reg_11208.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_337_V_read612_phi_phi_fu_21542_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_337_V_read612_phi_phi_fu_21542_p4 = ap_phi_mux_data_337_V_read612_rewind_phi_fu_11226_p6.read();
    } else {
        ap_phi_mux_data_337_V_read612_phi_phi_fu_21542_p4 = ap_phi_reg_pp0_iter1_data_337_V_read612_phi_reg_21538.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_337_V_read612_rewind_phi_fu_11226_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_337_V_read612_rewind_phi_fu_11226_p6 = data_337_V_read612_phi_reg_21538.read();
    } else {
        ap_phi_mux_data_337_V_read612_rewind_phi_fu_11226_p6 = data_337_V_read612_rewind_reg_11222.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_338_V_read613_phi_phi_fu_21554_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_338_V_read613_phi_phi_fu_21554_p4 = ap_phi_mux_data_338_V_read613_rewind_phi_fu_11240_p6.read();
    } else {
        ap_phi_mux_data_338_V_read613_phi_phi_fu_21554_p4 = ap_phi_reg_pp0_iter1_data_338_V_read613_phi_reg_21550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_338_V_read613_rewind_phi_fu_11240_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_338_V_read613_rewind_phi_fu_11240_p6 = data_338_V_read613_phi_reg_21550.read();
    } else {
        ap_phi_mux_data_338_V_read613_rewind_phi_fu_11240_p6 = data_338_V_read613_rewind_reg_11236.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_339_V_read614_phi_phi_fu_21566_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_339_V_read614_phi_phi_fu_21566_p4 = ap_phi_mux_data_339_V_read614_rewind_phi_fu_11254_p6.read();
    } else {
        ap_phi_mux_data_339_V_read614_phi_phi_fu_21566_p4 = ap_phi_reg_pp0_iter1_data_339_V_read614_phi_reg_21562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_339_V_read614_rewind_phi_fu_11254_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_339_V_read614_rewind_phi_fu_11254_p6 = data_339_V_read614_phi_reg_21562.read();
    } else {
        ap_phi_mux_data_339_V_read614_rewind_phi_fu_11254_p6 = data_339_V_read614_rewind_reg_11250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_33_V_read308_phi_phi_fu_17894_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_33_V_read308_phi_phi_fu_17894_p4 = ap_phi_mux_data_33_V_read308_rewind_phi_fu_6970_p6.read();
    } else {
        ap_phi_mux_data_33_V_read308_phi_phi_fu_17894_p4 = ap_phi_reg_pp0_iter1_data_33_V_read308_phi_reg_17890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_33_V_read308_rewind_phi_fu_6970_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_33_V_read308_rewind_phi_fu_6970_p6 = data_33_V_read308_phi_reg_17890.read();
    } else {
        ap_phi_mux_data_33_V_read308_rewind_phi_fu_6970_p6 = data_33_V_read308_rewind_reg_6966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_340_V_read615_phi_phi_fu_21578_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_340_V_read615_phi_phi_fu_21578_p4 = ap_phi_mux_data_340_V_read615_rewind_phi_fu_11268_p6.read();
    } else {
        ap_phi_mux_data_340_V_read615_phi_phi_fu_21578_p4 = ap_phi_reg_pp0_iter1_data_340_V_read615_phi_reg_21574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_340_V_read615_rewind_phi_fu_11268_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_340_V_read615_rewind_phi_fu_11268_p6 = data_340_V_read615_phi_reg_21574.read();
    } else {
        ap_phi_mux_data_340_V_read615_rewind_phi_fu_11268_p6 = data_340_V_read615_rewind_reg_11264.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_341_V_read616_phi_phi_fu_21590_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_341_V_read616_phi_phi_fu_21590_p4 = ap_phi_mux_data_341_V_read616_rewind_phi_fu_11282_p6.read();
    } else {
        ap_phi_mux_data_341_V_read616_phi_phi_fu_21590_p4 = ap_phi_reg_pp0_iter1_data_341_V_read616_phi_reg_21586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_341_V_read616_rewind_phi_fu_11282_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_341_V_read616_rewind_phi_fu_11282_p6 = data_341_V_read616_phi_reg_21586.read();
    } else {
        ap_phi_mux_data_341_V_read616_rewind_phi_fu_11282_p6 = data_341_V_read616_rewind_reg_11278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_342_V_read617_phi_phi_fu_21602_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_342_V_read617_phi_phi_fu_21602_p4 = ap_phi_mux_data_342_V_read617_rewind_phi_fu_11296_p6.read();
    } else {
        ap_phi_mux_data_342_V_read617_phi_phi_fu_21602_p4 = ap_phi_reg_pp0_iter1_data_342_V_read617_phi_reg_21598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_342_V_read617_rewind_phi_fu_11296_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_342_V_read617_rewind_phi_fu_11296_p6 = data_342_V_read617_phi_reg_21598.read();
    } else {
        ap_phi_mux_data_342_V_read617_rewind_phi_fu_11296_p6 = data_342_V_read617_rewind_reg_11292.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_343_V_read618_phi_phi_fu_21614_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_343_V_read618_phi_phi_fu_21614_p4 = ap_phi_mux_data_343_V_read618_rewind_phi_fu_11310_p6.read();
    } else {
        ap_phi_mux_data_343_V_read618_phi_phi_fu_21614_p4 = ap_phi_reg_pp0_iter1_data_343_V_read618_phi_reg_21610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_343_V_read618_rewind_phi_fu_11310_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_343_V_read618_rewind_phi_fu_11310_p6 = data_343_V_read618_phi_reg_21610.read();
    } else {
        ap_phi_mux_data_343_V_read618_rewind_phi_fu_11310_p6 = data_343_V_read618_rewind_reg_11306.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_344_V_read619_phi_phi_fu_21626_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_344_V_read619_phi_phi_fu_21626_p4 = ap_phi_mux_data_344_V_read619_rewind_phi_fu_11324_p6.read();
    } else {
        ap_phi_mux_data_344_V_read619_phi_phi_fu_21626_p4 = ap_phi_reg_pp0_iter1_data_344_V_read619_phi_reg_21622.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_344_V_read619_rewind_phi_fu_11324_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_344_V_read619_rewind_phi_fu_11324_p6 = data_344_V_read619_phi_reg_21622.read();
    } else {
        ap_phi_mux_data_344_V_read619_rewind_phi_fu_11324_p6 = data_344_V_read619_rewind_reg_11320.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_345_V_read620_phi_phi_fu_21638_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_345_V_read620_phi_phi_fu_21638_p4 = ap_phi_mux_data_345_V_read620_rewind_phi_fu_11338_p6.read();
    } else {
        ap_phi_mux_data_345_V_read620_phi_phi_fu_21638_p4 = ap_phi_reg_pp0_iter1_data_345_V_read620_phi_reg_21634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_345_V_read620_rewind_phi_fu_11338_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_345_V_read620_rewind_phi_fu_11338_p6 = data_345_V_read620_phi_reg_21634.read();
    } else {
        ap_phi_mux_data_345_V_read620_rewind_phi_fu_11338_p6 = data_345_V_read620_rewind_reg_11334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_346_V_read621_phi_phi_fu_21650_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_346_V_read621_phi_phi_fu_21650_p4 = ap_phi_mux_data_346_V_read621_rewind_phi_fu_11352_p6.read();
    } else {
        ap_phi_mux_data_346_V_read621_phi_phi_fu_21650_p4 = ap_phi_reg_pp0_iter1_data_346_V_read621_phi_reg_21646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_346_V_read621_rewind_phi_fu_11352_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_346_V_read621_rewind_phi_fu_11352_p6 = data_346_V_read621_phi_reg_21646.read();
    } else {
        ap_phi_mux_data_346_V_read621_rewind_phi_fu_11352_p6 = data_346_V_read621_rewind_reg_11348.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_347_V_read622_phi_phi_fu_21662_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_347_V_read622_phi_phi_fu_21662_p4 = ap_phi_mux_data_347_V_read622_rewind_phi_fu_11366_p6.read();
    } else {
        ap_phi_mux_data_347_V_read622_phi_phi_fu_21662_p4 = ap_phi_reg_pp0_iter1_data_347_V_read622_phi_reg_21658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_347_V_read622_rewind_phi_fu_11366_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_347_V_read622_rewind_phi_fu_11366_p6 = data_347_V_read622_phi_reg_21658.read();
    } else {
        ap_phi_mux_data_347_V_read622_rewind_phi_fu_11366_p6 = data_347_V_read622_rewind_reg_11362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_348_V_read623_phi_phi_fu_21674_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_348_V_read623_phi_phi_fu_21674_p4 = ap_phi_mux_data_348_V_read623_rewind_phi_fu_11380_p6.read();
    } else {
        ap_phi_mux_data_348_V_read623_phi_phi_fu_21674_p4 = ap_phi_reg_pp0_iter1_data_348_V_read623_phi_reg_21670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_348_V_read623_rewind_phi_fu_11380_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_348_V_read623_rewind_phi_fu_11380_p6 = data_348_V_read623_phi_reg_21670.read();
    } else {
        ap_phi_mux_data_348_V_read623_rewind_phi_fu_11380_p6 = data_348_V_read623_rewind_reg_11376.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_349_V_read624_phi_phi_fu_21686_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_349_V_read624_phi_phi_fu_21686_p4 = ap_phi_mux_data_349_V_read624_rewind_phi_fu_11394_p6.read();
    } else {
        ap_phi_mux_data_349_V_read624_phi_phi_fu_21686_p4 = ap_phi_reg_pp0_iter1_data_349_V_read624_phi_reg_21682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_349_V_read624_rewind_phi_fu_11394_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_349_V_read624_rewind_phi_fu_11394_p6 = data_349_V_read624_phi_reg_21682.read();
    } else {
        ap_phi_mux_data_349_V_read624_rewind_phi_fu_11394_p6 = data_349_V_read624_rewind_reg_11390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_34_V_read309_phi_phi_fu_17906_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_34_V_read309_phi_phi_fu_17906_p4 = ap_phi_mux_data_34_V_read309_rewind_phi_fu_6984_p6.read();
    } else {
        ap_phi_mux_data_34_V_read309_phi_phi_fu_17906_p4 = ap_phi_reg_pp0_iter1_data_34_V_read309_phi_reg_17902.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_34_V_read309_rewind_phi_fu_6984_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_34_V_read309_rewind_phi_fu_6984_p6 = data_34_V_read309_phi_reg_17902.read();
    } else {
        ap_phi_mux_data_34_V_read309_rewind_phi_fu_6984_p6 = data_34_V_read309_rewind_reg_6980.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_350_V_read625_phi_phi_fu_21698_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_350_V_read625_phi_phi_fu_21698_p4 = ap_phi_mux_data_350_V_read625_rewind_phi_fu_11408_p6.read();
    } else {
        ap_phi_mux_data_350_V_read625_phi_phi_fu_21698_p4 = ap_phi_reg_pp0_iter1_data_350_V_read625_phi_reg_21694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_350_V_read625_rewind_phi_fu_11408_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_350_V_read625_rewind_phi_fu_11408_p6 = data_350_V_read625_phi_reg_21694.read();
    } else {
        ap_phi_mux_data_350_V_read625_rewind_phi_fu_11408_p6 = data_350_V_read625_rewind_reg_11404.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_351_V_read626_phi_phi_fu_21710_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_351_V_read626_phi_phi_fu_21710_p4 = ap_phi_mux_data_351_V_read626_rewind_phi_fu_11422_p6.read();
    } else {
        ap_phi_mux_data_351_V_read626_phi_phi_fu_21710_p4 = ap_phi_reg_pp0_iter1_data_351_V_read626_phi_reg_21706.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_351_V_read626_rewind_phi_fu_11422_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_351_V_read626_rewind_phi_fu_11422_p6 = data_351_V_read626_phi_reg_21706.read();
    } else {
        ap_phi_mux_data_351_V_read626_rewind_phi_fu_11422_p6 = data_351_V_read626_rewind_reg_11418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_352_V_read627_phi_phi_fu_21722_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_352_V_read627_phi_phi_fu_21722_p4 = ap_phi_mux_data_352_V_read627_rewind_phi_fu_11436_p6.read();
    } else {
        ap_phi_mux_data_352_V_read627_phi_phi_fu_21722_p4 = ap_phi_reg_pp0_iter1_data_352_V_read627_phi_reg_21718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_352_V_read627_rewind_phi_fu_11436_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_352_V_read627_rewind_phi_fu_11436_p6 = data_352_V_read627_phi_reg_21718.read();
    } else {
        ap_phi_mux_data_352_V_read627_rewind_phi_fu_11436_p6 = data_352_V_read627_rewind_reg_11432.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_353_V_read628_phi_phi_fu_21734_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_353_V_read628_phi_phi_fu_21734_p4 = ap_phi_mux_data_353_V_read628_rewind_phi_fu_11450_p6.read();
    } else {
        ap_phi_mux_data_353_V_read628_phi_phi_fu_21734_p4 = ap_phi_reg_pp0_iter1_data_353_V_read628_phi_reg_21730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_353_V_read628_rewind_phi_fu_11450_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_353_V_read628_rewind_phi_fu_11450_p6 = data_353_V_read628_phi_reg_21730.read();
    } else {
        ap_phi_mux_data_353_V_read628_rewind_phi_fu_11450_p6 = data_353_V_read628_rewind_reg_11446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_354_V_read629_phi_phi_fu_21746_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_354_V_read629_phi_phi_fu_21746_p4 = ap_phi_mux_data_354_V_read629_rewind_phi_fu_11464_p6.read();
    } else {
        ap_phi_mux_data_354_V_read629_phi_phi_fu_21746_p4 = ap_phi_reg_pp0_iter1_data_354_V_read629_phi_reg_21742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_354_V_read629_rewind_phi_fu_11464_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_354_V_read629_rewind_phi_fu_11464_p6 = data_354_V_read629_phi_reg_21742.read();
    } else {
        ap_phi_mux_data_354_V_read629_rewind_phi_fu_11464_p6 = data_354_V_read629_rewind_reg_11460.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_355_V_read630_phi_phi_fu_21758_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_355_V_read630_phi_phi_fu_21758_p4 = ap_phi_mux_data_355_V_read630_rewind_phi_fu_11478_p6.read();
    } else {
        ap_phi_mux_data_355_V_read630_phi_phi_fu_21758_p4 = ap_phi_reg_pp0_iter1_data_355_V_read630_phi_reg_21754.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_355_V_read630_rewind_phi_fu_11478_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_355_V_read630_rewind_phi_fu_11478_p6 = data_355_V_read630_phi_reg_21754.read();
    } else {
        ap_phi_mux_data_355_V_read630_rewind_phi_fu_11478_p6 = data_355_V_read630_rewind_reg_11474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_356_V_read631_phi_phi_fu_21770_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_356_V_read631_phi_phi_fu_21770_p4 = ap_phi_mux_data_356_V_read631_rewind_phi_fu_11492_p6.read();
    } else {
        ap_phi_mux_data_356_V_read631_phi_phi_fu_21770_p4 = ap_phi_reg_pp0_iter1_data_356_V_read631_phi_reg_21766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_356_V_read631_rewind_phi_fu_11492_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_356_V_read631_rewind_phi_fu_11492_p6 = data_356_V_read631_phi_reg_21766.read();
    } else {
        ap_phi_mux_data_356_V_read631_rewind_phi_fu_11492_p6 = data_356_V_read631_rewind_reg_11488.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_357_V_read632_phi_phi_fu_21782_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_357_V_read632_phi_phi_fu_21782_p4 = ap_phi_mux_data_357_V_read632_rewind_phi_fu_11506_p6.read();
    } else {
        ap_phi_mux_data_357_V_read632_phi_phi_fu_21782_p4 = ap_phi_reg_pp0_iter1_data_357_V_read632_phi_reg_21778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_357_V_read632_rewind_phi_fu_11506_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_357_V_read632_rewind_phi_fu_11506_p6 = data_357_V_read632_phi_reg_21778.read();
    } else {
        ap_phi_mux_data_357_V_read632_rewind_phi_fu_11506_p6 = data_357_V_read632_rewind_reg_11502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_358_V_read633_phi_phi_fu_21794_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_358_V_read633_phi_phi_fu_21794_p4 = ap_phi_mux_data_358_V_read633_rewind_phi_fu_11520_p6.read();
    } else {
        ap_phi_mux_data_358_V_read633_phi_phi_fu_21794_p4 = ap_phi_reg_pp0_iter1_data_358_V_read633_phi_reg_21790.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_358_V_read633_rewind_phi_fu_11520_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_358_V_read633_rewind_phi_fu_11520_p6 = data_358_V_read633_phi_reg_21790.read();
    } else {
        ap_phi_mux_data_358_V_read633_rewind_phi_fu_11520_p6 = data_358_V_read633_rewind_reg_11516.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_359_V_read634_phi_phi_fu_21806_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_359_V_read634_phi_phi_fu_21806_p4 = ap_phi_mux_data_359_V_read634_rewind_phi_fu_11534_p6.read();
    } else {
        ap_phi_mux_data_359_V_read634_phi_phi_fu_21806_p4 = ap_phi_reg_pp0_iter1_data_359_V_read634_phi_reg_21802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_359_V_read634_rewind_phi_fu_11534_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_359_V_read634_rewind_phi_fu_11534_p6 = data_359_V_read634_phi_reg_21802.read();
    } else {
        ap_phi_mux_data_359_V_read634_rewind_phi_fu_11534_p6 = data_359_V_read634_rewind_reg_11530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_35_V_read310_phi_phi_fu_17918_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_35_V_read310_phi_phi_fu_17918_p4 = ap_phi_mux_data_35_V_read310_rewind_phi_fu_6998_p6.read();
    } else {
        ap_phi_mux_data_35_V_read310_phi_phi_fu_17918_p4 = ap_phi_reg_pp0_iter1_data_35_V_read310_phi_reg_17914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_35_V_read310_rewind_phi_fu_6998_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_35_V_read310_rewind_phi_fu_6998_p6 = data_35_V_read310_phi_reg_17914.read();
    } else {
        ap_phi_mux_data_35_V_read310_rewind_phi_fu_6998_p6 = data_35_V_read310_rewind_reg_6994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_360_V_read635_phi_phi_fu_21818_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_360_V_read635_phi_phi_fu_21818_p4 = ap_phi_mux_data_360_V_read635_rewind_phi_fu_11548_p6.read();
    } else {
        ap_phi_mux_data_360_V_read635_phi_phi_fu_21818_p4 = ap_phi_reg_pp0_iter1_data_360_V_read635_phi_reg_21814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_360_V_read635_rewind_phi_fu_11548_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_360_V_read635_rewind_phi_fu_11548_p6 = data_360_V_read635_phi_reg_21814.read();
    } else {
        ap_phi_mux_data_360_V_read635_rewind_phi_fu_11548_p6 = data_360_V_read635_rewind_reg_11544.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_361_V_read636_phi_phi_fu_21830_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_361_V_read636_phi_phi_fu_21830_p4 = ap_phi_mux_data_361_V_read636_rewind_phi_fu_11562_p6.read();
    } else {
        ap_phi_mux_data_361_V_read636_phi_phi_fu_21830_p4 = ap_phi_reg_pp0_iter1_data_361_V_read636_phi_reg_21826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_361_V_read636_rewind_phi_fu_11562_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_361_V_read636_rewind_phi_fu_11562_p6 = data_361_V_read636_phi_reg_21826.read();
    } else {
        ap_phi_mux_data_361_V_read636_rewind_phi_fu_11562_p6 = data_361_V_read636_rewind_reg_11558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_362_V_read637_phi_phi_fu_21842_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_362_V_read637_phi_phi_fu_21842_p4 = ap_phi_mux_data_362_V_read637_rewind_phi_fu_11576_p6.read();
    } else {
        ap_phi_mux_data_362_V_read637_phi_phi_fu_21842_p4 = ap_phi_reg_pp0_iter1_data_362_V_read637_phi_reg_21838.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_362_V_read637_rewind_phi_fu_11576_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_362_V_read637_rewind_phi_fu_11576_p6 = data_362_V_read637_phi_reg_21838.read();
    } else {
        ap_phi_mux_data_362_V_read637_rewind_phi_fu_11576_p6 = data_362_V_read637_rewind_reg_11572.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_363_V_read638_phi_phi_fu_21854_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_363_V_read638_phi_phi_fu_21854_p4 = ap_phi_mux_data_363_V_read638_rewind_phi_fu_11590_p6.read();
    } else {
        ap_phi_mux_data_363_V_read638_phi_phi_fu_21854_p4 = ap_phi_reg_pp0_iter1_data_363_V_read638_phi_reg_21850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_363_V_read638_rewind_phi_fu_11590_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_363_V_read638_rewind_phi_fu_11590_p6 = data_363_V_read638_phi_reg_21850.read();
    } else {
        ap_phi_mux_data_363_V_read638_rewind_phi_fu_11590_p6 = data_363_V_read638_rewind_reg_11586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_364_V_read639_phi_phi_fu_21866_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_364_V_read639_phi_phi_fu_21866_p4 = ap_phi_mux_data_364_V_read639_rewind_phi_fu_11604_p6.read();
    } else {
        ap_phi_mux_data_364_V_read639_phi_phi_fu_21866_p4 = ap_phi_reg_pp0_iter1_data_364_V_read639_phi_reg_21862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_364_V_read639_rewind_phi_fu_11604_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_364_V_read639_rewind_phi_fu_11604_p6 = data_364_V_read639_phi_reg_21862.read();
    } else {
        ap_phi_mux_data_364_V_read639_rewind_phi_fu_11604_p6 = data_364_V_read639_rewind_reg_11600.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_365_V_read640_phi_phi_fu_21878_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_365_V_read640_phi_phi_fu_21878_p4 = ap_phi_mux_data_365_V_read640_rewind_phi_fu_11618_p6.read();
    } else {
        ap_phi_mux_data_365_V_read640_phi_phi_fu_21878_p4 = ap_phi_reg_pp0_iter1_data_365_V_read640_phi_reg_21874.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_365_V_read640_rewind_phi_fu_11618_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_365_V_read640_rewind_phi_fu_11618_p6 = data_365_V_read640_phi_reg_21874.read();
    } else {
        ap_phi_mux_data_365_V_read640_rewind_phi_fu_11618_p6 = data_365_V_read640_rewind_reg_11614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_366_V_read641_phi_phi_fu_21890_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_366_V_read641_phi_phi_fu_21890_p4 = ap_phi_mux_data_366_V_read641_rewind_phi_fu_11632_p6.read();
    } else {
        ap_phi_mux_data_366_V_read641_phi_phi_fu_21890_p4 = ap_phi_reg_pp0_iter1_data_366_V_read641_phi_reg_21886.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_366_V_read641_rewind_phi_fu_11632_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_366_V_read641_rewind_phi_fu_11632_p6 = data_366_V_read641_phi_reg_21886.read();
    } else {
        ap_phi_mux_data_366_V_read641_rewind_phi_fu_11632_p6 = data_366_V_read641_rewind_reg_11628.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_367_V_read642_phi_phi_fu_21902_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_367_V_read642_phi_phi_fu_21902_p4 = ap_phi_mux_data_367_V_read642_rewind_phi_fu_11646_p6.read();
    } else {
        ap_phi_mux_data_367_V_read642_phi_phi_fu_21902_p4 = ap_phi_reg_pp0_iter1_data_367_V_read642_phi_reg_21898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_367_V_read642_rewind_phi_fu_11646_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_367_V_read642_rewind_phi_fu_11646_p6 = data_367_V_read642_phi_reg_21898.read();
    } else {
        ap_phi_mux_data_367_V_read642_rewind_phi_fu_11646_p6 = data_367_V_read642_rewind_reg_11642.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_368_V_read643_phi_phi_fu_21914_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_368_V_read643_phi_phi_fu_21914_p4 = ap_phi_mux_data_368_V_read643_rewind_phi_fu_11660_p6.read();
    } else {
        ap_phi_mux_data_368_V_read643_phi_phi_fu_21914_p4 = ap_phi_reg_pp0_iter1_data_368_V_read643_phi_reg_21910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_368_V_read643_rewind_phi_fu_11660_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_368_V_read643_rewind_phi_fu_11660_p6 = data_368_V_read643_phi_reg_21910.read();
    } else {
        ap_phi_mux_data_368_V_read643_rewind_phi_fu_11660_p6 = data_368_V_read643_rewind_reg_11656.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_369_V_read644_phi_phi_fu_21926_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_369_V_read644_phi_phi_fu_21926_p4 = ap_phi_mux_data_369_V_read644_rewind_phi_fu_11674_p6.read();
    } else {
        ap_phi_mux_data_369_V_read644_phi_phi_fu_21926_p4 = ap_phi_reg_pp0_iter1_data_369_V_read644_phi_reg_21922.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_369_V_read644_rewind_phi_fu_11674_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_369_V_read644_rewind_phi_fu_11674_p6 = data_369_V_read644_phi_reg_21922.read();
    } else {
        ap_phi_mux_data_369_V_read644_rewind_phi_fu_11674_p6 = data_369_V_read644_rewind_reg_11670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_36_V_read311_phi_phi_fu_17930_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_36_V_read311_phi_phi_fu_17930_p4 = ap_phi_mux_data_36_V_read311_rewind_phi_fu_7012_p6.read();
    } else {
        ap_phi_mux_data_36_V_read311_phi_phi_fu_17930_p4 = ap_phi_reg_pp0_iter1_data_36_V_read311_phi_reg_17926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_36_V_read311_rewind_phi_fu_7012_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_36_V_read311_rewind_phi_fu_7012_p6 = data_36_V_read311_phi_reg_17926.read();
    } else {
        ap_phi_mux_data_36_V_read311_rewind_phi_fu_7012_p6 = data_36_V_read311_rewind_reg_7008.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_370_V_read645_phi_phi_fu_21938_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_370_V_read645_phi_phi_fu_21938_p4 = ap_phi_mux_data_370_V_read645_rewind_phi_fu_11688_p6.read();
    } else {
        ap_phi_mux_data_370_V_read645_phi_phi_fu_21938_p4 = ap_phi_reg_pp0_iter1_data_370_V_read645_phi_reg_21934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_370_V_read645_rewind_phi_fu_11688_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_370_V_read645_rewind_phi_fu_11688_p6 = data_370_V_read645_phi_reg_21934.read();
    } else {
        ap_phi_mux_data_370_V_read645_rewind_phi_fu_11688_p6 = data_370_V_read645_rewind_reg_11684.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_371_V_read646_phi_phi_fu_21950_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_371_V_read646_phi_phi_fu_21950_p4 = ap_phi_mux_data_371_V_read646_rewind_phi_fu_11702_p6.read();
    } else {
        ap_phi_mux_data_371_V_read646_phi_phi_fu_21950_p4 = ap_phi_reg_pp0_iter1_data_371_V_read646_phi_reg_21946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_371_V_read646_rewind_phi_fu_11702_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_371_V_read646_rewind_phi_fu_11702_p6 = data_371_V_read646_phi_reg_21946.read();
    } else {
        ap_phi_mux_data_371_V_read646_rewind_phi_fu_11702_p6 = data_371_V_read646_rewind_reg_11698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_372_V_read647_phi_phi_fu_21962_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_372_V_read647_phi_phi_fu_21962_p4 = ap_phi_mux_data_372_V_read647_rewind_phi_fu_11716_p6.read();
    } else {
        ap_phi_mux_data_372_V_read647_phi_phi_fu_21962_p4 = ap_phi_reg_pp0_iter1_data_372_V_read647_phi_reg_21958.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_372_V_read647_rewind_phi_fu_11716_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_372_V_read647_rewind_phi_fu_11716_p6 = data_372_V_read647_phi_reg_21958.read();
    } else {
        ap_phi_mux_data_372_V_read647_rewind_phi_fu_11716_p6 = data_372_V_read647_rewind_reg_11712.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_373_V_read648_phi_phi_fu_21974_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_373_V_read648_phi_phi_fu_21974_p4 = ap_phi_mux_data_373_V_read648_rewind_phi_fu_11730_p6.read();
    } else {
        ap_phi_mux_data_373_V_read648_phi_phi_fu_21974_p4 = ap_phi_reg_pp0_iter1_data_373_V_read648_phi_reg_21970.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_373_V_read648_rewind_phi_fu_11730_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_373_V_read648_rewind_phi_fu_11730_p6 = data_373_V_read648_phi_reg_21970.read();
    } else {
        ap_phi_mux_data_373_V_read648_rewind_phi_fu_11730_p6 = data_373_V_read648_rewind_reg_11726.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_374_V_read649_phi_phi_fu_21986_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_374_V_read649_phi_phi_fu_21986_p4 = ap_phi_mux_data_374_V_read649_rewind_phi_fu_11744_p6.read();
    } else {
        ap_phi_mux_data_374_V_read649_phi_phi_fu_21986_p4 = ap_phi_reg_pp0_iter1_data_374_V_read649_phi_reg_21982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_374_V_read649_rewind_phi_fu_11744_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_374_V_read649_rewind_phi_fu_11744_p6 = data_374_V_read649_phi_reg_21982.read();
    } else {
        ap_phi_mux_data_374_V_read649_rewind_phi_fu_11744_p6 = data_374_V_read649_rewind_reg_11740.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_375_V_read650_phi_phi_fu_21998_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_375_V_read650_phi_phi_fu_21998_p4 = ap_phi_mux_data_375_V_read650_rewind_phi_fu_11758_p6.read();
    } else {
        ap_phi_mux_data_375_V_read650_phi_phi_fu_21998_p4 = ap_phi_reg_pp0_iter1_data_375_V_read650_phi_reg_21994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_375_V_read650_rewind_phi_fu_11758_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_375_V_read650_rewind_phi_fu_11758_p6 = data_375_V_read650_phi_reg_21994.read();
    } else {
        ap_phi_mux_data_375_V_read650_rewind_phi_fu_11758_p6 = data_375_V_read650_rewind_reg_11754.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_376_V_read651_phi_phi_fu_22010_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_376_V_read651_phi_phi_fu_22010_p4 = ap_phi_mux_data_376_V_read651_rewind_phi_fu_11772_p6.read();
    } else {
        ap_phi_mux_data_376_V_read651_phi_phi_fu_22010_p4 = ap_phi_reg_pp0_iter1_data_376_V_read651_phi_reg_22006.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_376_V_read651_rewind_phi_fu_11772_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_376_V_read651_rewind_phi_fu_11772_p6 = data_376_V_read651_phi_reg_22006.read();
    } else {
        ap_phi_mux_data_376_V_read651_rewind_phi_fu_11772_p6 = data_376_V_read651_rewind_reg_11768.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_377_V_read652_phi_phi_fu_22022_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_377_V_read652_phi_phi_fu_22022_p4 = ap_phi_mux_data_377_V_read652_rewind_phi_fu_11786_p6.read();
    } else {
        ap_phi_mux_data_377_V_read652_phi_phi_fu_22022_p4 = ap_phi_reg_pp0_iter1_data_377_V_read652_phi_reg_22018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_377_V_read652_rewind_phi_fu_11786_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_377_V_read652_rewind_phi_fu_11786_p6 = data_377_V_read652_phi_reg_22018.read();
    } else {
        ap_phi_mux_data_377_V_read652_rewind_phi_fu_11786_p6 = data_377_V_read652_rewind_reg_11782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_378_V_read653_phi_phi_fu_22034_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_378_V_read653_phi_phi_fu_22034_p4 = ap_phi_mux_data_378_V_read653_rewind_phi_fu_11800_p6.read();
    } else {
        ap_phi_mux_data_378_V_read653_phi_phi_fu_22034_p4 = ap_phi_reg_pp0_iter1_data_378_V_read653_phi_reg_22030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_378_V_read653_rewind_phi_fu_11800_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_378_V_read653_rewind_phi_fu_11800_p6 = data_378_V_read653_phi_reg_22030.read();
    } else {
        ap_phi_mux_data_378_V_read653_rewind_phi_fu_11800_p6 = data_378_V_read653_rewind_reg_11796.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_379_V_read654_phi_phi_fu_22046_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_379_V_read654_phi_phi_fu_22046_p4 = ap_phi_mux_data_379_V_read654_rewind_phi_fu_11814_p6.read();
    } else {
        ap_phi_mux_data_379_V_read654_phi_phi_fu_22046_p4 = ap_phi_reg_pp0_iter1_data_379_V_read654_phi_reg_22042.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_379_V_read654_rewind_phi_fu_11814_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_379_V_read654_rewind_phi_fu_11814_p6 = data_379_V_read654_phi_reg_22042.read();
    } else {
        ap_phi_mux_data_379_V_read654_rewind_phi_fu_11814_p6 = data_379_V_read654_rewind_reg_11810.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_37_V_read312_phi_phi_fu_17942_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_37_V_read312_phi_phi_fu_17942_p4 = ap_phi_mux_data_37_V_read312_rewind_phi_fu_7026_p6.read();
    } else {
        ap_phi_mux_data_37_V_read312_phi_phi_fu_17942_p4 = ap_phi_reg_pp0_iter1_data_37_V_read312_phi_reg_17938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_37_V_read312_rewind_phi_fu_7026_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_37_V_read312_rewind_phi_fu_7026_p6 = data_37_V_read312_phi_reg_17938.read();
    } else {
        ap_phi_mux_data_37_V_read312_rewind_phi_fu_7026_p6 = data_37_V_read312_rewind_reg_7022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_380_V_read655_phi_phi_fu_22058_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_380_V_read655_phi_phi_fu_22058_p4 = ap_phi_mux_data_380_V_read655_rewind_phi_fu_11828_p6.read();
    } else {
        ap_phi_mux_data_380_V_read655_phi_phi_fu_22058_p4 = ap_phi_reg_pp0_iter1_data_380_V_read655_phi_reg_22054.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_380_V_read655_rewind_phi_fu_11828_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_380_V_read655_rewind_phi_fu_11828_p6 = data_380_V_read655_phi_reg_22054.read();
    } else {
        ap_phi_mux_data_380_V_read655_rewind_phi_fu_11828_p6 = data_380_V_read655_rewind_reg_11824.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_381_V_read656_phi_phi_fu_22070_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_381_V_read656_phi_phi_fu_22070_p4 = ap_phi_mux_data_381_V_read656_rewind_phi_fu_11842_p6.read();
    } else {
        ap_phi_mux_data_381_V_read656_phi_phi_fu_22070_p4 = ap_phi_reg_pp0_iter1_data_381_V_read656_phi_reg_22066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_381_V_read656_rewind_phi_fu_11842_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_381_V_read656_rewind_phi_fu_11842_p6 = data_381_V_read656_phi_reg_22066.read();
    } else {
        ap_phi_mux_data_381_V_read656_rewind_phi_fu_11842_p6 = data_381_V_read656_rewind_reg_11838.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_382_V_read657_phi_phi_fu_22082_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_382_V_read657_phi_phi_fu_22082_p4 = ap_phi_mux_data_382_V_read657_rewind_phi_fu_11856_p6.read();
    } else {
        ap_phi_mux_data_382_V_read657_phi_phi_fu_22082_p4 = ap_phi_reg_pp0_iter1_data_382_V_read657_phi_reg_22078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_382_V_read657_rewind_phi_fu_11856_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_382_V_read657_rewind_phi_fu_11856_p6 = data_382_V_read657_phi_reg_22078.read();
    } else {
        ap_phi_mux_data_382_V_read657_rewind_phi_fu_11856_p6 = data_382_V_read657_rewind_reg_11852.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_383_V_read658_phi_phi_fu_22094_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_383_V_read658_phi_phi_fu_22094_p4 = ap_phi_mux_data_383_V_read658_rewind_phi_fu_11870_p6.read();
    } else {
        ap_phi_mux_data_383_V_read658_phi_phi_fu_22094_p4 = ap_phi_reg_pp0_iter1_data_383_V_read658_phi_reg_22090.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_383_V_read658_rewind_phi_fu_11870_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_383_V_read658_rewind_phi_fu_11870_p6 = data_383_V_read658_phi_reg_22090.read();
    } else {
        ap_phi_mux_data_383_V_read658_rewind_phi_fu_11870_p6 = data_383_V_read658_rewind_reg_11866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_384_V_read659_phi_phi_fu_22106_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_384_V_read659_phi_phi_fu_22106_p4 = ap_phi_mux_data_384_V_read659_rewind_phi_fu_11884_p6.read();
    } else {
        ap_phi_mux_data_384_V_read659_phi_phi_fu_22106_p4 = ap_phi_reg_pp0_iter1_data_384_V_read659_phi_reg_22102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_384_V_read659_rewind_phi_fu_11884_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_384_V_read659_rewind_phi_fu_11884_p6 = data_384_V_read659_phi_reg_22102.read();
    } else {
        ap_phi_mux_data_384_V_read659_rewind_phi_fu_11884_p6 = data_384_V_read659_rewind_reg_11880.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_385_V_read660_phi_phi_fu_22118_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_385_V_read660_phi_phi_fu_22118_p4 = ap_phi_mux_data_385_V_read660_rewind_phi_fu_11898_p6.read();
    } else {
        ap_phi_mux_data_385_V_read660_phi_phi_fu_22118_p4 = ap_phi_reg_pp0_iter1_data_385_V_read660_phi_reg_22114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_385_V_read660_rewind_phi_fu_11898_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_385_V_read660_rewind_phi_fu_11898_p6 = data_385_V_read660_phi_reg_22114.read();
    } else {
        ap_phi_mux_data_385_V_read660_rewind_phi_fu_11898_p6 = data_385_V_read660_rewind_reg_11894.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_386_V_read661_phi_phi_fu_22130_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_386_V_read661_phi_phi_fu_22130_p4 = ap_phi_mux_data_386_V_read661_rewind_phi_fu_11912_p6.read();
    } else {
        ap_phi_mux_data_386_V_read661_phi_phi_fu_22130_p4 = ap_phi_reg_pp0_iter1_data_386_V_read661_phi_reg_22126.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_386_V_read661_rewind_phi_fu_11912_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_386_V_read661_rewind_phi_fu_11912_p6 = data_386_V_read661_phi_reg_22126.read();
    } else {
        ap_phi_mux_data_386_V_read661_rewind_phi_fu_11912_p6 = data_386_V_read661_rewind_reg_11908.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_387_V_read662_phi_phi_fu_22142_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_387_V_read662_phi_phi_fu_22142_p4 = ap_phi_mux_data_387_V_read662_rewind_phi_fu_11926_p6.read();
    } else {
        ap_phi_mux_data_387_V_read662_phi_phi_fu_22142_p4 = ap_phi_reg_pp0_iter1_data_387_V_read662_phi_reg_22138.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_387_V_read662_rewind_phi_fu_11926_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_387_V_read662_rewind_phi_fu_11926_p6 = data_387_V_read662_phi_reg_22138.read();
    } else {
        ap_phi_mux_data_387_V_read662_rewind_phi_fu_11926_p6 = data_387_V_read662_rewind_reg_11922.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_388_V_read663_phi_phi_fu_22154_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_388_V_read663_phi_phi_fu_22154_p4 = ap_phi_mux_data_388_V_read663_rewind_phi_fu_11940_p6.read();
    } else {
        ap_phi_mux_data_388_V_read663_phi_phi_fu_22154_p4 = ap_phi_reg_pp0_iter1_data_388_V_read663_phi_reg_22150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_388_V_read663_rewind_phi_fu_11940_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_388_V_read663_rewind_phi_fu_11940_p6 = data_388_V_read663_phi_reg_22150.read();
    } else {
        ap_phi_mux_data_388_V_read663_rewind_phi_fu_11940_p6 = data_388_V_read663_rewind_reg_11936.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_389_V_read664_phi_phi_fu_22166_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_389_V_read664_phi_phi_fu_22166_p4 = ap_phi_mux_data_389_V_read664_rewind_phi_fu_11954_p6.read();
    } else {
        ap_phi_mux_data_389_V_read664_phi_phi_fu_22166_p4 = ap_phi_reg_pp0_iter1_data_389_V_read664_phi_reg_22162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_389_V_read664_rewind_phi_fu_11954_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_389_V_read664_rewind_phi_fu_11954_p6 = data_389_V_read664_phi_reg_22162.read();
    } else {
        ap_phi_mux_data_389_V_read664_rewind_phi_fu_11954_p6 = data_389_V_read664_rewind_reg_11950.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_38_V_read313_phi_phi_fu_17954_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_38_V_read313_phi_phi_fu_17954_p4 = ap_phi_mux_data_38_V_read313_rewind_phi_fu_7040_p6.read();
    } else {
        ap_phi_mux_data_38_V_read313_phi_phi_fu_17954_p4 = ap_phi_reg_pp0_iter1_data_38_V_read313_phi_reg_17950.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_38_V_read313_rewind_phi_fu_7040_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_38_V_read313_rewind_phi_fu_7040_p6 = data_38_V_read313_phi_reg_17950.read();
    } else {
        ap_phi_mux_data_38_V_read313_rewind_phi_fu_7040_p6 = data_38_V_read313_rewind_reg_7036.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_390_V_read665_phi_phi_fu_22178_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_390_V_read665_phi_phi_fu_22178_p4 = ap_phi_mux_data_390_V_read665_rewind_phi_fu_11968_p6.read();
    } else {
        ap_phi_mux_data_390_V_read665_phi_phi_fu_22178_p4 = ap_phi_reg_pp0_iter1_data_390_V_read665_phi_reg_22174.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_390_V_read665_rewind_phi_fu_11968_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_390_V_read665_rewind_phi_fu_11968_p6 = data_390_V_read665_phi_reg_22174.read();
    } else {
        ap_phi_mux_data_390_V_read665_rewind_phi_fu_11968_p6 = data_390_V_read665_rewind_reg_11964.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_391_V_read666_phi_phi_fu_22190_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_391_V_read666_phi_phi_fu_22190_p4 = ap_phi_mux_data_391_V_read666_rewind_phi_fu_11982_p6.read();
    } else {
        ap_phi_mux_data_391_V_read666_phi_phi_fu_22190_p4 = ap_phi_reg_pp0_iter1_data_391_V_read666_phi_reg_22186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_391_V_read666_rewind_phi_fu_11982_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_391_V_read666_rewind_phi_fu_11982_p6 = data_391_V_read666_phi_reg_22186.read();
    } else {
        ap_phi_mux_data_391_V_read666_rewind_phi_fu_11982_p6 = data_391_V_read666_rewind_reg_11978.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_392_V_read667_phi_phi_fu_22202_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_392_V_read667_phi_phi_fu_22202_p4 = ap_phi_mux_data_392_V_read667_rewind_phi_fu_11996_p6.read();
    } else {
        ap_phi_mux_data_392_V_read667_phi_phi_fu_22202_p4 = ap_phi_reg_pp0_iter1_data_392_V_read667_phi_reg_22198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_392_V_read667_rewind_phi_fu_11996_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_392_V_read667_rewind_phi_fu_11996_p6 = data_392_V_read667_phi_reg_22198.read();
    } else {
        ap_phi_mux_data_392_V_read667_rewind_phi_fu_11996_p6 = data_392_V_read667_rewind_reg_11992.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_393_V_read668_phi_phi_fu_22214_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_393_V_read668_phi_phi_fu_22214_p4 = ap_phi_mux_data_393_V_read668_rewind_phi_fu_12010_p6.read();
    } else {
        ap_phi_mux_data_393_V_read668_phi_phi_fu_22214_p4 = ap_phi_reg_pp0_iter1_data_393_V_read668_phi_reg_22210.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_393_V_read668_rewind_phi_fu_12010_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_393_V_read668_rewind_phi_fu_12010_p6 = data_393_V_read668_phi_reg_22210.read();
    } else {
        ap_phi_mux_data_393_V_read668_rewind_phi_fu_12010_p6 = data_393_V_read668_rewind_reg_12006.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_394_V_read669_phi_phi_fu_22226_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_394_V_read669_phi_phi_fu_22226_p4 = ap_phi_mux_data_394_V_read669_rewind_phi_fu_12024_p6.read();
    } else {
        ap_phi_mux_data_394_V_read669_phi_phi_fu_22226_p4 = ap_phi_reg_pp0_iter1_data_394_V_read669_phi_reg_22222.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_394_V_read669_rewind_phi_fu_12024_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_394_V_read669_rewind_phi_fu_12024_p6 = data_394_V_read669_phi_reg_22222.read();
    } else {
        ap_phi_mux_data_394_V_read669_rewind_phi_fu_12024_p6 = data_394_V_read669_rewind_reg_12020.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_395_V_read670_phi_phi_fu_22238_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_395_V_read670_phi_phi_fu_22238_p4 = ap_phi_mux_data_395_V_read670_rewind_phi_fu_12038_p6.read();
    } else {
        ap_phi_mux_data_395_V_read670_phi_phi_fu_22238_p4 = ap_phi_reg_pp0_iter1_data_395_V_read670_phi_reg_22234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_395_V_read670_rewind_phi_fu_12038_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_395_V_read670_rewind_phi_fu_12038_p6 = data_395_V_read670_phi_reg_22234.read();
    } else {
        ap_phi_mux_data_395_V_read670_rewind_phi_fu_12038_p6 = data_395_V_read670_rewind_reg_12034.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_396_V_read671_phi_phi_fu_22250_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_396_V_read671_phi_phi_fu_22250_p4 = ap_phi_mux_data_396_V_read671_rewind_phi_fu_12052_p6.read();
    } else {
        ap_phi_mux_data_396_V_read671_phi_phi_fu_22250_p4 = ap_phi_reg_pp0_iter1_data_396_V_read671_phi_reg_22246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_396_V_read671_rewind_phi_fu_12052_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_396_V_read671_rewind_phi_fu_12052_p6 = data_396_V_read671_phi_reg_22246.read();
    } else {
        ap_phi_mux_data_396_V_read671_rewind_phi_fu_12052_p6 = data_396_V_read671_rewind_reg_12048.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_397_V_read672_phi_phi_fu_22262_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_397_V_read672_phi_phi_fu_22262_p4 = ap_phi_mux_data_397_V_read672_rewind_phi_fu_12066_p6.read();
    } else {
        ap_phi_mux_data_397_V_read672_phi_phi_fu_22262_p4 = ap_phi_reg_pp0_iter1_data_397_V_read672_phi_reg_22258.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_397_V_read672_rewind_phi_fu_12066_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_397_V_read672_rewind_phi_fu_12066_p6 = data_397_V_read672_phi_reg_22258.read();
    } else {
        ap_phi_mux_data_397_V_read672_rewind_phi_fu_12066_p6 = data_397_V_read672_rewind_reg_12062.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_398_V_read673_phi_phi_fu_22274_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_398_V_read673_phi_phi_fu_22274_p4 = ap_phi_mux_data_398_V_read673_rewind_phi_fu_12080_p6.read();
    } else {
        ap_phi_mux_data_398_V_read673_phi_phi_fu_22274_p4 = ap_phi_reg_pp0_iter1_data_398_V_read673_phi_reg_22270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_398_V_read673_rewind_phi_fu_12080_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_398_V_read673_rewind_phi_fu_12080_p6 = data_398_V_read673_phi_reg_22270.read();
    } else {
        ap_phi_mux_data_398_V_read673_rewind_phi_fu_12080_p6 = data_398_V_read673_rewind_reg_12076.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_399_V_read674_phi_phi_fu_22286_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_399_V_read674_phi_phi_fu_22286_p4 = ap_phi_mux_data_399_V_read674_rewind_phi_fu_12094_p6.read();
    } else {
        ap_phi_mux_data_399_V_read674_phi_phi_fu_22286_p4 = ap_phi_reg_pp0_iter1_data_399_V_read674_phi_reg_22282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_399_V_read674_rewind_phi_fu_12094_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_399_V_read674_rewind_phi_fu_12094_p6 = data_399_V_read674_phi_reg_22282.read();
    } else {
        ap_phi_mux_data_399_V_read674_rewind_phi_fu_12094_p6 = data_399_V_read674_rewind_reg_12090.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_39_V_read314_phi_phi_fu_17966_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_39_V_read314_phi_phi_fu_17966_p4 = ap_phi_mux_data_39_V_read314_rewind_phi_fu_7054_p6.read();
    } else {
        ap_phi_mux_data_39_V_read314_phi_phi_fu_17966_p4 = ap_phi_reg_pp0_iter1_data_39_V_read314_phi_reg_17962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_39_V_read314_rewind_phi_fu_7054_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_39_V_read314_rewind_phi_fu_7054_p6 = data_39_V_read314_phi_reg_17962.read();
    } else {
        ap_phi_mux_data_39_V_read314_rewind_phi_fu_7054_p6 = data_39_V_read314_rewind_reg_7050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_3_V_read278_phi_phi_fu_17534_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_3_V_read278_phi_phi_fu_17534_p4 = ap_phi_mux_data_3_V_read278_rewind_phi_fu_6550_p6.read();
    } else {
        ap_phi_mux_data_3_V_read278_phi_phi_fu_17534_p4 = ap_phi_reg_pp0_iter1_data_3_V_read278_phi_reg_17530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_3_V_read278_rewind_phi_fu_6550_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_3_V_read278_rewind_phi_fu_6550_p6 = data_3_V_read278_phi_reg_17530.read();
    } else {
        ap_phi_mux_data_3_V_read278_rewind_phi_fu_6550_p6 = data_3_V_read278_rewind_reg_6546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_400_V_read675_phi_phi_fu_22298_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_400_V_read675_phi_phi_fu_22298_p4 = ap_phi_mux_data_400_V_read675_rewind_phi_fu_12108_p6.read();
    } else {
        ap_phi_mux_data_400_V_read675_phi_phi_fu_22298_p4 = ap_phi_reg_pp0_iter1_data_400_V_read675_phi_reg_22294.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_400_V_read675_rewind_phi_fu_12108_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_400_V_read675_rewind_phi_fu_12108_p6 = data_400_V_read675_phi_reg_22294.read();
    } else {
        ap_phi_mux_data_400_V_read675_rewind_phi_fu_12108_p6 = data_400_V_read675_rewind_reg_12104.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_401_V_read676_phi_phi_fu_22310_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_401_V_read676_phi_phi_fu_22310_p4 = ap_phi_mux_data_401_V_read676_rewind_phi_fu_12122_p6.read();
    } else {
        ap_phi_mux_data_401_V_read676_phi_phi_fu_22310_p4 = ap_phi_reg_pp0_iter1_data_401_V_read676_phi_reg_22306.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_401_V_read676_rewind_phi_fu_12122_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_401_V_read676_rewind_phi_fu_12122_p6 = data_401_V_read676_phi_reg_22306.read();
    } else {
        ap_phi_mux_data_401_V_read676_rewind_phi_fu_12122_p6 = data_401_V_read676_rewind_reg_12118.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_402_V_read677_phi_phi_fu_22322_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_402_V_read677_phi_phi_fu_22322_p4 = ap_phi_mux_data_402_V_read677_rewind_phi_fu_12136_p6.read();
    } else {
        ap_phi_mux_data_402_V_read677_phi_phi_fu_22322_p4 = ap_phi_reg_pp0_iter1_data_402_V_read677_phi_reg_22318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_402_V_read677_rewind_phi_fu_12136_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_402_V_read677_rewind_phi_fu_12136_p6 = data_402_V_read677_phi_reg_22318.read();
    } else {
        ap_phi_mux_data_402_V_read677_rewind_phi_fu_12136_p6 = data_402_V_read677_rewind_reg_12132.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_403_V_read678_phi_phi_fu_22334_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_403_V_read678_phi_phi_fu_22334_p4 = ap_phi_mux_data_403_V_read678_rewind_phi_fu_12150_p6.read();
    } else {
        ap_phi_mux_data_403_V_read678_phi_phi_fu_22334_p4 = ap_phi_reg_pp0_iter1_data_403_V_read678_phi_reg_22330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_403_V_read678_rewind_phi_fu_12150_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_403_V_read678_rewind_phi_fu_12150_p6 = data_403_V_read678_phi_reg_22330.read();
    } else {
        ap_phi_mux_data_403_V_read678_rewind_phi_fu_12150_p6 = data_403_V_read678_rewind_reg_12146.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_404_V_read679_phi_phi_fu_22346_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_404_V_read679_phi_phi_fu_22346_p4 = ap_phi_mux_data_404_V_read679_rewind_phi_fu_12164_p6.read();
    } else {
        ap_phi_mux_data_404_V_read679_phi_phi_fu_22346_p4 = ap_phi_reg_pp0_iter1_data_404_V_read679_phi_reg_22342.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_404_V_read679_rewind_phi_fu_12164_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_404_V_read679_rewind_phi_fu_12164_p6 = data_404_V_read679_phi_reg_22342.read();
    } else {
        ap_phi_mux_data_404_V_read679_rewind_phi_fu_12164_p6 = data_404_V_read679_rewind_reg_12160.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_405_V_read680_phi_phi_fu_22358_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_405_V_read680_phi_phi_fu_22358_p4 = ap_phi_mux_data_405_V_read680_rewind_phi_fu_12178_p6.read();
    } else {
        ap_phi_mux_data_405_V_read680_phi_phi_fu_22358_p4 = ap_phi_reg_pp0_iter1_data_405_V_read680_phi_reg_22354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_405_V_read680_rewind_phi_fu_12178_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_405_V_read680_rewind_phi_fu_12178_p6 = data_405_V_read680_phi_reg_22354.read();
    } else {
        ap_phi_mux_data_405_V_read680_rewind_phi_fu_12178_p6 = data_405_V_read680_rewind_reg_12174.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_406_V_read681_phi_phi_fu_22370_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_406_V_read681_phi_phi_fu_22370_p4 = ap_phi_mux_data_406_V_read681_rewind_phi_fu_12192_p6.read();
    } else {
        ap_phi_mux_data_406_V_read681_phi_phi_fu_22370_p4 = ap_phi_reg_pp0_iter1_data_406_V_read681_phi_reg_22366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_406_V_read681_rewind_phi_fu_12192_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_406_V_read681_rewind_phi_fu_12192_p6 = data_406_V_read681_phi_reg_22366.read();
    } else {
        ap_phi_mux_data_406_V_read681_rewind_phi_fu_12192_p6 = data_406_V_read681_rewind_reg_12188.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_407_V_read682_phi_phi_fu_22382_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_407_V_read682_phi_phi_fu_22382_p4 = ap_phi_mux_data_407_V_read682_rewind_phi_fu_12206_p6.read();
    } else {
        ap_phi_mux_data_407_V_read682_phi_phi_fu_22382_p4 = ap_phi_reg_pp0_iter1_data_407_V_read682_phi_reg_22378.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_407_V_read682_rewind_phi_fu_12206_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_407_V_read682_rewind_phi_fu_12206_p6 = data_407_V_read682_phi_reg_22378.read();
    } else {
        ap_phi_mux_data_407_V_read682_rewind_phi_fu_12206_p6 = data_407_V_read682_rewind_reg_12202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_408_V_read683_phi_phi_fu_22394_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_408_V_read683_phi_phi_fu_22394_p4 = ap_phi_mux_data_408_V_read683_rewind_phi_fu_12220_p6.read();
    } else {
        ap_phi_mux_data_408_V_read683_phi_phi_fu_22394_p4 = ap_phi_reg_pp0_iter1_data_408_V_read683_phi_reg_22390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_408_V_read683_rewind_phi_fu_12220_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_408_V_read683_rewind_phi_fu_12220_p6 = data_408_V_read683_phi_reg_22390.read();
    } else {
        ap_phi_mux_data_408_V_read683_rewind_phi_fu_12220_p6 = data_408_V_read683_rewind_reg_12216.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_409_V_read684_phi_phi_fu_22406_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_409_V_read684_phi_phi_fu_22406_p4 = ap_phi_mux_data_409_V_read684_rewind_phi_fu_12234_p6.read();
    } else {
        ap_phi_mux_data_409_V_read684_phi_phi_fu_22406_p4 = ap_phi_reg_pp0_iter1_data_409_V_read684_phi_reg_22402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_409_V_read684_rewind_phi_fu_12234_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_409_V_read684_rewind_phi_fu_12234_p6 = data_409_V_read684_phi_reg_22402.read();
    } else {
        ap_phi_mux_data_409_V_read684_rewind_phi_fu_12234_p6 = data_409_V_read684_rewind_reg_12230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_40_V_read315_phi_phi_fu_17978_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_40_V_read315_phi_phi_fu_17978_p4 = ap_phi_mux_data_40_V_read315_rewind_phi_fu_7068_p6.read();
    } else {
        ap_phi_mux_data_40_V_read315_phi_phi_fu_17978_p4 = ap_phi_reg_pp0_iter1_data_40_V_read315_phi_reg_17974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_40_V_read315_rewind_phi_fu_7068_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_40_V_read315_rewind_phi_fu_7068_p6 = data_40_V_read315_phi_reg_17974.read();
    } else {
        ap_phi_mux_data_40_V_read315_rewind_phi_fu_7068_p6 = data_40_V_read315_rewind_reg_7064.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_410_V_read685_phi_phi_fu_22418_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_410_V_read685_phi_phi_fu_22418_p4 = ap_phi_mux_data_410_V_read685_rewind_phi_fu_12248_p6.read();
    } else {
        ap_phi_mux_data_410_V_read685_phi_phi_fu_22418_p4 = ap_phi_reg_pp0_iter1_data_410_V_read685_phi_reg_22414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_410_V_read685_rewind_phi_fu_12248_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_410_V_read685_rewind_phi_fu_12248_p6 = data_410_V_read685_phi_reg_22414.read();
    } else {
        ap_phi_mux_data_410_V_read685_rewind_phi_fu_12248_p6 = data_410_V_read685_rewind_reg_12244.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_411_V_read686_phi_phi_fu_22430_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_411_V_read686_phi_phi_fu_22430_p4 = ap_phi_mux_data_411_V_read686_rewind_phi_fu_12262_p6.read();
    } else {
        ap_phi_mux_data_411_V_read686_phi_phi_fu_22430_p4 = ap_phi_reg_pp0_iter1_data_411_V_read686_phi_reg_22426.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_411_V_read686_rewind_phi_fu_12262_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_411_V_read686_rewind_phi_fu_12262_p6 = data_411_V_read686_phi_reg_22426.read();
    } else {
        ap_phi_mux_data_411_V_read686_rewind_phi_fu_12262_p6 = data_411_V_read686_rewind_reg_12258.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_412_V_read687_phi_phi_fu_22442_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_412_V_read687_phi_phi_fu_22442_p4 = ap_phi_mux_data_412_V_read687_rewind_phi_fu_12276_p6.read();
    } else {
        ap_phi_mux_data_412_V_read687_phi_phi_fu_22442_p4 = ap_phi_reg_pp0_iter1_data_412_V_read687_phi_reg_22438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_412_V_read687_rewind_phi_fu_12276_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_412_V_read687_rewind_phi_fu_12276_p6 = data_412_V_read687_phi_reg_22438.read();
    } else {
        ap_phi_mux_data_412_V_read687_rewind_phi_fu_12276_p6 = data_412_V_read687_rewind_reg_12272.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_413_V_read688_phi_phi_fu_22454_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_413_V_read688_phi_phi_fu_22454_p4 = ap_phi_mux_data_413_V_read688_rewind_phi_fu_12290_p6.read();
    } else {
        ap_phi_mux_data_413_V_read688_phi_phi_fu_22454_p4 = ap_phi_reg_pp0_iter1_data_413_V_read688_phi_reg_22450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_413_V_read688_rewind_phi_fu_12290_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_413_V_read688_rewind_phi_fu_12290_p6 = data_413_V_read688_phi_reg_22450.read();
    } else {
        ap_phi_mux_data_413_V_read688_rewind_phi_fu_12290_p6 = data_413_V_read688_rewind_reg_12286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_414_V_read689_phi_phi_fu_22466_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_414_V_read689_phi_phi_fu_22466_p4 = ap_phi_mux_data_414_V_read689_rewind_phi_fu_12304_p6.read();
    } else {
        ap_phi_mux_data_414_V_read689_phi_phi_fu_22466_p4 = ap_phi_reg_pp0_iter1_data_414_V_read689_phi_reg_22462.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_414_V_read689_rewind_phi_fu_12304_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_414_V_read689_rewind_phi_fu_12304_p6 = data_414_V_read689_phi_reg_22462.read();
    } else {
        ap_phi_mux_data_414_V_read689_rewind_phi_fu_12304_p6 = data_414_V_read689_rewind_reg_12300.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_415_V_read690_phi_phi_fu_22478_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_415_V_read690_phi_phi_fu_22478_p4 = ap_phi_mux_data_415_V_read690_rewind_phi_fu_12318_p6.read();
    } else {
        ap_phi_mux_data_415_V_read690_phi_phi_fu_22478_p4 = ap_phi_reg_pp0_iter1_data_415_V_read690_phi_reg_22474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_415_V_read690_rewind_phi_fu_12318_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_415_V_read690_rewind_phi_fu_12318_p6 = data_415_V_read690_phi_reg_22474.read();
    } else {
        ap_phi_mux_data_415_V_read690_rewind_phi_fu_12318_p6 = data_415_V_read690_rewind_reg_12314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_416_V_read691_phi_phi_fu_22490_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_416_V_read691_phi_phi_fu_22490_p4 = ap_phi_mux_data_416_V_read691_rewind_phi_fu_12332_p6.read();
    } else {
        ap_phi_mux_data_416_V_read691_phi_phi_fu_22490_p4 = ap_phi_reg_pp0_iter1_data_416_V_read691_phi_reg_22486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_416_V_read691_rewind_phi_fu_12332_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_416_V_read691_rewind_phi_fu_12332_p6 = data_416_V_read691_phi_reg_22486.read();
    } else {
        ap_phi_mux_data_416_V_read691_rewind_phi_fu_12332_p6 = data_416_V_read691_rewind_reg_12328.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_417_V_read692_phi_phi_fu_22502_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_417_V_read692_phi_phi_fu_22502_p4 = ap_phi_mux_data_417_V_read692_rewind_phi_fu_12346_p6.read();
    } else {
        ap_phi_mux_data_417_V_read692_phi_phi_fu_22502_p4 = ap_phi_reg_pp0_iter1_data_417_V_read692_phi_reg_22498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_417_V_read692_rewind_phi_fu_12346_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_417_V_read692_rewind_phi_fu_12346_p6 = data_417_V_read692_phi_reg_22498.read();
    } else {
        ap_phi_mux_data_417_V_read692_rewind_phi_fu_12346_p6 = data_417_V_read692_rewind_reg_12342.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_418_V_read693_phi_phi_fu_22514_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_418_V_read693_phi_phi_fu_22514_p4 = ap_phi_mux_data_418_V_read693_rewind_phi_fu_12360_p6.read();
    } else {
        ap_phi_mux_data_418_V_read693_phi_phi_fu_22514_p4 = ap_phi_reg_pp0_iter1_data_418_V_read693_phi_reg_22510.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_418_V_read693_rewind_phi_fu_12360_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_418_V_read693_rewind_phi_fu_12360_p6 = data_418_V_read693_phi_reg_22510.read();
    } else {
        ap_phi_mux_data_418_V_read693_rewind_phi_fu_12360_p6 = data_418_V_read693_rewind_reg_12356.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_419_V_read694_phi_phi_fu_22526_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_419_V_read694_phi_phi_fu_22526_p4 = ap_phi_mux_data_419_V_read694_rewind_phi_fu_12374_p6.read();
    } else {
        ap_phi_mux_data_419_V_read694_phi_phi_fu_22526_p4 = ap_phi_reg_pp0_iter1_data_419_V_read694_phi_reg_22522.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_419_V_read694_rewind_phi_fu_12374_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_419_V_read694_rewind_phi_fu_12374_p6 = data_419_V_read694_phi_reg_22522.read();
    } else {
        ap_phi_mux_data_419_V_read694_rewind_phi_fu_12374_p6 = data_419_V_read694_rewind_reg_12370.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_41_V_read316_phi_phi_fu_17990_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_41_V_read316_phi_phi_fu_17990_p4 = ap_phi_mux_data_41_V_read316_rewind_phi_fu_7082_p6.read();
    } else {
        ap_phi_mux_data_41_V_read316_phi_phi_fu_17990_p4 = ap_phi_reg_pp0_iter1_data_41_V_read316_phi_reg_17986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_41_V_read316_rewind_phi_fu_7082_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_41_V_read316_rewind_phi_fu_7082_p6 = data_41_V_read316_phi_reg_17986.read();
    } else {
        ap_phi_mux_data_41_V_read316_rewind_phi_fu_7082_p6 = data_41_V_read316_rewind_reg_7078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_420_V_read695_phi_phi_fu_22538_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_420_V_read695_phi_phi_fu_22538_p4 = ap_phi_mux_data_420_V_read695_rewind_phi_fu_12388_p6.read();
    } else {
        ap_phi_mux_data_420_V_read695_phi_phi_fu_22538_p4 = ap_phi_reg_pp0_iter1_data_420_V_read695_phi_reg_22534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_420_V_read695_rewind_phi_fu_12388_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_420_V_read695_rewind_phi_fu_12388_p6 = data_420_V_read695_phi_reg_22534.read();
    } else {
        ap_phi_mux_data_420_V_read695_rewind_phi_fu_12388_p6 = data_420_V_read695_rewind_reg_12384.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_421_V_read696_phi_phi_fu_22550_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_421_V_read696_phi_phi_fu_22550_p4 = ap_phi_mux_data_421_V_read696_rewind_phi_fu_12402_p6.read();
    } else {
        ap_phi_mux_data_421_V_read696_phi_phi_fu_22550_p4 = ap_phi_reg_pp0_iter1_data_421_V_read696_phi_reg_22546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_421_V_read696_rewind_phi_fu_12402_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_421_V_read696_rewind_phi_fu_12402_p6 = data_421_V_read696_phi_reg_22546.read();
    } else {
        ap_phi_mux_data_421_V_read696_rewind_phi_fu_12402_p6 = data_421_V_read696_rewind_reg_12398.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_422_V_read697_phi_phi_fu_22562_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_422_V_read697_phi_phi_fu_22562_p4 = ap_phi_mux_data_422_V_read697_rewind_phi_fu_12416_p6.read();
    } else {
        ap_phi_mux_data_422_V_read697_phi_phi_fu_22562_p4 = ap_phi_reg_pp0_iter1_data_422_V_read697_phi_reg_22558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_422_V_read697_rewind_phi_fu_12416_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_422_V_read697_rewind_phi_fu_12416_p6 = data_422_V_read697_phi_reg_22558.read();
    } else {
        ap_phi_mux_data_422_V_read697_rewind_phi_fu_12416_p6 = data_422_V_read697_rewind_reg_12412.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_423_V_read698_phi_phi_fu_22574_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_423_V_read698_phi_phi_fu_22574_p4 = ap_phi_mux_data_423_V_read698_rewind_phi_fu_12430_p6.read();
    } else {
        ap_phi_mux_data_423_V_read698_phi_phi_fu_22574_p4 = ap_phi_reg_pp0_iter1_data_423_V_read698_phi_reg_22570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_423_V_read698_rewind_phi_fu_12430_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_423_V_read698_rewind_phi_fu_12430_p6 = data_423_V_read698_phi_reg_22570.read();
    } else {
        ap_phi_mux_data_423_V_read698_rewind_phi_fu_12430_p6 = data_423_V_read698_rewind_reg_12426.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_424_V_read699_phi_phi_fu_22586_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_424_V_read699_phi_phi_fu_22586_p4 = ap_phi_mux_data_424_V_read699_rewind_phi_fu_12444_p6.read();
    } else {
        ap_phi_mux_data_424_V_read699_phi_phi_fu_22586_p4 = ap_phi_reg_pp0_iter1_data_424_V_read699_phi_reg_22582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_424_V_read699_rewind_phi_fu_12444_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_424_V_read699_rewind_phi_fu_12444_p6 = data_424_V_read699_phi_reg_22582.read();
    } else {
        ap_phi_mux_data_424_V_read699_rewind_phi_fu_12444_p6 = data_424_V_read699_rewind_reg_12440.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_425_V_read700_phi_phi_fu_22598_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_425_V_read700_phi_phi_fu_22598_p4 = ap_phi_mux_data_425_V_read700_rewind_phi_fu_12458_p6.read();
    } else {
        ap_phi_mux_data_425_V_read700_phi_phi_fu_22598_p4 = ap_phi_reg_pp0_iter1_data_425_V_read700_phi_reg_22594.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_425_V_read700_rewind_phi_fu_12458_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_425_V_read700_rewind_phi_fu_12458_p6 = data_425_V_read700_phi_reg_22594.read();
    } else {
        ap_phi_mux_data_425_V_read700_rewind_phi_fu_12458_p6 = data_425_V_read700_rewind_reg_12454.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_426_V_read701_phi_phi_fu_22610_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_426_V_read701_phi_phi_fu_22610_p4 = ap_phi_mux_data_426_V_read701_rewind_phi_fu_12472_p6.read();
    } else {
        ap_phi_mux_data_426_V_read701_phi_phi_fu_22610_p4 = ap_phi_reg_pp0_iter1_data_426_V_read701_phi_reg_22606.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_426_V_read701_rewind_phi_fu_12472_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_426_V_read701_rewind_phi_fu_12472_p6 = data_426_V_read701_phi_reg_22606.read();
    } else {
        ap_phi_mux_data_426_V_read701_rewind_phi_fu_12472_p6 = data_426_V_read701_rewind_reg_12468.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_427_V_read702_phi_phi_fu_22622_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_427_V_read702_phi_phi_fu_22622_p4 = ap_phi_mux_data_427_V_read702_rewind_phi_fu_12486_p6.read();
    } else {
        ap_phi_mux_data_427_V_read702_phi_phi_fu_22622_p4 = ap_phi_reg_pp0_iter1_data_427_V_read702_phi_reg_22618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_427_V_read702_rewind_phi_fu_12486_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_427_V_read702_rewind_phi_fu_12486_p6 = data_427_V_read702_phi_reg_22618.read();
    } else {
        ap_phi_mux_data_427_V_read702_rewind_phi_fu_12486_p6 = data_427_V_read702_rewind_reg_12482.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_428_V_read703_phi_phi_fu_22634_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_428_V_read703_phi_phi_fu_22634_p4 = ap_phi_mux_data_428_V_read703_rewind_phi_fu_12500_p6.read();
    } else {
        ap_phi_mux_data_428_V_read703_phi_phi_fu_22634_p4 = ap_phi_reg_pp0_iter1_data_428_V_read703_phi_reg_22630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_428_V_read703_rewind_phi_fu_12500_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_428_V_read703_rewind_phi_fu_12500_p6 = data_428_V_read703_phi_reg_22630.read();
    } else {
        ap_phi_mux_data_428_V_read703_rewind_phi_fu_12500_p6 = data_428_V_read703_rewind_reg_12496.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_429_V_read704_phi_phi_fu_22646_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_429_V_read704_phi_phi_fu_22646_p4 = ap_phi_mux_data_429_V_read704_rewind_phi_fu_12514_p6.read();
    } else {
        ap_phi_mux_data_429_V_read704_phi_phi_fu_22646_p4 = ap_phi_reg_pp0_iter1_data_429_V_read704_phi_reg_22642.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_429_V_read704_rewind_phi_fu_12514_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_429_V_read704_rewind_phi_fu_12514_p6 = data_429_V_read704_phi_reg_22642.read();
    } else {
        ap_phi_mux_data_429_V_read704_rewind_phi_fu_12514_p6 = data_429_V_read704_rewind_reg_12510.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_42_V_read317_phi_phi_fu_18002_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_42_V_read317_phi_phi_fu_18002_p4 = ap_phi_mux_data_42_V_read317_rewind_phi_fu_7096_p6.read();
    } else {
        ap_phi_mux_data_42_V_read317_phi_phi_fu_18002_p4 = ap_phi_reg_pp0_iter1_data_42_V_read317_phi_reg_17998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_42_V_read317_rewind_phi_fu_7096_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_42_V_read317_rewind_phi_fu_7096_p6 = data_42_V_read317_phi_reg_17998.read();
    } else {
        ap_phi_mux_data_42_V_read317_rewind_phi_fu_7096_p6 = data_42_V_read317_rewind_reg_7092.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_430_V_read705_phi_phi_fu_22658_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_430_V_read705_phi_phi_fu_22658_p4 = ap_phi_mux_data_430_V_read705_rewind_phi_fu_12528_p6.read();
    } else {
        ap_phi_mux_data_430_V_read705_phi_phi_fu_22658_p4 = ap_phi_reg_pp0_iter1_data_430_V_read705_phi_reg_22654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_430_V_read705_rewind_phi_fu_12528_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_430_V_read705_rewind_phi_fu_12528_p6 = data_430_V_read705_phi_reg_22654.read();
    } else {
        ap_phi_mux_data_430_V_read705_rewind_phi_fu_12528_p6 = data_430_V_read705_rewind_reg_12524.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_431_V_read706_phi_phi_fu_22670_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_431_V_read706_phi_phi_fu_22670_p4 = ap_phi_mux_data_431_V_read706_rewind_phi_fu_12542_p6.read();
    } else {
        ap_phi_mux_data_431_V_read706_phi_phi_fu_22670_p4 = ap_phi_reg_pp0_iter1_data_431_V_read706_phi_reg_22666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_431_V_read706_rewind_phi_fu_12542_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_431_V_read706_rewind_phi_fu_12542_p6 = data_431_V_read706_phi_reg_22666.read();
    } else {
        ap_phi_mux_data_431_V_read706_rewind_phi_fu_12542_p6 = data_431_V_read706_rewind_reg_12538.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_432_V_read707_phi_phi_fu_22682_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_432_V_read707_phi_phi_fu_22682_p4 = ap_phi_mux_data_432_V_read707_rewind_phi_fu_12556_p6.read();
    } else {
        ap_phi_mux_data_432_V_read707_phi_phi_fu_22682_p4 = ap_phi_reg_pp0_iter1_data_432_V_read707_phi_reg_22678.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_432_V_read707_rewind_phi_fu_12556_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_432_V_read707_rewind_phi_fu_12556_p6 = data_432_V_read707_phi_reg_22678.read();
    } else {
        ap_phi_mux_data_432_V_read707_rewind_phi_fu_12556_p6 = data_432_V_read707_rewind_reg_12552.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_433_V_read708_phi_phi_fu_22694_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_433_V_read708_phi_phi_fu_22694_p4 = ap_phi_mux_data_433_V_read708_rewind_phi_fu_12570_p6.read();
    } else {
        ap_phi_mux_data_433_V_read708_phi_phi_fu_22694_p4 = ap_phi_reg_pp0_iter1_data_433_V_read708_phi_reg_22690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_433_V_read708_rewind_phi_fu_12570_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_433_V_read708_rewind_phi_fu_12570_p6 = data_433_V_read708_phi_reg_22690.read();
    } else {
        ap_phi_mux_data_433_V_read708_rewind_phi_fu_12570_p6 = data_433_V_read708_rewind_reg_12566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_434_V_read709_phi_phi_fu_22706_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_434_V_read709_phi_phi_fu_22706_p4 = ap_phi_mux_data_434_V_read709_rewind_phi_fu_12584_p6.read();
    } else {
        ap_phi_mux_data_434_V_read709_phi_phi_fu_22706_p4 = ap_phi_reg_pp0_iter1_data_434_V_read709_phi_reg_22702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_434_V_read709_rewind_phi_fu_12584_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_434_V_read709_rewind_phi_fu_12584_p6 = data_434_V_read709_phi_reg_22702.read();
    } else {
        ap_phi_mux_data_434_V_read709_rewind_phi_fu_12584_p6 = data_434_V_read709_rewind_reg_12580.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_435_V_read710_phi_phi_fu_22718_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_435_V_read710_phi_phi_fu_22718_p4 = ap_phi_mux_data_435_V_read710_rewind_phi_fu_12598_p6.read();
    } else {
        ap_phi_mux_data_435_V_read710_phi_phi_fu_22718_p4 = ap_phi_reg_pp0_iter1_data_435_V_read710_phi_reg_22714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_435_V_read710_rewind_phi_fu_12598_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_435_V_read710_rewind_phi_fu_12598_p6 = data_435_V_read710_phi_reg_22714.read();
    } else {
        ap_phi_mux_data_435_V_read710_rewind_phi_fu_12598_p6 = data_435_V_read710_rewind_reg_12594.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_436_V_read711_phi_phi_fu_22730_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_436_V_read711_phi_phi_fu_22730_p4 = ap_phi_mux_data_436_V_read711_rewind_phi_fu_12612_p6.read();
    } else {
        ap_phi_mux_data_436_V_read711_phi_phi_fu_22730_p4 = ap_phi_reg_pp0_iter1_data_436_V_read711_phi_reg_22726.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_436_V_read711_rewind_phi_fu_12612_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_436_V_read711_rewind_phi_fu_12612_p6 = data_436_V_read711_phi_reg_22726.read();
    } else {
        ap_phi_mux_data_436_V_read711_rewind_phi_fu_12612_p6 = data_436_V_read711_rewind_reg_12608.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_437_V_read712_phi_phi_fu_22742_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_437_V_read712_phi_phi_fu_22742_p4 = ap_phi_mux_data_437_V_read712_rewind_phi_fu_12626_p6.read();
    } else {
        ap_phi_mux_data_437_V_read712_phi_phi_fu_22742_p4 = ap_phi_reg_pp0_iter1_data_437_V_read712_phi_reg_22738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_437_V_read712_rewind_phi_fu_12626_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_437_V_read712_rewind_phi_fu_12626_p6 = data_437_V_read712_phi_reg_22738.read();
    } else {
        ap_phi_mux_data_437_V_read712_rewind_phi_fu_12626_p6 = data_437_V_read712_rewind_reg_12622.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_438_V_read713_phi_phi_fu_22754_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_438_V_read713_phi_phi_fu_22754_p4 = ap_phi_mux_data_438_V_read713_rewind_phi_fu_12640_p6.read();
    } else {
        ap_phi_mux_data_438_V_read713_phi_phi_fu_22754_p4 = ap_phi_reg_pp0_iter1_data_438_V_read713_phi_reg_22750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_438_V_read713_rewind_phi_fu_12640_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_438_V_read713_rewind_phi_fu_12640_p6 = data_438_V_read713_phi_reg_22750.read();
    } else {
        ap_phi_mux_data_438_V_read713_rewind_phi_fu_12640_p6 = data_438_V_read713_rewind_reg_12636.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_439_V_read714_phi_phi_fu_22766_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_439_V_read714_phi_phi_fu_22766_p4 = ap_phi_mux_data_439_V_read714_rewind_phi_fu_12654_p6.read();
    } else {
        ap_phi_mux_data_439_V_read714_phi_phi_fu_22766_p4 = ap_phi_reg_pp0_iter1_data_439_V_read714_phi_reg_22762.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_439_V_read714_rewind_phi_fu_12654_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_439_V_read714_rewind_phi_fu_12654_p6 = data_439_V_read714_phi_reg_22762.read();
    } else {
        ap_phi_mux_data_439_V_read714_rewind_phi_fu_12654_p6 = data_439_V_read714_rewind_reg_12650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_43_V_read318_phi_phi_fu_18014_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_43_V_read318_phi_phi_fu_18014_p4 = ap_phi_mux_data_43_V_read318_rewind_phi_fu_7110_p6.read();
    } else {
        ap_phi_mux_data_43_V_read318_phi_phi_fu_18014_p4 = ap_phi_reg_pp0_iter1_data_43_V_read318_phi_reg_18010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_43_V_read318_rewind_phi_fu_7110_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_43_V_read318_rewind_phi_fu_7110_p6 = data_43_V_read318_phi_reg_18010.read();
    } else {
        ap_phi_mux_data_43_V_read318_rewind_phi_fu_7110_p6 = data_43_V_read318_rewind_reg_7106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_440_V_read715_phi_phi_fu_22778_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_440_V_read715_phi_phi_fu_22778_p4 = ap_phi_mux_data_440_V_read715_rewind_phi_fu_12668_p6.read();
    } else {
        ap_phi_mux_data_440_V_read715_phi_phi_fu_22778_p4 = ap_phi_reg_pp0_iter1_data_440_V_read715_phi_reg_22774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_440_V_read715_rewind_phi_fu_12668_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_440_V_read715_rewind_phi_fu_12668_p6 = data_440_V_read715_phi_reg_22774.read();
    } else {
        ap_phi_mux_data_440_V_read715_rewind_phi_fu_12668_p6 = data_440_V_read715_rewind_reg_12664.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_441_V_read716_phi_phi_fu_22790_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_441_V_read716_phi_phi_fu_22790_p4 = ap_phi_mux_data_441_V_read716_rewind_phi_fu_12682_p6.read();
    } else {
        ap_phi_mux_data_441_V_read716_phi_phi_fu_22790_p4 = ap_phi_reg_pp0_iter1_data_441_V_read716_phi_reg_22786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_441_V_read716_rewind_phi_fu_12682_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_441_V_read716_rewind_phi_fu_12682_p6 = data_441_V_read716_phi_reg_22786.read();
    } else {
        ap_phi_mux_data_441_V_read716_rewind_phi_fu_12682_p6 = data_441_V_read716_rewind_reg_12678.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_442_V_read717_phi_phi_fu_22802_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_442_V_read717_phi_phi_fu_22802_p4 = ap_phi_mux_data_442_V_read717_rewind_phi_fu_12696_p6.read();
    } else {
        ap_phi_mux_data_442_V_read717_phi_phi_fu_22802_p4 = ap_phi_reg_pp0_iter1_data_442_V_read717_phi_reg_22798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_442_V_read717_rewind_phi_fu_12696_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_442_V_read717_rewind_phi_fu_12696_p6 = data_442_V_read717_phi_reg_22798.read();
    } else {
        ap_phi_mux_data_442_V_read717_rewind_phi_fu_12696_p6 = data_442_V_read717_rewind_reg_12692.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_443_V_read718_phi_phi_fu_22814_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_443_V_read718_phi_phi_fu_22814_p4 = ap_phi_mux_data_443_V_read718_rewind_phi_fu_12710_p6.read();
    } else {
        ap_phi_mux_data_443_V_read718_phi_phi_fu_22814_p4 = ap_phi_reg_pp0_iter1_data_443_V_read718_phi_reg_22810.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_443_V_read718_rewind_phi_fu_12710_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_443_V_read718_rewind_phi_fu_12710_p6 = data_443_V_read718_phi_reg_22810.read();
    } else {
        ap_phi_mux_data_443_V_read718_rewind_phi_fu_12710_p6 = data_443_V_read718_rewind_reg_12706.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_444_V_read719_phi_phi_fu_22826_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_444_V_read719_phi_phi_fu_22826_p4 = ap_phi_mux_data_444_V_read719_rewind_phi_fu_12724_p6.read();
    } else {
        ap_phi_mux_data_444_V_read719_phi_phi_fu_22826_p4 = ap_phi_reg_pp0_iter1_data_444_V_read719_phi_reg_22822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_444_V_read719_rewind_phi_fu_12724_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_444_V_read719_rewind_phi_fu_12724_p6 = data_444_V_read719_phi_reg_22822.read();
    } else {
        ap_phi_mux_data_444_V_read719_rewind_phi_fu_12724_p6 = data_444_V_read719_rewind_reg_12720.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_445_V_read720_phi_phi_fu_22838_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_445_V_read720_phi_phi_fu_22838_p4 = ap_phi_mux_data_445_V_read720_rewind_phi_fu_12738_p6.read();
    } else {
        ap_phi_mux_data_445_V_read720_phi_phi_fu_22838_p4 = ap_phi_reg_pp0_iter1_data_445_V_read720_phi_reg_22834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_445_V_read720_rewind_phi_fu_12738_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_445_V_read720_rewind_phi_fu_12738_p6 = data_445_V_read720_phi_reg_22834.read();
    } else {
        ap_phi_mux_data_445_V_read720_rewind_phi_fu_12738_p6 = data_445_V_read720_rewind_reg_12734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_446_V_read721_phi_phi_fu_22850_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_446_V_read721_phi_phi_fu_22850_p4 = ap_phi_mux_data_446_V_read721_rewind_phi_fu_12752_p6.read();
    } else {
        ap_phi_mux_data_446_V_read721_phi_phi_fu_22850_p4 = ap_phi_reg_pp0_iter1_data_446_V_read721_phi_reg_22846.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_446_V_read721_rewind_phi_fu_12752_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_446_V_read721_rewind_phi_fu_12752_p6 = data_446_V_read721_phi_reg_22846.read();
    } else {
        ap_phi_mux_data_446_V_read721_rewind_phi_fu_12752_p6 = data_446_V_read721_rewind_reg_12748.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_447_V_read722_phi_phi_fu_22862_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_447_V_read722_phi_phi_fu_22862_p4 = ap_phi_mux_data_447_V_read722_rewind_phi_fu_12766_p6.read();
    } else {
        ap_phi_mux_data_447_V_read722_phi_phi_fu_22862_p4 = ap_phi_reg_pp0_iter1_data_447_V_read722_phi_reg_22858.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_447_V_read722_rewind_phi_fu_12766_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_447_V_read722_rewind_phi_fu_12766_p6 = data_447_V_read722_phi_reg_22858.read();
    } else {
        ap_phi_mux_data_447_V_read722_rewind_phi_fu_12766_p6 = data_447_V_read722_rewind_reg_12762.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_448_V_read723_phi_phi_fu_22874_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_448_V_read723_phi_phi_fu_22874_p4 = ap_phi_mux_data_448_V_read723_rewind_phi_fu_12780_p6.read();
    } else {
        ap_phi_mux_data_448_V_read723_phi_phi_fu_22874_p4 = ap_phi_reg_pp0_iter1_data_448_V_read723_phi_reg_22870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_448_V_read723_rewind_phi_fu_12780_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_448_V_read723_rewind_phi_fu_12780_p6 = data_448_V_read723_phi_reg_22870.read();
    } else {
        ap_phi_mux_data_448_V_read723_rewind_phi_fu_12780_p6 = data_448_V_read723_rewind_reg_12776.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_449_V_read724_phi_phi_fu_22886_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_449_V_read724_phi_phi_fu_22886_p4 = ap_phi_mux_data_449_V_read724_rewind_phi_fu_12794_p6.read();
    } else {
        ap_phi_mux_data_449_V_read724_phi_phi_fu_22886_p4 = ap_phi_reg_pp0_iter1_data_449_V_read724_phi_reg_22882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_449_V_read724_rewind_phi_fu_12794_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_449_V_read724_rewind_phi_fu_12794_p6 = data_449_V_read724_phi_reg_22882.read();
    } else {
        ap_phi_mux_data_449_V_read724_rewind_phi_fu_12794_p6 = data_449_V_read724_rewind_reg_12790.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_44_V_read319_phi_phi_fu_18026_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_44_V_read319_phi_phi_fu_18026_p4 = ap_phi_mux_data_44_V_read319_rewind_phi_fu_7124_p6.read();
    } else {
        ap_phi_mux_data_44_V_read319_phi_phi_fu_18026_p4 = ap_phi_reg_pp0_iter1_data_44_V_read319_phi_reg_18022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_44_V_read319_rewind_phi_fu_7124_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_44_V_read319_rewind_phi_fu_7124_p6 = data_44_V_read319_phi_reg_18022.read();
    } else {
        ap_phi_mux_data_44_V_read319_rewind_phi_fu_7124_p6 = data_44_V_read319_rewind_reg_7120.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_450_V_read725_phi_phi_fu_22898_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_450_V_read725_phi_phi_fu_22898_p4 = ap_phi_mux_data_450_V_read725_rewind_phi_fu_12808_p6.read();
    } else {
        ap_phi_mux_data_450_V_read725_phi_phi_fu_22898_p4 = ap_phi_reg_pp0_iter1_data_450_V_read725_phi_reg_22894.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_450_V_read725_rewind_phi_fu_12808_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_450_V_read725_rewind_phi_fu_12808_p6 = data_450_V_read725_phi_reg_22894.read();
    } else {
        ap_phi_mux_data_450_V_read725_rewind_phi_fu_12808_p6 = data_450_V_read725_rewind_reg_12804.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_451_V_read726_phi_phi_fu_22910_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_451_V_read726_phi_phi_fu_22910_p4 = ap_phi_mux_data_451_V_read726_rewind_phi_fu_12822_p6.read();
    } else {
        ap_phi_mux_data_451_V_read726_phi_phi_fu_22910_p4 = ap_phi_reg_pp0_iter1_data_451_V_read726_phi_reg_22906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_451_V_read726_rewind_phi_fu_12822_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_451_V_read726_rewind_phi_fu_12822_p6 = data_451_V_read726_phi_reg_22906.read();
    } else {
        ap_phi_mux_data_451_V_read726_rewind_phi_fu_12822_p6 = data_451_V_read726_rewind_reg_12818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_452_V_read727_phi_phi_fu_22922_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_452_V_read727_phi_phi_fu_22922_p4 = ap_phi_mux_data_452_V_read727_rewind_phi_fu_12836_p6.read();
    } else {
        ap_phi_mux_data_452_V_read727_phi_phi_fu_22922_p4 = ap_phi_reg_pp0_iter1_data_452_V_read727_phi_reg_22918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_452_V_read727_rewind_phi_fu_12836_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_452_V_read727_rewind_phi_fu_12836_p6 = data_452_V_read727_phi_reg_22918.read();
    } else {
        ap_phi_mux_data_452_V_read727_rewind_phi_fu_12836_p6 = data_452_V_read727_rewind_reg_12832.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_453_V_read728_phi_phi_fu_22934_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_453_V_read728_phi_phi_fu_22934_p4 = ap_phi_mux_data_453_V_read728_rewind_phi_fu_12850_p6.read();
    } else {
        ap_phi_mux_data_453_V_read728_phi_phi_fu_22934_p4 = ap_phi_reg_pp0_iter1_data_453_V_read728_phi_reg_22930.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_453_V_read728_rewind_phi_fu_12850_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_453_V_read728_rewind_phi_fu_12850_p6 = data_453_V_read728_phi_reg_22930.read();
    } else {
        ap_phi_mux_data_453_V_read728_rewind_phi_fu_12850_p6 = data_453_V_read728_rewind_reg_12846.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_454_V_read729_phi_phi_fu_22946_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_454_V_read729_phi_phi_fu_22946_p4 = ap_phi_mux_data_454_V_read729_rewind_phi_fu_12864_p6.read();
    } else {
        ap_phi_mux_data_454_V_read729_phi_phi_fu_22946_p4 = ap_phi_reg_pp0_iter1_data_454_V_read729_phi_reg_22942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_454_V_read729_rewind_phi_fu_12864_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_454_V_read729_rewind_phi_fu_12864_p6 = data_454_V_read729_phi_reg_22942.read();
    } else {
        ap_phi_mux_data_454_V_read729_rewind_phi_fu_12864_p6 = data_454_V_read729_rewind_reg_12860.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_455_V_read730_phi_phi_fu_22958_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_455_V_read730_phi_phi_fu_22958_p4 = ap_phi_mux_data_455_V_read730_rewind_phi_fu_12878_p6.read();
    } else {
        ap_phi_mux_data_455_V_read730_phi_phi_fu_22958_p4 = ap_phi_reg_pp0_iter1_data_455_V_read730_phi_reg_22954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_455_V_read730_rewind_phi_fu_12878_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_455_V_read730_rewind_phi_fu_12878_p6 = data_455_V_read730_phi_reg_22954.read();
    } else {
        ap_phi_mux_data_455_V_read730_rewind_phi_fu_12878_p6 = data_455_V_read730_rewind_reg_12874.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_456_V_read731_phi_phi_fu_22970_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_456_V_read731_phi_phi_fu_22970_p4 = ap_phi_mux_data_456_V_read731_rewind_phi_fu_12892_p6.read();
    } else {
        ap_phi_mux_data_456_V_read731_phi_phi_fu_22970_p4 = ap_phi_reg_pp0_iter1_data_456_V_read731_phi_reg_22966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_456_V_read731_rewind_phi_fu_12892_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_456_V_read731_rewind_phi_fu_12892_p6 = data_456_V_read731_phi_reg_22966.read();
    } else {
        ap_phi_mux_data_456_V_read731_rewind_phi_fu_12892_p6 = data_456_V_read731_rewind_reg_12888.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_457_V_read732_phi_phi_fu_22982_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_457_V_read732_phi_phi_fu_22982_p4 = ap_phi_mux_data_457_V_read732_rewind_phi_fu_12906_p6.read();
    } else {
        ap_phi_mux_data_457_V_read732_phi_phi_fu_22982_p4 = ap_phi_reg_pp0_iter1_data_457_V_read732_phi_reg_22978.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_457_V_read732_rewind_phi_fu_12906_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_457_V_read732_rewind_phi_fu_12906_p6 = data_457_V_read732_phi_reg_22978.read();
    } else {
        ap_phi_mux_data_457_V_read732_rewind_phi_fu_12906_p6 = data_457_V_read732_rewind_reg_12902.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_458_V_read733_phi_phi_fu_22994_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_458_V_read733_phi_phi_fu_22994_p4 = ap_phi_mux_data_458_V_read733_rewind_phi_fu_12920_p6.read();
    } else {
        ap_phi_mux_data_458_V_read733_phi_phi_fu_22994_p4 = ap_phi_reg_pp0_iter1_data_458_V_read733_phi_reg_22990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_458_V_read733_rewind_phi_fu_12920_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_458_V_read733_rewind_phi_fu_12920_p6 = data_458_V_read733_phi_reg_22990.read();
    } else {
        ap_phi_mux_data_458_V_read733_rewind_phi_fu_12920_p6 = data_458_V_read733_rewind_reg_12916.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_459_V_read734_phi_phi_fu_23006_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_459_V_read734_phi_phi_fu_23006_p4 = ap_phi_mux_data_459_V_read734_rewind_phi_fu_12934_p6.read();
    } else {
        ap_phi_mux_data_459_V_read734_phi_phi_fu_23006_p4 = ap_phi_reg_pp0_iter1_data_459_V_read734_phi_reg_23002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_459_V_read734_rewind_phi_fu_12934_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_459_V_read734_rewind_phi_fu_12934_p6 = data_459_V_read734_phi_reg_23002.read();
    } else {
        ap_phi_mux_data_459_V_read734_rewind_phi_fu_12934_p6 = data_459_V_read734_rewind_reg_12930.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_45_V_read320_phi_phi_fu_18038_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_45_V_read320_phi_phi_fu_18038_p4 = ap_phi_mux_data_45_V_read320_rewind_phi_fu_7138_p6.read();
    } else {
        ap_phi_mux_data_45_V_read320_phi_phi_fu_18038_p4 = ap_phi_reg_pp0_iter1_data_45_V_read320_phi_reg_18034.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_45_V_read320_rewind_phi_fu_7138_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_45_V_read320_rewind_phi_fu_7138_p6 = data_45_V_read320_phi_reg_18034.read();
    } else {
        ap_phi_mux_data_45_V_read320_rewind_phi_fu_7138_p6 = data_45_V_read320_rewind_reg_7134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_460_V_read735_phi_phi_fu_23018_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_460_V_read735_phi_phi_fu_23018_p4 = ap_phi_mux_data_460_V_read735_rewind_phi_fu_12948_p6.read();
    } else {
        ap_phi_mux_data_460_V_read735_phi_phi_fu_23018_p4 = ap_phi_reg_pp0_iter1_data_460_V_read735_phi_reg_23014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_460_V_read735_rewind_phi_fu_12948_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_460_V_read735_rewind_phi_fu_12948_p6 = data_460_V_read735_phi_reg_23014.read();
    } else {
        ap_phi_mux_data_460_V_read735_rewind_phi_fu_12948_p6 = data_460_V_read735_rewind_reg_12944.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_461_V_read736_phi_phi_fu_23030_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_461_V_read736_phi_phi_fu_23030_p4 = ap_phi_mux_data_461_V_read736_rewind_phi_fu_12962_p6.read();
    } else {
        ap_phi_mux_data_461_V_read736_phi_phi_fu_23030_p4 = ap_phi_reg_pp0_iter1_data_461_V_read736_phi_reg_23026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_461_V_read736_rewind_phi_fu_12962_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_461_V_read736_rewind_phi_fu_12962_p6 = data_461_V_read736_phi_reg_23026.read();
    } else {
        ap_phi_mux_data_461_V_read736_rewind_phi_fu_12962_p6 = data_461_V_read736_rewind_reg_12958.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_462_V_read737_phi_phi_fu_23042_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_462_V_read737_phi_phi_fu_23042_p4 = ap_phi_mux_data_462_V_read737_rewind_phi_fu_12976_p6.read();
    } else {
        ap_phi_mux_data_462_V_read737_phi_phi_fu_23042_p4 = ap_phi_reg_pp0_iter1_data_462_V_read737_phi_reg_23038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_462_V_read737_rewind_phi_fu_12976_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_462_V_read737_rewind_phi_fu_12976_p6 = data_462_V_read737_phi_reg_23038.read();
    } else {
        ap_phi_mux_data_462_V_read737_rewind_phi_fu_12976_p6 = data_462_V_read737_rewind_reg_12972.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_463_V_read738_phi_phi_fu_23054_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_463_V_read738_phi_phi_fu_23054_p4 = ap_phi_mux_data_463_V_read738_rewind_phi_fu_12990_p6.read();
    } else {
        ap_phi_mux_data_463_V_read738_phi_phi_fu_23054_p4 = ap_phi_reg_pp0_iter1_data_463_V_read738_phi_reg_23050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_463_V_read738_rewind_phi_fu_12990_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_463_V_read738_rewind_phi_fu_12990_p6 = data_463_V_read738_phi_reg_23050.read();
    } else {
        ap_phi_mux_data_463_V_read738_rewind_phi_fu_12990_p6 = data_463_V_read738_rewind_reg_12986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_464_V_read739_phi_phi_fu_23066_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_464_V_read739_phi_phi_fu_23066_p4 = ap_phi_mux_data_464_V_read739_rewind_phi_fu_13004_p6.read();
    } else {
        ap_phi_mux_data_464_V_read739_phi_phi_fu_23066_p4 = ap_phi_reg_pp0_iter1_data_464_V_read739_phi_reg_23062.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_464_V_read739_rewind_phi_fu_13004_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_464_V_read739_rewind_phi_fu_13004_p6 = data_464_V_read739_phi_reg_23062.read();
    } else {
        ap_phi_mux_data_464_V_read739_rewind_phi_fu_13004_p6 = data_464_V_read739_rewind_reg_13000.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_465_V_read740_phi_phi_fu_23078_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_465_V_read740_phi_phi_fu_23078_p4 = ap_phi_mux_data_465_V_read740_rewind_phi_fu_13018_p6.read();
    } else {
        ap_phi_mux_data_465_V_read740_phi_phi_fu_23078_p4 = ap_phi_reg_pp0_iter1_data_465_V_read740_phi_reg_23074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_465_V_read740_rewind_phi_fu_13018_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_465_V_read740_rewind_phi_fu_13018_p6 = data_465_V_read740_phi_reg_23074.read();
    } else {
        ap_phi_mux_data_465_V_read740_rewind_phi_fu_13018_p6 = data_465_V_read740_rewind_reg_13014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_466_V_read741_phi_phi_fu_23090_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_466_V_read741_phi_phi_fu_23090_p4 = ap_phi_mux_data_466_V_read741_rewind_phi_fu_13032_p6.read();
    } else {
        ap_phi_mux_data_466_V_read741_phi_phi_fu_23090_p4 = ap_phi_reg_pp0_iter1_data_466_V_read741_phi_reg_23086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_466_V_read741_rewind_phi_fu_13032_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_466_V_read741_rewind_phi_fu_13032_p6 = data_466_V_read741_phi_reg_23086.read();
    } else {
        ap_phi_mux_data_466_V_read741_rewind_phi_fu_13032_p6 = data_466_V_read741_rewind_reg_13028.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_467_V_read742_phi_phi_fu_23102_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_467_V_read742_phi_phi_fu_23102_p4 = ap_phi_mux_data_467_V_read742_rewind_phi_fu_13046_p6.read();
    } else {
        ap_phi_mux_data_467_V_read742_phi_phi_fu_23102_p4 = ap_phi_reg_pp0_iter1_data_467_V_read742_phi_reg_23098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_467_V_read742_rewind_phi_fu_13046_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_467_V_read742_rewind_phi_fu_13046_p6 = data_467_V_read742_phi_reg_23098.read();
    } else {
        ap_phi_mux_data_467_V_read742_rewind_phi_fu_13046_p6 = data_467_V_read742_rewind_reg_13042.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_468_V_read743_phi_phi_fu_23114_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_468_V_read743_phi_phi_fu_23114_p4 = ap_phi_mux_data_468_V_read743_rewind_phi_fu_13060_p6.read();
    } else {
        ap_phi_mux_data_468_V_read743_phi_phi_fu_23114_p4 = ap_phi_reg_pp0_iter1_data_468_V_read743_phi_reg_23110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_468_V_read743_rewind_phi_fu_13060_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_468_V_read743_rewind_phi_fu_13060_p6 = data_468_V_read743_phi_reg_23110.read();
    } else {
        ap_phi_mux_data_468_V_read743_rewind_phi_fu_13060_p6 = data_468_V_read743_rewind_reg_13056.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_469_V_read744_phi_phi_fu_23126_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_469_V_read744_phi_phi_fu_23126_p4 = ap_phi_mux_data_469_V_read744_rewind_phi_fu_13074_p6.read();
    } else {
        ap_phi_mux_data_469_V_read744_phi_phi_fu_23126_p4 = ap_phi_reg_pp0_iter1_data_469_V_read744_phi_reg_23122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_469_V_read744_rewind_phi_fu_13074_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_469_V_read744_rewind_phi_fu_13074_p6 = data_469_V_read744_phi_reg_23122.read();
    } else {
        ap_phi_mux_data_469_V_read744_rewind_phi_fu_13074_p6 = data_469_V_read744_rewind_reg_13070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_46_V_read321_phi_phi_fu_18050_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_46_V_read321_phi_phi_fu_18050_p4 = ap_phi_mux_data_46_V_read321_rewind_phi_fu_7152_p6.read();
    } else {
        ap_phi_mux_data_46_V_read321_phi_phi_fu_18050_p4 = ap_phi_reg_pp0_iter1_data_46_V_read321_phi_reg_18046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_46_V_read321_rewind_phi_fu_7152_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_46_V_read321_rewind_phi_fu_7152_p6 = data_46_V_read321_phi_reg_18046.read();
    } else {
        ap_phi_mux_data_46_V_read321_rewind_phi_fu_7152_p6 = data_46_V_read321_rewind_reg_7148.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_470_V_read745_phi_phi_fu_23138_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_470_V_read745_phi_phi_fu_23138_p4 = ap_phi_mux_data_470_V_read745_rewind_phi_fu_13088_p6.read();
    } else {
        ap_phi_mux_data_470_V_read745_phi_phi_fu_23138_p4 = ap_phi_reg_pp0_iter1_data_470_V_read745_phi_reg_23134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_470_V_read745_rewind_phi_fu_13088_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_470_V_read745_rewind_phi_fu_13088_p6 = data_470_V_read745_phi_reg_23134.read();
    } else {
        ap_phi_mux_data_470_V_read745_rewind_phi_fu_13088_p6 = data_470_V_read745_rewind_reg_13084.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_471_V_read746_phi_phi_fu_23150_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_471_V_read746_phi_phi_fu_23150_p4 = ap_phi_mux_data_471_V_read746_rewind_phi_fu_13102_p6.read();
    } else {
        ap_phi_mux_data_471_V_read746_phi_phi_fu_23150_p4 = ap_phi_reg_pp0_iter1_data_471_V_read746_phi_reg_23146.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_471_V_read746_rewind_phi_fu_13102_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_471_V_read746_rewind_phi_fu_13102_p6 = data_471_V_read746_phi_reg_23146.read();
    } else {
        ap_phi_mux_data_471_V_read746_rewind_phi_fu_13102_p6 = data_471_V_read746_rewind_reg_13098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_472_V_read747_phi_phi_fu_23162_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_472_V_read747_phi_phi_fu_23162_p4 = ap_phi_mux_data_472_V_read747_rewind_phi_fu_13116_p6.read();
    } else {
        ap_phi_mux_data_472_V_read747_phi_phi_fu_23162_p4 = ap_phi_reg_pp0_iter1_data_472_V_read747_phi_reg_23158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_472_V_read747_rewind_phi_fu_13116_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_472_V_read747_rewind_phi_fu_13116_p6 = data_472_V_read747_phi_reg_23158.read();
    } else {
        ap_phi_mux_data_472_V_read747_rewind_phi_fu_13116_p6 = data_472_V_read747_rewind_reg_13112.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_473_V_read748_phi_phi_fu_23174_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_473_V_read748_phi_phi_fu_23174_p4 = ap_phi_mux_data_473_V_read748_rewind_phi_fu_13130_p6.read();
    } else {
        ap_phi_mux_data_473_V_read748_phi_phi_fu_23174_p4 = ap_phi_reg_pp0_iter1_data_473_V_read748_phi_reg_23170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_473_V_read748_rewind_phi_fu_13130_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_473_V_read748_rewind_phi_fu_13130_p6 = data_473_V_read748_phi_reg_23170.read();
    } else {
        ap_phi_mux_data_473_V_read748_rewind_phi_fu_13130_p6 = data_473_V_read748_rewind_reg_13126.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_474_V_read749_phi_phi_fu_23186_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_474_V_read749_phi_phi_fu_23186_p4 = ap_phi_mux_data_474_V_read749_rewind_phi_fu_13144_p6.read();
    } else {
        ap_phi_mux_data_474_V_read749_phi_phi_fu_23186_p4 = ap_phi_reg_pp0_iter1_data_474_V_read749_phi_reg_23182.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_474_V_read749_rewind_phi_fu_13144_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_474_V_read749_rewind_phi_fu_13144_p6 = data_474_V_read749_phi_reg_23182.read();
    } else {
        ap_phi_mux_data_474_V_read749_rewind_phi_fu_13144_p6 = data_474_V_read749_rewind_reg_13140.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_475_V_read750_phi_phi_fu_23198_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_475_V_read750_phi_phi_fu_23198_p4 = ap_phi_mux_data_475_V_read750_rewind_phi_fu_13158_p6.read();
    } else {
        ap_phi_mux_data_475_V_read750_phi_phi_fu_23198_p4 = ap_phi_reg_pp0_iter1_data_475_V_read750_phi_reg_23194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_475_V_read750_rewind_phi_fu_13158_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_475_V_read750_rewind_phi_fu_13158_p6 = data_475_V_read750_phi_reg_23194.read();
    } else {
        ap_phi_mux_data_475_V_read750_rewind_phi_fu_13158_p6 = data_475_V_read750_rewind_reg_13154.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_476_V_read751_phi_phi_fu_23210_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_476_V_read751_phi_phi_fu_23210_p4 = ap_phi_mux_data_476_V_read751_rewind_phi_fu_13172_p6.read();
    } else {
        ap_phi_mux_data_476_V_read751_phi_phi_fu_23210_p4 = ap_phi_reg_pp0_iter1_data_476_V_read751_phi_reg_23206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_476_V_read751_rewind_phi_fu_13172_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_476_V_read751_rewind_phi_fu_13172_p6 = data_476_V_read751_phi_reg_23206.read();
    } else {
        ap_phi_mux_data_476_V_read751_rewind_phi_fu_13172_p6 = data_476_V_read751_rewind_reg_13168.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_477_V_read752_phi_phi_fu_23222_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_477_V_read752_phi_phi_fu_23222_p4 = ap_phi_mux_data_477_V_read752_rewind_phi_fu_13186_p6.read();
    } else {
        ap_phi_mux_data_477_V_read752_phi_phi_fu_23222_p4 = ap_phi_reg_pp0_iter1_data_477_V_read752_phi_reg_23218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_477_V_read752_rewind_phi_fu_13186_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_477_V_read752_rewind_phi_fu_13186_p6 = data_477_V_read752_phi_reg_23218.read();
    } else {
        ap_phi_mux_data_477_V_read752_rewind_phi_fu_13186_p6 = data_477_V_read752_rewind_reg_13182.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_478_V_read753_phi_phi_fu_23234_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_478_V_read753_phi_phi_fu_23234_p4 = ap_phi_mux_data_478_V_read753_rewind_phi_fu_13200_p6.read();
    } else {
        ap_phi_mux_data_478_V_read753_phi_phi_fu_23234_p4 = ap_phi_reg_pp0_iter1_data_478_V_read753_phi_reg_23230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_478_V_read753_rewind_phi_fu_13200_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_478_V_read753_rewind_phi_fu_13200_p6 = data_478_V_read753_phi_reg_23230.read();
    } else {
        ap_phi_mux_data_478_V_read753_rewind_phi_fu_13200_p6 = data_478_V_read753_rewind_reg_13196.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_479_V_read754_phi_phi_fu_23246_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_479_V_read754_phi_phi_fu_23246_p4 = ap_phi_mux_data_479_V_read754_rewind_phi_fu_13214_p6.read();
    } else {
        ap_phi_mux_data_479_V_read754_phi_phi_fu_23246_p4 = ap_phi_reg_pp0_iter1_data_479_V_read754_phi_reg_23242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_479_V_read754_rewind_phi_fu_13214_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_479_V_read754_rewind_phi_fu_13214_p6 = data_479_V_read754_phi_reg_23242.read();
    } else {
        ap_phi_mux_data_479_V_read754_rewind_phi_fu_13214_p6 = data_479_V_read754_rewind_reg_13210.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_47_V_read322_phi_phi_fu_18062_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_47_V_read322_phi_phi_fu_18062_p4 = ap_phi_mux_data_47_V_read322_rewind_phi_fu_7166_p6.read();
    } else {
        ap_phi_mux_data_47_V_read322_phi_phi_fu_18062_p4 = ap_phi_reg_pp0_iter1_data_47_V_read322_phi_reg_18058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_47_V_read322_rewind_phi_fu_7166_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_47_V_read322_rewind_phi_fu_7166_p6 = data_47_V_read322_phi_reg_18058.read();
    } else {
        ap_phi_mux_data_47_V_read322_rewind_phi_fu_7166_p6 = data_47_V_read322_rewind_reg_7162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_480_V_read755_phi_phi_fu_23258_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6474.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_480_V_read755_phi_phi_fu_23258_p4 = ap_phi_mux_data_480_V_read755_rewind_phi_fu_13228_p6.read();
    } else {
        ap_phi_mux_data_480_V_read755_phi_phi_fu_23258_p4 = ap_phi_reg_pp0_iter1_data_480_V_read755_phi_reg_23254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_7_5_3_0_config3_s::thread_ap_phi_mux_data_480_V_read755_rewind_phi_fu_13228_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln151_reg_44207_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_480_V_read755_rewind_phi_fu_13228_p6 = data_480_V_read755_phi_reg_23254.read();
    } else {
        ap_phi_mux_data_480_V_read755_rewind_phi_fu_13228_p6 = data_480_V_read755_rewind_reg_13224.read();
    }
}

}

